/*    */ package de.cuuky.varo.gui.team;
/*    */ 
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TeamChooseGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public TeamChooseGUI(Player opener) {
/* 17 */     super("§3Choose Category", opener, 9, false);
/*    */     
/* 19 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 24 */     if (this.opener.hasPermission("varo.admin"))
/*    */     {
/* 26 */       return true;
/*    */     }
/*    */     
/* 29 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 43 */     int i = 1; byte b; int j; TeamListGUI.TeamGUIType[] arrayOfTeamGUIType;
/* 44 */     for (j = (arrayOfTeamGUIType = TeamListGUI.TeamGUIType.values()).length, b = 0; b < j; ) { final TeamListGUI.TeamGUIType type = arrayOfTeamGUIType[b];
/* 45 */       linkItemTo(i, (new ItemBuilder()).displayname(type.getTypeName()).itemstack(new ItemStack(type.getIcon())).amount(getFixedSize(type.getList().size())).build(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */ 
/*    */       
/* 52 */       i += 2;
/*    */       b++; }
/*    */     
/* 55 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\team\TeamChooseGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */