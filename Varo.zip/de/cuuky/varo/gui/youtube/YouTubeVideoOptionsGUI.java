/*    */ package de.cuuky.varo.gui.youtube;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.stats.stat.YouTubeVideo;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class YouTubeVideoOptionsGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private YouTubeVideo video;
/*    */   
/*    */   public YouTubeVideoOptionsGUI(Player opener, YouTubeVideo video) {
/* 20 */     super("§5" + video.getVideoId(), opener, 9, false);
/*    */     
/* 22 */     this.video = video;
/*    */     
/* 24 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 29 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 43 */     linkItemTo(1, (new ItemBuilder()).displayname("§aOpen").itemstack(new ItemStack(Material.PAPER)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 47 */             YouTubeVideoOptionsGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Link:");
/* 48 */             YouTubeVideoOptionsGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + YouTubeVideoOptionsGUI.this.video.getLink());
/*    */           }
/*    */         });
/*    */     
/* 52 */     linkItemTo(8, (new ItemBuilder()).displayname("§cRemove").itemstack(new ItemStack(Material.REDSTONE)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 56 */             YouTubeVideoOptionsGUI.this.video.remove();
/*    */           }
/*    */         });
/*    */ 
/*    */     
/* 61 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\youtube\YouTubeVideoOptionsGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */