/*    */ package de.cuuky.varo.gui.admin.varoevents;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.event.VaroEvent;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class VaroEventGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public VaroEventGUI(Player opener) {
/* 19 */     super("§5VaroEvents", opener, 9, false);
/*    */     
/* 21 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 26 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {
/* 31 */     updateInventory();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 44 */     int i = 0;
/* 45 */     for (VaroEvent event : VaroEvent.getEvents()) {
/* 46 */       linkItemTo(i, (new ItemBuilder()).displayname(event.getEventType().getName()).itemstack(new ItemStack(event.getIcon())).lore(JavaUtils.combineArrays(new String[][] { { "§7Enabled: " + (event.isEnabled() ? "§a" : "§c") + event.isEnabled(), "" }, , JavaUtils.addIntoEvery(event.getDescription().split("\n"), "§7", true) })).build(), new Runnable()
/*    */           {
/*    */             public void run()
/*    */             {
/* 50 */               if (Main.getVaroGame().getGameState() != GameState.STARTED) {
/* 51 */                 VaroEventGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Spiel wurde noch nicht gestartet!");
/*    */                 
/*    */                 return;
/*    */               } 
/* 55 */               event.setEnabled(!event.isEnabled());
/*    */             }
/*    */           });
/*    */       
/* 59 */       i += 2;
/*    */     } 
/*    */     
/* 62 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\varoevents\VaroEventGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */