/*    */ package de.cuuky.varo.gui.admin.config;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSettingSection;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class ConfigSectionGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public ConfigSectionGUI(Player opener) {
/* 19 */     super("§aConfig-Section", opener, JavaUtils.getNextToNine((ConfigSettingSection.values()).length), false);
/*    */     
/* 21 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 27 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 41 */     int i = -1; byte b; int j; ConfigSettingSection[] arrayOfConfigSettingSection;
/* 42 */     for (j = (arrayOfConfigSettingSection = ConfigSettingSection.values()).length, b = 0; b < j; ) { final ConfigSettingSection section = arrayOfConfigSettingSection[b];
/* 43 */       i++;
/*    */       
/* 45 */       linkItemTo(i, (new ItemBuilder()).displayname("§7" + section.getName()).itemstack(new ItemStack(section.getMaterial())).lore(JavaUtils.getArgsToString(JavaUtils.addIntoEvery(section.getDescription().split("\n"), Main.getColorCode(), true), "\n").split("\n")).build(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */       
/*    */       b++; }
/*    */ 
/*    */     
/* 54 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\config\ConfigSectionGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */