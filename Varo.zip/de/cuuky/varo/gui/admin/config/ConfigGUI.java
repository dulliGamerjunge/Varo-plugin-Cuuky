/*     */ package de.cuuky.varo.gui.admin.config;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.SectionEntry;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSettingSection;
/*     */ import de.cuuky.varo.gui.SuperInventory;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.gui.utils.chat.ChatHookListener;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import de.cuuky.varo.version.types.Sounds;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigGUI
/*     */   extends SuperInventory
/*     */ {
/*     */   private ConfigSettingSection section;
/*     */   
/*     */   public ConfigGUI(Player opener, ConfigSettingSection section) {
/*  28 */     super("§a" + section.getName(), opener, JavaUtils.getNextToNine(section.getEntries().size() + 1), false);
/*     */     
/*  30 */     this.section = section;
/*     */     
/*  32 */     open();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void hookChat(ConfigSetting entry) {
/*  59 */     this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7Gib zum Abbruch §ccancel§7 ein.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBackClick() {
/*  65 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(InventoryClickEvent event) {}
/*     */ 
/*     */   
/*     */   public void onClose(InventoryCloseEvent event) {}
/*     */ 
/*     */   
/*     */   public void onInventoryAction(PageAction action) {}
/*     */ 
/*     */   
/*     */   public boolean onOpen() {
/*  79 */     int i = -1;
/*  80 */     for (SectionEntry sentry : this.section.getEntries()) {
/*  81 */       final ConfigSetting entry = (ConfigSetting)sentry;
/*  82 */       i++;
/*  83 */       ArrayList<String> lore = new ArrayList<>(); byte b; int j; String[] arrayOfString;
/*  84 */       for (j = (arrayOfString = entry.getDescription()).length, b = 0; b < j; ) { String strin = arrayOfString[b];
/*  85 */         lore.add(String.valueOf(Main.getColorCode()) + strin); b++; }
/*     */       
/*  87 */       lore.add(" ");
/*  88 */       lore.add("Value: " + entry.getValue());
/*     */       
/*  90 */       linkItemTo(i, (new ItemBuilder()).displayname("§7" + entry.getPath()).itemstack(new ItemStack(Materials.SIGN.parseMaterial())).lore(lore).build(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/*  94 */               ConfigGUI.this.close(false);
/*  95 */               ConfigGUI.this.hookChat(entry);
/*     */             }
/*     */           });
/*     */     } 
/*     */     
/* 100 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\config\ConfigGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */