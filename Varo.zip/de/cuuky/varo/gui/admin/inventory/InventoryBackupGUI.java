/*    */ package de.cuuky.varo.gui.admin.inventory;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class InventoryBackupGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private InventoryBackup backup;
/*    */   
/*    */   public InventoryBackupGUI(Player opener, InventoryBackup backup) {
/* 21 */     super("§b" + backup.getVaroPlayer().getName(), opener, 9, false);
/*    */     
/* 23 */     this.backup = backup;
/*    */     
/* 25 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 31 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 45 */     linkItemTo(1, (new ItemBuilder()).displayname("§aShow").itemstack(new ItemStack(Material.CHEST)).build(), new Runnable()
/*    */         {
/*    */           public void run() {}
/*    */         });
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 53 */     linkItemTo(4, (new ItemBuilder()).displayname("§2Restore").itemstack(new ItemStack(Material.EMERALD)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 57 */             if (!InventoryBackupGUI.this.backup.getVaroPlayer().isOnline()) {
/* 58 */               InventoryBackupGUI.this.backup.getVaroPlayer().getStats().setRestoreBackup(InventoryBackupGUI.this.backup);
/* 59 */               InventoryBackupGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Inventar wird beim naechsten Betreten wiederhergestellt!");
/*    */               
/*    */               return;
/*    */             } 
/* 63 */             InventoryBackupGUI.this.backup.restoreUpdate(InventoryBackupGUI.this.backup.getVaroPlayer().getPlayer());
/* 64 */             InventoryBackupGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Inventar wurde wiederhergestellt!");
/*    */           }
/*    */         });
/*    */     
/* 68 */     linkItemTo(7, (new ItemBuilder()).displayname("§cRemove").itemstack(Materials.REDSTONE.parseItem()).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 72 */             InventoryBackupGUI.this.backup.getVaroPlayer().getStats().removeInventoryBackup(InventoryBackupGUI.this.backup);
/*    */           }
/*    */         });
/*    */ 
/*    */     
/* 77 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\inventory\InventoryBackupGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */