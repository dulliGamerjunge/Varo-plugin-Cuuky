/*    */ package de.cuuky.varo.gui.admin.debug;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.gui.utils.chat.ChatHookListener;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ import de.cuuky.varo.utils.varo.LocationFormat;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public DebugGUI(Player opener) {
/* 24 */     super("§6DEBUG", opener, 18, false);
/*    */     
/* 26 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 32 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 46 */     linkItemTo(1, (new ItemBuilder()).displayname("§cTrigger Event").itemstack(new ItemStack(Materials.SIGN.parseMaterial())).lore(new String[] { "§7Fuehrt ein Event aus, um den DiscordBot,", "TelegramBot, Config etc. zu testen" }, ).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 50 */             DebugGUI.this.close(false);
/*    */           }
/*    */         });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 64 */     linkItemTo(4, (new ItemBuilder()).displayname("§cDo daily timer").itemstack(new ItemStack(Material.DAYLIGHT_DETECTOR)).lore(new String[] { "§7Fuehrt die Dinge aus, die sonst immer", "§7Nachts ausgefuehrt werden, wie Sessionreset" }, ).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 68 */             Main.getDataManager().getDailyTimer().doDailyChecks();
/* 69 */             DebugGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§aErfolgreich!");
/*    */           }
/*    */         });
/*    */     
/* 73 */     linkItemTo(7, (new ItemBuilder()).displayname("§cTrigger Coordpost").itemstack(new ItemStack(Material.ANVIL)).amount(1).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 77 */             String post = "";
/* 78 */             for (VaroPlayer vp : VaroPlayer.getAlivePlayer()) {
/* 79 */               post = String.valueOf(post) + (post.isEmpty() ? "Liste der Koordinaten aller Spieler:\n\n" : "\n") + vp.getName() + ((vp.getTeam() != null) ? (" (#" + vp.getTeam().getName() + ")") : "") + ": " + ((vp.getStats().getLastLocation() != null) ? (new LocationFormat(vp.getStats().getLastLocation())).format("X:x Y:y Z:z in world") : "/");
/*    */             }
/* 81 */             Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, post);
/*    */           }
/*    */         });
/*    */     
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\debug\DebugGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */