/*    */ package de.cuuky.varo.gui.admin.discordbot;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class DiscordBotGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public DiscordBotGUI(Player opener) {
/* 19 */     super("§2DiscordBot", opener, 9, false);
/*    */     
/* 21 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 27 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {
/* 32 */     updateInventory();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 44 */     linkItemTo(1, (new ItemBuilder()).displayname(Main.getBotLauncher().getDiscordbot().isEnabled() ? "§cShutdown" : "§aStart").itemstack(new ItemStack(Main.getBotLauncher().getDiscordbot().isEnabled() ? Material.REDSTONE : Material.EMERALD)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 48 */             boolean enabled = Main.getBotLauncher().getDiscordbot().isEnabled();
/* 49 */             if (enabled) {
/* 50 */               Main.getBotLauncher().getDiscordbot().disconnect();
/*    */             } else {
/* 52 */               Main.getBotLauncher().getDiscordbot().connect();
/*    */             } 
/* 54 */             if (Main.getBotLauncher().getDiscordbot().isEnabled() == enabled) {
/* 55 */               DiscordBotGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7Could not start DiscordBot.");
/*    */             } else {
/* 57 */               DiscordBotGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7Erfolg!");
/*    */             } 
/*    */           }
/*    */         });
/* 61 */     linkItemTo(7, (new ItemBuilder()).displayname("§eBotRegister").itemstack(new ItemStack(Material.BOOK)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 65 */             if (Main.getBotLauncher().getDiscordbot().isEnabled() || !ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/* 66 */               DiscordBotGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Das System ist nicht aktiviert!");
/*    */               
/*    */               return;
/*    */             } 
/*    */           }
/*    */         });
/* 72 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\discordbot\DiscordBotGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */