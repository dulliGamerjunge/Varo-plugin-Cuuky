/*    */ package de.cuuky.varo.gui.admin.discordbot.botregister;
/*    */ 
/*    */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class BotRegisterGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private BotRegister register;
/*    */   
/*    */   public BotRegisterGUI(Player opener, BotRegister register) {
/* 19 */     super("§7BotRegister: §a" + register.getPlayerName(), opener, 9, false);
/*    */     
/* 21 */     this.register = register;
/* 22 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 28 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 42 */     linkItemTo(1, (new ItemBuilder()).displayname("§4Delete").itemstack(new ItemStack(Material.REDSTONE)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 46 */             BotRegisterGUI.this.register.delete();
/*    */           }
/*    */         });
/*    */     
/* 50 */     linkItemTo(4, (new ItemBuilder()).displayname("§cUnregister").itemstack(new ItemStack(Material.COAL)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 54 */             BotRegisterGUI.this.register.setUserId(-1L);
/*    */           }
/*    */         });
/*    */     
/* 58 */     linkItemTo(7, (new ItemBuilder()).displayname(String.valueOf(this.register.isBypass() ? "§cRemove" : "§aAllow") + " §7Bypass").itemstack(new ItemStack(this.register.isBypass() ? Material.ANVIL : Material.EMERALD)).build(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 62 */             BotRegisterGUI.this.register.setBypass(!BotRegisterGUI.this.register.isBypass());
/*    */           }
/*    */         });
/* 65 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\discordbot\botregister\BotRegisterGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */