/*     */ package de.cuuky.varo.gui.admin.alert;
/*     */ 
/*     */ import de.cuuky.varo.alert.Alert;
/*     */ import de.cuuky.varo.gui.SuperInventory;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class AlertChooseGUI
/*     */   extends SuperInventory {
/*     */   private AlertGUIType type;
/*     */   
/*     */   public enum AlertGUIType {
/*  22 */     ALL("§fALL", Material.BOOK),
/*  23 */     CLOSED("§4CLOSED", Materials.SKELETON_SKULL.parseMaterial()),
/*  24 */     OPEN("§eOPENED", Material.EMERALD);
/*     */     
/*     */     private Material icon;
/*     */     private String typeName;
/*     */     
/*     */     AlertGUIType(String typeName, Material icon) {
/*  30 */       this.typeName = typeName;
/*  31 */       this.icon = icon;
/*     */     }
/*     */     
/*     */     public Material getIcon() {
/*  35 */       return this.icon;
/*     */     }
/*     */     
/*     */     public ArrayList<Alert> getList() {
/*  39 */       switch (this) {
/*     */         case null:
/*  41 */           return Alert.getAlerts();
/*     */         case CLOSED:
/*  43 */           return Alert.getClosedAlerts();
/*     */         case OPEN:
/*  45 */           return Alert.getOpenAlerts();
/*     */       } 
/*     */       
/*  48 */       return null;
/*     */     }
/*     */     
/*     */     public String getTypeName() {
/*  52 */       return this.typeName; } public static AlertGUIType getType(String name) {
/*     */       byte b;
/*     */       int i;
/*     */       AlertGUIType[] arrayOfAlertGUIType;
/*  56 */       for (i = (arrayOfAlertGUIType = values()).length, b = 0; b < i; ) { AlertGUIType type = arrayOfAlertGUIType[b];
/*  57 */         if (type.getTypeName().equals(name))
/*  58 */           return type;  b++; }
/*     */       
/*  60 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AlertChooseGUI(Player opener, AlertGUIType type) {
/*  67 */     super("§4Alerts", opener, 45, false);
/*     */     
/*  69 */     this.type = type;
/*     */     
/*  71 */     open();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBackClick() {
/*  77 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(InventoryClickEvent event) {}
/*     */ 
/*     */   
/*     */   public void onClose(InventoryCloseEvent event) {}
/*     */ 
/*     */   
/*     */   public void onInventoryAction(PageAction action) {}
/*     */ 
/*     */   
/*     */   public boolean onOpen() {
/*  91 */     final ArrayList<Alert> alerts = this.type.getList();
/*  92 */     Collections.reverse(alerts);
/*     */     
/*  94 */     int start = getSize() * (getPage() - 1);
/*  95 */     if (start != 0) {
/*  96 */       start -= 2;
/*     */     }
/*  98 */     for (int i = 0; i != getSize() - 2; i++) {
/*     */       final Alert alert;
/*     */       try {
/* 101 */         alert = alerts.get(start);
/* 102 */       } catch (IndexOutOfBoundsException e) {
/*     */         break;
/*     */       } 
/*     */       
/* 106 */       linkItemTo(i, (new ItemBuilder()).displayname("§c" + alert.getType() + " §8| §7" + alert.getId()).itemstack(new ItemStack(Material.BOOK)).lore(new String[] { "§7Message: §f" + alert.getMessage(), "§7Date: §f" + (new SimpleDateFormat("dd.MM.yyy HH:mm:ss")).format(alert.getCreated()), "§7Open: §f" + alert.isOpen() }, ).build(), new Runnable()
/*     */           {
/*     */             public void run() {}
/*     */           });
/*     */ 
/*     */ 
/*     */       
/* 113 */       start++;
/*     */     } 
/*     */     
/* 116 */     linkItemTo(getSize() - 1, (new ItemBuilder()).displayname("§cClose all").itemstack(new ItemStack(Materials.REDSTONE.parseMaterial())).build(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 120 */             for (Alert alert : alerts) {
/* 121 */               alert.setOpen(false);
/*     */             }
/* 123 */             AlertChooseGUI.this.updateInventory();
/*     */           }
/*     */         });
/*     */     
/* 127 */     return (calculatePages(alerts.size(), getSize()) == getPage());
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\alert\AlertChooseGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */