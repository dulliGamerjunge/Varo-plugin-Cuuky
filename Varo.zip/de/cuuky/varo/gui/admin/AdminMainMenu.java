/*     */ package de.cuuky.varo.gui.admin;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.alert.Alert;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import de.cuuky.varo.gui.SuperInventory;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.report.Report;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdminMainMenu
/*     */   extends SuperInventory
/*     */ {
/*     */   public AdminMainMenu(Player opener) {
/*  34 */     super(String.valueOf(Main.getProjectName()) + " §8| §cAdmin", opener, 45, false);
/*     */     
/*  36 */     open();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onBackClick() {
/*  41 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(InventoryClickEvent event) {}
/*     */ 
/*     */   
/*     */   public void onClose(InventoryCloseEvent event) {}
/*     */ 
/*     */   
/*     */   public void onInventoryAction(PageAction action) {}
/*     */ 
/*     */   
/*     */   public boolean onOpen() {
/*  55 */     linkItemTo(0, (new ItemBuilder()).displayname("§eSetup Assistant").itemstack(new ItemStack(Materials.ENDER_EYE.parseMaterial())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     linkItemTo(4, (new ItemBuilder()).displayname("§cConfig").itemstack(new ItemStack(Materials.WHEAT.parseMaterial())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     linkItemTo(10, (new ItemBuilder()).displayname("§4Reports").itemstack(new ItemStack(Material.BLAZE_ROD)).amount(getFixedSize(Report.getReports().size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     linkItemTo(16, (new ItemBuilder()).playername(this.opener.getName()).displayname("§aSpieler").amount(getFixedSize(VaroPlayer.getVaroPlayer().size())).buildSkull(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     linkItemTo(18, (new ItemBuilder()).displayname("§cAlerts").itemstack(new ItemStack(Material.BOOK)).amount(getFixedSize(Alert.getOpenAlerts().size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     linkItemTo(22, (new ItemBuilder()).displayname("§aBackups").itemstack(Materials.WRITTEN_BOOK.parseItem()).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     linkItemTo(26, (new ItemBuilder()).displayname("§1DiscordBot").itemstack(new ItemStack((Main.getBotLauncher().getDiscordbot() != null) ? Material.ANVIL : Materials.GUNPOWDER.parseMaterial())).build(), new Runnable() {
/*     */           public void run() {
/* 105 */             if (Main.getBotLauncher().getDiscordbot() == null) {
/* 106 */               AdminMainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Der DiscordBot wurde nicht aktiviert.");
/* 107 */               AdminMainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Bitte untersuche die Konsolenausgaben nach Fehlern und ueberpruefe, ob du den DiscordBot aktiviert hast.");
/* 108 */               AdminMainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "https://www.mediafire.com/file/yzhm845j7ieh678/JDA.jar/file");
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 116 */     linkItemTo(28, (new ItemBuilder()).displayname("§5Game").itemstack(new ItemStack(Material.CAKE)).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     linkItemTo(34, (new ItemBuilder()).displayname("§2Teams").itemstack(new ItemStack(Material.DIAMOND_HELMET)).amount(getFixedSize(VaroTeam.getTeams().size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     linkItemTo(40, (new ItemBuilder()).displayname("§6OreLogger").itemstack(new ItemStack(Material.DIAMOND_ORE)).amount(getFixedSize(Main.getDataManager().getVaroLoggerManager().getBlockLogger().getLogs().size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     if (ConfigSetting.DEBUG_OPTIONS.getValueAsBoolean()) {
/* 141 */       linkItemTo(this.inv.getSize() - 9, (new ItemBuilder()).displayname("§6Debug").itemstack(new ItemStack(Material.BUCKET)).build(), new Runnable()
/*     */           {
/*     */             public void run() {}
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 149 */     linkItemTo(this.inv.getSize() - 1, (new ItemBuilder()).displayname("§5Info").itemstack(new ItemStack(Materials.MAP.parseMaterial())).build(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 153 */             AdminMainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "§l" + Main.getPluginName());
/* 154 */             AdminMainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7Version: " + Main.getColorCode() + Main.getInstance().getDescription().getVersion());
/* 155 */             AdminMainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7Discordserver: " + Main.getColorCode() + "https://discord.gg/CnDSVVx");
/* 156 */             AdminMainMenu.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "§7All rights reserved!");
/*     */           }
/*     */         });
/*     */     
/* 160 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\AdminMainMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */