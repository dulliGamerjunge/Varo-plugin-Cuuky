/*    */ package de.cuuky.varo.gui.admin.backup;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.recovery.recoveries.VaroBackup;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class BackupGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private VaroBackup backup;
/*    */   
/*    */   public BackupGUI(Player opener, VaroBackup backup) {
/* 22 */     super("§7Backup §a" + backup.getZipFile().getName().replace(".zip", ""), opener, 0, false);
/*    */     
/* 24 */     this.backup = backup;
/* 25 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 31 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 45 */     int i = -1;
/*    */     do {
/* 47 */       i++;
/* 48 */       if (i != 1 && i != 4 && i != 7) {
/* 49 */         this.inv.setItem(i, new ItemStack(Materials.BLACK_STAINED_GLASS_PANE.parseMaterial(), 1, (short)15));
/*    */       } else {
/* 51 */         if (i == 1)
/* 52 */           linkItemTo(i, (new ItemBuilder()).displayname("§aLoad").itemstack(new ItemStack(Material.EMERALD)).build(), new Runnable()
/*    */               {
/*    */                 public void run()
/*    */                 {
/* 56 */                   if (BackupGUI.this.backup.unzip("plugins/Varo")) {
/* 57 */                     BackupGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Backup erfolgreich wieder hergestellt!");
/* 58 */                     BackupGUI.this.closeInventory();
/* 59 */                     Main.getDataManager().setDoSave(false);
/* 60 */                     Bukkit.getServer().reload();
/*    */                   } else {
/* 62 */                     BackupGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Backup konnte nicht wieder hergestellt werden!");
/*    */                   } 
/*    */                 }
/*    */               }); 
/* 66 */         if (i == 7) {
/* 67 */           linkItemTo(i, (new ItemBuilder()).displayname("§4Delete").itemstack(Materials.REDSTONE.parseItem()).build(), new Runnable()
/*    */               {
/*    */                 public void run()
/*    */                 {
/* 71 */                   BackupGUI.this.backup.delete();
/*    */                 }
/*    */               });
/*    */         }
/*    */       } 
/* 76 */     } while (i != this.inv.getSize() - 1);
/*    */     
/* 78 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\backup\BackupGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */