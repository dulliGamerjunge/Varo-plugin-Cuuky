/*    */ package de.cuuky.varo.gui.admin.backup;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.recovery.recoveries.VaroBackup;
/*    */ import java.text.DateFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackupListGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public BackupListGUI(Player opener) {
/* 24 */     super("§aBackups", opener, 45, false);
/*    */     
/* 26 */     open();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 32 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 46 */     ArrayList<VaroBackup> backups = VaroBackup.getBackups();
/* 47 */     int start = getSize() * (getPage() - 1);
/* 48 */     if (start != 0) {
/* 49 */       start -= 2;
/*    */     }
/* 51 */     for (int i = 0; i != getSize() - 2; i++) {
/*    */       final VaroBackup backup;
/*    */       try {
/* 54 */         backup = backups.get(start);
/* 55 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */       
/* 59 */       ArrayList<String> lore = new ArrayList<>();
/* 60 */       lore.add("Backup made date: ");
/* 61 */       String[] split1 = backup.getZipFile().getName().split("_");
/* 62 */       lore.add("Year: " + split1[0].split("-")[0] + ", Month: " + split1[0].split("-")[1] + ", Day: " + split1[0].split("-")[2]);
/* 63 */       lore.add("Hour: " + split1[1].split("-")[0] + ", Minute: " + split1[1].split("-")[1] + ", Second: " + split1[1].split("-")[2].replace(".zip", ""));
/* 64 */       linkItemTo(i, (new ItemBuilder()).displayname("§7" + backup.getZipFile().getName().replace(".zip", "")).itemstack(new ItemStack(Material.DISPENSER)).lore(lore).build(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */ 
/*    */       
/* 71 */       start++;
/*    */     } 
/*    */     
/* 74 */     linkItemTo(44, (new ItemBuilder()).displayname("§aCreate Backup").itemstack(new ItemStack(Material.EMERALD)).build(), new Runnable()
/*    */         {
/*    */           private String getCurrentDate() {
/* 77 */             DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
/* 78 */             Date date = new Date();
/*    */             
/* 80 */             return dateFormat.format(date);
/*    */           }
/*    */ 
/*    */           
/*    */           public void run() {
/* 85 */             if (VaroBackup.getBackup(getCurrentDate()) != null) {
/* 86 */               BackupListGUI.this.opener.sendMessage(String.valueOf(Main.getPrefix()) + "Warte kurz, bevor du ein neues Backup erstellen kannst.");
/*    */               
/*    */               return;
/*    */             } 
/*    */             
/* 91 */             BackupListGUI.this.updateInventory();
/*    */           }
/*    */         });
/*    */     
/* 95 */     return (calculatePages(backups.size(), getSize() - 2) == this.page);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\admin\backup\BackupListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */