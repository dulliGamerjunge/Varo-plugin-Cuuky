package de.cuuky.varo.gui.utils.chat;

public interface ChatHookListener {
  void onChat(String paramString);
}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gu\\utils\chat\ChatHookListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */