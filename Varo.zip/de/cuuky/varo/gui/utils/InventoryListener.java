/*    */ package de.cuuky.varo.gui.utils;
/*    */ 
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.listener.utils.InventoryClickUtil;
/*    */ import de.cuuky.varo.version.types.Sounds;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ 
/*    */ 
/*    */ public class InventoryListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onInvClick(InventoryClickEvent event) {
/* 19 */     Inventory inventory = (new InventoryClickUtil(event)).getInventory();
/* 20 */     if (inventory == null || event.getCurrentItem() == null || event.getCurrentItem().getItemMeta() == null || event.getCurrentItem().getItemMeta().getDisplayName() == null) {
/*    */       return;
/*    */     }
/* 23 */     Player player = (Player)event.getWhoClicked();
/* 24 */     String itemName = event.getCurrentItem().getItemMeta().getDisplayName();
/*    */     
/* 26 */     for (int i = 0; i < SuperInventory.getGUIS().size(); ) {
/* 27 */       SuperInventory inv = SuperInventory.getGUIS().get(i);
/* 28 */       if (!inv.getInventory().equals(inventory)) {
/*    */         i++; continue;
/*    */       } 
/* 31 */       player.playSound(player.getLocation(), Sounds.CLICK.bukkitSound(), 1.0F, 1.0F);
/* 32 */       event.setCancelled(true);
/* 33 */       if (itemName.equals("§c"))
/*    */         return; 
/*    */       String str;
/* 36 */       switch ((str = itemName).hashCode()) { case -1364629827: if (!str.equals("§aSeite vorwaerts"))
/*    */             break; 
/* 38 */           inv.pageForwards();
/* 39 */           inv.pageActionChanged(PageAction.PAGE_SWITCH_FORWARDS);
/*    */           return;
/*    */         
/*    */         case 187377350:
/*    */           if (!str.equals("§4Schliessen")) {
/*    */             break;
/*    */           }
/* 46 */           inv.closeInventory(); return;case 585260108: if (!str.equals("§cSeite rueckwaerts"))
/*    */             break;  inv.pageBackwards(); inv.pageActionChanged(PageAction.PAGE_SWITCH_FORWARDS); return;
/*    */         case 964070114: if (!str.equals("§4Zurueck"))
/* 49 */             break;  inv.closeInventory();
/* 50 */           inv.back();
/*    */           return; }
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 56 */       inv.executeLink(event.getCurrentItem());
/* 57 */       inv.onClick(event);
/*    */       break;
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onInvClose(InventoryCloseEvent event) {
/* 64 */     if (event.getInventory() == null) {
/*    */       return;
/*    */     }
/* 67 */     SuperInventory inv1 = null;
/* 68 */     for (SuperInventory inv : SuperInventory.getGUIS()) {
/* 69 */       if (!inv.getInventory().equals(event.getInventory())) {
/*    */         continue;
/*    */       }
/* 72 */       inv1 = inv;
/*    */       
/*    */       break;
/*    */     } 
/* 76 */     if (inv1 != null) {
/* 77 */       inv1.onClose(event);
/* 78 */       inv1.closeInventory();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gu\\utils\InventoryListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */