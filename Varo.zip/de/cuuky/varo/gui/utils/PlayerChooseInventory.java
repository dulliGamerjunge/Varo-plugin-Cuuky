/*     */ package de.cuuky.varo.gui.utils;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.listener.utils.InventoryClickUtil;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class PlayerChooseInventory {
/*     */   private PlayerChooseHandler chooseHandler;
/*     */   private Inventory inv;
/*     */   private PlayerInventoryHandler invHandler;
/*     */   private Listener listener;
/*     */   private int page;
/*     */   private Player player;
/*     */   private Player[] players;
/*     */   private int size;
/*     */   
/*     */   public class PlayerAddEvent {
/*     */     private String displayName;
/*     */     
/*     */     public PlayerAddEvent(Player toAdd) {
/*  28 */       this.toAdd = toAdd;
/*     */     }
/*     */     private String[] lore; private Player toAdd;
/*     */     public String getDisplayName() {
/*  32 */       return this.displayName;
/*     */     }
/*     */     
/*     */     public String[] getLore() {
/*  36 */       return this.lore;
/*     */     }
/*     */     
/*     */     public Player getToAdd() {
/*  40 */       return this.toAdd;
/*     */     }
/*     */     
/*     */     public void setDisplayName(String displayName) {
/*  44 */       this.displayName = displayName;
/*     */     }
/*     */     
/*     */     public void setLore(String[] lore) {
/*  48 */       this.lore = lore;
/*     */     }
/*     */   }
/*     */   
/*     */   public class PlayerChooseEvent
/*     */   {
/*     */     private boolean all;
/*     */     private Player choosen;
/*     */     
/*     */     public PlayerChooseEvent(Player choosen, boolean all) {
/*  58 */       this.choosen = choosen;
/*     */     }
/*     */     
/*     */     public boolean chosenAll() {
/*  62 */       return this.all;
/*     */     }
/*     */     
/*     */     public Player getChoosen() {
/*  66 */       return this.choosen;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlayerChooseInventory(Player player, Player[] players, PlayerChooseHandler handler) {
/*  97 */     this.player = player;
/*  98 */     this.chooseHandler = handler;
/*  99 */     this.size = 54;
/* 100 */     this.page = 1;
/* 101 */     this.players = players;
/*     */     
/* 103 */     addListener(handler);
/*     */     
/* 105 */     open();
/*     */   }
/*     */   
/*     */   public PlayerChooseInventory(Player player, Player[] players, PlayerChooseHandler handler, PlayerInventoryHandler invHandler) {
/* 109 */     this.player = player;
/* 110 */     this.chooseHandler = handler;
/* 111 */     this.size = 54;
/* 112 */     this.page = 1;
/* 113 */     this.invHandler = invHandler;
/* 114 */     this.players = players;
/*     */     
/* 116 */     addListener(handler);
/*     */     
/* 118 */     open();
/*     */   }
/*     */   
/*     */   private void addListener(final PlayerChooseHandler handler) {
/* 122 */     this.listener = new Listener()
/*     */       {
/*     */         @EventHandler
/*     */         public void onInventoryClick(InventoryClickEvent event) {
/* 126 */           Inventory inventory = (new InventoryClickUtil(event)).getInventory();
/* 127 */           if (inventory == null || event.getCurrentItem() == null || event.getCurrentItem().getItemMeta() == null || event.getCurrentItem().getItemMeta().getDisplayName() == null) {
/*     */             return;
/*     */           }
/* 130 */           if (!PlayerChooseInventory.this.inv.equals(event.getInventory())) {
/*     */             return;
/*     */           }
/* 133 */           String displayname = event.getCurrentItem().getItemMeta().getDisplayName();
/*     */           
/* 135 */           if (displayname.contains("Backwards") || displayname.contains("Forwards")) {
/* 136 */             PlayerChooseInventory.this.page = displayname.contains("Backwards") ? (Integer.valueOf(displayname.split("| ")[1]).intValue() - 1) : (Integer.valueOf(displayname.split("§8| §7")[1]).intValue() + 1);
/* 137 */             PlayerChooseInventory.this.open();
/*     */             
/*     */             return;
/*     */           } 
/* 141 */           event.setCancelled(true);
/*     */           
/* 143 */           Player choosen = Bukkit.getPlayerExact(displayname.replaceFirst("§c", ""));
/* 144 */           handler.onPlayerChoose(new PlayerChooseInventory.PlayerChooseEvent(choosen, displayname.equals("§aChoose all")));
/*     */           
/* 146 */           PlayerChooseInventory.this.player.closeInventory();
/*     */         }
/*     */         
/*     */         @EventHandler
/*     */         public void onInventoryClose(InventoryCloseEvent event) {
/* 151 */           if (!PlayerChooseInventory.this.inv.equals(event.getInventory())) {
/*     */             return;
/*     */           }
/* 154 */           handler.onPlayerChoose(new PlayerChooseInventory.PlayerChooseEvent(null, false));
/*     */         }
/*     */       };
/*     */     
/* 158 */     Bukkit.getPluginManager().registerEvents(this.listener, (Plugin)Main.getInstance());
/*     */   }
/*     */   
/*     */   private void open() {
/* 162 */     this.inv = Bukkit.createInventory(null, 54, "§cChoose a player §8| §7" + this.page);
/*     */     
/* 164 */     int start = this.size * (this.page - 1);
/* 165 */     boolean notEnough = false;
/* 166 */     Player[] players = (this.players != null) ? this.players : (Player[])VersionUtils.getOnlinePlayer().toArray();
/* 167 */     for (int i = 0; i != this.size - 3; i++) {
/*     */       Player player;
/*     */       
/*     */       try {
/* 171 */         player = players[start];
/* 172 */       } catch (IndexOutOfBoundsException e) {
/*     */         break;
/*     */       } 
/*     */       
/* 176 */       ItemStack stack = (new ItemBuilder()).player(player).build();
/* 177 */       if (this.invHandler != null) {
/* 178 */         PlayerAddEvent event = new PlayerAddEvent(player);
/* 179 */         this.invHandler.onPlayerInventoryAdd(event);
/* 180 */         if (event.getDisplayName() != null) {
/* 181 */           stack.getItemMeta().setDisplayName(event.getDisplayName());
/*     */         }
/* 183 */         if (event.getLore() != null) {
/* 184 */           stack.getItemMeta().setLore(JavaUtils.collectionToArray(event.getLore()));
/*     */         }
/*     */       } 
/* 187 */       this.inv.setItem(start, stack);
/* 188 */       start++;
/*     */       
/* 190 */       if (start == this.size - 3) {
/* 191 */         notEnough = true;
/*     */       }
/*     */     } 
/* 194 */     this.inv.setItem(51, (new ItemBuilder()).displayname("§aChoose all").itemstack(new ItemStack(Materials.SKELETON_SKULL.parseMaterial())).build());
/*     */     
/* 196 */     if (notEnough) {
/* 197 */       this.inv.setItem(53, (new ItemBuilder()).displayname("§aForwards").itemstack((new ItemBuilder()).playername("MHF_ArrowRight").buildSkull()).build());
/*     */     }
/* 199 */     if (this.page != 1) {
/* 200 */       this.inv.setItem(52, (new ItemBuilder()).displayname("§cBackwards").itemstack((new ItemBuilder()).playername("MHF_ArrowLeft").buildSkull()).build());
/*     */     }
/* 202 */     this.player.openInventory(this.inv);
/*     */   }
/*     */   
/*     */   public static interface PlayerChooseHandler {
/*     */     void onPlayerChoose(PlayerChooseInventory.PlayerChooseEvent param1PlayerChooseEvent);
/*     */   }
/*     */   
/*     */   public static interface PlayerInventoryHandler {
/*     */     void onPlayerInventoryAdd(PlayerChooseInventory.PlayerAddEvent param1PlayerAddEvent);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gu\\utils\PlayerChooseInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */