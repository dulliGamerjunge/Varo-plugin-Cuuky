/*    */ package de.cuuky.varo.gui.player;
/*    */ 
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerListChooseGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   private boolean showStats;
/*    */   
/*    */   public PlayerListChooseGUI(Player opener, boolean showStats) {
/* 19 */     super("§aChoose Players", opener, 9, false);
/*    */     
/* 21 */     this.showStats = showStats;
/* 22 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 27 */     if (this.opener.hasPermission("varo.admin"))
/*    */     {
/* 29 */       return true;
/*    */     }
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 45 */     int i = 0; byte b; int j; PlayerListGUI.PlayerGUIType[] arrayOfPlayerGUIType;
/* 46 */     for (j = (arrayOfPlayerGUIType = PlayerListGUI.PlayerGUIType.values()).length, b = 0; b < j; ) { final PlayerListGUI.PlayerGUIType type = arrayOfPlayerGUIType[b];
/* 47 */       linkItemTo(i, (new ItemBuilder()).displayname(type.getTypeName()).itemstack(new ItemStack(type.getIcon())).amount(getFixedSize(type.getList().size())).build(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */ 
/*    */       
/* 54 */       i += 2;
/*    */       b++; }
/*    */     
/* 57 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\player\PlayerListChooseGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */