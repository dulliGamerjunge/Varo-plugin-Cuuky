/*     */ package de.cuuky.varo.gui.player;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.Stats;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.entity.player.stats.stat.Rank;
/*     */ import de.cuuky.varo.gui.SuperInventory;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.gui.utils.chat.ChatHookListener;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import java.net.URL;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerOptionsGUI
/*     */   extends SuperInventory
/*     */ {
/*     */   private Stats stats;
/*     */   private VaroPlayer target;
/*     */   private PlayerListGUI.PlayerGUIType type;
/*     */   
/*     */   public PlayerOptionsGUI(Player opener, VaroPlayer target, PlayerListGUI.PlayerGUIType type) {
/*  31 */     super("§2" + target.getName() + " §7(" + target.getId() + ")", opener, 54, false);
/*     */     
/*  33 */     this.target = target;
/*  34 */     this.stats = target.getStats();
/*  35 */     this.type = type;
/*     */     
/*  37 */     open();
/*     */   }
/*     */   
/*     */   private boolean isURl(String link) {
/*     */     try {
/*  42 */       (new URL(link)).openConnection();
/*  43 */       return true;
/*  44 */     } catch (Exception e) {
/*  45 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateStats() {
/*  50 */     if (getPage() == 1) {
/*  51 */       this.inv.setItem(4, (new ItemBuilder()).displayname("§cKills").itemstack(new ItemStack(Material.DIAMOND_SWORD)).lore(new String[] { "§7Current: " + this.stats.getKills() }).build());
/*  52 */       this.inv.setItem(13, (new ItemBuilder()).displayname("§6Rank").itemstack(new ItemStack(Materials.SIGN.parseMaterial())).lore(new String[] { "§7Current: " + ((this.target.getRank() == null) ? "/" : this.target.getRank().getDisplay()) }).build());
/*  53 */       this.inv.setItem(22, (new ItemBuilder()).displayname("§5YouTube-Link").itemstack(new ItemStack(Materials.PAPER.parseMaterial())).lore(new String[] { "§7Current: " + this.stats.getYoutubeLink() }).build());
/*  54 */       this.inv.setItem(31, (new ItemBuilder()).displayname("§bSessions").itemstack(new ItemStack(Material.DIAMOND)).lore(new String[] { "§7Current: " + this.stats.getSessions() }).build());
/*  55 */     } else if (getPage() == 2) {
/*  56 */       this.inv.setItem(4, (new ItemBuilder()).displayname("§5EpisodesPlayed").itemstack(new ItemStack(Material.BLAZE_POWDER)).lore(new String[] { "§7Current: " + this.stats.getSessionsPlayed() }).build());
/*  57 */       this.inv.setItem(13, (new ItemBuilder()).displayname("§6Countdown").itemstack(new ItemStack(Materials.SIGN.parseMaterial())).lore(new String[] { "§7Current: " + this.stats.getCountdown() }).build());
/*     */       
/*  59 */       this.inv.setItem(36, (new ItemBuilder()).displayname("§7Change §cWill InventoryClear").itemstack(new ItemStack(Material.ARROW)).lore(new String[] { "§7Current: " + this.stats.isWillClear() }).build());
/*  60 */       this.inv.setItem(37, (new ItemBuilder()).displayname("§7Change §6State").itemstack(new ItemStack(Material.GOLDEN_APPLE)).lore(new String[] { "§7Current: " + this.stats.getState().getName() }).build());
/*  61 */       this.inv.setItem(38, (new ItemBuilder()).displayname("§7Remove §cTimeUntilAddSession").itemstack(new ItemStack(Materials.PAPER.parseMaterial())).lore(new String[] { "§7Current: " + this.stats.getTimeUntilAddSession() }).build());
/*     */     } 
/*     */   }
/*     */   
/*     */   public VaroPlayer getTarget() {
/*  66 */     return this.target;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onBackClick() {
/*  72 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(InventoryClickEvent event) {
/*  77 */     String itemname = event.getCurrentItem().getItemMeta().getDisplayName();
/*     */     
/*  79 */     if (itemname.contains("EpisodesPlayed")) {
/*  80 */       if (itemname.contains("Add")) {
/*  81 */         this.stats.addSessionPlayed();
/*  82 */       } else if (itemname.contains("Remove")) {
/*  83 */         this.stats.setSessionsPlayed(this.stats.getSessionsPlayed() - 1);
/*     */       } 
/*     */     }
/*  86 */     if (itemname.contains("Countdown")) {
/*  87 */       if (itemname.contains("Reset")) {
/*  88 */         this.stats.removeCountdown();
/*  89 */       } else if (itemname.contains("Remove")) {
/*  90 */         this.stats.setCountdown(1);
/*     */       } 
/*     */     }
/*  93 */     if (itemname.contains("Will InventoryClear")) {
/*  94 */       this.stats.setWillClear(!this.stats.isWillClear());
/*     */     }
/*  96 */     if (itemname.contains("Kill")) {
/*  97 */       if (itemname.contains("Add")) {
/*  98 */         this.stats.addKill();
/*  99 */       } else if (itemname.contains("Remove")) {
/* 100 */         this.stats.setKills(this.stats.getKills() - 1);
/*     */       } 
/*     */     }
/* 103 */     if (itemname.contains("Session")) {
/* 104 */       if (itemname.contains("Add")) {
/* 105 */         this.stats.setSessions(this.stats.getSessions() + 1);
/* 106 */       } else if (itemname.contains("Remove")) {
/* 107 */         this.stats.setSessions(this.stats.getSessions() - 1);
/*     */       } 
/*     */     }
/* 110 */     if (itemname.contains("Link")) {
/* 111 */       if (itemname.contains("Set")) {
/* 112 */         close(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 128 */       else if (itemname.contains("Remove")) {
/* 129 */         this.stats.setYoutubeLink(null);
/*     */       } 
/*     */     }
/* 132 */     if (itemname.contains("Rank")) {
/* 133 */       if (itemname.contains("Set")) {
/* 134 */         close(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 145 */       else if (itemname.contains("Remove")) {
/* 146 */         this.target.setRank(null);
/*     */       } 
/*     */     }
/* 149 */     if (itemname.contains("State")) {
/* 150 */       PlayerState state = null;
/* 151 */       switch (this.target.getStats().getState()) {
/*     */         case DEAD:
/* 153 */           state = PlayerState.SPECTATOR;
/*     */           break;
/*     */         case null:
/* 156 */           state = PlayerState.DEAD;
/*     */           break;
/*     */         case SPECTATOR:
/* 159 */           state = PlayerState.ALIVE;
/*     */           break;
/*     */       } 
/*     */       
/* 163 */       this.stats.setState(state);
/*     */     } 
/*     */     
/* 166 */     if (itemname.contains("TimeUntilAddSession")) {
/* 167 */       this.stats.setTimeUntilAddSession(null);
/* 168 */       this.stats.setSessions(this.stats.getSessions() + 1);
/*     */     } 
/*     */     
/* 171 */     updateStats();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClose(InventoryCloseEvent event) {}
/*     */ 
/*     */   
/*     */   public void onInventoryAction(PageAction action) {}
/*     */ 
/*     */   
/*     */   public boolean onOpen() {
/* 182 */     if (getPage() == 1) {
/* 183 */       this.inv.setItem(8, (new ItemBuilder()).displayname("§aAdd Kill").itemstack(new ItemStack(Material.APPLE)).build());
/* 184 */       this.inv.setItem(0, (new ItemBuilder()).displayname("§cRemove Kill").itemstack(Materials.REDSTONE.parseItem()).build());
/*     */       
/* 186 */       this.inv.setItem(17, (new ItemBuilder()).displayname("§aSet Rank").itemstack(new ItemStack(Material.APPLE)).build());
/* 187 */       this.inv.setItem(9, (new ItemBuilder()).displayname("§cRemove Rank").itemstack(Materials.REDSTONE.parseItem()).build());
/*     */       
/* 189 */       this.inv.setItem(26, (new ItemBuilder()).displayname("§aSet Link").itemstack(new ItemStack(Material.APPLE)).build());
/* 190 */       this.inv.setItem(18, (new ItemBuilder()).displayname("§cRemove Link").itemstack(Materials.REDSTONE.parseItem()).build());
/*     */       
/* 192 */       this.inv.setItem(35, (new ItemBuilder()).displayname("§aAdd Session").itemstack(new ItemStack(Material.APPLE)).build());
/* 193 */       this.inv.setItem(27, (new ItemBuilder()).displayname("§cRemove Session").itemstack(Materials.REDSTONE.parseItem()).build());
/* 194 */     } else if (getPage() == 2) {
/* 195 */       this.inv.setItem(8, (new ItemBuilder()).displayname("§aAdd EpisodesPlayed").itemstack(new ItemStack(Material.APPLE)).build());
/* 196 */       this.inv.setItem(0, (new ItemBuilder()).displayname("§cRemove EpisodesPlayed").itemstack(Materials.REDSTONE.parseItem()).build());
/*     */       
/* 198 */       this.inv.setItem(17, (new ItemBuilder()).displayname("§aReset Countdown").itemstack(new ItemStack(Material.APPLE)).build());
/* 199 */       this.inv.setItem(9, (new ItemBuilder()).displayname("§cRemove Countdown").itemstack(Materials.REDSTONE.parseItem()).build());
/*     */     } 
/*     */     
/* 202 */     updateStats();
/* 203 */     return (getPage() == 2);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\player\PlayerOptionsGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */