/*     */ package de.cuuky.varo.gui.player;
/*     */ 
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.gui.SuperInventory;
/*     */ import de.cuuky.varo.gui.utils.PageAction;
/*     */ import de.cuuky.varo.item.ItemBuilder;
/*     */ import de.cuuky.varo.utils.varo.LocationFormat;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerGUI
/*     */   extends SuperInventory
/*     */ {
/*     */   private VaroPlayer target;
/*     */   private PlayerListGUI.PlayerGUIType type;
/*     */   
/*     */   public PlayerGUI(Player opener, VaroPlayer target, PlayerListGUI.PlayerGUIType type) {
/*  25 */     super("§2" + target.getName() + " §7(" + target.getId() + ")", opener, 27, false);
/*     */     
/*  27 */     this.target = target;
/*  28 */     this.type = type;
/*     */     
/*  30 */     open();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onBackClick() {
/*  35 */     if (this.type != null) {
/*     */     
/*     */     } else {
/*     */     
/*  39 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClick(InventoryClickEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClose(InventoryCloseEvent event) {}
/*     */ 
/*     */   
/*     */   public void onInventoryAction(PageAction action) {}
/*     */ 
/*     */   
/*     */   public boolean onOpen() {
/*  55 */     linkItemTo(1, (new ItemBuilder()).displayname("§aInventory Backups").itemstack(new ItemStack(Material.DIAMOND_CHESTPLATE)).lore("§7Click to see more options").build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     linkItemTo(4, (new ItemBuilder()).displayname("§2Last Location").itemstack(new ItemStack(Materials.MAP.parseMaterial())).lore(new String[] { "§cClick to teleport", "§7" + ((this.target.getStats().getLastLocation() != null) ? (new LocationFormat(this.target.getStats().getLastLocation())).format("x, y, z in world") : "/") }, ).build(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  67 */             if (PlayerGUI.this.target.getStats().getLastLocation() == null) {
/*     */               return;
/*     */             }
/*  70 */             PlayerGUI.this.opener.teleport(PlayerGUI.this.target.getStats().getLastLocation());
/*     */           }
/*     */         });
/*     */     
/*  74 */     linkItemTo(7, (new ItemBuilder()).displayname("§eKisten/Öfen").itemstack(new ItemStack(Materials.REDSTONE.parseMaterial())).amount(getFixedSize(this.target.getStats().getSaveables().size())).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     linkItemTo(11, (new ItemBuilder()).displayname("§4Remove").itemstack(new ItemStack(Materials.SKELETON_SKULL.parseMaterial())).build(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  86 */             PlayerGUI.this.target.delete();
/*  87 */             if (PlayerGUI.this.type != null) {
/*     */             
/*     */             } else {
/*     */             
/*     */             } 
/*     */           }
/*     */         });
/*  94 */     linkItemTo(15, (new ItemBuilder()).displayname("§cReset").itemstack(new ItemStack(Material.BUCKET)).build(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  98 */             if (PlayerGUI.this.target.isOnline()) {
/*  99 */               PlayerGUI.this.target.getPlayer().kickPlayer("§7You've been resetted.\n§cPlease join again.");
/*     */             }
/* 101 */             PlayerGUI.this.target.getStats().loadDefaults();
/* 102 */             PlayerGUI.this.updateInventory();
/*     */           }
/*     */         });
/*     */     
/* 106 */     linkItemTo(22, (new ItemBuilder()).displayname("§5More Options").itemstack(new ItemStack(Material.BOOK)).lore(this.target.getStats().getStatsListed()).build(), new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\player\PlayerGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */