/*    */ package de.cuuky.varo.gui.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.gui.SuperInventory;
/*    */ import de.cuuky.varo.gui.utils.PageAction;
/*    */ import de.cuuky.varo.item.ItemBuilder;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class EventListGUI
/*    */   extends SuperInventory
/*    */ {
/*    */   public EventListGUI(Player opener) {
/* 20 */     super("§5Events", opener, 45, false);
/*    */     
/* 22 */     open();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onBackClick() {
/* 27 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onClick(InventoryClickEvent event) {}
/*    */ 
/*    */   
/*    */   public void onClose(InventoryCloseEvent event) {}
/*    */ 
/*    */   
/*    */   public void onInventoryAction(PageAction action) {}
/*    */ 
/*    */   
/*    */   public boolean onOpen() {
/* 41 */     ArrayList<String> list = Main.getDataManager().getVaroLoggerManager().getEventLogger().getLogs();
/* 42 */     Collections.reverse(list);
/*    */     
/* 44 */     int start = getSize() * (getPage() - 1);
/* 45 */     for (int i = 0; i != getSize(); i++) {
/*    */       String[] line;
/*    */       try {
/* 48 */         line = ((String)list.get(start)).split("] ");
/* 49 */       } catch (IndexOutOfBoundsException e) {
/*    */         break;
/*    */       } 
/*    */       
/* 53 */       line[0] = line[0].replace("[", "");
/* 54 */       ArrayList<String> s = new ArrayList<>();
/* 55 */       s.add("§c" + line[0]);
/* 56 */       linkItemTo(i, (new ItemBuilder()).displayname("§7" + line[1]).itemstack(new ItemStack(Materials.SIGN.parseMaterial())).lore(s).build(), new Runnable()
/*    */           {
/*    */             public void run() {}
/*    */           });
/*    */ 
/*    */ 
/*    */       
/* 63 */       start++;
/*    */     } 
/*    */     
/* 66 */     return (calculatePages(list.size(), getSize()) == this.page);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\gui\events\EventListGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */