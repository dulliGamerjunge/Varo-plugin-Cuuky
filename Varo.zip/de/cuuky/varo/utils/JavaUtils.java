/*     */ package de.cuuky.varo.utils;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public final class JavaUtils
/*     */ {
/*     */   public static long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
/*  14 */     long diffInMillies = date2.getTime() - date1.getTime();
/*  15 */     return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */   public static ArrayList<String> addIntoEvery(ArrayList<String> input, String into, boolean start) {
/*  19 */     for (int i = 0; i < input.size(); i++) {
/*  20 */       input.set(i, start ? (String.valueOf(into) + (String)input.get(i)) : (String.valueOf(input.get(i)) + into));
/*     */     }
/*  22 */     return input;
/*     */   }
/*     */   
/*     */   public static String[] addIntoEvery(String[] input, String into, boolean start) {
/*  26 */     for (int i = 0; i < input.length; i++) {
/*  27 */       input[i] = start ? (String.valueOf(into) + input[i]) : (String.valueOf(input[i]) + into);
/*     */     }
/*  29 */     return input;
/*     */   }
/*     */   
/*     */   public static String[] arrayToCollection(List<String> strings) {
/*  33 */     String[] newStrings = new String[strings.size()];
/*     */     
/*  35 */     for (int i = 0; i < strings.size(); i++) {
/*  36 */       newStrings[i] = strings.get(i);
/*     */     }
/*  38 */     return newStrings;
/*     */   }
/*     */   
/*     */   public static ArrayList<String> collectionToArray(String[] strings) {
/*  42 */     ArrayList<String> newStrings = new ArrayList<>(); byte b; int i; String[] arrayOfString;
/*  43 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String string = arrayOfString[b];
/*  44 */       newStrings.add(string); b++; }
/*     */     
/*  46 */     return newStrings;
/*     */   }
/*     */   
/*     */   public static String[] combineArrays(String[]... strings) {
/*  50 */     ArrayList<String> string = new ArrayList<>(); byte b; int i;
/*     */     String[][] arrayOfString;
/*  52 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String[] ss = arrayOfString[b]; byte b1; int j; String[] arrayOfString1;
/*  53 */       for (j = (arrayOfString1 = ss).length, b1 = 0; b1 < j; ) { String strin = arrayOfString1[b1];
/*  54 */         string.add(strin); b1++; }
/*     */        b++; }
/*  56 */      return getAsArray(string);
/*     */   }
/*     */   
/*     */   public static String getArgsToString(ArrayList<String> args, String insertBewteen) {
/*  60 */     String command = "";
/*  61 */     for (String arg : args) {
/*  62 */       if (command.equals("")) {
/*  63 */         command = arg; continue;
/*     */       } 
/*  65 */       command = String.valueOf(command) + insertBewteen + arg;
/*     */     } 
/*  67 */     return command;
/*     */   }
/*     */   
/*     */   public static String getArgsToString(String[] args, String insertBewteen) {
/*  71 */     String command = ""; byte b; int i; String[] arrayOfString;
/*  72 */     for (i = (arrayOfString = args).length, b = 0; b < i; ) { String arg = arrayOfString[b];
/*  73 */       if (command.equals("")) {
/*  74 */         command = arg;
/*     */       } else {
/*  76 */         command = String.valueOf(command) + insertBewteen + arg;
/*     */       }  b++; }
/*  78 */      return command;
/*     */   }
/*     */   
/*     */   public static String[] getAsArray(ArrayList<String> string) {
/*  82 */     String[] list = new String[string.size()];
/*  83 */     for (int i = 0; i < string.size(); i++) {
/*  84 */       list[i] = string.get(i);
/*     */     }
/*  86 */     return list;
/*     */   }
/*     */   
/*     */   public static ArrayList<Object> getAsList(String[] lis) {
/*  90 */     ArrayList<Object> list = new ArrayList(); byte b; int i; String[] arrayOfString;
/*  91 */     for (i = (arrayOfString = lis).length, b = 0; b < i; ) { Object u = arrayOfString[b];
/*  92 */       list.add(u); b++; }
/*     */     
/*  94 */     return list;
/*     */   }
/*     */   
/*     */   public static int getNextToNine(int to) {
/*  98 */     int result = 9 - to % 9 + to;
/*  99 */     return (result > 54) ? 54 : result;
/*     */   }
/*     */   
/*     */   public static Object getStringObject(String obj) {
/*     */     try {
/* 104 */       return Integer.valueOf(Integer.parseInt(obj));
/* 105 */     } catch (NumberFormatException numberFormatException) {
/*     */       
/*     */       try {
/* 108 */         return Long.valueOf(Long.parseLong(obj));
/* 109 */       } catch (NumberFormatException numberFormatException1) {
/*     */         
/*     */         try {
/* 112 */           return Double.valueOf(Double.parseDouble(obj));
/* 113 */         } catch (NumberFormatException numberFormatException2) {
/*     */           
/* 115 */           if (obj.equalsIgnoreCase("true") || obj.equalsIgnoreCase("false")) {
/* 116 */             return Boolean.valueOf(obj.equalsIgnoreCase("true"));
/*     */           }
/* 118 */           return obj;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int randomInt(int min, int max) {
/* 129 */     Random rand = new Random();
/* 130 */     int randomNum = rand.nextInt(max - min + 1) + min;
/*     */     
/* 132 */     return randomNum;
/*     */   }
/*     */   
/*     */   public static String[] removeString(String[] string, int loc) {
/* 136 */     String[] ret = new String[string.length - 1];
/* 137 */     int i = 0;
/* 138 */     boolean removed = false; byte b; int j; String[] arrayOfString1;
/* 139 */     for (j = (arrayOfString1 = string).length, b = 0; b < j; ) { String arg = arrayOfString1[b];
/* 140 */       if (i == loc && !removed) {
/* 141 */         removed = true;
/*     */       }
/*     */       else {
/*     */         
/* 145 */         ret[i] = arg;
/* 146 */         i++;
/*     */       }  b++; }
/*     */     
/* 149 */     return ret;
/*     */   }
/*     */   
/*     */   public static String replaceAllColors(String s) {
/* 153 */     String newMessage = "";
/* 154 */     boolean lastPara = false; byte b; int i; char[] arrayOfChar;
/* 155 */     for (i = (arrayOfChar = s.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/* 156 */       if (lastPara) {
/* 157 */         lastPara = false;
/*     */ 
/*     */       
/*     */       }
/* 161 */       else if (c == "§".toCharArray()[0] || c == "&".toCharArray()[0]) {
/* 162 */         lastPara = true;
/*     */       }
/*     */       else {
/*     */         
/* 166 */         newMessage = newMessage.isEmpty() ? String.valueOf(c) : (String.valueOf(newMessage) + c);
/*     */       }  b++; }
/*     */     
/* 169 */     return newMessage;
/*     */   }
/*     */   
/*     */   public static String getCurrentDateAsFileable() {
/* 173 */     DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
/* 174 */     Date date = new Date();
/*     */     
/* 176 */     return dateFormat.format(date);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\var\\utils\JavaUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */