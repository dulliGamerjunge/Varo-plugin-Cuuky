/*    */ package de.cuuky.varo.utils;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.Date;
/*    */ import java.util.Scanner;
/*    */ import java.util.UUID;
/*    */ import org.json.simple.JSONArray;
/*    */ import org.json.simple.JSONObject;
/*    */ import org.json.simple.JSONValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UUIDUtils
/*    */ {
/*    */   private static UUID getUUIDTime(String name, long time) throws Exception {
/*    */     Scanner scanner;
/* 18 */     if (time == -1L) {
/* 19 */       scanner = new Scanner((new URL("https://api.mojang.com/users/profiles/minecraft/" + name)).openStream());
/*    */     } else {
/* 21 */       scanner = new Scanner((new URL("https://api.mojang.com/users/profiles/minecraft/" + name + "?at=" + String.valueOf(time))).openStream());
/*    */     } 
/*    */     
/* 24 */     String input = scanner.nextLine();
/* 25 */     scanner.close();
/*    */     
/* 27 */     JSONObject UUIDObject = (JSONObject)JSONValue.parseWithException(input);
/* 28 */     String uuidString = UUIDObject.get("id").toString();
/* 29 */     String uuidSeperation = uuidString.replaceFirst("([0-9a-fA-F]{8})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]+)", "$1-$2-$3-$4-$5");
/* 30 */     UUID uuid = UUID.fromString(uuidSeperation);
/* 31 */     return uuid;
/*    */   }
/*    */   
/*    */   public static String getNamesChanged(String name) throws Exception {
/* 35 */     Date Date = new Date();
/* 36 */     long Time = Date.getTime() / 1000L;
/*    */     
/* 38 */     UUID UUIDOld = getUUIDTime(name, Time - 2592000L);
/* 39 */     String uuid = UUIDOld.toString().replace("-", "");
/*    */     
/* 41 */     Scanner scanner = new Scanner((new URL("https://api.mojang.com/user/profiles/" + uuid + "/names")).openStream());
/* 42 */     String input = scanner.nextLine();
/* 43 */     scanner.close();
/*    */     
/* 45 */     JSONArray nameArray = (JSONArray)JSONValue.parseWithException(input);
/* 46 */     String playerSlot = nameArray.get(nameArray.size() - 1).toString();
/* 47 */     JSONObject nameObject = (JSONObject)JSONValue.parseWithException(playerSlot);
/* 48 */     String newName = nameObject.get("name").toString();
/* 49 */     return newName;
/*    */   }
/*    */   
/*    */   public static UUID getUUID(String name) throws Exception {
/* 53 */     return getUUIDTime(name, -1L);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\var\\utils\UUIDUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */