/*    */ package de.cuuky.varo.spigot;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ 
/*    */ public class FileDownloader {
/*    */   protected String link;
/*    */   protected String path;
/*    */   
/*    */   public FileDownloader(String link, String path) {
/* 13 */     this.link = link;
/* 14 */     this.path = path;
/*    */   }
/*    */   
/*    */   public void startDownload() throws IOException {
/* 18 */     URL download = new URL(this.link);
/*    */ 
/*    */ 
/*    */     
/* 22 */     BufferedInputStream in = new BufferedInputStream(download.openStream());
/* 23 */     FileOutputStream fout = new FileOutputStream(this.path);
/*    */     
/* 25 */     byte[] data = new byte[1024];
/*    */     int count;
/* 27 */     while ((count = in.read(data, 0, 1024)) != -1) {
/* 28 */       fout.write(data, 0, count);
/*    */     }
/*    */     
/* 31 */     if (in != null) {
/* 32 */       in.close();
/*    */     }
/* 34 */     if (fout != null)
/* 35 */       fout.close(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\spigot\FileDownloader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */