/*    */ package de.cuuky.varo.spigot.updater;public class VaroUpdateResultSet {
/*    */   private UpdateResult updateResult;
/*    */   private String versionName;
/*    */   private String versionId;
/*    */   
/*    */   public enum UpdateResult {
/*  7 */     FAIL_SPIGOT("Es konnte keine Verbindung zum Server hergestellt werden."),
/*  8 */     NO_UPDATE("Das Plugin ist auf dem neuesten Stand!"),
/*  9 */     TEST_BUILD("Das Plugin ist auf dem neuesten Stand! (Test-Build)"),
/* 10 */     UPDATE_AVAILABLE("Es ist ein Update verfuegbar! Benutze /varo update oder lade es manuell unter https://www.spigotmc.org/resources/71075/ herunter");
/*    */     
/*    */     private String message;
/*    */     
/*    */     UpdateResult(String message) {
/* 15 */       this.message = message;
/*    */     }
/*    */     
/*    */     public String getMessage() {
/* 19 */       return this.message;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VaroUpdateResultSet(UpdateResult result, String versionName, String versionId) {
/* 27 */     this.updateResult = result;
/* 28 */     this.versionName = versionName;
/* 29 */     this.versionId = versionId;
/*    */   }
/*    */   
/*    */   public UpdateResult getUpdateResult() {
/* 33 */     return this.updateResult;
/*    */   }
/*    */   
/*    */   public String getVersionName() {
/* 37 */     return this.versionName;
/*    */   }
/*    */   
/*    */   public String getVersionId() {
/* 41 */     return this.versionId;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\spigo\\updater\VaroUpdateResultSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */