/*    */ package de.cuuky.varo.logger.logger;
/*    */ 
/*    */ import de.cuuky.varo.logger.VaroLogger;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ 
/*    */ public class ChatLogger
/*    */   extends VaroLogger {
/*    */   public enum ChatLogType {
/*  9 */     CHAT("CHAT"),
/* 10 */     PRIVATE_CHAT("PRIVATECHAT"),
/* 11 */     TEAMCHAT("TEAMCHAT");
/*    */     
/*    */     private String name;
/*    */     
/*    */     ChatLogType(String name) {
/* 16 */       this.name = name;
/*    */     }
/*    */     
/*    */     public String getName() {
/* 20 */       return this.name; } public static ChatLogType getType(String s) {
/*    */       byte b;
/*    */       int i;
/*    */       ChatLogType[] arrayOfChatLogType;
/* 24 */       for (i = (arrayOfChatLogType = values()).length, b = 0; b < i; ) { ChatLogType type = arrayOfChatLogType[b];
/* 25 */         if (type.getName().equalsIgnoreCase(s))
/* 26 */           return type;  b++; }
/*    */       
/* 28 */       return null;
/*    */     }
/*    */   }
/*    */   
/*    */   public ChatLogger(String name) {
/* 33 */     super(name, false);
/*    */   }
/*    */   
/*    */   public void println(ChatLogType type, String message) {
/* 37 */     message = JavaUtils.replaceAllColors(message);
/*    */     
/* 39 */     String log = String.valueOf(getCurrentDate()) + " || " + "[" + type.getName() + "] " + message;
/*    */     
/* 41 */     this.pw.println(log);
/* 42 */     this.logs.add(log);
/*    */     
/* 44 */     this.pw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\logger\logger\ChatLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */