/*    */ package de.cuuky.varo.logger.logger;
/*    */ 
/*    */ import de.cuuky.varo.logger.VaroLogger;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class ConsoleLogger
/*    */   extends VaroLogger {
/*    */   public ConsoleLogger(String name) {
/* 11 */     super(name, false);
/*    */     
/* 13 */     startListening();
/*    */   }
/*    */   
/*    */   private void startListening() {
/* 17 */     System.setOut(new PrintStream(System.out)
/*    */         {
/*    */           public void println(Object x)
/*    */           {
/* 21 */             super.println(x);
/*    */             
/* 23 */             if (x == null) {
/* 24 */               ConsoleLogger.this.println("null");
/*    */             } else {
/* 26 */               ConsoleLogger.this.println(x.toString());
/*    */             } 
/*    */           }
/*    */           
/*    */           public void println(String x) {
/* 31 */             super.println(x);
/*    */             
/* 33 */             ConsoleLogger.this.println(x);
/*    */           }
/*    */         });
/*    */     
/* 37 */     System.setErr(new PrintStream(System.err)
/*    */         {
/*    */           public void println(Object x)
/*    */           {
/* 41 */             super.println(x);
/*    */             
/* 43 */             ConsoleLogger.this.println(x.toString());
/*    */           }
/*    */ 
/*    */           
/*    */           public void println(String x) {
/* 48 */             super.println(x);
/*    */             
/* 50 */             ConsoleLogger.this.println(x);
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public void println(String line) {
/* 56 */     line = "[" + getCurrentDate() + "] " + JavaUtils.replaceAllColors(line);
/*    */     
/* 58 */     this.pw.println(line);
/* 59 */     this.logs.add(line);
/*    */     
/* 61 */     this.pw.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\logger\logger\ConsoleLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */