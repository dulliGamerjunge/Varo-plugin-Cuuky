/*    */ package de.cuuky.varo.logger;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.text.DateFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import java.util.Scanner;
/*    */ 
/*    */ public abstract class VaroLogger
/*    */ {
/*    */   protected File file;
/*    */   protected FileWriter fw;
/*    */   protected ArrayList<String> logs;
/*    */   protected PrintWriter pw;
/*    */   protected Scanner scanner;
/*    */   
/*    */   public VaroLogger(String name, boolean loadPrevious) {
/* 22 */     this.file = new File("plugins/Varo/logs/", String.valueOf(name) + ".yml");
/* 23 */     this.logs = new ArrayList<>();
/*    */     
/*    */     try {
/* 26 */       if (!this.file.exists()) {
/* 27 */         (new File(this.file.getParent())).mkdirs();
/* 28 */         this.file.createNewFile();
/*    */       } 
/*    */       
/* 31 */       this.fw = new FileWriter(this.file, true);
/* 32 */       this.pw = new PrintWriter(this.fw);
/* 33 */       this.scanner = new Scanner(this.file);
/*    */       
/* 35 */       if (loadPrevious)
/* 36 */         while (this.scanner.hasNextLine())
/* 37 */           this.logs.add(this.scanner.nextLine());  
/* 38 */     } catch (IOException e) {
/* 39 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   protected String getCurrentDate() {
/* 44 */     DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
/* 45 */     Date date = new Date();
/*    */     
/* 47 */     return dateFormat.format(date);
/*    */   }
/*    */   
/*    */   public File getFile() {
/* 51 */     return this.file;
/*    */   }
/*    */   
/*    */   public ArrayList<String> getLogs() {
/* 55 */     return this.logs;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\logger\VaroLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */