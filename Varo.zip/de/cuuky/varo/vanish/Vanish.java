/*    */ package de.cuuky.varo.vanish;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class Vanish {
/*    */   private static class VanishListener
/*    */     implements Listener {
/*    */     private VanishListener() {}
/*    */     
/*    */     @EventHandler
/*    */     public void onPlayerJoin(PlayerJoinEvent event) {
/* 20 */       for (Vanish vanish : Vanish.vanishes)
/* 21 */         vanish.hideFor(event.getPlayer()); 
/*    */     }
/*    */     
/*    */     @EventHandler
/*    */     public void onPlayerLeave(PlayerQuitEvent event) {
/* 26 */       Vanish v = Vanish.getVanish(event.getPlayer());
/* 27 */       if (v != null) {
/* 28 */         v.remove();
/*    */       }
/* 30 */       for (Vanish vanish : Vanish.vanishes) {
/* 31 */         vanish.unHideFor(event.getPlayer());
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 38 */   private static ArrayList<Vanish> vanishes = new ArrayList<>();
/*    */   static {
/* 40 */     Bukkit.getPluginManager().registerEvents(new VanishListener(null), (Plugin)Main.getInstance());
/*    */   }
/*    */   
/*    */   private Player player;
/*    */   
/*    */   public Vanish(Player player) {
/* 46 */     this.player = player;
/*    */     
/* 48 */     hide();
/* 49 */     vanishes.add(this);
/*    */   }
/*    */   
/*    */   private void hide() {
/* 53 */     for (Player allplayer : Bukkit.getOnlinePlayers())
/* 54 */       allplayer.hidePlayer(this.player); 
/*    */   }
/*    */   
/*    */   private void unhide() {
/* 58 */     for (Player allplayer : Bukkit.getOnlinePlayers())
/* 59 */       allplayer.showPlayer(this.player); 
/*    */   }
/*    */   
/*    */   public void hideFor(Player player) {
/* 63 */     player.hidePlayer(this.player);
/*    */   }
/*    */   
/*    */   public void remove() {
/* 67 */     unhide();
/* 68 */     vanishes.remove(this);
/*    */   }
/*    */   
/*    */   public void unHideFor(Player player) {
/* 72 */     player.showPlayer(this.player);
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 76 */     return this.player;
/*    */   }
/*    */   
/*    */   public static Vanish getVanish(Player player) {
/* 80 */     for (Vanish vanish : vanishes) {
/* 81 */       if (vanish.getPlayer().equals(player))
/* 82 */         return vanish; 
/*    */     } 
/* 84 */     return null;
/*    */   }
/*    */   
/*    */   public static ArrayList<Vanish> getVanishes() {
/* 88 */     return vanishes;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\vanish\Vanish.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */