/*     */ package de.cuuky.varo.clientadapter.scoreboard;
/*     */ 
/*     */ import de.cuuky.varo.clientadapter.BoardHandler;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.scoreboard.DisplaySlot;
/*     */ import org.bukkit.scoreboard.Objective;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScoreboardHandler
/*     */   implements BoardHandler
/*     */ {
/*     */   private String header;
/*     */   private HashMap<Player, String> headers;
/*     */   private HashMap<Player, ArrayList<String>> replaces;
/*     */   private ArrayList<String> scoreboardLines;
/*     */   
/*     */   public ScoreboardHandler() {
/*  33 */     updateList();
/*     */   }
/*     */   
/*     */   private String prepareScoreboardStatement(Scoreboard board, int index, String line) {
/*  37 */     String teamname = "team-" + getAsTeam(index);
/*  38 */     Team team = board.getTeam(teamname);
/*  39 */     if (team == null) {
/*  40 */       team = board.registerNewTeam(teamname);
/*     */     }
/*  42 */     String playerName = getAsTeam(index);
/*  43 */     String[] pas = getPrefixAndSuffix(line);
/*  44 */     team.setPrefix(pas[0]);
/*  45 */     team.setSuffix(pas[1]);
/*  46 */     team.addPlayer(new FakeOfflinePlayer(playerName));
/*     */     
/*  48 */     return playerName;
/*     */   }
/*     */   
/*     */   private String[] getPrefixAndSuffix(String value) {
/*  52 */     String prefix = getPrefix(value);
/*  53 */     String suffix = "";
/*     */     
/*  55 */     if (prefix.substring(prefix.length() - 1, prefix.length()).equals("§")) {
/*  56 */       prefix = prefix.substring(0, prefix.length() - 1);
/*  57 */       suffix = getPrefix("§" + getSuffix(value));
/*     */     } else {
/*  59 */       suffix = getPrefix(String.valueOf(ChatColor.getLastColors(prefix)) + getSuffix(value));
/*     */     } 
/*  61 */     return new String[] { prefix, suffix };
/*     */   }
/*     */   
/*     */   private String getPrefix(String value) {
/*  65 */     return (value.length() > 16) ? value.substring(0, 16) : value;
/*     */   }
/*     */   
/*     */   private String getSuffix(String value) {
/*  69 */     value = (value.length() > 32) ? value.substring(0, 32) : value;
/*     */     
/*  71 */     return (value.length() > 16) ? value.substring(16) : "";
/*     */   }
/*     */   
/*     */   private String getAsTeam(int index) {
/*  75 */     return ChatColor.values()[index].toString();
/*     */   }
/*     */   
/*     */   private String getConvString(String line, VaroPlayer vp) {
/*  79 */     if ((line.contains("%min%") || line.contains("%sec%")) && 
/*  80 */       ConfigSetting.PLAY_TIME.getValueAsInt() < 1) {
/*  81 */       return "§cUnlimited";
/*     */     }
/*  83 */     line = ConfigMessages.getValue(line, vp);
/*     */     
/*  85 */     return line;
/*     */   }
/*     */   
/*     */   private void saveFile(YamlConfiguration config, File file) {
/*     */     try {
/*  90 */       config.save(file);
/*  91 */     } catch (IOException e) {
/*  92 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getHeader() {
/*  97 */     return "Die Liste aller Placeholder kannst du mit /varo ph aufrufen!";
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateList() {
/* 102 */     this.scoreboardLines = new ArrayList<>();
/* 103 */     this.replaces = new HashMap<>();
/* 104 */     this.headers = new HashMap<>();
/*     */     
/* 106 */     File file = new File("plugins/Varo/config", "scoreboard.yml");
/* 107 */     YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
/*     */     
/* 109 */     ArrayList<String> scoreboard = new ArrayList<>();
/* 110 */     cfg.options().header(getHeader());
/* 111 */     cfg.options().copyDefaults(true);
/*     */     
/* 113 */     scoreboard.add("%space%");
/* 114 */     scoreboard.add("&7Team&8:");
/* 115 */     scoreboard.add("%colorcode%%team%");
/* 116 */     scoreboard.add("%space%");
/* 117 */     scoreboard.add("&7Kills&8:");
/* 118 */     scoreboard.add("%colorcode%%kills%");
/* 119 */     scoreboard.add("%space%");
/* 120 */     scoreboard.add("&7Zeit&8:");
/* 121 */     scoreboard.add("%colorcode%%min%&8:%colorcode%%sec%");
/* 122 */     scoreboard.add("%space%");
/* 123 */     scoreboard.add("&7Online: %colorcode%%online%");
/* 124 */     scoreboard.add("&7Remaining: %colorcode%%remaining%");
/* 125 */     scoreboard.add("&7Players: %colorcode%%players%");
/* 126 */     scoreboard.add("%space%");
/*     */     
/* 128 */     cfg.addDefault("header", "%projectname%");
/* 129 */     cfg.addDefault("scoreboard", scoreboard);
/*     */     
/* 131 */     if (cfg.contains("Scoreboard")) {
/* 132 */       this.scoreboardLines.addAll(cfg.getStringList("Scoreboard"));
/*     */       
/* 134 */       cfg.set("Scoreboard", null);
/* 135 */       cfg.set("scoreboard", this.scoreboardLines);
/* 136 */       saveFile(cfg, file);
/*     */     } else {
/* 138 */       this.scoreboardLines.addAll(cfg.getStringList("scoreboard"));
/*     */     } 
/* 140 */     this.header = cfg.getString("header");
/*     */     
/* 142 */     if (!file.exists()) {
/* 143 */       saveFile(cfg, file);
/*     */     }
/* 145 */     Collections.reverse(this.scoreboardLines);
/*     */     
/* 147 */     String space = "";
/* 148 */     for (int i = 0; i < this.scoreboardLines.size(); i++) {
/* 149 */       String line = this.scoreboardLines.get(i);
/* 150 */       if (line.equals("%space%")) {
/* 151 */         space = String.valueOf(space) + " ";
/* 152 */         this.scoreboardLines.set(i, space);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendScoreBoard(VaroPlayer vp) {
/* 158 */     if (!ConfigSetting.SCOREBOARD.getValueAsBoolean() || !vp.getStats().isShowScoreboard()) {
/*     */       return;
/*     */     }
/* 161 */     Player player = vp.getPlayer();
/* 162 */     Scoreboard sb = Bukkit.getServer().getScoreboardManager().getNewScoreboard();
/* 163 */     Objective obj = sb.registerNewObjective("silent", "dummy");
/*     */     
/* 165 */     this.headers.put(vp.getPlayer(), getConvString(this.header, vp));
/* 166 */     obj.setDisplayName(this.headers.get(vp.getPlayer()));
/* 167 */     obj.setDisplaySlot(DisplaySlot.SIDEBAR);
/*     */     
/* 169 */     player.setScoreboard(sb);
/*     */     
/* 171 */     this.replaces.remove(player);
/* 172 */     updatePlayer(vp);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updatePlayer(VaroPlayer player) {
/* 177 */     ArrayList<String> replacesLst = this.replaces.get(player.getPlayer());
/* 178 */     if (replacesLst == null) {
/* 179 */       this.replaces.put(player.getPlayer(), replacesLst = new ArrayList<>());
/*     */     }
/* 181 */     Scoreboard board = player.getPlayer().getScoreboard();
/* 182 */     Objective obj = board.getObjective(DisplaySlot.SIDEBAR);
/*     */     
/* 184 */     if (obj == null || !this.headers.containsKey(player.getPlayer())) {
/* 185 */       sendScoreBoard(player);
/*     */       
/*     */       return;
/*     */     } 
/* 189 */     String header = getConvString(this.header, player);
/* 190 */     if (!((String)this.headers.get(player.getPlayer())).equals(header)) {
/* 191 */       obj.setDisplayName(header);
/*     */     }
/* 193 */     if (board.getEntries().size() > this.scoreboardLines.size()) {
/* 194 */       for (Team team : board.getTeams()) {
/* 195 */         if (team.getName().startsWith("team-"))
/* 196 */           team.unregister(); 
/*     */       } 
/* 198 */       for (String s : board.getEntries()) {
/* 199 */         board.resetScores(s);
/*     */       }
/* 201 */       replacesLst.clear();
/*     */     } 
/*     */     
/* 204 */     for (int index = 0; index < this.scoreboardLines.size(); index++) {
/* 205 */       String line = getConvString(this.scoreboardLines.get(index), player);
/*     */       
/* 207 */       if (replacesLst.size() < this.scoreboardLines.size()) {
/* 208 */         obj.getScore(prepareScoreboardStatement(board, index, line)).setScore(index + 1);
/* 209 */         replacesLst.add(line);
/* 210 */       } else if (!((String)replacesLst.get(index)).equals(line)) {
/* 211 */         String sbs = prepareScoreboardStatement(board, index, line);
/* 212 */         board.resetScores(sbs);
/* 213 */         obj.getScore(sbs).setScore(index + 1);
/* 214 */         replacesLst.set(index, line);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\clientadapter\scoreboard\ScoreboardHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */