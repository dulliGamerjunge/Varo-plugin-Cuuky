/*    */ package de.cuuky.varo.clientadapter.scoreboard;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.OfflinePlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class FakeOfflinePlayer
/*    */   implements OfflinePlayer
/*    */ {
/*    */   private String name;
/*    */   
/*    */   public FakeOfflinePlayer(String name) {
/* 15 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOp() {
/* 20 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setOp(boolean arg0) {}
/*    */ 
/*    */   
/*    */   public Map<String, Object> serialize() {
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getBedSpawnLocation() {
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getFirstPlayed() {
/* 38 */     return 0L;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getLastPlayed() {
/* 43 */     return 0L;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 48 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public Player getPlayer() {
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public UUID getUniqueId() {
/* 58 */     return UUID.fromString("fbaa9566-6002-4359-b42a-f7235487f10c");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasPlayedBefore() {
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBanned() {
/* 68 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOnline() {
/* 73 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isWhitelisted() {
/* 78 */     return false;
/*    */   }
/*    */   
/*    */   public void setBanned(boolean arg0) {}
/*    */   
/*    */   public void setWhitelisted(boolean arg0) {}
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\clientadapter\scoreboard\FakeOfflinePlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */