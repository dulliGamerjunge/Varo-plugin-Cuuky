package de.cuuky.varo.clientadapter;

import de.cuuky.varo.entity.player.VaroPlayer;

public interface BoardHandler {
  void updateList();
  
  void updatePlayer(VaroPlayer paramVaroPlayer);
}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\clientadapter\BoardHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */