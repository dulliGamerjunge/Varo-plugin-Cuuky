/*    */ package de.cuuky.varo.game.world;
/*    */ 
/*    */ import de.cuuky.varo.game.world.border.VaroWorldBorder;
/*    */ import de.cuuky.varo.version.BukkitVersion;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import org.bukkit.World;
/*    */ 
/*    */ 
/*    */ public class VaroWorld
/*    */ {
/*    */   private World world;
/*    */   private VaroWorldBorder varoWorldBorder;
/*    */   
/*    */   public VaroWorld(World world) {
/* 15 */     this.world = world;
/*    */     
/* 17 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7))
/* 18 */       this.varoWorldBorder = new VaroWorldBorder(world); 
/*    */   }
/*    */   
/*    */   public World getWorld() {
/* 22 */     return this.world;
/*    */   }
/*    */   
/*    */   public VaroWorldBorder getVaroBorder() {
/* 26 */     return this.varoWorldBorder;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\world\VaroWorld.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */