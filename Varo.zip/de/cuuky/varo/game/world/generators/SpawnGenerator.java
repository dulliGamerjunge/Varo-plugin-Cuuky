/*     */ package de.cuuky.varo.game.world.generators;
/*     */ 
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import de.cuuky.varo.spawns.Spawn;
/*     */ import de.cuuky.varo.utils.BlockUtils;
/*     */ import de.cuuky.varo.version.types.Materials;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ 
/*     */ 
/*     */ public class SpawnGenerator
/*     */ {
/*     */   private String blockId;
/*     */   private String sideBlockId;
/*     */   
/*     */   private SpawnGenerator(Location location, int radius, String blockId, String sideBlockId) {
/*  19 */     this.blockId = blockId;
/*  20 */     this.sideBlockId = sideBlockId;
/*     */     
/*  22 */     for (Spawn spawn : Spawn.getSpawnsClone())
/*  23 */       spawn.delete(); 
/*     */   }
/*     */   
/*     */   public SpawnGenerator(Location location, int radius, int amount, String blockId, String sideBlockId) {
/*  27 */     this(location, radius, blockId, sideBlockId);
/*     */     
/*  29 */     int i = 0;
/*  30 */     for (Location loc : generateSpawns(location, radius, amount)) {
/*  31 */       i++;
/*  32 */       Location newLoc = loc.clone();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SpawnGenerator(Location location, int radius, boolean withTeams, String blockId, String sideBlockId) {
/*  39 */     this(location, radius, blockId, sideBlockId);
/*     */     
/*  41 */     ArrayList<Location> locations = generateSpawns(location, radius, VaroPlayer.getAlivePlayer().size());
/*  42 */     int i = 0;
/*     */     
/*  44 */     if (withTeams) {
/*  45 */       for (VaroTeam team : VaroTeam.getTeams()) {
/*  46 */         for (VaroPlayer player : team.getMember()) {
/*  47 */           if (!player.getStats().isAlive()) {
/*     */             continue;
/*     */           }
/*     */           
/*  51 */           i++;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*  56 */     for (VaroPlayer player : VaroPlayer.getAlivePlayer()) {
/*  57 */       if (Spawn.getSpawn(player) != null) {
/*     */         continue;
/*     */       }
/*     */       
/*  61 */       i++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Location setSpawnAt(Location newLoc) {
/*  66 */     if (BlockUtils.isAir(newLoc.getBlock())) {
/*  67 */       while (BlockUtils.isAir(newLoc.clone().add(0.0D, -1.0D, 0.0D).getBlock()))
/*  68 */         newLoc = newLoc.add(0.0D, -1.0D, 0.0D); 
/*     */     } else {
/*  70 */       while (!BlockUtils.isAir(newLoc.getBlock()))
/*  71 */         newLoc = newLoc.add(0.0D, 1.0D, 0.0D); 
/*     */     } 
/*  73 */     newLoc.getBlock().setType(Material.AIR);
/*  74 */     newLoc.clone().add(0.0D, -1.0D, 0.0D).getBlock().setType(Material.AIR);
/*  75 */     Materials xmat = (this.blockId != null && !this.blockId.isEmpty()) ? Materials.fromString(this.blockId) : Materials.STONE_BRICK_SLAB;
/*  76 */     BlockUtils.setBlock(newLoc.clone().add(1.0D, 0.0D, 0.0D).getBlock(), xmat);
/*  77 */     BlockUtils.setBlock(newLoc.clone().add(0.0D, 0.0D, 1.0D).getBlock(), xmat);
/*  78 */     BlockUtils.setBlock(newLoc.clone().add(-1.0D, 0.0D, 0.0D).getBlock(), xmat);
/*  79 */     BlockUtils.setBlock(newLoc.clone().add(0.0D, 0.0D, -1.0D).getBlock(), xmat);
/*     */     
/*  81 */     Materials mat = (this.sideBlockId != null && !this.sideBlockId.isEmpty()) ? Materials.fromString(this.sideBlockId) : Materials.GRASS_BLOCK;
/*  82 */     BlockUtils.setBlock(newLoc.clone().add(0.0D, -2.0D, 0.0D).getBlock(), mat);
/*  83 */     BlockUtils.setBlock(newLoc.clone().add(1.0D, -1.0D, 0.0D).getBlock(), mat);
/*  84 */     BlockUtils.setBlock(newLoc.clone().add(0.0D, -1.0D, 1.0D).getBlock(), mat);
/*  85 */     BlockUtils.setBlock(newLoc.clone().add(-1.0D, -1.0D, 0.0D).getBlock(), mat);
/*  86 */     BlockUtils.setBlock(newLoc.clone().add(0.0D, -1.0D, -1.0D).getBlock(), mat);
/*     */     
/*  88 */     return newLoc.getBlock().getLocation().add(0.5D, -1.0D, 0.5D);
/*     */   }
/*     */   
/*     */   private ArrayList<Location> generateSpawns(Location middle, double radius, int amount) {
/*  92 */     double alpha = 6.283185307179586D / amount;
/*     */     
/*  94 */     ArrayList<Location> locs = new ArrayList<>();
/*     */     
/*  96 */     for (int count = 0; count != amount; count++) {
/*  97 */       double beta = alpha * count;
/*     */       
/*  99 */       double x = radius * Math.cos(beta);
/* 100 */       double z = radius * Math.sin(beta);
/*     */       
/* 102 */       Location loc = middle.clone().add(x, 0.0D, z);
/* 103 */       locs.add(loc);
/*     */     } 
/*     */     
/* 106 */     return locs;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\world\generators\SpawnGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */