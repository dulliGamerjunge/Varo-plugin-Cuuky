/*    */ package de.cuuky.varo.game.world.border.decrease;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import java.util.Date;
/*    */ import org.apache.commons.lang.time.DateUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.scheduler.BukkitRunnable;
/*    */ 
/*    */ public class BorderDecreaseDayTimer
/*    */   implements VaroSerializeable
/*    */ {
/*    */   @VaroSerializeField(path = "nextDecrease")
/*    */   private Date nextDecrease;
/*    */   
/*    */   public BorderDecreaseDayTimer() {}
/*    */   
/*    */   public BorderDecreaseDayTimer(boolean new1) {
/* 22 */     if (!ConfigSetting.BORDER_TIME_DAY_DECREASE.getValueAsBoolean() || !Main.getVaroGame().isRunning()) {
/*    */       return;
/*    */     }
/* 25 */     generateNextDecrease();
/* 26 */     startTimer();
/* 27 */     Main.getVaroGame().setBorderDecrease(this);
/*    */   }
/*    */   
/*    */   private void generateNextDecrease() {
/* 31 */     this.nextDecrease = new Date();
/* 32 */     this.nextDecrease = DateUtils.addDays(this.nextDecrease, ConfigSetting.BORDER_TIME_DAY_DECREASE_DAYS.getValueAsInt());
/*    */   }
/*    */   
/*    */   private long getTime() {
/* 36 */     if (this.nextDecrease.before(new Date())) {
/* 37 */       return 20L;
/*    */     }
/* 39 */     return (this.nextDecrease.getTime() - (new Date()).getTime()) / 1000L * 20L;
/*    */   }
/*    */   
/*    */   private void startTimer() {
/* 43 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           
/*    */           public void run()
/*    */           {
/* 48 */             if (Main.getVaroGame().isRunning()) {
/* 49 */               Main.getVaroGame().getVaroWorldHandler().decreaseBorder(DecreaseReason.TIME_MINUTES);
/*    */             }
/* 51 */             Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new BukkitRunnable()
/*    */                 {
/*    */ 
/*    */                   
/*    */                   public void run() {}
/*    */                 }, 
/* 57 */                 20L);
/*    */           }
/* 59 */         }getTime());
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDeserializeEnd() {
/* 64 */     if (!ConfigSetting.BORDER_TIME_DAY_DECREASE.getValueAsBoolean() || !Main.getVaroGame().isRunning()) {
/*    */       return;
/*    */     }
/* 67 */     if (this.nextDecrease == null) {
/* 68 */       generateNextDecrease();
/*    */     }
/* 70 */     startTimer();
/*    */   }
/*    */   
/*    */   public void onSerializeStart() {}
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\world\border\decrease\BorderDecreaseDayTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */