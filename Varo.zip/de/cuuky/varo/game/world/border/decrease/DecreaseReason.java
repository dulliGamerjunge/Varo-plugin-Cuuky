/*    */ package de.cuuky.varo.game.world.border.decrease;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ import org.bukkit.Bukkit;
/*    */ 
/*    */ 
/*    */ public enum DecreaseReason
/*    */ {
/* 12 */   DEATH(ConfigSetting.BORDER_DEATH_DECREASE, ConfigSetting.BORDER_DEATH_DECREASE_SIZE, ConfigSetting.BORDER_DEATH_DECREASE_SPEED, null, ConfigMessages.BORDER_DECREASE_DEATH, ConfigMessages.ALERT_BORDER_DECREASED_DEATH),
/* 13 */   TIME_DAYS(ConfigSetting.BORDER_TIME_DAY_DECREASE, ConfigSetting.BORDER_TIME_DAY_DECREASE_SIZE, ConfigSetting.BORDER_TIME_DAY_DECREASE_SPEED, ConfigSetting.BORDER_TIME_DAY_DECREASE_DAYS, ConfigMessages.BORDER_DECREASE_DAYS, ConfigMessages.ALERT_BORDER_DECREASED_TIME_DAYS),
/* 14 */   TIME_MINUTES(ConfigSetting.BORDER_TIME_MINUTE_DECREASE, ConfigSetting.BORDER_TIME_MINUTE_DECREASE_SIZE, ConfigSetting.BORDER_TIME_MINUTE_DECREASE_SPEED, ConfigSetting.BORDER_TIME_MINUTE_DECREASE_MINUTES, ConfigMessages.BORDER_DECREASE_MINUTES, ConfigMessages.ALERT_BORDER_DECREASED_TIME_MINUTE);
/*    */   private ConfigMessages broadcast;
/*    */   private ConfigMessages alert;
/*    */   private ConfigSetting enabled;
/*    */   
/*    */   DecreaseReason(ConfigSetting enabled, ConfigSetting size, ConfigSetting speed, ConfigSetting time, ConfigMessages broadcast, ConfigMessages alert) {
/* 20 */     this.enabled = enabled;
/* 21 */     this.size = size;
/* 22 */     this.speed = speed;
/* 23 */     this.time = time;
/* 24 */     this.broadcast = broadcast;
/* 25 */     this.alert = alert;
/*    */   }
/*    */   private ConfigSetting size; private ConfigSetting speed; private ConfigSetting time;
/*    */   public double getDecreaseSpeed() {
/*    */     try {
/* 30 */       return this.speed.getValueAsInt();
/* 31 */     } catch (IllegalArgumentException e) {
/* 32 */       return this.speed.getValueAsDouble();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void postAlert() {
/* 37 */     Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.BORDER, this.alert.getValue().replace("%size%", String.valueOf(getSize())).replace("%speed%", String.valueOf(getDecreaseSpeed())).replace("%days%", (this.time != null) ? String.valueOf(this.time.getValueAsInt()) : "").replace("%minutes%", (this.time != null) ? String.valueOf(this.time.getValueAsInt()) : ""));
/*    */   }
/*    */   
/*    */   public void postBroadcast() {
/* 41 */     Bukkit.broadcastMessage(this.broadcast.getValue().replace("%size%", String.valueOf(getSize())).replace("%speed%", String.valueOf(getDecreaseSpeed())).replace("%days%", (this.time != null) ? String.valueOf(this.time.getValueAsInt()) : "").replace("%minutes%", (this.time != null) ? String.valueOf(this.time.getValueAsInt()) : ""));
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 45 */     return this.size.getValueAsInt();
/*    */   }
/*    */   
/*    */   public int getTime() {
/* 49 */     return this.time.getValueAsInt();
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 53 */     return this.enabled.getValueAsBoolean();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\world\border\decrease\DecreaseReason.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */