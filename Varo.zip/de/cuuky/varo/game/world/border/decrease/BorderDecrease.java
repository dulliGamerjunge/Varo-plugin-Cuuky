/*    */ package de.cuuky.varo.game.world.border.decrease;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.game.world.VaroWorldHandler;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BorderDecrease
/*    */ {
/*    */   private static boolean running = false;
/*    */   private double amount;
/* 18 */   private static ArrayList<BorderDecrease> decreases = new ArrayList<>();
/*    */   
/*    */   static {
/* 21 */     startShrinking();
/*    */   }
/*    */ 
/*    */   
/*    */   private double bps;
/*    */   
/*    */   public BorderDecrease(double amount, double bps) {
/* 28 */     this.amount = amount;
/* 29 */     this.bps = bps;
/*    */     
/* 31 */     decreases.add(this);
/*    */   }
/*    */   private Runnable startHook; private Runnable finishHook;
/*    */   private void waitForBorder(double d) {
/*    */     try {
/* 36 */       Thread.sleep((long)(d * 1000.0D) + 1000L);
/* 37 */     } catch (InterruptedException e) {
/* 38 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void shrink() {
/* 43 */     VaroWorldHandler worldHandler = Main.getVaroGame().getVaroWorldHandler();
/*    */     
/* 45 */     int minsize = ConfigSetting.MIN_BORDER_SIZE.getValueAsInt();
/* 46 */     double size = worldHandler.getBorderSize(null);
/* 47 */     if (size <= minsize) {
/* 48 */       Bukkit.broadcastMessage(ConfigMessages.BORDER_MINIMUM_REACHED.getValue());
/* 49 */       remove();
/*    */       
/*    */       return;
/*    */     } 
/* 53 */     this.startHook.run();
/* 54 */     if (minsize > 0) {
/* 55 */       if ((int)(size - this.amount) < minsize) {
/* 56 */         worldHandler.setBorderSize(minsize, (long)((size - minsize) / this.bps), null);
/* 57 */         waitForBorder((size - minsize) / this.bps);
/*    */       } else {
/* 59 */         worldHandler.setBorderSize(size - this.amount, (long)(this.amount / this.bps), null);
/* 60 */         waitForBorder(this.amount / this.bps);
/*    */       } 
/*    */     }
/* 63 */     this.finishHook.run();
/* 64 */     remove();
/*    */   }
/*    */   
/*    */   public void remove() {
/* 68 */     decreases.remove(this);
/*    */   }
/*    */   
/*    */   public double getBps() {
/* 72 */     return this.bps;
/*    */   }
/*    */   
/*    */   public void setFinishHook(Runnable finishHook) {
/* 76 */     this.finishHook = finishHook;
/*    */   }
/*    */   
/*    */   public void setStartHook(Runnable startHook) {
/* 80 */     this.startHook = startHook;
/*    */   }
/*    */   
/*    */   private static void startShrinking() {
/* 84 */     Bukkit.getScheduler().scheduleAsyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           
/*    */           public void run()
/*    */           {
/* 89 */             if (BorderDecrease.running) {
/*    */               return;
/*    */             }
/* 92 */             for (int i = 0; i < BorderDecrease.decreases.size(); i++) {
/* 93 */               BorderDecrease.running = true;
/* 94 */               ((BorderDecrease)BorderDecrease.decreases.get(i)).shrink();
/*    */             } 
/*    */             
/* 97 */             BorderDecrease.running = false;
/*    */           }
/* 99 */         }1L, 20L);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\world\border\decrease\BorderDecrease.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */