/*    */ package de.cuuky.varo.game.world.border.decrease;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class BorderDecreaseMinuteTimer
/*    */ {
/*    */   private int decreaseScheduler;
/*    */   
/*    */   public BorderDecreaseMinuteTimer() {
/* 15 */     if (!DecreaseReason.TIME_MINUTES.isEnabled()) {
/*    */       return;
/*    */     }
/* 18 */     this.timer = DecreaseReason.TIME_MINUTES.getTime() * 60;
/* 19 */     this.secondsPassed = this.timer;
/* 20 */     startScheduling();
/*    */   }
/*    */   private int secondsPassed; private int timer;
/*    */   private void startScheduling() {
/* 24 */     this.decreaseScheduler = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 28 */             if ((Main.getVaroGame().getGameState() != GameState.STARTED && !Main.getVaroGame().isStarting()) || !DecreaseReason.TIME_MINUTES.isEnabled()) {
/* 29 */               BorderDecreaseMinuteTimer.this.remove();
/*    */               
/*    */               return;
/*    */             } 
/* 33 */             if (BorderDecreaseMinuteTimer.this.secondsPassed == 0) {
/* 34 */               Main.getVaroGame().getVaroWorldHandler().decreaseBorder(DecreaseReason.TIME_MINUTES);
/* 35 */               BorderDecreaseMinuteTimer.this.secondsPassed = BorderDecreaseMinuteTimer.this.timer;
/* 36 */             } else if (BorderDecreaseMinuteTimer.this.secondsPassed % ConfigSetting.BORDER_TIME_MINUTE_BC_INTERVAL.getValueAsInt() == 0 && BorderDecreaseMinuteTimer.this.secondsPassed != BorderDecreaseMinuteTimer.this.timer) {
/* 37 */               Bukkit.broadcastMessage(ConfigMessages.BORDER_MINUTE_TIME_UPDATE.getValue().replace("%minutes%", BorderDecreaseMinuteTimer.this.getCountdownMin(BorderDecreaseMinuteTimer.this.secondsPassed)).replace("%seconds%", BorderDecreaseMinuteTimer.this.getCountdownSec(BorderDecreaseMinuteTimer.this.secondsPassed)).replace("%size%", String.valueOf(ConfigSetting.BORDER_TIME_MINUTE_DECREASE_SIZE.getValueAsInt())));
/*    */             } 
/* 39 */             BorderDecreaseMinuteTimer.this.secondsPassed = BorderDecreaseMinuteTimer.this.secondsPassed - 1;
/*    */           }
/* 41 */         }20L, 20L);
/*    */   }
/*    */   
/*    */   private String getCountdownMin(int sec) {
/* 45 */     int min = sec / 60;
/*    */     
/* 47 */     if (min < 10) {
/* 48 */       return "0" + min;
/*    */     }
/* 50 */     return (new StringBuilder(String.valueOf(min))).toString();
/*    */   }
/*    */   
/*    */   private String getCountdownSec(int sec) {
/* 54 */     sec %= 60;
/*    */     
/* 56 */     if (sec < 10) {
/* 57 */       return "0" + sec;
/*    */     }
/* 59 */     return (new StringBuilder(String.valueOf(sec))).toString();
/*    */   }
/*    */   
/*    */   public void remove() {
/* 63 */     Bukkit.getScheduler().cancelTask(this.decreaseScheduler);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\world\border\decrease\BorderDecreaseMinuteTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */