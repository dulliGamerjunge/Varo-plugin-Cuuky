/*     */ package de.cuuky.varo.game.world.border;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class VaroWorldBorder {
/*     */   private static Method setCenterMethod;
/*     */   private static Method getCenterMethod;
/*     */   private static Method setSizeMethod;
/*     */   
/*     */   static {
/*  22 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7))
/*     */       
/*     */       try {
/*  25 */         Class<?> borderClass = Class.forName("org.bukkit.WorldBorder");
/*     */         
/*  27 */         setCenterMethod = borderClass.getDeclaredMethod("setCenter", new Class[] { Location.class });
/*  28 */         getCenterMethod = borderClass.getDeclaredMethod("getCenter", new Class[0]);
/*  29 */         setSizeMethod = borderClass.getDeclaredMethod("setSize", new Class[] { double.class, long.class });
/*  30 */         getSizeMethod = borderClass.getDeclaredMethod("getSize", new Class[0]);
/*  31 */       } catch (ClassNotFoundException|NoSuchMethodException|SecurityException e) {
/*  32 */         e.printStackTrace();
/*     */       }  
/*     */   }
/*     */   
/*     */   private static Method getSizeMethod;
/*     */   private World world;
/*     */   private Object border;
/*     */   private HashMap<Player, Double> distances;
/*     */   
/*     */   public VaroWorldBorder(World world) {
/*  42 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*  45 */     this.world = world;
/*  46 */     this.distances = new HashMap<>();
/*     */     
/*  48 */     loadBorder();
/*  49 */     startCalculating();
/*     */   }
/*     */   
/*     */   private void loadBorder() {
/*     */     try {
/*  54 */       this.border = this.world.getClass().getDeclaredMethod("getWorldBorder", new Class[0]).invoke(this.world, new Object[0]);
/*  55 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*  56 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private double getDistanceToBorder(Player player) {
/*  61 */     Location center, playerLoc = player.getLocation();
/*     */ 
/*     */     
/*  64 */     double size = 0.0D;
/*     */     
/*     */     try {
/*  67 */       center = getCenter();
/*  68 */       size = getBorderSize() / 2.0D;
/*  69 */     } catch (Exception e) {
/*  70 */       e.printStackTrace();
/*  71 */       return -1.0D;
/*     */     } 
/*     */     
/*  74 */     ArrayList<Double> distanceArray = new ArrayList<>();
/*  75 */     double playerDifferenceX = playerLoc.getX() - center.getX();
/*  76 */     double playerDifferenceZ = playerLoc.getZ() - center.getZ();
/*  77 */     distanceArray.add(Double.valueOf(Math.abs(playerDifferenceX + size)));
/*  78 */     distanceArray.add(Double.valueOf(Math.abs(playerDifferenceX - size)));
/*  79 */     distanceArray.add(Double.valueOf(Math.abs(playerDifferenceZ + size)));
/*  80 */     distanceArray.add(Double.valueOf(Math.abs(playerDifferenceZ - size)));
/*  81 */     double nearest = Double.MAX_VALUE;
/*  82 */     for (Iterator<Double> iterator = distanceArray.iterator(); iterator.hasNext(); ) { double distance = ((Double)iterator.next()).doubleValue();
/*  83 */       if (distance < nearest)
/*  84 */         nearest = distance;  }
/*     */     
/*  86 */     return Math.round(nearest);
/*     */   }
/*     */   
/*     */   private void startCalculating() {
/*  90 */     Bukkit.getScheduler().scheduleAsyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  94 */             for (Player player : VersionUtils.getOnlinePlayer())
/*  95 */               VaroWorldBorder.this.distances.put(player, Double.valueOf(VaroWorldBorder.this.getDistanceToBorder(player))); 
/*     */           }
/*  97 */         }20L, 20L);
/*     */   }
/*     */   
/*     */   public Location getCenter() {
/*     */     try {
/* 102 */       return (Location)getCenterMethod.invoke(this.border, new Object[0]);
/* 103 */     } catch (Exception e) {
/* 104 */       e.printStackTrace();
/*     */ 
/*     */       
/* 107 */       return null;
/*     */     } 
/*     */   }
/*     */   public double getBorderDistanceTo(Player p) {
/* 111 */     if (p == null || this.distances == null || !this.distances.containsKey(p)) {
/* 112 */       return 0.0D;
/*     */     }
/* 114 */     return ((Double)this.distances.get(p)).doubleValue();
/*     */   }
/*     */   
/*     */   public double getBorderSize() {
/*     */     try {
/* 119 */       return ((Double)getSizeMethod.invoke(this.border, new Object[0])).doubleValue();
/* 120 */     } catch (Exception e) {
/* 121 */       e.printStackTrace();
/*     */ 
/*     */       
/* 124 */       return 0.0D;
/*     */     } 
/*     */   }
/*     */   public void setBorderCenter(Location loc) {
/*     */     try {
/* 129 */       setCenterMethod.invoke(this.border, new Object[] { loc });
/* 130 */     } catch (Exception e) {
/* 131 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setBorderSize(double size, long time) {
/*     */     try {
/* 137 */       setSizeMethod.invoke(this.border, new Object[] { Double.valueOf(size), Long.valueOf(time) });
/* 138 */     } catch (Exception e) {
/* 139 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\world\border\VaroWorldBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */