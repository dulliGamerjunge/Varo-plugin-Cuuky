/*    */ package de.cuuky.varo.game.world.schematic;
/*    */ 
/*    */ import com.sk89q.worldedit.EditSession;
/*    */ import com.sk89q.worldedit.EditSessionFactory;
/*    */ import com.sk89q.worldedit.WorldEdit;
/*    */ import com.sk89q.worldedit.bukkit.BukkitWorld;
/*    */ import com.sk89q.worldedit.extent.Extent;
/*    */ import com.sk89q.worldedit.extent.clipboard.Clipboard;
/*    */ import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
/*    */ import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
/*    */ import com.sk89q.worldedit.function.operation.Operation;
/*    */ import com.sk89q.worldedit.function.operation.Operations;
/*    */ import com.sk89q.worldedit.session.ClipboardHolder;
/*    */ import com.sk89q.worldedit.session.PasteBuilder;
/*    */ import com.sk89q.worldedit.world.World;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.lang.reflect.Method;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchematicLoader
/*    */ {
/*    */   private static Class<?> blockVectorClass;
/*    */   private static Class<?> clipboardFormatsClass;
/*    */   private static Class<?> cuboidClipClass;
/*    */   private static Class<?> localWorldClass;
/*    */   private static boolean old;
/*    */   private static Class<?> vectorClass;
/*    */   private File file;
/*    */   
/*    */   static {
/*    */     try {
/* 38 */       clipboardFormatsClass = Class.forName("com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats");
/* 39 */       blockVectorClass = Class.forName("com.sk89q.worldedit.math.BlockVector3");
/* 40 */       old = false;
/* 41 */     } catch (Exception|Error exception) {}
/*    */     
/*    */     try {
/* 44 */       vectorClass = Class.forName("com.sk89q.worldedit.Vector");
/* 45 */       cuboidClipClass = Class.forName("com.sk89q.worldedit.CuboidClipboard");
/* 46 */       localWorldClass = Class.forName("com.sk89q.worldedit.LocalWorld");
/* 47 */       old = true;
/* 48 */     } catch (Exception|Error exception) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SchematicLoader(File file) {
/* 54 */     this.file = file;
/*    */   }
/*    */   
/*    */   public void paste(Location location) {
/* 58 */     if (!old) {
/*    */       try {
/* 60 */         ClipboardFormat format = (ClipboardFormat)clipboardFormatsClass.getDeclaredMethod("findByFile", new Class[] { File.class }).invoke((Object)null, new Object[] { this.file });
/* 61 */         Clipboard clipboard = null;
/* 62 */         ClipboardReader reader = format.getReader(new FileInputStream(this.file));
/* 63 */         clipboard = (Clipboard)reader.getClass().getDeclaredMethod("read", new Class[0]).invoke(reader, (Object[])null);
/*    */         
/* 65 */         EditSessionFactory factory = WorldEdit.getInstance().getEditSessionFactory();
/* 66 */         Method m = factory.getClass().getDeclaredMethod("getEditSession", new Class[] { World.class, int.class });
/* 67 */         m.setAccessible(true);
/* 68 */         EditSession editSession = (EditSession)m.invoke(factory, new Object[] { new BukkitWorld(location.getWorld()), Integer.valueOf(-1) });
/*    */         
/* 70 */         ClipboardHolder cholder = ClipboardHolder.class.getConstructor(new Class[] { Clipboard.class }).newInstance(new Object[] { clipboard });
/*    */         
/* 72 */         Object vector3 = blockVectorClass.getDeclaredMethod("at", new Class[] { int.class, int.class, int.class }).invoke((Object)null, new Object[] { Integer.valueOf(location.getBlockX()), Integer.valueOf(location.getBlockY()), Integer.valueOf(location.getBlockZ()) });
/*    */         
/* 74 */         Object paste = cholder.getClass().getDeclaredMethod("createPaste", new Class[] { Extent.class }).invoke(cholder, new Object[] { editSession });
/* 75 */         Object to = paste.getClass().getDeclaredMethod("to", new Class[] { vector3.getClass() }).invoke(paste, new Object[] { vector3 });
/*    */         
/* 77 */         Operation operation = ((PasteBuilder)to).ignoreAirBlocks(false).build();
/*    */         
/* 79 */         Operations.complete(operation);
/* 80 */         editSession.getClass().getDeclaredMethod("flushSession", new Class[0]).invoke(editSession, (Object[])null);
/* 81 */       } catch (Exception e) {
/* 82 */         e.printStackTrace();
/*    */       } 
/*    */     } else {
/*    */       try {
/* 86 */         Object origin = vectorClass.getDeclaredMethod("toBlockPoint", new Class[] { double.class, double.class, double.class }).invoke((Object)null, new Object[] { Double.valueOf(location.getX()), Double.valueOf(location.getY()), Double.valueOf(location.getZ()) });
/*    */         
/* 88 */         EditSession es = EditSession.class.getConstructor(new Class[] { localWorldClass, int.class }).newInstance(new Object[] { new BukkitWorld(location.getWorld()), Integer.valueOf(999999999) });
/*    */         
/* 90 */         Object clipboard = cuboidClipClass.getDeclaredMethod("loadSchematic", new Class[] { File.class }).invoke((Object)null, new Object[] { this.file });
/* 91 */         clipboard.getClass().getMethod("paste", new Class[] { es.getClass(), vectorClass, boolean.class }).invoke(clipboard, new Object[] { es, origin, Boolean.valueOf(false) });
/* 92 */       } catch (Exception e2) {
/* 93 */         e2.printStackTrace();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\world\schematic\SchematicLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */