/*    */ package de.cuuky.varo.game.suro;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.listener.helper.cancelable.CancelAbleType;
/*    */ import de.cuuky.varo.listener.helper.cancelable.VaroCancelAble;
/*    */ import de.cuuky.varo.version.types.Sounds;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ 
/*    */ public class SuroStart
/*    */ {
/*    */   private int sched;
/*    */   private ArrayList<String> titles;
/*    */   
/*    */   public SuroStart() {
/* 22 */     this.titles = new ArrayList<>();
/*    */     
/* 24 */     this.titles.add("§a%name%");
/* 25 */     this.titles.add("§6...du bist gestrandet...");
/* 26 */     this.titles.add("§c...auf einer Insel...");
/* 27 */     this.titles.add("§6...genau so wie...");
/* 28 */     this.titles.add("§c%players% weitere Spieler auch!");
/* 29 */     this.titles.add("§6Bist du bereit, §a%name%§6?");
/* 30 */     this.titles.add("§aJa?");
/* 31 */     this.titles.add("§6dann viel Glueck bei...");
/* 32 */     this.titles.add("§cMINECRAFT SURO!");
/* 33 */     this.titles.add("§cWach auf!");
/* 34 */     this.titles.add("§c10!");
/* 35 */     this.titles.add("");
/* 36 */     this.titles.add("");
/* 37 */     this.titles.add("");
/* 38 */     this.titles.add("");
/* 39 */     this.titles.add("§c5!");
/* 40 */     this.titles.add("§c4!");
/* 41 */     this.titles.add("§c3!");
/* 42 */     this.titles.add("§c2!");
/* 43 */     this.titles.add("§c1!");
/* 44 */     this.titles.add("§cGO!");
/*    */     
/* 46 */     start(60, 0, false);
/*    */   }
/*    */   
/*    */   public void start(int delay, int start, final boolean ignore) {
/* 50 */     this.sched = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable(start)
/*    */         {
/*    */           int i;
/*    */ 
/*    */           
/*    */           public void run() {
/* 56 */             if (SuroStart.this.titles.size() - 11 == this.i && !ignore) {
/* 57 */               Bukkit.getScheduler().cancelTask(SuroStart.this.sched);
/* 58 */               SuroStart.this.start(20, this.i, true);
/*    */             } 
/*    */             
/* 61 */             if (this.i >= SuroStart.this.titles.size()) {
/* 62 */               Bukkit.getScheduler().cancelTask(SuroStart.this.sched);
/* 63 */               Main.getVaroGame().setGamestate(GameState.STARTED);
/* 64 */               for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/* 65 */                 vp.getPlayer().playSound(vp.getPlayer().getLocation(), Sounds.NOTE_PLING.bukkitSound(), 1.0F, 1.0F);
/* 66 */                 vp.getPlayer().removePotionEffect(PotionEffectType.BLINDNESS);
/* 67 */                 VaroCancelAble.removeCancelAble(vp, CancelAbleType.FREEZE);
/* 68 */                 VaroCancelAble.removeCancelAble(vp, CancelAbleType.MUTE);
/* 69 */                 VaroCancelAble.removeCancelAble(vp, CancelAbleType.PROTECTION);
/*    */               } 
/*    */               
/*    */               return;
/*    */             } 
/* 74 */             for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/*    */ 
/*    */ 
/*    */ 
/*    */               
/* 79 */               vp.cleanUpPlayer();
/* 80 */               vp.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 9999, 3));
/* 81 */               if (!((String)SuroStart.this.titles.get(this.i)).isEmpty()) {
/* 82 */                 vp.getNetworkManager().sendTitle(((String)SuroStart.this.titles.get(this.i)).replace("%name%", vp.getName()).replace("%players%", String.valueOf(VaroPlayer.getAlivePlayer().size())), "");
/*    */               }
/*    */             } 
/* 85 */             this.i++;
/*    */           }
/* 87 */         }1L, delay);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\suro\SuroStart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */