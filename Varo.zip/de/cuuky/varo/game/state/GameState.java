/*    */ package de.cuuky.varo.game.state;
/*    */ 
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ 
/*    */ public enum GameState
/*    */   implements VaroSerializeable {
/*  8 */   LOBBY(
/*  9 */     "LOBBY"),
/*    */   
/* 11 */   STARTED(
/* 12 */     "STARTED"),
/*    */   
/* 14 */   END(
/* 15 */     "END");
/*    */   
/*    */   private String name;
/*    */   
/*    */   GameState(String name) {
/* 20 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 24 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDeserializeEnd() {}
/*    */ 
/*    */   
/*    */   public void onSerializeStart() {}
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\state\GameState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */