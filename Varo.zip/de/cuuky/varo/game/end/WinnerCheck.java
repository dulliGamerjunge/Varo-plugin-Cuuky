/*    */ package de.cuuky.varo.game.end;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Comparator;
/*    */ import java.util.Date;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ 
/*    */ public class WinnerCheck
/*    */ {
/*    */   private HashMap<Integer, ArrayList<VaroPlayer>> places;
/*    */   
/*    */   public WinnerCheck() {
/* 21 */     if (Main.getVaroGame().getGameState() != GameState.STARTED) {
/*    */       return;
/*    */     }
/* 24 */     check();
/*    */   }
/*    */   
/*    */   private void check() {
/* 28 */     this.places = new HashMap<>();
/* 29 */     ArrayList<VaroPlayer> alive = VaroPlayer.getAlivePlayer();
/* 30 */     if ((alive.size() > ConfigSetting.TEAMREQUEST_MAXTEAMMEMBERS.getValueAsInt() && alive.size() > 2) || alive.size() == 0) {
/*    */       return;
/*    */     }
/* 33 */     VaroPlayer lastAlive = null;
/* 34 */     for (VaroPlayer vp : alive) {
/* 35 */       if (lastAlive == null) {
/* 36 */         lastAlive = vp;
/*    */         
/*    */         continue;
/*    */       } 
/* 40 */       if (lastAlive.getTeam() == null || vp.getTeam() == null || !vp.getTeam().equals(lastAlive.getTeam())) {
/*    */         return;
/*    */       }
/*    */     } 
/* 44 */     if (lastAlive.getTeam() == null) {
/* 45 */       lastAlive.onEvent(BukkitEventType.WIN);
/* 46 */       ArrayList<VaroPlayer> first = new ArrayList<>();
/* 47 */       first.add(lastAlive);
/* 48 */       this.places.put(Integer.valueOf(1), first);
/*    */     } else {
/* 50 */       lastAlive.getTeam().getMember().forEach(member -> member.onEvent(BukkitEventType.WIN));
/* 51 */       this.places.put(Integer.valueOf(1), lastAlive.getTeam().getMember());
/*    */     } 
/*    */     
/* 54 */     Map<Date, VaroPlayer> sorted = new TreeMap<>(new Comparator<Date>()
/*    */         {
/*    */           public int compare(Date d1, Date d2) {
/* 57 */             return d1.after(d2) ? -1 : 1;
/*    */           }
/*    */         });
/*    */     
/* 61 */     for (VaroPlayer vp : VaroPlayer.getDeadPlayer()) {
/* 62 */       sorted.put(vp.getStats().getDiedAt(), vp);
/*    */     }
/* 64 */     int i = 2;
/* 65 */     for (VaroPlayer vp : sorted.values()) {
/* 66 */       if (isSorted(vp)) {
/*    */         continue;
/*    */       }
/* 69 */       if (vp.getTeam() == null) {
/* 70 */         ArrayList<VaroPlayer> first = new ArrayList<>();
/* 71 */         first.add(vp);
/* 72 */         this.places.put(Integer.valueOf(i), first);
/*    */       } else {
/* 74 */         this.places.put(Integer.valueOf(i), vp.getTeam().getMember());
/*    */       } 
/* 76 */       i++;
/*    */     } 
/*    */     
/* 79 */     Main.getVaroGame().end(this);
/*    */   }
/*    */   
/*    */   private boolean isSorted(VaroPlayer vp) {
/* 83 */     for (ArrayList<VaroPlayer> list : this.places.values()) {
/* 84 */       if (list.contains(vp))
/* 85 */         return true; 
/*    */     } 
/* 87 */     return false;
/*    */   }
/*    */   
/*    */   public HashMap<Integer, ArrayList<VaroPlayer>> getPlaces() {
/* 91 */     return this.places;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\end\WinnerCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */