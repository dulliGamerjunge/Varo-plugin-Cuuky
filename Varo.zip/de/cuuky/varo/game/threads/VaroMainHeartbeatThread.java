/*     */ package de.cuuky.varo.game.threads;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.event.VaroEvent;
/*     */ import de.cuuky.varo.event.VaroEventType;
/*     */ import de.cuuky.varo.game.VaroGame;
/*     */ import de.cuuky.varo.game.state.GameState;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.lang.time.DateUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ public class VaroMainHeartbeatThread
/*     */   implements Runnable
/*     */ {
/*     */   private int seconds;
/*     */   private int protectionTime;
/*     */   private int noKickDistance;
/*     */   
/*     */   public VaroMainHeartbeatThread() {
/*  29 */     this.seconds = 0;
/*  30 */     this.game = Main.getVaroGame();
/*     */     
/*  32 */     loadVariables();
/*     */   }
/*     */   private int playTime; private boolean showDistanceToBorder; private boolean showTimeInActionBar; private VaroGame game;
/*     */   public void loadVariables() {
/*  36 */     this.showDistanceToBorder = ConfigSetting.SHOW_DISTANCE_TO_BORDER.getValueAsBoolean();
/*  37 */     this.showTimeInActionBar = ConfigSetting.SHOW_TIME_IN_ACTIONBAR.getValueAsBoolean();
/*  38 */     this.protectionTime = ConfigSetting.JOIN_PROTECTIONTIME.getValueAsInt();
/*  39 */     this.noKickDistance = ConfigSetting.NO_KICK_DISTANCE.getValueAsInt();
/*  40 */     this.playTime = ConfigSetting.PLAY_TIME.getValueAsInt() * 60;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  46 */     this.seconds++;
/*  47 */     if (this.game.getGameState() == GameState.STARTED) {
/*  48 */       if (this.seconds == 60) {
/*  49 */         this.seconds = 0;
/*  50 */         if (ConfigSetting.KICK_AT_SERVER_CLOSE.getValueAsBoolean()) {
/*  51 */           double minutesToClose = (int)((Main.getDataManager().getOutsideTimeChecker().getDate2().getTime().getTime() - (new Date()).getTime()) / 1000L / 60L);
/*     */           
/*  53 */           if (minutesToClose == 10.0D || minutesToClose == 5.0D || minutesToClose == 3.0D || minutesToClose == 2.0D || minutesToClose == 1.0D) {
/*  54 */             Bukkit.broadcastMessage(ConfigMessages.QUIT_KICK_SERVER_CLOSE_SOON.getValue().replace("%minutes%", String.valueOf(minutesToClose)));
/*     */           }
/*  56 */           if (!Main.getDataManager().getOutsideTimeChecker().canJoin()) {
/*  57 */             for (VaroPlayer vp : VaroPlayer.getOnlinePlayer().clone()) {
/*  58 */               vp.getStats().setCountdown(0);
/*  59 */               vp.getPlayer().kickPlayer("§cDie Spielzeit ist nun vorueber!\n§7Versuche es morgen erneut");
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*  64 */       if (ConfigSetting.PLAY_TIME.isIntActivated()) {
/*  65 */         for (VaroPlayer vp : VaroPlayer.getOnlinePlayer().clone()) {
/*  66 */           if (vp.getStats().isSpectator() || vp.isAdminIgnore()) {
/*     */             continue;
/*     */           }
/*  69 */           int countdown = vp.getStats().getCountdown() - 1;
/*  70 */           Player p = vp.getPlayer();
/*  71 */           ArrayList<String> actionbar = new ArrayList<>();
/*     */           
/*  73 */           if (this.showTimeInActionBar || vp.getStats().isShowActionbarTime())
/*  74 */             actionbar.add(String.valueOf(Main.getColorCode()) + vp.getStats().getCountdownMin(countdown) + "§8:" + Main.getColorCode() + vp.getStats().getCountdownSec(countdown)); 
/*  75 */           if (this.showDistanceToBorder) {
/*  76 */             int distance = (int)Main.getVaroGame().getVaroWorldHandler().getVaroWorld(p.getWorld()).getVaroBorder().getBorderDistanceTo(p);
/*  77 */             if (!ConfigSetting.DISTANCE_TO_BORDER_REQUIRED.isIntActivated() || distance <= ConfigSetting.DISTANCE_TO_BORDER_REQUIRED.getValueAsInt()) {
/*  78 */               actionbar.add("§7Distanz zur Border: " + Main.getColorCode() + distance);
/*     */             }
/*     */           } 
/*  81 */           if (!actionbar.isEmpty()) {
/*  82 */             vp.getNetworkManager().sendActionbar(JavaUtils.getArgsToString(actionbar, "§7 | "));
/*     */           }
/*  84 */           if (countdown == this.playTime - this.protectionTime - 1 && !this.game.isFirstTime() && !VaroEvent.getEvent(VaroEventType.MASS_RECORDING).isEnabled()) {
/*  85 */             Bukkit.broadcastMessage(ConfigMessages.JOIN_PROTECTION_OVER.getValue(vp));
/*     */           }
/*  87 */           if (countdown == 30 || countdown == 10 || countdown == 5 || countdown == 4 || countdown == 3 || countdown == 2 || countdown == 1 || countdown == 0) {
/*  88 */             if (countdown == 0 && !VaroEvent.getEvent(VaroEventType.MASS_RECORDING).isEnabled()) {
/*  89 */               Bukkit.broadcastMessage(ConfigMessages.QUIT_KICK_BROADCAST.getValue(vp));
/*  90 */               vp.onEvent(BukkitEventType.KICKED);
/*  91 */               p.kickPlayer(ConfigMessages.KICK_SESSION_OVER.getValue(vp));
/*     */               continue;
/*     */             } 
/*  94 */             if (countdown == 1 && 
/*  95 */               !vp.canBeKicked(this.noKickDistance)) {
/*  96 */               vp.sendMessage(ConfigMessages.QUIT_KICK_PLAYER_NEARBY.getValue().replace("%distance%", String.valueOf(ConfigSetting.NO_KICK_DISTANCE.getValueAsInt())));
/*  97 */               countdown++;
/*     */             } 
/*     */             
/* 100 */             Bukkit.broadcastMessage(ConfigMessages.QUIT_KICK_IN_SECONDS.getValue().replace("%player%", vp.getName()).replace("%countdown%", (countdown == 1) ? "einer" : String.valueOf(countdown)));
/*     */           } 
/*     */ 
/*     */           
/* 104 */           vp.getStats().setCountdown(countdown);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 109 */     for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/* 110 */       if (this.game.getGameState() == GameState.LOBBY) {
/* 111 */         vp.getStats().setCountdown(this.playTime);
/* 112 */         vp.setAdminIgnore(false);
/* 113 */         if (vp.getStats().getState() == PlayerState.DEAD) {
/* 114 */           vp.getStats().setState(PlayerState.ALIVE);
/*     */         }
/*     */       } 
/*     */       
/* 118 */       vp.update();
/*     */     } 
/*     */     
/* 121 */     if (ConfigSetting.SESSIONS_PER_DAY.getValueAsInt() <= 0)
/* 122 */       for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/* 123 */         if (vp.getStats().getTimeUntilAddSession() == null) {
/*     */           continue;
/*     */         }
/* 126 */         if ((new Date()).after(vp.getStats().getTimeUntilAddSession())) {
/* 127 */           vp.getStats().setSessions(vp.getStats().getSessions() + 1);
/* 128 */           if (vp.getStats().getSessions() < ConfigSetting.PRE_PRODUCE_SESSIONS.getValueAsInt() + 1) {
/* 129 */             vp.getStats().setTimeUntilAddSession(DateUtils.addHours(new Date(), ConfigSetting.JOIN_AFTER_HOURS.getValueAsInt())); continue;
/*     */           } 
/* 131 */           vp.getStats().setTimeUntilAddSession(null);
/*     */         } 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\threads\VaroMainHeartbeatThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */