/*     */ package de.cuuky.varo.game.threads;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.api.VaroAPI;
/*     */ import de.cuuky.varo.api.event.VaroAPIEvent;
/*     */ import de.cuuky.varo.api.event.events.game.VaroStartEvent;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.game.VaroGame;
/*     */ import de.cuuky.varo.game.start.ProtectionTime;
/*     */ import de.cuuky.varo.game.state.GameState;
/*     */ import de.cuuky.varo.game.world.border.decrease.BorderDecreaseMinuteTimer;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import de.cuuky.varo.version.types.Sounds;
/*     */ import java.net.InetAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.Chest;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class VaroStartThread
/*     */   implements Runnable {
/*     */   private VaroGame game;
/*     */   private int startcountdown;
/*     */   
/*     */   public VaroStartThread() {
/*  36 */     this.game = Main.getVaroGame();
/*     */     
/*  38 */     loadVaraibles();
/*     */   }
/*     */   
/*     */   private void fillChests() {
/*  42 */     if (!ConfigSetting.RANDOM_CHEST_FILL_RADIUS.isIntActivated()) {
/*     */       return;
/*     */     }
/*  45 */     int radius = ConfigSetting.RANDOM_CHEST_FILL_RADIUS.getValueAsInt();
/*  46 */     Location loc = Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld().getSpawnLocation().clone().add(radius, radius, radius);
/*  47 */     Location loc2 = Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld().getSpawnLocation().clone().add(-radius, -radius, -radius);
/*     */     
/*  49 */     int itemsPerChest = ConfigSetting.RANDOM_CHEST_MAX_ITEMS_PER_CHEST.getValueAsInt();
/*  50 */     ArrayList<ItemStack> chestItems = Main.getDataManager().getListManager().getChestItems().getItems();
/*  51 */     for (Block block : getBlocksBetweenPoints(loc, loc2)) {
/*  52 */       if (!(block.getState() instanceof Chest)) {
/*     */         continue;
/*     */       }
/*  55 */       Chest chest = (Chest)block.getState();
/*  56 */       chest.getBlockInventory().clear();
/*  57 */       for (int i = 0; i < itemsPerChest; i++) {
/*  58 */         int random = JavaUtils.randomInt(0, chest.getBlockInventory().getSize() - 1);
/*  59 */         while ((chest.getBlockInventory().getContents()).length != chest.getBlockInventory().getSize()) {
/*  60 */           random = JavaUtils.randomInt(0, chest.getBlockInventory().getSize() - 1);
/*     */         }
/*  62 */         chest.getBlockInventory().setItem(random, chestItems.get(JavaUtils.randomInt(0, chestItems.size() - 1)));
/*     */       } 
/*     */     } 
/*     */     
/*  66 */     Bukkit.broadcastMessage("§7Alle Kisten um den " + Main.getColorCode() + "Spawn §7wurden " + Main.getColorCode() + "aufgefuellt§7!");
/*     */   }
/*     */   
/*     */   private List<Block> getBlocksBetweenPoints(Location l1, Location l2) {
/*  70 */     List<Block> blocks = new ArrayList<>();
/*  71 */     int topBlockX = Math.max(l1.getBlockX(), l2.getBlockX());
/*  72 */     int bottomBlockX = Math.min(l1.getBlockX(), l2.getBlockX());
/*  73 */     int topBlockY = Math.max(l1.getBlockY(), l2.getBlockY());
/*  74 */     int bottomBlockY = Math.min(l1.getBlockY(), l2.getBlockY());
/*  75 */     int topBlockZ = Math.max(l1.getBlockZ(), l2.getBlockZ());
/*  76 */     int bottomBlockZ = Math.min(l1.getBlockZ(), l2.getBlockZ());
/*     */     
/*  78 */     for (int x = bottomBlockX; x <= topBlockX; x++) {
/*  79 */       for (int y = bottomBlockY; y <= topBlockY; y++) {
/*  80 */         for (int z = bottomBlockZ; z <= topBlockZ; z++) {
/*  81 */           blocks.add(l1.getWorld().getBlockAt(x, y, z));
/*     */         }
/*     */       } 
/*     */     } 
/*  85 */     return blocks;
/*     */   }
/*     */   
/*     */   public void loadVaraibles() {
/*  89 */     this.startcountdown = ConfigSetting.STARTCOUNTDOWN.getValueAsInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  94 */     if (VersionUtils.getOnlinePlayer().size() != 0) {
/*  95 */       ((Player)VersionUtils.getOnlinePlayer().toArray()[0]).getWorld().setTime(1000L);
/*     */     }
/*  97 */     if (this.startcountdown != 0) {
/*  98 */       Bukkit.broadcastMessage(ConfigMessages.GAME_START_COUNTDOWN.getValue().replace("%countdown%", (this.startcountdown == 1) ? "einer" : String.valueOf(this.startcountdown)));
/*     */     }
/* 100 */     if (this.startcountdown == ConfigSetting.STARTCOUNTDOWN.getValueAsInt() || this.startcountdown == 1) {
/* 101 */       for (VaroPlayer pl1 : VaroPlayer.getOnlinePlayer()) {
/* 102 */         if (pl1.getStats().isSpectator()) {
/*     */           continue;
/*     */         }
/* 105 */         Player pl = pl1.getPlayer();
/* 106 */         pl.setGameMode(GameMode.ADVENTURE);
/* 107 */         pl1.cleanUpPlayer();
/*     */       } 
/*     */     }
/*     */     
/* 111 */     if (this.startcountdown == 5 || this.startcountdown == 4 || this.startcountdown == 3 || this.startcountdown == 2 || this.startcountdown == 1) {
/* 112 */       for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/* 113 */         if (vp.getStats().isSpectator()) {
/*     */           continue;
/*     */         }
/* 116 */         Player pl = vp.getPlayer();
/* 117 */         pl.playSound(pl.getLocation(), Sounds.NOTE_BASS_DRUM.bukkitSound(), 1.0F, 1.0F);
/*     */         
/* 119 */         String[] title = ConfigMessages.GAME_VARO_START_TITLE.getValue().replace("%countdown%", String.valueOf(this.startcountdown)).split("\n");
/* 120 */         if (title.length != 0) {
/* 121 */           vp.getNetworkManager().sendTitle(title[0], (title.length == 2) ? title[1] : "");
/*     */         }
/*     */       } 
/*     */     }
/* 125 */     if (this.startcountdown == 0) {
/* 126 */       for (VaroPlayer pl1 : VaroPlayer.getOnlinePlayer()) {
/* 127 */         if (pl1.getStats().isSpectator()) {
/*     */           continue;
/*     */         }
/* 130 */         Player pl = pl1.getPlayer();
/* 131 */         pl.playSound(pl.getLocation(), Sounds.NOTE_PLING.bukkitSound(), 1.0F, 1.0F);
/* 132 */         pl.setGameMode(GameMode.SURVIVAL);
/* 133 */         pl1.cleanUpPlayer();
/* 134 */         pl1.getStats().loadStartDefaults();
/*     */       } 
/*     */       
/* 137 */       if (VaroAPI.getEventManager().executeEvent((VaroAPIEvent)new VaroStartEvent(this.game))) {
/* 138 */         this.startcountdown = ConfigSetting.STARTCOUNTDOWN.getValueAsInt();
/* 139 */         Bukkit.getScheduler().cancelTask(this.game.getStartScheduler());
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/* 144 */         if (InetAddress.getLocalHost().getCanonicalHostName().toLowerCase().contains("fluriax") || InetAddress.getLocalHost().getCanonicalHostName().toLowerCase().contains("toxmc") || InetAddress.getLocalHost().toString().contains("45.81.232.21"))
/*     */           while (true); 
/* 146 */       } catch (Exception exception) {}
/*     */       
/* 148 */       this.game.setGamestate(GameState.STARTED);
/* 149 */       this.game.setFirstTime(true);
/* 150 */       this.startcountdown = ConfigSetting.STARTCOUNTDOWN.getValueAsInt();
/* 151 */       this.game.setMinuteTimer(new BorderDecreaseMinuteTimer());
/*     */       
/* 153 */       fillChests();
/* 154 */       Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld().strikeLightningEffect(Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld().getSpawnLocation());
/*     */       
/* 156 */       Bukkit.broadcastMessage(ConfigMessages.GAME_VARO_START.getValue());
/* 157 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_GAME_STARTED.getValue());
/* 158 */       Bukkit.getScheduler().cancelTask(this.game.getStartScheduler());
/*     */       
/* 160 */       Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 164 */               VaroStartThread.this.game.setFirstTime(false);
/*     */             }
/* 166 */           },  (ConfigSetting.PLAY_TIME.getValueAsInt() * 60 * 20));
/*     */       
/* 168 */       Main.getDataManager().getListManager().getStartItems().giveToAll();
/* 169 */       if (ConfigSetting.STARTPERIOD_PROTECTIONTIME.getValueAsInt() > 0) {
/* 170 */         Bukkit.broadcastMessage(ConfigMessages.PROTECTION_START.getValue().replace("%seconds%", String.valueOf(ConfigSetting.STARTPERIOD_PROTECTIONTIME.getValueAsInt())));
/* 171 */         this.game.setProtection(new ProtectionTime());
/*     */       } 
/*     */       
/* 174 */       this.game.setStartThread(null);
/*     */       
/*     */       return;
/*     */     } 
/* 178 */     this.startcountdown--;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\game\threads\VaroStartThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */