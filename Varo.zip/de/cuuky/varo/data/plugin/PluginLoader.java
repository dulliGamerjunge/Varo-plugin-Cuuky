/*    */ package de.cuuky.varo.data.plugin;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.spigot.FileDownloader;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.bukkit.Bukkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginLoader
/*    */ {
/*    */   public PluginLoader() {
/* 17 */     loadPlugins();
/*    */   }
/*    */   
/*    */   private void loadPlugins() {
/* 21 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Checking for additional plugins to load...");
/* 22 */     boolean failed = false; byte b; int i; DownloadPlugin[] arrayOfDownloadPlugin;
/* 23 */     for (i = (arrayOfDownloadPlugin = DownloadPlugin.values()).length, b = 0; b < i; ) { DownloadPlugin dp = arrayOfDownloadPlugin[b];
/* 24 */       if (!dp.shallLoad()) {
/*    */         continue;
/*    */       }
/*    */       try {
/* 28 */         Class.forName(dp.getRequiredClassName());
/* 29 */       } catch (ClassNotFoundException e) {
/* 30 */         System.out.println(String.valueOf(Main.getConsolePrefix()) + "Das " + dp.getName() + "-Plugin wird automatisch heruntergeladen...");
/* 31 */         if (!loadAdditionalPlugin(dp.getId(), String.valueOf(dp.getName()) + ".jar")) {
/* 32 */           failed = true;
/*    */           
/*    */           continue;
/*    */         } 
/*    */       } 
/* 37 */       dp.checkedAndLoaded(); continue;
/*    */       b++; }
/*    */     
/* 40 */     if (failed) {
/* 41 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Beim Herunterladen / Initialisieren der Plugins ist ein Fehler aufgetreten.");
/* 42 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Der Server wird nun heruntergefahren. Bitte danach fahre den Server wieder hoch.");
/* 43 */       Bukkit.getServer().shutdown();
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean loadAdditionalPlugin(int resourceId, String dataName) {
/*    */     try {
/* 49 */       FileDownloader fd = new FileDownloader("http://api.spiget.org/v2/resources/" + resourceId + "/download", "plugins/" + dataName);
/*    */       
/* 51 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Downloade plugin " + dataName + "...");
/*    */       
/* 53 */       fd.startDownload();
/*    */       
/* 55 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Donwload von " + dataName + " erfolgreich abgeschlossen!");
/*    */       
/* 57 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + dataName + " wird nun geladen...");
/* 58 */       Bukkit.getPluginManager().enablePlugin(Bukkit.getPluginManager().loadPlugin(new File("plugins/" + dataName)));
/* 59 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + dataName + " wurde erfolgreich geladen!");
/* 60 */       return true;
/* 61 */     } catch (IOException|org.bukkit.plugin.UnknownDependencyException|org.bukkit.plugin.InvalidPluginException|org.bukkit.plugin.InvalidDescriptionException e) {
/* 62 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Es gab einen kritischen Fehler beim Download eines Plugins.");
/* 63 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "---------- Stack Trace ----------");
/* 64 */       e.printStackTrace();
/* 65 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "---------- Stack Trace ----------");
/* 66 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\data\plugin\PluginLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */