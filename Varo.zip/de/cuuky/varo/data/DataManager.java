/*     */ package de.cuuky.varo.data;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.alert.AlertHandler;
/*     */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*     */ import de.cuuky.varo.broadcast.Broadcaster;
/*     */ import de.cuuky.varo.clientadapter.scoreboard.ScoreboardHandler;
/*     */ import de.cuuky.varo.clientadapter.tablist.TablistHandler;
/*     */ import de.cuuky.varo.configuration.ConfigHandler;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.placeholder.MessagePlaceholder;
/*     */ import de.cuuky.varo.data.plugin.PluginLoader;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.VaroPlayerHandler;
/*     */ import de.cuuky.varo.entity.team.VaroTeamHandler;
/*     */ import de.cuuky.varo.game.VaroGameHandler;
/*     */ import de.cuuky.varo.list.VaroList;
/*     */ import de.cuuky.varo.list.VaroListManager;
/*     */ import de.cuuky.varo.logger.VaroLoggerManager;
/*     */ import de.cuuky.varo.mysql.MySQLClient;
/*     */ import de.cuuky.varo.report.ReportHandler;
/*     */ import de.cuuky.varo.serialize.VaroSerializeHandler;
/*     */ import de.cuuky.varo.spawns.SpawnHandler;
/*     */ import de.cuuky.varo.threads.daily.DailyTimer;
/*     */ import de.cuuky.varo.utils.varo.OutSideTimeChecker;
/*     */ import de.cuuky.varo.utils.varo.ServerPropertiesReader;
/*     */ import de.cuuky.varo.utils.varo.VaroUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scoreboard.DisplaySlot;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataManager
/*     */ {
/*     */   private ConfigHandler configHandler;
/*     */   private VaroGameHandler varoGameHandler;
/*     */   private VaroPlayerHandler varoPlayerHandler;
/*     */   private VaroTeamHandler varoTeamHandler;
/*     */   private SpawnHandler spawnHandler;
/*     */   private ScoreboardHandler scoreboardHandler;
/*     */   private TablistHandler tablistHandler;
/*     */   private ReportHandler reportHandler;
/*     */   private AlertHandler alertHandler;
/*     */   private OutSideTimeChecker outsideTimeChecker;
/*     */   private MySQLClient mysqlClient;
/*     */   private VaroListManager listManager;
/*     */   private VaroLoggerManager varoLoggerManager;
/*     */   private Broadcaster broadcaster;
/*     */   private DailyTimer dailyTimer;
/*     */   private ServerPropertiesReader propertiesReader;
/*     */   private PluginLoader pluginLoader;
/*     */   private boolean doSave;
/*     */   
/*     */   public DataManager() {
/*  56 */     Main.setDataManager(this);
/*     */     
/*  58 */     load();
/*  59 */     startAutoSave();
/*     */     
/*  61 */     this.doSave = true;
/*     */   }
/*     */   
/*     */   private void load() {
/*  65 */     VaroUtils.loadBlock();
/*     */     
/*  67 */     this.varoLoggerManager = new VaroLoggerManager();
/*  68 */     this.configHandler = new ConfigHandler();
/*  69 */     this.propertiesReader = new ServerPropertiesReader();
/*  70 */     this.scoreboardHandler = new ScoreboardHandler();
/*  71 */     this.tablistHandler = new TablistHandler();
/*  72 */     this.varoGameHandler = new VaroGameHandler();
/*  73 */     this.varoPlayerHandler = new VaroPlayerHandler();
/*  74 */     this.varoTeamHandler = new VaroTeamHandler();
/*  75 */     this.spawnHandler = new SpawnHandler();
/*  76 */     this.reportHandler = new ReportHandler();
/*  77 */     this.alertHandler = new AlertHandler();
/*  78 */     this.outsideTimeChecker = new OutSideTimeChecker();
/*  79 */     this.mysqlClient = new MySQLClient();
/*  80 */     this.listManager = new VaroListManager();
/*  81 */     this.broadcaster = new Broadcaster();
/*  82 */     this.dailyTimer = new DailyTimer();
/*     */     
/*  84 */     Bukkit.getServer().setSpawnRadius(ConfigSetting.SPAWN_PROTECTION_RADIUS.getValueAsInt());
/*  85 */     VaroUtils.setWorldToTime();
/*     */     
/*  87 */     VaroPlayer.getOnlinePlayer().forEach(vp -> vp.update());
/*     */     
/*  89 */     this.pluginLoader = new PluginLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   private void startAutoSave() {
/*  94 */     Bukkit.getScheduler().scheduleAsyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  98 */             DataManager.this.save();
/*     */           }
/* 100 */         },  12000L, 12000L);
/*     */   }
/*     */   
/*     */   public void reloadConfig() {
/* 104 */     VaroList.reloadLists();
/* 105 */     MessagePlaceholder.clearPlaceholder();
/* 106 */     this.configHandler.reload();
/* 107 */     this.scoreboardHandler.updateList();
/* 108 */     this.tablistHandler.updateList();
/*     */     
/* 110 */     for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/* 111 */       vp.getPlayer().getScoreboard().clearSlot(DisplaySlot.SIDEBAR);
/* 112 */       this.scoreboardHandler.sendScoreBoard(vp);
/* 113 */       if (vp.getNametag() != null)
/* 114 */         vp.getNametag().giveAll(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void save() {
/* 119 */     if (!this.doSave) {
/*     */       return;
/*     */     }
/* 122 */     VaroSerializeHandler.saveAll();
/* 123 */     VaroList.saveLists();
/*     */     
/*     */     try {
/* 126 */       BotRegister.saveAll();
/* 127 */     } catch (NoClassDefFoundError noClassDefFoundError) {}
/*     */   }
/*     */   
/*     */   public PluginLoader getPluginLoader() {
/* 131 */     return this.pluginLoader;
/*     */   }
/*     */   
/*     */   public void setDoSave(boolean doSave) {
/* 135 */     this.doSave = doSave;
/*     */   }
/*     */   
/*     */   public ServerPropertiesReader getPropertiesReader() {
/* 139 */     return this.propertiesReader;
/*     */   }
/*     */   
/*     */   public TablistHandler getTablistHandler() {
/* 143 */     return this.tablistHandler;
/*     */   }
/*     */   
/*     */   public AlertHandler getAlertHandler() {
/* 147 */     return this.alertHandler;
/*     */   }
/*     */   
/*     */   public Broadcaster getBroadcaster() {
/* 151 */     return this.broadcaster;
/*     */   }
/*     */   
/*     */   public ConfigHandler getConfigHandler() {
/* 155 */     return this.configHandler;
/*     */   }
/*     */   
/*     */   public VaroListManager getListManager() {
/* 159 */     return this.listManager;
/*     */   }
/*     */   
/*     */   public VaroLoggerManager getVaroLoggerManager() {
/* 163 */     return this.varoLoggerManager;
/*     */   }
/*     */   
/*     */   public MySQLClient getMysqlClient() {
/* 167 */     return this.mysqlClient;
/*     */   }
/*     */   
/*     */   public OutSideTimeChecker getOutsideTimeChecker() {
/* 171 */     return this.outsideTimeChecker;
/*     */   }
/*     */   
/*     */   public ReportHandler getReportHandler() {
/* 175 */     return this.reportHandler;
/*     */   }
/*     */   
/*     */   public ScoreboardHandler getScoreboardHandler() {
/* 179 */     return this.scoreboardHandler;
/*     */   }
/*     */   
/*     */   public SpawnHandler getSpawnHandler() {
/* 183 */     return this.spawnHandler;
/*     */   }
/*     */   
/*     */   public VaroGameHandler getVaroGameHandler() {
/* 187 */     return this.varoGameHandler;
/*     */   }
/*     */   
/*     */   public VaroPlayerHandler getVaroPlayerHandler() {
/* 191 */     return this.varoPlayerHandler;
/*     */   }
/*     */   
/*     */   public VaroTeamHandler getVaroTeamHandler() {
/* 195 */     return this.varoTeamHandler;
/*     */   }
/*     */   
/*     */   public DailyTimer getDailyTimer() {
/* 199 */     return this.dailyTimer;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\data\DataManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */