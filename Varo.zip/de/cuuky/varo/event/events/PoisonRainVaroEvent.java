/*    */ package de.cuuky.varo.event.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.event.VaroEvent;
/*    */ import de.cuuky.varo.event.VaroEventType;
/*    */ import de.cuuky.varo.utils.BlockUtils;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class PoisonRainVaroEvent
/*    */   extends VaroEvent {
/*    */   private int sched;
/*    */   
/*    */   public PoisonRainVaroEvent() {
/* 18 */     super(VaroEventType.POISON_RAIN, Material.ARROW, "Regen macht Schaden");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 23 */     Bukkit.getScheduler().cancelTask(this.sched);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 28 */     this.sched = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 32 */             for (Player p : VersionUtils.getOnlinePlayer()) {
/* 33 */               if (p.getWorld().hasStorm() && !p.getLocation().getBlock().getBiome().toString().contains("SAVANNA")) {
/* 34 */                 int i = p.getLocation().getBlockY(); while (true) { if (i >= p.getWorld().getMaxHeight())
/*    */                   
/*    */                   { 
/*    */                     
/* 38 */                     p.damage(0.75D); break; }  if (!BlockUtils.isAir(p.getWorld().getBlockAt(p.getLocation().getBlockX(), i, p.getLocation().getBlockZ())))
/*    */                     break;  i++; }
/*    */               
/*    */               } 
/* 42 */             }  } }1L, 20L);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\event\events\PoisonRainVaroEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */