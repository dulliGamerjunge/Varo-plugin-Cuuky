/*    */ package de.cuuky.varo.event.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.event.VaroEvent;
/*    */ import de.cuuky.varo.event.VaroEventType;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ public class MoonGravityVaroEvent
/*    */   extends VaroEvent {
/* 16 */   private int sched = -1;
/*    */   private PotionEffectType type;
/*    */   
/*    */   public MoonGravityVaroEvent() {
/* 20 */     super(VaroEventType.MOON_GRAVITY, Materials.STONE.parseMaterial(), "Mond-Gravitation\nVorsicht: Ab 1.13 moeglich.");
/*    */     
/* 22 */     this.type = PotionEffectType.getByName("SLOW_FALLING");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 27 */     if (this.type == null) {
/*    */       return;
/*    */     }
/* 30 */     Bukkit.getScheduler().cancelTask(this.sched);
/*    */     
/* 32 */     for (Player p : VersionUtils.getOnlinePlayer()) {
/* 33 */       p.removePotionEffect(PotionEffectType.getByName("SLOW_FALLING"));
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEnable() {
/* 38 */     if (this.type == null) {
/* 39 */       this.enabled = false;
/*    */       
/*    */       return;
/*    */     } 
/* 43 */     this.sched = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 47 */             for (Player p : VersionUtils.getOnlinePlayer())
/* 48 */               p.addPotionEffect(new PotionEffect(PotionEffectType.getByName("SLOW_FALLING"), 9999, 1)); 
/*    */           }
/* 50 */         }1L, 100L);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\event\events\MoonGravityVaroEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */