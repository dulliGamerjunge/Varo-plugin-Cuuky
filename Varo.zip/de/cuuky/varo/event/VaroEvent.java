/*    */ package de.cuuky.varo.event;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroEvent
/*    */ {
/* 22 */   private static ArrayList<VaroEvent> events = new ArrayList<>();
/*    */ 
/*    */   
/*    */   private VaroEventType eventType;
/*    */ 
/*    */   
/*    */   private String description;
/*    */ 
/*    */   
/*    */   private Material icon;
/*    */   
/*    */   protected boolean enabled;
/*    */ 
/*    */   
/*    */   public VaroEvent(VaroEventType eventType, Material icon, String description) {
/* 37 */     this.eventType = eventType;
/* 38 */     this.icon = icon;
/* 39 */     this.description = description;
/* 40 */     this.enabled = false;
/*    */     
/* 42 */     events.add(this);
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 46 */     return this.description;
/*    */   }
/*    */   
/*    */   public Material getIcon() {
/* 50 */     return this.icon;
/*    */   }
/*    */   
/*    */   public VaroEventType getEventType() {
/* 54 */     return this.eventType;
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 58 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 62 */     if (Main.getVaroGame().getGameState() != GameState.STARTED && enabled) {
/*    */       return;
/*    */     }
/* 65 */     if (enabled) {
/* 66 */       onEnable();
/*    */     } else {
/* 68 */       onDisable();
/*    */     } 
/* 70 */     this.enabled = enabled;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {}
/*    */   
/*    */   public void onEnable() {}
/*    */   
/*    */   public static ArrayList<VaroEvent> getEnabledEvents() {
/* 79 */     ArrayList<VaroEvent> enabledEvents = new ArrayList<>();
/* 80 */     for (VaroEvent event : events) {
/* 81 */       if (event.isEnabled())
/* 82 */         enabledEvents.add(event); 
/*    */     } 
/* 84 */     return enabledEvents;
/*    */   } public void onInteract(PlayerInteractEvent event) {}
/*    */   public void onMove(PlayerMoveEvent event) {}
/*    */   public static VaroEvent getEvent(VaroEventType eventType) {
/* 88 */     for (VaroEvent event : events) {
/* 89 */       if (event.getEventType() == eventType)
/* 90 */         return event; 
/*    */     } 
/* 92 */     return null;
/*    */   }
/*    */   
/*    */   public static ArrayList<VaroEvent> getEvents() {
/* 96 */     return events;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\event\VaroEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */