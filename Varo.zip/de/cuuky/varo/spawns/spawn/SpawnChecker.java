/*    */ package de.cuuky.varo.spawns.spawn;
/*    */ 
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.block.Biome;
/*    */ 
/*    */ 
/*    */ public class SpawnChecker
/*    */ {
/*    */   public static boolean checkSpawns(World world, int xPos, int zPos, float radius, int amount) {
/* 14 */     double alpha = 6.283185307179586D / amount;
/* 15 */     Biome biome = (new Location(world, xPos, world.getMaxHeight(), zPos)).getBlock().getBiome();
/* 16 */     if (biome != Biome.PLAINS) {
/* 17 */       return false;
/*    */     }
/* 19 */     int tolerance = ConfigSetting.WORLD_SPAWNS_GENERATE_Y_TOLERANCE.getValueAsInt();
/* 20 */     int firstY = -1;
/* 21 */     for (int count = 0; count != amount; count++) {
/* 22 */       double beta = alpha * count;
/*    */       
/* 24 */       double x = radius * Math.sin(beta);
/* 25 */       double z = radius * Math.cos(beta);
/*    */       
/* 27 */       int y = world.getMaxHeight();
/*    */       Material type;
/* 29 */       while (!(type = world.getBlockAt(xPos + (int)x, y, zPos + (int)z).getType()).isSolid()) {
/* 30 */         if (type == Material.WATER || type == Materials.WATER.parseMaterial() || type == Material.LAVA || type == Materials.LAVA.parseMaterial() || type.name().contains("LEAVES") || type.name().contains("WOOD")) {
/* 31 */           return false;
/*    */         }
/* 33 */         y--;
/*    */       } 
/*    */       
/* 36 */       if (firstY == -1) {
/* 37 */         firstY = y;
/* 38 */       } else if (((firstY > y) ? (firstY - y) : (y - firstY)) > tolerance) {
/* 39 */         return false;
/*    */       } 
/*    */     } 
/* 42 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\spawns\spawn\SpawnChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */