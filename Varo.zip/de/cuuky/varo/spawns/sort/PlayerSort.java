/*     */ package de.cuuky.varo.spawns.sort;
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.spawns.Spawn;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class PlayerSort {
/*     */   private int scheduler;
/*     */   private HashMap<Player, Location> toTeleport;
/*     */   
/*     */   public enum SortResult {
/*  19 */     NO_SPAWN,
/*  20 */     NO_SPAWN_WITH_TEAM,
/*  21 */     SORTED_WELL;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PlayerSort() {
/*  27 */     this.toTeleport = new HashMap<>();
/*     */   }
/*     */   
/*     */   private void startTeleporting() {
/*  31 */     this.scheduler = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*  33 */           int index = 0;
/*     */ 
/*     */           
/*     */           public void run() {
/*  37 */             if (this.index == PlayerSort.this.toTeleport.size()) {
/*  38 */               PlayerSort.this.toTeleport.clear();
/*  39 */               Bukkit.getScheduler().cancelTask(PlayerSort.this.scheduler);
/*     */               
/*     */               return;
/*     */             } 
/*  43 */             Player player = (Player)PlayerSort.this.toTeleport.keySet().toArray()[this.index];
/*  44 */             player.teleport((Location)PlayerSort.this.toTeleport.get(player));
/*  45 */             this.index++;
/*     */           }
/*  47 */         },  0L, 1L);
/*     */   }
/*     */   
/*     */   public SortResult sortPlayers() {
/*  51 */     ArrayList<VaroPlayer> players = VaroPlayer.getOnlinePlayer();
/*  52 */     ArrayList<VaroPlayer> playersForIterator = VaroPlayer.getOnlinePlayer();
/*  53 */     ArrayList<Spawn> spawns = Spawn.getSpawnsClone();
/*  54 */     ArrayList<Spawn> spawnsForIterator = Spawn.getSpawns();
/*     */     
/*  56 */     for (VaroPlayer vp : playersForIterator) {
/*  57 */       if (!vp.getStats().isSpectator()) {
/*     */         continue;
/*     */       }
/*  60 */       this.toTeleport.put(vp.getPlayer(), vp.getPlayer().getWorld().getSpawnLocation());
/*  61 */       vp.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SORT_SPECTATOR_TELEPORT.getValue());
/*  62 */       players.remove(vp);
/*     */     } 
/*     */     
/*  65 */     for (Spawn spawn : spawnsForIterator) {
/*  66 */       if (spawn.getPlayer() == null)
/*     */         continue; 
/*  68 */       if (!spawn.getPlayer().isOnline()) {
/*     */         continue;
/*     */       }
/*  71 */       spawn.getPlayer().cleanUpPlayer();
/*  72 */       this.toTeleport.put(spawn.getPlayer().getPlayer(), spawn.getLocation());
/*  73 */       spawn.getPlayer().sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SORT_OWN_HOLE.getValue());
/*  74 */       players.remove(spawn.getPlayer());
/*  75 */       spawns.remove(spawn);
/*     */     } 
/*     */ 
/*     */     
/*  79 */     SortResult result = SortResult.SORTED_WELL;
/*     */     
/*  81 */     while (spawns.size() > 0 && 
/*  82 */       players.size() > 0) {
/*     */ 
/*     */       
/*  85 */       VaroPlayer player = players.get(0);
/*  86 */       Spawn spawn = spawns.get(0);
/*  87 */       player.cleanUpPlayer();
/*  88 */       this.toTeleport.put(player.getPlayer(), spawn.getLocation());
/*  89 */       spawn.setPlayer(player);
/*  90 */       player.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SORT_NUMBER_HOLE.getValue().replace("%number%", String.valueOf(spawn.getNumber())));
/*  91 */       players.remove(0);
/*  92 */       spawns.remove(0);
/*     */       
/*  94 */       if (player.getTeam() == null) {
/*     */         continue;
/*     */       }
/*  97 */       int playerTeamRegistered = 1;
/*  98 */       for (VaroPlayer teamPlayer : player.getTeam().getMember()) {
/*  99 */         if (spawns.size() <= 0) {
/*     */           break;
/*     */         }
/*     */         
/* 103 */         if (ConfigSetting.TEAM_PLACE_SPAWN.getValueAsInt() > 0) {
/* 104 */           if (playerTeamRegistered < ConfigSetting.TEAM_PLACE_SPAWN.getValueAsInt()) {
/* 105 */             if (players.contains(teamPlayer)) {
/* 106 */               teamPlayer.cleanUpPlayer();
/* 107 */               this.toTeleport.put(teamPlayer.getPlayer(), ((Spawn)spawns.get(0)).getLocation());
/* 108 */               ((Spawn)spawns.get(0)).setPlayer(teamPlayer);
/* 109 */               teamPlayer.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SORT_NUMBER_HOLE.getValue().replace("%number%", String.valueOf(((Spawn)spawns.get(0)).getNumber())));
/* 110 */               players.remove(teamPlayer);
/*     */             } 
/*     */             
/* 113 */             spawns.remove(0);
/* 114 */             playerTeamRegistered++; continue;
/*     */           } 
/* 116 */           result = SortResult.NO_SPAWN_WITH_TEAM;
/* 117 */           players.remove(teamPlayer);
/* 118 */           teamPlayer.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SORT_NO_HOLE_FOUND_TEAM.getValue()); continue;
/*     */         } 
/* 120 */         if (players.contains(teamPlayer)) {
/* 121 */           teamPlayer.cleanUpPlayer();
/* 122 */           this.toTeleport.put(teamPlayer.getPlayer(), ((Spawn)spawns.get(0)).getLocation());
/* 123 */           ((Spawn)spawns.get(0)).setPlayer(teamPlayer);
/* 124 */           teamPlayer.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SORT_NUMBER_HOLE.getValue().replace("%number%", String.valueOf(((Spawn)spawns.get(0)).getNumber())));
/* 125 */           players.remove(teamPlayer);
/* 126 */           spawns.remove(0);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 131 */     for (VaroPlayer vp : players) {
/* 132 */       vp.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SORT_NO_HOLE_FOUND.getValue());
/* 133 */       if (result == SortResult.SORTED_WELL) {
/* 134 */         result = SortResult.NO_SPAWN;
/*     */       }
/*     */     } 
/*     */     
/* 138 */     startTeleporting();
/* 139 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\spawns\sort\PlayerSort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */