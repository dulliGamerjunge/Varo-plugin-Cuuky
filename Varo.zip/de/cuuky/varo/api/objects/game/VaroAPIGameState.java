/*    */ package de.cuuky.varo.api.objects.game;
/*    */ 
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ 
/*    */ public enum VaroAPIGameState
/*    */ {
/*  7 */   END(GameState.END),
/*  8 */   LOBBY(GameState.LOBBY),
/*  9 */   RUNNING(GameState.STARTED);
/*    */   
/*    */   private GameState origin;
/*    */   
/*    */   VaroAPIGameState(GameState origin) {
/* 14 */     this.origin = origin;
/*    */   }
/*    */   
/*    */   public GameState getOrigin() {
/* 18 */     return this.origin; } public static VaroAPIGameState getState(GameState state) {
/*    */     byte b;
/*    */     int i;
/*    */     VaroAPIGameState[] arrayOfVaroAPIGameState;
/* 22 */     for (i = (arrayOfVaroAPIGameState = values()).length, b = 0; b < i; ) { VaroAPIGameState apistate = arrayOfVaroAPIGameState[b];
/* 23 */       if (apistate.getOrigin() == state)
/* 24 */         return apistate;  b++; }
/*    */     
/* 26 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\objects\game\VaroAPIGameState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */