/*    */ package de.cuuky.varo.api.objects.player.stats;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*    */ import java.util.Date;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroAPIInventoryBackup
/*    */ {
/*    */   private InventoryBackup backup;
/*    */   
/*    */   public VaroAPIInventoryBackup(InventoryBackup backup) {
/* 15 */     this.backup = backup;
/*    */   }
/*    */   
/*    */   public Date getDateCreated() {
/* 19 */     return this.backup.getDate();
/*    */   }
/*    */   
/*    */   public Inventory getInventory() {
/* 23 */     return this.backup.getInventory().getInventory();
/*    */   }
/*    */   
/*    */   public void restore(Player player) {
/* 27 */     this.backup.restoreUpdate(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\objects\player\stats\VaroAPIInventoryBackup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */