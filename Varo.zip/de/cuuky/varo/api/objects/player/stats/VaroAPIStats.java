/*    */ package de.cuuky.varo.api.objects.player.stats;
/*    */ 
/*    */ import de.cuuky.varo.api.objects.player.VaroAPIState;
/*    */ import de.cuuky.varo.entity.player.stats.Stats;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroAPIStats
/*    */ {
/*    */   private Stats stats;
/*    */   
/*    */   public VaroAPIStats(Stats stats) {
/* 18 */     this.stats = stats;
/*    */   }
/*    */   
/*    */   public void addKill() {
/* 22 */     this.stats.addKill();
/*    */   }
/*    */   
/*    */   public int getCountdown() {
/* 26 */     return this.stats.getCountdown();
/*    */   }
/*    */   
/*    */   public ArrayList<VaroAPIInventoryBackup> getInventoryBackups() {
/* 30 */     ArrayList<VaroAPIInventoryBackup> backups = new ArrayList<>();
/* 31 */     for (InventoryBackup invB : this.stats.getInventoryBackups()) {
/* 32 */       backups.add(new VaroAPIInventoryBackup(invB));
/*    */     }
/* 34 */     return backups;
/*    */   }
/*    */   
/*    */   public int getKills() {
/* 38 */     return this.stats.getKills();
/*    */   }
/*    */   
/*    */   public Location getLastLocation() {
/* 42 */     return this.stats.getLastLocation();
/*    */   }
/*    */   
/*    */   public VaroAPIState getState() {
/* 46 */     return VaroAPIState.getState(this.stats.getState());
/*    */   }
/*    */   
/*    */   public List<VaroAPIStrike> getStrikes() {
/* 50 */     List<VaroAPIStrike> strikes = new ArrayList<>();
/* 51 */     for (Strike strike : this.stats.getStrikes()) {
/* 52 */       strikes.add(new VaroAPIStrike(strike));
/*    */     }
/* 54 */     return strikes;
/*    */   }
/*    */   
/*    */   public void setCountdown(int time) {
/* 58 */     this.stats.setCountdown(time);
/*    */   }
/*    */   
/*    */   public void setState(VaroAPIState state) {
/* 62 */     this.stats.setState(state.getOrigin());
/*    */   }
/*    */   
/*    */   public void setWillClearInventory(boolean willClear) {
/* 66 */     this.stats.setWillClear(willClear);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\objects\player\stats\VaroAPIStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */