/*    */ package de.cuuky.varo.api.objects.player;
/*    */ 
/*    */ import de.cuuky.varo.api.objects.player.stats.VaroAPIStats;
/*    */ import de.cuuky.varo.api.objects.team.VaroAPITeam;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class VaroAPIPlayer
/*    */ {
/*    */   private VaroPlayer vp;
/*    */   
/*    */   public VaroAPIPlayer(VaroPlayer vp) {
/* 15 */     this.vp = vp;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 19 */     return this.vp.getId();
/*    */   }
/*    */   
/*    */   public String getName() {
/* 23 */     return this.vp.getName();
/*    */   }
/*    */   
/*    */   public VaroAPIStats getStats() {
/* 27 */     return new VaroAPIStats(this.vp.getStats());
/*    */   }
/*    */   
/*    */   public VaroAPITeam getTeam() {
/* 31 */     return (this.vp.getTeam() == null) ? null : new VaroAPITeam(this.vp.getTeam());
/*    */   }
/*    */   
/*    */   public String getUUID() {
/* 35 */     return this.vp.getUuid();
/*    */   }
/*    */   
/*    */   public static List<VaroAPIPlayer> getAlivePlayers() {
/* 39 */     ArrayList<VaroAPIPlayer> alive = new ArrayList<>();
/* 40 */     for (VaroPlayer vp : VaroPlayer.getAlivePlayer()) {
/* 41 */       alive.add(new VaroAPIPlayer(vp));
/*    */     }
/* 43 */     return alive;
/*    */   }
/*    */   
/*    */   public static List<VaroAPIPlayer> getOnlinePlayers() {
/* 47 */     ArrayList<VaroAPIPlayer> alive = new ArrayList<>();
/* 48 */     for (VaroPlayer vp : VaroPlayer.getOnlinePlayer()) {
/* 49 */       alive.add(new VaroAPIPlayer(vp));
/*    */     }
/* 51 */     return alive;
/*    */   }
/*    */   
/*    */   public static List<VaroAPIPlayer> getVaroPlayers() {
/* 55 */     ArrayList<VaroAPIPlayer> alive = new ArrayList<>();
/* 56 */     for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/* 57 */       alive.add(new VaroAPIPlayer(vp));
/*    */     }
/* 59 */     return alive;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\objects\player\VaroAPIPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */