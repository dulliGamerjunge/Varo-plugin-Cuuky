/*    */ package de.cuuky.varo.api.objects.player;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*    */ 
/*    */ public enum VaroAPIState
/*    */ {
/*  7 */   ALIVE(PlayerState.ALIVE),
/*  8 */   DEAD(PlayerState.DEAD),
/*  9 */   SPECTATOR(PlayerState.SPECTATOR);
/*    */   
/*    */   private PlayerState origin;
/*    */   
/*    */   VaroAPIState(PlayerState origin) {
/* 14 */     this.origin = origin;
/*    */   }
/*    */   
/*    */   public PlayerState getOrigin() {
/* 18 */     return this.origin; } public static VaroAPIState getState(PlayerState state) {
/*    */     byte b;
/*    */     int i;
/*    */     VaroAPIState[] arrayOfVaroAPIState;
/* 22 */     for (i = (arrayOfVaroAPIState = values()).length, b = 0; b < i; ) { VaroAPIState apistate = arrayOfVaroAPIState[b];
/* 23 */       if (apistate.getOrigin() == state)
/* 24 */         return apistate;  b++; }
/*    */     
/* 26 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\objects\player\VaroAPIState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */