/*    */ package de.cuuky.varo.api.objects.team;
/*    */ 
/*    */ import de.cuuky.varo.api.objects.player.VaroAPIPlayer;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.team.VaroTeam;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ public class VaroAPITeam
/*    */ {
/*    */   private VaroTeam team;
/*    */   
/*    */   public VaroAPITeam(VaroTeam team) {
/* 14 */     this.team = team;
/*    */   }
/*    */   
/*    */   public String getColorcode() {
/* 18 */     return this.team.getColorCode();
/*    */   }
/*    */   
/*    */   public String getDisplayName() {
/* 22 */     return this.team.getDisplay();
/*    */   }
/*    */   
/*    */   public int getId() {
/* 26 */     return this.team.getId();
/*    */   }
/*    */   
/*    */   public int getKills() {
/* 30 */     return this.team.getKills();
/*    */   }
/*    */   
/*    */   public String getName() {
/* 34 */     return this.team.getName();
/*    */   }
/*    */   
/*    */   public void setColorcode(String code) {
/* 38 */     this.team.setColorCode(code);
/*    */   }
/*    */   
/*    */   public ArrayList<VaroAPIPlayer> getMember() {
/* 42 */     ArrayList<VaroAPIPlayer> teams = new ArrayList<>();
/* 43 */     for (VaroPlayer player : this.team.getMember()) {
/* 44 */       teams.add(new VaroAPIPlayer(player));
/*    */     }
/* 46 */     return teams;
/*    */   }
/*    */   
/*    */   public static ArrayList<VaroAPITeam> getTeams() {
/* 50 */     ArrayList<VaroAPITeam> teams = new ArrayList<>();
/* 51 */     for (VaroTeam team : VaroTeam.getTeams()) {
/* 52 */       teams.add(new VaroAPITeam(team));
/*    */     }
/* 54 */     return teams;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\objects\team\VaroAPITeam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */