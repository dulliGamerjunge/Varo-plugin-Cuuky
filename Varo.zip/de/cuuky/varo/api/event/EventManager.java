/*    */ package de.cuuky.varo.api.event;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.api.event.register.VaroEventMethod;
/*    */ import de.cuuky.varo.api.event.register.VaroListener;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventManager
/*    */ {
/* 15 */   private ArrayList<EventHandler> handlerList = new ArrayList<>();
/*    */ 
/*    */   
/*    */   public boolean executeEvent(VaroAPIEvent event) {
/* 19 */     for (EventHandler handler : this.handlerList) {
/* 20 */       if (!handler.getEvent().equals(event.getClass())) {
/*    */         continue;
/*    */       }
/* 23 */       handler.execute(event);
/* 24 */       return event.isCancelled();
/*    */     } 
/*    */     
/* 27 */     return false;
/*    */   }
/*    */   
/*    */   public ArrayList<EventHandler> getHandler() {
/* 31 */     return this.handlerList;
/*    */   } public void registerEvent(VaroListener listener) {
/*    */     byte b;
/*    */     int i;
/*    */     Method[] arrayOfMethod;
/* 36 */     for (i = (arrayOfMethod = listener.getClass().getDeclaredMethods()).length, b = 0; b < i; ) { Method method = arrayOfMethod[b];
/* 37 */       if (method.getAnnotation(VaroEventMethod.class) != null) {
/*    */ 
/*    */         
/* 40 */         Class[] clazzes = method.getParameterTypes();
/*    */         
/* 42 */         if (clazzes.length != 1 || !VaroAPIEvent.class.isAssignableFrom(clazzes[0])) {
/* 43 */           System.out.println(String.valueOf(Main.getConsolePrefix()) + "Failed to register listener " + listener.getClass().getName() + " caused by wrong parameters given.");
/*    */         }
/*    */         else {
/*    */           
/* 47 */           this.handlerList.add(new EventHandler(listener, method, clazzes[0]));
/*    */         } 
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\event\EventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */