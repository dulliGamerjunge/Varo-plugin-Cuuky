/*    */ package de.cuuky.varo.api.event;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.api.event.register.VaroListener;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventHandler
/*    */ {
/*    */   private Class<? extends VaroAPIEvent> event;
/*    */   private VaroListener listener;
/*    */   private Method method;
/*    */   
/*    */   public EventHandler(VaroListener listener, Method method, Class<? extends VaroAPIEvent> event) {
/* 16 */     this.listener = listener;
/* 17 */     this.method = method;
/* 18 */     this.event = event;
/*    */   }
/*    */   
/*    */   public void execute(VaroAPIEvent event) {
/*    */     try {
/* 23 */       this.method.invoke(this.listener, new Object[] { event });
/* 24 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 25 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "An error occured on invoking a method, did you register it right? Listener: " + this.listener.getClass().getName());
/*    */       return;
/*    */     } 
/*    */   }
/*    */   
/*    */   public Class<? extends VaroAPIEvent> getEvent() {
/* 31 */     return this.event;
/*    */   }
/*    */   
/*    */   public VaroListener getListener() {
/* 35 */     return this.listener;
/*    */   }
/*    */   
/*    */   public Method getMethod() {
/* 39 */     return this.method;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\event\EventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */