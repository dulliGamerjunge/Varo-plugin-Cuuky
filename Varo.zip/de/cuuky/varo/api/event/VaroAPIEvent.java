/*    */ package de.cuuky.varo.api.event;
/*    */ 
/*    */ public class VaroAPIEvent
/*    */ {
/*    */   private boolean cancelAble;
/*    */   private boolean cancelled;
/*    */   
/*    */   public VaroAPIEvent() {
/*  9 */     this.cancelAble = true;
/*    */   }
/*    */   
/*    */   public VaroAPIEvent(boolean cancelAble) {
/* 13 */     this.cancelAble = cancelAble;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 17 */     return this.cancelled;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancelled) {
/* 21 */     if (this.cancelAble)
/* 22 */       this.cancelled = cancelled; 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\event\VaroAPIEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */