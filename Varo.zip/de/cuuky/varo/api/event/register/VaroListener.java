package de.cuuky.varo.api.event.register;

public interface VaroListener {}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\event\register\VaroListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */