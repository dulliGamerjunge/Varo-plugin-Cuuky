/*    */ package de.cuuky.varo.api.event.events;
/*    */ 
/*    */ import de.cuuky.varo.api.VaroAPI;
/*    */ import de.cuuky.varo.api.event.events.player.strike.PlayerStrikeReceiveEvent;
/*    */ import de.cuuky.varo.api.event.register.VaroEventMethod;
/*    */ import de.cuuky.varo.api.event.register.VaroListener;
/*    */ 
/*    */ public class EventListener
/*    */   implements VaroListener {
/*    */   static {
/* 11 */     VaroAPI.getEventManager().registerEvent(new EventListener());
/*    */   }
/*    */   
/*    */   @VaroEventMethod
/*    */   public void onPlayerStrike(PlayerStrikeReceiveEvent event) {
/* 16 */     System.out.println(event.getStrike().getReason());
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\event\events\EventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */