/*    */ package de.cuuky.varo.api.event.events.player;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*    */ 
/*    */ public class PlayerStateChangeEvent
/*    */   extends VaroPlayerEvent {
/*    */   private PlayerState state;
/*    */   
/*    */   public PlayerStateChangeEvent(VaroPlayer player, PlayerState state) {
/* 11 */     super(player, true);
/*    */     
/* 13 */     this.state = state;
/*    */   }
/*    */   
/*    */   public PlayerState getState() {
/* 17 */     return this.state;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\api\event\events\player\PlayerStateChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */