/*     */ package de.cuuky.varo.entity.team.request;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import de.cuuky.varo.gui.utils.chat.ChatHookListener;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VaroTeamRequest
/*     */ {
/*  20 */   private static ArrayList<VaroTeamRequest> requests = new ArrayList<>();
/*     */   
/*     */   private VaroPlayer invited;
/*     */   private VaroPlayer invitor;
/*     */   private int sched;
/*     */   
/*     */   public VaroTeamRequest(VaroPlayer invitor, VaroPlayer invited) {
/*  27 */     this.invitor = invitor;
/*  28 */     this.invited = invited;
/*     */     
/*  30 */     requests.add(this);
/*     */     
/*  32 */     startSched();
/*     */   }
/*     */   
/*     */   private void addToTeam(VaroTeam team) {
/*  36 */     if (!team.isMember(this.invitor)) {
/*  37 */       team.addMember(this.invitor);
/*     */     }
/*  39 */     if (this.invited.getTeam() != null) {
/*  40 */       this.invited.getTeam().removeMember(this.invited);
/*     */     }
/*  42 */     if (ConfigSetting.TEAMREQUEST_MAXTEAMMEMBERS.getValueAsInt() <= team.getMember().size()) {
/*  43 */       this.invitor.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.TEAMREQUEST_TEAM_FULL.getValue().replace("%invited%", this.invited.getName()));
/*     */       
/*     */       return;
/*     */     } 
/*  47 */     team.addMember(this.invited);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendChatHook() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void startSched() {
/*  81 */     if (!ConfigSetting.TEAMREQUEST_EXPIRETIME.isIntActivated()) {
/*     */       return;
/*     */     }
/*  84 */     this.sched = Bukkit.getScheduler().scheduleAsyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  88 */             if (!VaroTeamRequest.this.invitor.isOnline()) {
/*  89 */               VaroTeamRequest.this.invitor.sendMessage(String.valueOf(Main.getPrefix()) + "§7Deine Einladung an " + Main.getColorCode() + VaroTeamRequest.this.invited.getName() + " §7ist abgelaufen!");
/*     */             }
/*  91 */             if (!VaroTeamRequest.this.invited.isOnline()) {
/*  92 */               VaroTeamRequest.this.invited.sendMessage(String.valueOf(Main.getPrefix()) + "§7Die Einladung von " + Main.getColorCode() + VaroTeamRequest.this.invitor.getName() + " §7ist abgelaufen!");
/*     */             }
/*  94 */             VaroTeamRequest.this.remove();
/*     */           }
/*     */         }, 
/*  97 */         (20 * ConfigSetting.TEAMREQUEST_EXPIRETIME.getValueAsInt()));
/*     */   }
/*     */   
/*     */   public void accept() {
/* 101 */     if (!this.invitor.isOnline()) {
/* 102 */       this.invited.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.TEAMREQUEST_PLAYER_NOT_ONLINE.getValue().replace("%invitor%", this.invitor.getName()));
/* 103 */       remove();
/*     */       
/*     */       return;
/*     */     } 
/* 107 */     if (this.invitor.getTeam() == null) {
/* 108 */       sendChatHook();
/*     */     } else {
/* 110 */       addToTeam(this.invitor.getTeam());
/* 111 */     }  remove();
/*     */   }
/*     */   
/*     */   public void decline() {
/* 115 */     remove();
/*     */   }
/*     */   
/*     */   public void remove() {
/* 119 */     Bukkit.getScheduler().cancelTask(this.sched);
/* 120 */     requests.remove(this);
/*     */   }
/*     */   
/*     */   public void revoke() {
/* 124 */     this.invitor.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.TEAMREQUEST_REVOKED.getValue());
/* 125 */     remove();
/*     */   }
/*     */   
/*     */   public VaroPlayer getInvited() {
/* 129 */     return this.invited;
/*     */   }
/*     */   
/*     */   public VaroPlayer getInvitor() {
/* 133 */     return this.invitor;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroTeamRequest> getAllRequests() {
/* 137 */     return requests;
/*     */   }
/*     */   
/*     */   public static VaroTeamRequest getByAll(VaroPlayer inviter, VaroPlayer invited) {
/* 141 */     for (VaroTeamRequest req : requests) {
/* 142 */       if (req.getInvitor().equals(inviter) && req.getInvited().equals(invited))
/* 143 */         return req; 
/*     */     } 
/* 145 */     return null;
/*     */   }
/*     */   
/*     */   public static VaroTeamRequest getByInvited(VaroPlayer invited) {
/* 149 */     for (VaroTeamRequest req : requests) {
/* 150 */       if (req.getInvitor().equals(invited))
/* 151 */         return req; 
/*     */     } 
/* 153 */     return null;
/*     */   }
/*     */   
/*     */   public static VaroTeamRequest getByInvitor(VaroPlayer invitor) {
/* 157 */     for (VaroTeamRequest req : requests) {
/* 158 */       if (req.getInvitor().equals(invitor))
/* 159 */         return req; 
/*     */     } 
/* 161 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\team\request\VaroTeamRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */