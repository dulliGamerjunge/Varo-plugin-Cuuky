/*     */ package de.cuuky.varo.entity.team;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.clientadapter.nametag.Nametag;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.VaroEntity;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.VaroInventory;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VaroTeam
/*     */   extends VaroEntity
/*     */ {
/*  22 */   private static ArrayList<VaroTeam> teams = new ArrayList<>(); static {
/*  23 */     highestNumber = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private ArrayList<VaroPlayer> member = new ArrayList<>(); @VaroSerializeField(path = "teamBackPack")
/*  48 */   private VaroInventory teamBackPack = new VaroInventory(ConfigSetting.BACKPACK_TEAM_SIZE.getValueAsInt()); @VaroSerializeField(path = "memberid")
/*  49 */   private ArrayList<Integer> memberid = new ArrayList<>();
/*     */   private static int highestNumber; @VaroSerializeField(path = "colorCode")
/*     */   private String colorCode;
/*     */   
/*  53 */   public VaroTeam(String name) { this();
/*     */     
/*  55 */     this.name = name;
/*  56 */     this.id = generateId();
/*  57 */     loadDefaults();
/*     */     
/*  59 */     Nametag.refreshAll();
/*  60 */     if (this.id > highestNumber) {
/*  61 */       highestNumber = this.id;
/*     */     }
/*  63 */     teams.add(this); } @VaroSerializeField(path = "id")
/*     */   private int id; @VaroSerializeField(path = "lifes")
/*     */   private double lifes; @VaroSerializeField(path = "name")
/*     */   private String name; private int generateId() {
/*  67 */     int i = teams.size() + 1;
/*  68 */     while (getTeam(i) != null) {
/*  69 */       i++;
/*     */     }
/*  71 */     return i;
/*     */   }
/*     */   
/*     */   public void addMember(VaroPlayer vp) {
/*  75 */     if (isMember(vp)) {
/*     */       return;
/*     */     }
/*  78 */     this.member.add(vp);
/*  79 */     vp.setTeam(this);
/*     */   }
/*     */   
/*     */   public void delete() {
/*  83 */     this.member.forEach(member -> member.setTeam(null));
/*  84 */     int id = getId();
/*  85 */     int number = getTeams().size();
/*  86 */     for (int i = id; i < number; i++) {
/*  87 */       ((VaroTeam)getTeams().get(i)).setId(i);
/*     */     }
/*  89 */     teams.remove(this);
/*     */   }
/*     */   
/*     */   public boolean isDead() {
/*  93 */     for (VaroPlayer player : this.member) {
/*  94 */       if (player.getStats().getState() != PlayerState.ALIVE) {
/*     */         continue;
/*     */       }
/*  97 */       return false;
/*     */     } 
/*     */     
/* 100 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isOnline() {
/* 104 */     for (VaroPlayer vp : this.member) {
/* 105 */       if (!vp.isOnline())
/* 106 */         return false; 
/*     */     } 
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   public void loadDefaults() {
/* 112 */     this.lifes = ConfigSetting.TEAM_LIFES.getValueAsInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/* 117 */     for (Iterator<Integer> iterator = this.memberid.iterator(); iterator.hasNext(); ) { int id = ((Integer)iterator.next()).intValue();
/* 118 */       VaroPlayer vp = VaroPlayer.getPlayer(id);
/* 119 */       if (vp == null) {
/* 120 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.LOG, String.valueOf(id) + " has been removed without reason - please report this to the creator of this plugin");
/*     */         
/*     */         continue;
/*     */       } 
/* 124 */       addMember(vp); }
/*     */ 
/*     */     
/* 127 */     if (this.id > highestNumber)
/* 128 */       highestNumber = this.id; 
/* 129 */     this.memberid.clear();
/* 130 */     teams.add(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {
/* 135 */     for (VaroPlayer member : this.member)
/* 136 */       this.memberid.add(Integer.valueOf(member.getId())); 
/*     */   }
/*     */   
/*     */   public void removeMember(VaroPlayer vp) {
/* 140 */     this.member.remove(vp);
/* 141 */     vp.setTeam(null);
/*     */     
/* 143 */     if (this.member.size() == 0)
/* 144 */       teams.remove(this); 
/*     */   }
/*     */   
/*     */   public void removeSaveable(VaroSaveable saveable) {
/* 148 */     for (VaroPlayer vp : this.member) {
/* 149 */       if (vp.getStats().getSaveables().contains(saveable))
/* 150 */         vp.getStats().removeSaveable(saveable); 
/*     */     } 
/*     */   }
/*     */   public boolean isMember(VaroPlayer vp) {
/* 154 */     return this.member.contains(vp);
/*     */   }
/*     */   
/*     */   public void setColorCode(String colorCode) {
/* 158 */     this.colorCode = colorCode;
/* 159 */     if (colorCode != null) {
/* 160 */       this.colorCode = colorCode.replace("&", "§");
/*     */     }
/* 162 */     statChanged();
/*     */   }
/*     */   
/*     */   public String getColorCode() {
/* 166 */     return (this.colorCode == null) ? Main.getColorCode() : this.colorCode;
/*     */   }
/*     */   
/*     */   public String getDisplay() {
/* 170 */     return String.valueOf(getColorCode()) + "#" + this.name;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 174 */     return this.id;
/*     */   }
/*     */   
/*     */   public int getKills() {
/* 178 */     int kills = 0;
/* 179 */     for (VaroPlayer player : this.member) {
/* 180 */       kills += player.getStats().getKills();
/*     */     }
/* 182 */     return kills;
/*     */   }
/*     */   
/*     */   public double getLifes() {
/* 186 */     return this.lifes;
/*     */   }
/*     */   
/*     */   public ArrayList<VaroPlayer> getMember() {
/* 190 */     return this.member;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 194 */     return this.name;
/*     */   }
/*     */   
/*     */   public ArrayList<VaroSaveable> getSaveables() {
/* 198 */     ArrayList<VaroSaveable> save = new ArrayList<>();
/* 199 */     for (VaroPlayer vp : this.member) {
/* 200 */       save.addAll(vp.getStats().getSaveablesRaw());
/*     */     }
/* 202 */     return save;
/*     */   }
/*     */   
/*     */   public VaroInventory getTeamBackPack() {
/* 206 */     return this.teamBackPack;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/* 210 */     this.id = id;
/*     */   }
/*     */   
/*     */   public void setLifes(double lifes) {
/* 214 */     this.lifes = lifes;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 218 */     this.name = name;
/* 219 */     statChanged();
/*     */   }
/*     */   
/*     */   public void statChanged() {
/* 223 */     this.member.forEach(member -> member.update());
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroTeam> getAliveTeams() {
/* 227 */     ArrayList<VaroTeam> alive = new ArrayList<>();
/* 228 */     for (VaroTeam team : teams) {
/* 229 */       if (!team.isDead())
/* 230 */         alive.add(team); 
/*     */     } 
/* 232 */     return alive;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroTeam> getDeadTeams() {
/* 236 */     ArrayList<VaroTeam> dead = new ArrayList<>();
/* 237 */     for (VaroTeam team : teams) {
/* 238 */       if (team.isDead())
/* 239 */         dead.add(team); 
/*     */     } 
/* 241 */     return dead;
/*     */   }
/*     */   
/*     */   public static int getHighestNumber() {
/* 245 */     return highestNumber;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroTeam> getOnlineTeams() {
/* 249 */     ArrayList<VaroTeam> online = new ArrayList<>();
/* 250 */     for (VaroTeam team : teams) {
/* 251 */       if (team.isOnline())
/* 252 */         online.add(team); 
/*     */     } 
/* 254 */     return online;
/*     */   }
/*     */   
/*     */   public static VaroTeam getTeam(int id) {
/* 258 */     for (VaroTeam team : teams) {
/* 259 */       if (team.getId() != id) {
/*     */         continue;
/*     */       }
/* 262 */       return team;
/*     */     } 
/*     */     
/* 265 */     return null;
/*     */   }
/*     */   
/*     */   public static VaroTeam getTeam(String name) {
/* 269 */     for (VaroTeam team : teams) {
/* 270 */       if (!team.getName().equals(name) && !String.valueOf(team.getId()).equals(name)) {
/*     */         continue;
/*     */       }
/* 273 */       return team;
/*     */     } 
/*     */     
/* 276 */     return null;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroTeam> getTeams() {
/* 280 */     return teams;
/*     */   }
/*     */   
/*     */   public VaroTeam() {}
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\team\VaroTeam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */