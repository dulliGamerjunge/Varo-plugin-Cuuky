/*    */ package de.cuuky.varo.entity.player.event;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BukkitEvent
/*    */ {
/* 18 */   private static List<BukkitEvent> events = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected BukkitEventType eventType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected BukkitEvent(BukkitEventType eventType) {
/* 30 */     this.eventType = eventType;
/*    */     
/* 32 */     events.add(this);
/*    */   }
/*    */   
/*    */   public BukkitEvent(VaroPlayer player, BukkitEventType eventType) {
/* 36 */     for (BukkitEvent event : events) {
/* 37 */       if (event.getEventType().equals(eventType))
/* 38 */         event.onExec(player); 
/*    */     } 
/*    */   }
/*    */   public BukkitEventType getEventType() {
/* 42 */     return this.eventType;
/*    */   }
/*    */   
/*    */   public void onExec(VaroPlayer player) {}
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\event\BukkitEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */