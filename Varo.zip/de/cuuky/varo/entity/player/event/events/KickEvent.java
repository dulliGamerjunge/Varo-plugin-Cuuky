/*    */ package de.cuuky.varo.entity.player.event.events;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEvent;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ 
/*    */ public class KickEvent
/*    */   extends BukkitEvent {
/*    */   public KickEvent() {
/* 10 */     super(BukkitEventType.KICKED);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onExec(VaroPlayer player) {
/* 15 */     if (!player.isMassRecordingKick()) {
/* 16 */       player.getStats().addSessionPlayed();
/* 17 */       player.getStats().setBan();
/*    */     } else {
/* 19 */       player.setMassRecordingKick(false);
/*    */     } 
/*    */     
/* 22 */     player.getStats().removeCountdown();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\event\events\KickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */