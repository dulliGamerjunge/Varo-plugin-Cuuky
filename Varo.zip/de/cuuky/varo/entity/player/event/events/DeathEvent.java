/*    */ package de.cuuky.varo.entity.player.event.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEvent;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ import de.cuuky.varo.entity.player.stats.VaroInventory;
/*    */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.game.world.border.decrease.DecreaseReason;
/*    */ import java.util.Date;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class DeathEvent
/*    */   extends BukkitEvent
/*    */ {
/*    */   public DeathEvent() {
/* 23 */     super(BukkitEventType.KILLED); } private void dropInventory(VaroInventory inventory, Location location) {
/*    */     byte b;
/*    */     int i;
/*    */     ItemStack[] arrayOfItemStack;
/* 27 */     for (i = (arrayOfItemStack = inventory.getInventory().getContents()).length, b = 0; b < i; ) { ItemStack item = arrayOfItemStack[b];
/* 28 */       if (item != null && item.getType() != Material.AIR)
/* 29 */         location.getWorld().dropItemNaturally(location, item); 
/*    */       b++; }
/*    */   
/*    */   }
/*    */   public void onExec(VaroPlayer player) {
/* 34 */     player.getStats().addInventoryBackup(new InventoryBackup(player));
/*    */     
/* 36 */     player.getStats().removeCountdown();
/* 37 */     player.getStats().setDiedAt(new Date());
/* 38 */     player.getStats().setState(PlayerState.DEAD);
/*    */     
/* 40 */     if (ConfigSetting.BACKPACK_PLAYER_DROP_ON_DEATH.getValueAsBoolean() && 
/* 41 */       player.getStats().getPlayerBackpack() != null) {
/* 42 */       dropInventory(player.getStats().getPlayerBackpack(), player.getPlayer().getLocation());
/*    */     }
/* 44 */     if (ConfigSetting.BACKPACK_TEAM_DROP_ON_DEATH.getValueAsBoolean() && 
/* 45 */       player.getTeam() != null && player.getTeam().isDead() && player.getTeam().getTeamBackPack() != null) {
/* 46 */       dropInventory(player.getTeam().getTeamBackPack(), player.getPlayer().getLocation());
/*    */     }
/* 48 */     if (Main.getVaroGame().getGameState() == GameState.STARTED)
/* 49 */       Main.getVaroGame().getVaroWorldHandler().decreaseBorder(DecreaseReason.DEATH); 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\event\events\DeathEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */