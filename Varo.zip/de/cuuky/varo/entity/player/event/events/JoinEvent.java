/*    */ package de.cuuky.varo.entity.player.event.events;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.disconnect.VaroPlayerDisconnect;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEvent;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ import java.util.Date;
/*    */ import org.bukkit.GameMode;
/*    */ 
/*    */ 
/*    */ public class JoinEvent
/*    */   extends BukkitEvent
/*    */ {
/*    */   public JoinEvent() {
/* 16 */     super(BukkitEventType.JOINED);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onExec(VaroPlayer player) {
/* 21 */     player.setNormalAttackSpeed();
/* 22 */     if (player.getStats().getFirstTimeJoined() == null) {
/* 23 */       player.getStats().setFirstTimeJoined(new Date());
/*    */     }
/* 25 */     player.getStats().setLastJoined(new Date());
/* 26 */     player.getStats().setLastLocation(player.getPlayer().getLocation());
/*    */     
/* 28 */     if (player.getVillager() != null) {
/* 29 */       player.getVillager().remove();
/* 30 */       player.setVillager(null);
/*    */     } 
/*    */     
/* 33 */     if (player.getStats().isWillClear()) {
/* 34 */       player.getStats().clearInventory();
/* 35 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "Dein Inventar wurde geleert!");
/* 36 */       player.getStats().setWillClear(false);
/*    */     } 
/*    */     
/* 39 */     if (player.getStats().getRestoreBackup() != null) {
/* 40 */       player.getStats().getRestoreBackup().restoreUpdate(player.getPlayer());
/* 41 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "Dein Inventar wurde wiederhergestellt!");
/* 42 */       player.getStats().setRestoreBackup(null);
/*    */     } 
/*    */     
/* 45 */     if (player.getStats().isSpectator() || player.isAdminIgnore()) {
/* 46 */       player.setSpectacting();
/* 47 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "Da Du §c" + (player.isAdminIgnore() ? "als Admin gejoint bist und keine Folgen mehr produzieren darfst" : "du Spectator bist") + " §7wurdest du in den Zuschauer-Modus gesetzt!");
/*    */     } else {
/* 49 */       player.getPlayer().setGameMode(GameMode.SURVIVAL);
/*    */     } 
/* 51 */     VaroPlayerDisconnect.joinedAgain(player.getName());
/* 52 */     Main.getDataManager().getScoreboardHandler().sendScoreBoard(player);
/* 53 */     player.update();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\event\events\JoinEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */