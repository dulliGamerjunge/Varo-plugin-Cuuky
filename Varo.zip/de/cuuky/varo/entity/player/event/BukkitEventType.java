/*    */ package de.cuuky.varo.entity.player.event;
/*    */ 
/*    */ public enum BukkitEventType
/*    */ {
/*  5 */   JOINED,
/*  6 */   KICKED,
/*  7 */   KILL,
/*  8 */   KILLED,
/*  9 */   QUIT,
/* 10 */   WIN;
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\event\BukkitEventType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */