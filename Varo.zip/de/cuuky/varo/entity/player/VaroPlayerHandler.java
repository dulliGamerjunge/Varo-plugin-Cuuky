/*    */ package de.cuuky.varo.entity.player;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.stats.Stats;
/*    */ import de.cuuky.varo.entity.player.stats.VaroInventory;
/*    */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Rank;
/*    */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*    */ import de.cuuky.varo.entity.player.stats.stat.YouTubeVideo;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*    */ import de.cuuky.varo.entity.player.stats.stat.offlinevillager.OfflineVillager;
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class VaroPlayerHandler
/*    */   extends VaroSerializeObject {
/*    */   static {
/* 20 */     registerClass(Rank.class);
/* 21 */     registerClass(Strike.class);
/* 22 */     registerClass(Stats.class);
/* 23 */     registerClass(YouTubeVideo.class);
/* 24 */     registerClass(VaroSaveable.class);
/* 25 */     registerClass(InventoryBackup.class);
/* 26 */     registerClass(VaroInventory.class);
/* 27 */     registerClass(OfflineVillager.class);
/* 28 */     registerEnum(PlayerState.class);
/*    */   }
/*    */   
/*    */   public VaroPlayerHandler() {
/* 32 */     super(VaroPlayer.class, "/stats/players.yml");
/*    */     
/* 34 */     load();
/*    */     
/* 36 */     for (Player player : VersionUtils.getOnlinePlayer()) {
/* 37 */       if (VaroPlayer.getPlayer(player) == null)
/* 38 */         (new VaroPlayer(player)).register(); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void onSave() {
/* 43 */     clearOld();
/*    */     
/* 45 */     for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/* 46 */       save(String.valueOf(vp.getId()), (VaroSerializeable)vp, getConfiguration());
/*    */     }
/* 48 */     saveFile();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\VaroPlayerHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */