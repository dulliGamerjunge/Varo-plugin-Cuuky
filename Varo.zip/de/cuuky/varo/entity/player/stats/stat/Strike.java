/*     */ package de.cuuky.varo.entity.player.stats.stat;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.lang.time.DateUtils;
/*     */ import org.bukkit.Location;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Strike
/*     */   implements VaroSerializeable
/*     */ {
/*     */   @VaroSerializeField(path = "strikedId")
/*     */   private int strikedId;
/*     */   @VaroSerializeField(path = "striker")
/*     */   private String striker;
/*     */   @VaroSerializeField(path = "acquired")
/*     */   private Date acquired;
/*     */   @VaroSerializeField(path = "banUntil")
/*     */   private Date banUntil;
/*     */   @VaroSerializeField(path = "number")
/*     */   private int number;
/*     */   @VaroSerializeField(path = "posted")
/*     */   private boolean posted;
/*     */   @VaroSerializeField(path = "reason")
/*     */   private String reason;
/*     */   private VaroPlayer striked;
/*     */   
/*     */   public Strike() {}
/*     */   
/*     */   public Strike(String reason, VaroPlayer striked, String striker) {
/*  44 */     this.reason = reason;
/*  45 */     this.striker = striker;
/*  46 */     this.striked = striked;
/*  47 */     this.strikedId = striked.getId();
/*  48 */     this.acquired = new Date();
/*  49 */     this.posted = false;
/*     */   }
/*     */   
/*     */   public void activate(int number) {
/*  53 */     this.number = number;
/*     */     
/*  55 */     if (ConfigSetting.STRIKE_BAN_AFTER_STRIKE_HOURS.isIntActivated() && !ConfigSetting.STRIKE_BAN_AT_POST.getValueAsBoolean()) {
/*  56 */       this.banUntil = DateUtils.addHours(new Date(), ConfigSetting.STRIKE_BAN_AFTER_STRIKE_HOURS.getValueAsInt());
/*     */     }
/*  58 */     switch (number) {
/*     */       case 1:
/*     */         break;
/*     */       case 2:
/*  62 */         this.striked.getStats().clearInventory();
/*     */         break;
/*     */       
/*     */       default:
/*  66 */         this.striked.getStats().setState(PlayerState.DEAD);
/*  67 */         if (this.striked.isOnline()) {
/*  68 */           this.striked.getPlayer().kickPlayer(ConfigMessages.KICK_TOO_MANY_STRIKES.getValue());
/*     */         }
/*     */         break;
/*     */     } 
/*  72 */     if (!ConfigSetting.STRIKE_POST_RESET_HOUR.getValueAsBoolean())
/*  73 */       post(); 
/*     */   }
/*     */   
/*     */   public void decreaseStrikeNumber() {
/*  77 */     this.number--;
/*     */   }
/*     */   
/*     */   public Date getAcquiredDate() {
/*  81 */     return this.acquired;
/*     */   }
/*     */   
/*     */   public Date getBanUntil() {
/*  85 */     return this.banUntil;
/*     */   }
/*     */   
/*     */   public String getReason() {
/*  89 */     return this.reason;
/*     */   }
/*     */   
/*     */   public VaroPlayer getStriked() {
/*  93 */     return this.striked;
/*     */   }
/*     */   
/*     */   public int getStrikeNumber() {
/*  97 */     return this.number;
/*     */   }
/*     */   
/*     */   public String getStriker() {
/* 101 */     return this.striker;
/*     */   }
/*     */   
/*     */   public boolean isPosted() {
/* 105 */     return this.posted;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/* 110 */     this.striked = VaroPlayer.getPlayer(this.strikedId);
/*     */   }
/*     */   
/*     */   public void onSerializeStart() {}
/*     */   
/*     */   public void post() {
/*     */     Location loc;
/* 117 */     if (ConfigSetting.STRIKE_BAN_AFTER_STRIKE_HOURS.isIntActivated() && ConfigSetting.STRIKE_BAN_AT_POST.getValueAsBoolean()) {
/* 118 */       this.banUntil = DateUtils.addHours(new Date(), ConfigSetting.STRIKE_BAN_AFTER_STRIKE_HOURS.getValueAsInt());
/*     */     }
/* 120 */     switch (this.number) {
/*     */       case 1:
/* 122 */         if (this.striked.getStats().getLastLocation() == null) {
/* 123 */           Location location = Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld().getSpawnLocation();
/* 124 */           Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.STRIKE, ConfigMessages.ALERT_FIRST_STRIKE_NEVER_ONLINE.getValue().replace("%player%", this.striked.getName()).replace("%pos%", "X:" + location.getBlockX() + ", Y:" + location.getBlockY() + ", Z:" + location.getBlockZ() + " & world: " + location.getWorld().getName()).replace("%reason%", this.reason).replace("%striker%", this.striker)); break;
/*     */         } 
/* 126 */         loc = this.striked.isOnline() ? this.striked.getPlayer().getLocation() : this.striked.getStats().getLastLocation();
/* 127 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.STRIKE, ConfigMessages.ALERT_FIRST_STRIKE.getValue().replace("%player%", this.striked.getName()).replace("%pos%", "X:" + loc.getBlockX() + ", Y:" + loc.getBlockY() + ", Z:" + loc.getBlockZ() + " & world: " + loc.getWorld().getName()).replace("%reason%", this.reason).replace("%striker%", this.striker));
/*     */         break;
/*     */       
/*     */       case 2:
/* 131 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.STRIKE, ConfigMessages.ALERT_SECOND_STRIKE.getValue().replace("%player%", this.striked.getName()).replace("%reason%", this.reason).replace("%striker%", this.striker));
/*     */         break;
/*     */       case 3:
/* 134 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.STRIKE, ConfigMessages.ALERT_THRID_STRIKE.getValue().replace("%player%", this.striked.getName()).replace("%reason%", this.reason).replace("%striker%", this.striker));
/*     */         break;
/*     */       default:
/* 137 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.STRIKE, ConfigMessages.ALERT_GENERAL_STRIKE.getValue().replace("%player%", this.striked.getName()).replace("%strikeNumber%", String.valueOf(this.number)).replace("%reason%", this.reason).replace("%striker%", this.striker));
/*     */         break;
/*     */     } 
/*     */     
/* 141 */     this.posted = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\stats\stat\Strike.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */