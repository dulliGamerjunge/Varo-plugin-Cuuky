/*     */ package de.cuuky.varo.entity.player.stats.stat.inventory;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class VaroSaveable
/*     */   implements VaroSerializeable {
/*     */   public enum SaveableType
/*     */     implements VaroSerializeable {
/*  18 */     CHEST,
/*     */ 
/*     */     
/*  21 */     FURNANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void onDeserializeEnd() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void onSerializeStart() {}
/*     */   }
/*     */ 
/*     */   
/*  34 */   private static ArrayList<VaroSaveable> saveables = new ArrayList<>();
/*     */   
/*     */   @VaroSerializeField(path = "id")
/*     */   private int id;
/*     */   
/*     */   @VaroSerializeField(path = "playerId")
/*     */   private int playerId;
/*     */   
/*     */   @VaroSerializeField(path = "type")
/*     */   private SaveableType type;
/*     */   
/*     */   @VaroSerializeField(path = "blockLocation")
/*     */   private Location blockLocation;
/*     */   
/*     */   private VaroPlayer player;
/*     */   
/*     */   private Block block;
/*     */   
/*     */   public VaroSaveable() {
/*  53 */     saveables.add(this);
/*     */   }
/*     */   
/*     */   public VaroSaveable(SaveableType type, Location location, VaroPlayer player) {
/*  57 */     this.type = type;
/*  58 */     this.block = location.getBlock();
/*  59 */     this.id = generateId();
/*  60 */     this.player = player;
/*  61 */     player.getStats().addSaveable(this);
/*     */     
/*  63 */     saveables.add(this);
/*     */   }
/*     */   
/*     */   private int generateId() {
/*  67 */     int id = JavaUtils.randomInt(1000, 9999999);
/*  68 */     while (getSaveable(id) != null) {
/*  69 */       generateId();
/*     */     }
/*  71 */     return id;
/*     */   }
/*     */   
/*     */   public boolean canModify(VaroPlayer player) {
/*  75 */     if (this.player.getTeam() == null && !player.equals(this.player)) {
/*  76 */       return false;
/*     */     }
/*  78 */     if (this.player.getTeam() != null && !this.player.getTeam().isMember(player)) {
/*  79 */       return false;
/*     */     }
/*  81 */     return true;
/*     */   }
/*     */   
/*     */   public boolean holderDead() {
/*  85 */     if (this.player.getTeam() == null && this.player.getStats().isAlive()) {
/*  86 */       return false;
/*     */     }
/*  88 */     if (this.player.getTeam() != null && !this.player.getTeam().isDead()) {
/*  89 */       return false;
/*     */     }
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/*  96 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 100 */             VaroSaveable.this.player = VaroPlayer.getPlayer(VaroSaveable.this.playerId);
/* 101 */             VaroSaveable.this.block = VaroSaveable.this.blockLocation.getBlock();
/*     */           }
/* 103 */         },  1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {
/* 108 */     this.playerId = this.player.getId();
/* 109 */     this.blockLocation = this.block.getLocation();
/*     */   }
/*     */   
/*     */   public void remove() {
/* 113 */     this.player.getStats().removeSaveable(this);
/* 114 */     saveables.remove(this);
/*     */   }
/*     */   
/*     */   public static VaroSaveable getByLocation(Location loc) {
/* 118 */     for (VaroSaveable save : getSaveables()) {
/* 119 */       Location loc1 = save.getBlock().getLocation();
/* 120 */       if (loc1.getBlockX() == loc.getBlockX() && loc1.getBlockY() == loc.getBlockY() && loc.getBlockZ() == loc1.getBlockZ() && loc1.getWorld().equals(loc.getWorld())) {
/* 121 */         return save;
/*     */       }
/*     */     } 
/* 124 */     return null;
/*     */   }
/*     */   
/*     */   public static VaroSaveable getSaveable(int id) {
/* 128 */     for (VaroSaveable save : saveables) {
/* 129 */       if (save.getId() != id) {
/*     */         continue;
/*     */       }
/* 132 */       return save;
/*     */     } 
/*     */     
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   public Block getBlock() {
/* 139 */     return this.block;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 143 */     return this.id;
/*     */   }
/*     */   
/*     */   public VaroPlayer getPlayer() {
/* 147 */     return this.player;
/*     */   }
/*     */   
/*     */   public SaveableType getType() {
/* 151 */     return this.type;
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroSaveable> getSaveable(VaroPlayer player) {
/* 155 */     return player.getStats().getSaveables();
/*     */   }
/*     */   
/*     */   public static ArrayList<VaroSaveable> getSaveables() {
/* 159 */     return saveables;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\stats\stat\inventory\VaroSaveable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */