/*    */ package de.cuuky.varo.entity.player.stats.stat;
/*    */ 
/*    */ import de.cuuky.varo.clientadapter.nametag.Nametag;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Rank
/*    */   implements VaroSerializeable
/*    */ {
/*    */   private static int highestLocation;
/* 15 */   private static ArrayList<Rank> ranks = new ArrayList<>(); static {
/* 16 */     highestLocation = 1;
/*    */   }
/*    */ 
/*    */   
/*    */   @VaroSerializeField(path = "colorcode")
/*    */   private int colorcode;
/*    */   
/*    */   @VaroSerializeField(path = "name")
/*    */   private String name;
/*    */   @VaroSerializeField(path = "tablistLocation")
/*    */   private int tablistLocation;
/*    */   
/*    */   public Rank() {
/* 29 */     ranks.add(this);
/*    */   }
/*    */   
/*    */   public Rank(String name) {
/* 33 */     this.name = name.replace("&", "§");
/* 34 */     this.tablistLocation = 1;
/*    */     
/* 36 */     ranks.add(this);
/*    */     
/* 38 */     Nametag.refreshAll();
/*    */   }
/*    */   
/*    */   public int getColorcode() {
/* 42 */     return this.colorcode;
/*    */   }
/*    */   
/*    */   public String getDisplay() {
/* 46 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 50 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getTablistLocation() {
/* 54 */     return this.tablistLocation;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDeserializeEnd() {
/* 59 */     if (this.tablistLocation > highestLocation) {
/* 60 */       highestLocation = this.tablistLocation;
/*    */     }
/*    */   }
/*    */   
/*    */   public void onSerializeStart() {}
/*    */   
/*    */   public void remove() {
/* 67 */     ranks.remove(this);
/*    */   }
/*    */   
/*    */   public void setColorcode(int colorcode) {
/* 71 */     this.colorcode = colorcode;
/*    */   }
/*    */   
/*    */   public void setTablistLocation(int tablistLocation) {
/* 75 */     this.tablistLocation = tablistLocation;
/*    */     
/* 77 */     if (tablistLocation > highestLocation)
/* 78 */       highestLocation = tablistLocation; 
/*    */   }
/*    */   
/*    */   public static int getHighestLocation() {
/* 82 */     return highestLocation;
/*    */   }
/*    */   
/*    */   public static ArrayList<Rank> getRanks() {
/* 86 */     return ranks;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\stats\stat\Rank.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */