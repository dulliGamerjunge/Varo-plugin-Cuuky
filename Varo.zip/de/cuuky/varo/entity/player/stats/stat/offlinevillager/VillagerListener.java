/*    */ package de.cuuky.varo.entity.player.stats.stat.offlinevillager;
/*    */ 
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.listener.utils.EntityDamageByEntityUtil;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.bukkit.event.entity.EntityDeathEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*    */ 
/*    */ public class VillagerListener
/*    */   implements Listener {
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageEvent event) {
/* 18 */     if (!event.getEntity().getType().toString().contains("ZOMBIE") || event.getCause().toString().contains("ENTITY")) {
/*    */       return;
/*    */     }
/* 21 */     OfflineVillager vill = OfflineVillager.getVillager(event.getEntity());
/* 22 */     if (vill == null) {
/*    */       return;
/*    */     }
/* 25 */     event.setCancelled(true);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 30 */     if (!event.getEntity().getType().toString().contains("ZOMBIE")) {
/*    */       return;
/*    */     }
/* 33 */     OfflineVillager vill = OfflineVillager.getVillager(event.getEntity());
/* 34 */     if (vill == null) {
/*    */       return;
/*    */     }
/* 37 */     Player damager = (new EntityDamageByEntityUtil(event)).getDamager();
/* 38 */     if (damager == null) {
/*    */       return;
/*    */     }
/* 41 */     VaroPlayer vp = VaroPlayer.getPlayer(damager);
/* 42 */     if (vp.getTeam() == null || vill.getVp().getTeam() == null || !vp.getTeam().equals(vill.getVp().getTeam())) {
/*    */       return;
/*    */     }
/* 45 */     event.setCancelled(true);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDeath(EntityDeathEvent event) {
/* 50 */     if (event.getEntity().getKiller() == null || !event.getEntity().getType().toString().contains("ZOMBIE")) {
/*    */       return;
/*    */     }
/* 53 */     OfflineVillager vill = OfflineVillager.getVillager((Entity)event.getEntity());
/* 54 */     if (vill == null) {
/*    */       return;
/*    */     }
/* 57 */     vill.kill(VaroPlayer.getPlayer(event.getEntity().getKiller()));
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onInteract(PlayerInteractEntityEvent event) {
/* 62 */     if (!event.getRightClicked().getType().toString().contains("ZOMBIE")) {
/*    */       return;
/*    */     }
/* 65 */     OfflineVillager vill = OfflineVillager.getVillager(event.getRightClicked());
/* 66 */     if (vill == null) {
/*    */       return;
/*    */     }
/* 69 */     event.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\stats\stat\offlinevillager\VillagerListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */