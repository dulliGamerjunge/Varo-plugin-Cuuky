/*     */ package de.cuuky.varo.entity.player.stats.stat.offlinevillager;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*     */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Difficulty;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Zombie;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OfflineVillager
/*     */   implements VaroSerializeable
/*     */ {
/*     */   private static Class<?> nbttagClass;
/*  34 */   private static ArrayList<OfflineVillager> villagers = new ArrayList<>(); static {
/*  35 */     Bukkit.getPluginManager().registerEvents(new VillagerListener(), (Plugin)Main.getInstance());
/*     */     
/*     */     try {
/*  38 */       nbttagClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".NBTTagCompound");
/*  39 */     } catch (Exception|Error e) {
/*  40 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @VaroSerializeField(path = "lastInventory")
/*     */   private InventoryBackup backup;
/*     */   
/*     */   @VaroSerializeField(path = "villagerLocation")
/*     */   private Location location;
/*     */   private VaroPlayer vp;
/*     */   private Zombie zombie;
/*     */   private Entity entity;
/*     */   
/*     */   public OfflineVillager() {
/*  55 */     villagers.add(this);
/*     */   }
/*     */   
/*     */   public OfflineVillager(VaroPlayer vp, Location location) {
/*  59 */     this.backup = new InventoryBackup(vp);
/*  60 */     this.location = location;
/*  61 */     this.vp = vp;
/*     */     
/*  63 */     create();
/*     */     
/*  65 */     villagers.add(this);
/*     */   }
/*     */   
/*     */   private void freezeVillager() {
/*  69 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*  70 */       Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/*  74 */               OfflineVillager.this.zombie.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 1000000, 255));
/*     */             }
/*  76 */           }0L, 20000000L);
/*     */     } else {
/*     */       try {
/*  79 */         Object nmsEn = this.zombie.getClass().getMethod("getHandle", new Class[0]).invoke(this.zombie, new Object[0]);
/*  80 */         Object compound = nbttagClass.newInstance();
/*  81 */         nmsEn.getClass().getMethod("c", new Class[] { compound.getClass() }).invoke(nmsEn, new Object[] { compound });
/*  82 */         compound.getClass().getDeclaredMethod("setByte", new Class[] { String.class, byte.class }).invoke(compound, new Object[] { "NoAI", Byte.valueOf((byte)1) });
/*  83 */         nmsEn.getClass().getMethod("f", new Class[] { nbttagClass }).invoke(nmsEn, new Object[] { compound });
/*  84 */       } catch (Exception e) {
/*  85 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void create() {
/*  90 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  94 */             if (OfflineVillager.this.location.getWorld().getDifficulty() == Difficulty.PEACEFUL) {
/*  95 */               OfflineVillager.this.location.getWorld().setDifficulty(Difficulty.EASY);
/*     */             }
/*  97 */             EntityType type = VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_9) ? EntityType.valueOf("ZOMBIE_VILLAGER") : EntityType.ZOMBIE;
/*  98 */             OfflineVillager.this.zombie = (Zombie)OfflineVillager.this.location.getWorld().spawnEntity(OfflineVillager.this.location, type);
/*  99 */             OfflineVillager.this.zombie.setCustomName("§c" + OfflineVillager.this.vp.getName());
/* 100 */             OfflineVillager.this.zombie.setCustomNameVisible(true);
/*     */             
/* 102 */             if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_9)) {
/* 103 */               OfflineVillager.this.zombie.setVillager(true);
/*     */             }
/* 105 */             OfflineVillager.this.freezeVillager();
/* 106 */             OfflineVillager.this.entity = (Entity)OfflineVillager.this.zombie;
/*     */           }
/* 108 */         }1L);
/*     */   }
/*     */   
/*     */   public void kill(VaroPlayer killer) {
/* 112 */     if (this.zombie != null) {
/* 113 */       this.zombie.getWorld().strikeLightningEffect(this.zombie.getLocation());
/*     */     }
/* 115 */     remove(); byte b; int i;
/*     */     ItemStack[] arrayOfItemStack;
/* 117 */     for (i = (arrayOfItemStack = this.backup.getInventory().getInventory().getContents()).length, b = 0; b < i; ) { ItemStack it = arrayOfItemStack[b];
/* 118 */       if (it != null && it.getType() != Material.AIR)
/* 119 */         this.location.getWorld().dropItemNaturally(this.location, it);  b++; }
/*     */     
/* 121 */     for (ItemStack it : this.backup.getArmor()) {
/* 122 */       if (it != null && it.getType() != Material.AIR)
/* 123 */         this.location.getWorld().dropItemNaturally(this.location, it); 
/*     */     } 
/* 125 */     Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.DEATH, ConfigMessages.ALERT_DISCORD_KILL.getValue().replace("%death%", this.vp.getName()).replace("%killer%", killer.getName()));
/* 126 */     Bukkit.broadcastMessage(ConfigMessages.DEATH_KILLED_BY.getValue().replace("%death%", this.vp.getName()).replace("%killer%", killer.getName()));
/*     */     
/* 128 */     killer.onEvent(BukkitEventType.KILL);
/* 129 */     this.vp.onEvent(BukkitEventType.KILLED);
/*     */   }
/*     */   
/*     */   public void remove() {
/* 133 */     if (this.zombie != null) {
/* 134 */       this.zombie.remove();
/*     */     }
/* 136 */     villagers.remove(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {
/* 141 */     this.vp = this.backup.getVaroPlayer();
/* 142 */     if (this.vp == null) {
/* 143 */       remove();
/*     */     }
/* 145 */     for (Entity ent : this.location.getWorld().getEntities()) {
/* 146 */       if (ent.getType().toString().contains("ZOMBIE")) {
/* 147 */         Zombie zombie = (Zombie)ent;
/* 148 */         if (zombie.isVillager() && zombie.getCustomName() != null && zombie.getCustomName().equals("§c" + this.vp.getName())) {
/* 149 */           this.zombie = (Zombie)ent;
/* 150 */           this.entity = ent;
/*     */         } 
/*     */       } 
/*     */     } 
/* 154 */     if (this.zombie == null) {
/* 155 */       create();
/*     */     }
/*     */   }
/*     */   
/*     */   public void onSerializeStart() {}
/*     */   
/*     */   public Entity getEntity() {
/* 162 */     return this.entity;
/*     */   }
/*     */   
/*     */   public VaroPlayer getVp() {
/* 166 */     return this.vp;
/*     */   }
/*     */   
/*     */   public Zombie getZombie() {
/* 170 */     return this.zombie;
/*     */   }
/*     */   
/*     */   public static OfflineVillager getVillager(Entity entity) {
/* 174 */     for (OfflineVillager vill : villagers) {
/* 175 */       if (!entity.equals(vill.getEntity())) {
/*     */         continue;
/*     */       }
/* 178 */       return vill;
/*     */     } 
/*     */     
/* 181 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\stats\stat\offlinevillager\OfflineVillager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */