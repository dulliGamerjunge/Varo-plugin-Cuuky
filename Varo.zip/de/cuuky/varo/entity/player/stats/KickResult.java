/*    */ package de.cuuky.varo.entity.player.stats;
/*    */ 
/*    */ public enum KickResult
/*    */ {
/*  5 */   ALLOW,
/*  6 */   BANNED,
/*  7 */   DEAD,
/*  8 */   FINALE_JOIN,
/*  9 */   MASS_RECORDING_JOIN,
/* 10 */   NO_PREPRODUCES_LEFT,
/* 11 */   NO_PROJECTUSER,
/* 12 */   NO_SESSIONS_LEFT,
/* 13 */   NO_TIME,
/* 14 */   NOT_IN_TIME,
/* 15 */   SERVER_FULL,
/* 16 */   SERVER_NOT_PUBLISHED,
/* 17 */   SPECTATOR,
/* 18 */   STRIKE_BAN;
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\stats\KickResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */