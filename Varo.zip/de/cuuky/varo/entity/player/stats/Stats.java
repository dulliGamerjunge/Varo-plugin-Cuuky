/*     */ package de.cuuky.varo.entity.player.stats;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.api.VaroAPI;
/*     */ import de.cuuky.varo.api.event.VaroAPIEvent;
/*     */ import de.cuuky.varo.api.event.events.player.PlayerStateChangeEvent;
/*     */ import de.cuuky.varo.api.event.events.player.strike.PlayerStrikeReceiveEvent;
/*     */ import de.cuuky.varo.api.event.events.player.strike.PlayerStrikeRemoveEvent;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.entity.player.stats.stat.Strike;
/*     */ import de.cuuky.varo.entity.player.stats.stat.YouTubeVideo;
/*     */ import de.cuuky.varo.entity.player.stats.stat.inventory.InventoryBackup;
/*     */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*     */ import de.cuuky.varo.event.VaroEvent;
/*     */ import de.cuuky.varo.event.VaroEventType;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import de.cuuky.varo.spawns.Spawn;
/*     */ import de.cuuky.varo.utils.varo.LocationFormat;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import org.apache.commons.lang.time.DateUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Stats
/*     */   implements VaroSerializeable
/*     */ {
/*     */   @VaroSerializeField(path = "state")
/*     */   private PlayerState state;
/*     */   @VaroSerializeField(path = "lastLocation")
/*     */   private Location lastLocation;
/*     */   @VaroSerializeField(path = "countdown")
/*     */   private int countdown;
/*     */   @VaroSerializeField(path = "kills")
/*     */   private int kills;
/*     */   @VaroSerializeField(path = "sessions")
/*     */   private int sessions;
/*     */   @VaroSerializeField(path = "sessionsPlayed")
/*     */   private int sessionsPlayed;
/*     */   @VaroSerializeField(path = "wins")
/*     */   private int wins;
/*     */   @VaroSerializeField(path = "showActionbarTime")
/*     */   private boolean showActionbarTime;
/*     */   @VaroSerializeField(path = "showScoreboard")
/*     */   private boolean showScoreboard;
/*     */   @VaroSerializeField(path = "willClear")
/*     */   private boolean willClear;
/*     */   @VaroSerializeField(path = "firstTimeJoined")
/*     */   private Date firstTimeJoined;
/*     */   @VaroSerializeField(path = "lastJoined")
/*     */   private Date lastJoined;
/*     */   @VaroSerializeField(path = "lastEnemyContact")
/*     */   private Date lastEnemyContact;
/*     */   @VaroSerializeField(path = "diedAt")
/*     */   private Date diedAt;
/*     */   @VaroSerializeField(path = "timeUntilAddSession")
/*     */   private Date timeUntilAddSession;
/*     */   @VaroSerializeField(path = "playerBackpack")
/*     */   private VaroInventory playerBackpack;
/*     */   @VaroSerializeField(path = "restoreBackup")
/*     */   private InventoryBackup restoreBackup;
/*     */   @VaroSerializeField(path = "youtubeLink")
/*     */   private String youtubeLink;
/*     */   @VaroSerializeField(path = "inventoryBackups", arrayClass = InventoryBackup.class)
/*     */   private ArrayList<InventoryBackup> inventoryBackups;
/*     */   @VaroSerializeField(path = "saveables", arrayClass = VaroSaveable.class)
/*     */   private ArrayList<VaroSaveable> saveables;
/*     */   @VaroSerializeField(path = "strikes", arrayClass = Strike.class)
/*     */   private ArrayList<Strike> strikes;
/*     */   @VaroSerializeField(path = "videos", arrayClass = YouTubeVideo.class)
/*     */   private ArrayList<YouTubeVideo> videos;
/*     */   private VaroPlayer owner;
/*     */   
/*     */   public Stats() {}
/*     */   
/*     */   public Stats(VaroPlayer vp) {
/*  96 */     this.owner = vp;
/*     */   }
/*     */   
/*     */   public void addInventoryBackup(InventoryBackup backup) {
/* 100 */     this.inventoryBackups.add(backup);
/*     */   }
/*     */   
/*     */   public void addKill() {
/* 104 */     this.kills++;
/* 105 */     this.owner.update();
/* 106 */     Main.getVaroGame().getTopScores().update();
/*     */   }
/*     */   
/*     */   public void addSaveable(VaroSaveable saveable) {
/* 110 */     this.saveables.add(saveable);
/*     */   }
/*     */   
/*     */   public void addSessionPlayed() {
/* 114 */     this.sessionsPlayed++;
/*     */   }
/*     */   
/*     */   public void addStrike(Strike strike) {
/* 118 */     if (VaroAPI.getEventManager().executeEvent((VaroAPIEvent)new PlayerStrikeReceiveEvent(strike))) {
/*     */       return;
/*     */     }
/* 121 */     this.strikes.add(strike);
/* 122 */     strike.activate(this.strikes.size());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addVideo(YouTubeVideo video) {
/* 128 */     this.videos.add(video);
/*     */     
/* 130 */     Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.YOUTUBE, String.valueOf(this.owner.getName()) + " hat heute folgendes Projektvideo hochgeladen: " + video.getLink());
/*     */   }
/*     */   
/*     */   public void addWin() {
/* 134 */     this.wins++;
/*     */   }
/*     */   
/*     */   public void clearInventory() {
/* 138 */     if (this.owner.isOnline())
/* 139 */     { this.owner.getPlayer().getInventory().clear(); byte b; int i; ItemStack[] arrayOfItemStack;
/* 140 */       for (i = (arrayOfItemStack = this.owner.getPlayer().getInventory().getArmorContents()).length, b = 0; b < i; ) { ItemStack stack = arrayOfItemStack[b];
/* 141 */         stack.setType(Material.AIR); b++; }
/*     */        }
/* 143 */     else { setWillClear(true); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCountdown() {
/* 149 */     return this.countdown;
/*     */   }
/*     */   
/*     */   public String getCountdownMin(int sec) {
/* 153 */     int min = sec / 60;
/*     */     
/* 155 */     if (min < 10) {
/* 156 */       return "0" + min;
/*     */     }
/* 158 */     return (new StringBuilder(String.valueOf(min))).toString();
/*     */   }
/*     */   
/*     */   public String getCountdownSec(int sec) {
/* 162 */     sec %= 60;
/*     */     
/* 164 */     if (sec < 10) {
/* 165 */       return "0" + sec;
/*     */     }
/* 167 */     return (new StringBuilder(String.valueOf(sec))).toString();
/*     */   }
/*     */   
/*     */   public Date getDiedAt() {
/* 171 */     return this.diedAt;
/*     */   }
/*     */   
/*     */   public Date getFirstTimeJoined() {
/* 175 */     return this.firstTimeJoined;
/*     */   }
/*     */   
/*     */   public ArrayList<InventoryBackup> getInventoryBackups() {
/* 179 */     return this.inventoryBackups;
/*     */   }
/*     */   
/*     */   public KickResult getKickResult(Player player) {
/* 183 */     KickResult result = KickResult.ALLOW;
/* 184 */     if (Main.getVaroGame().hasStarted())
/* 185 */     { if (this.owner.isRegistered()) {
/* 186 */         result = getVaroKickResult();
/*     */       } else {
/* 188 */         result = KickResult.NO_PROJECTUSER;
/*     */       }  }
/* 190 */     else { if (!ConfigSetting.UNREGISTERED_PLAYER_JOIN.getValueAsBoolean() && !this.owner.isRegistered()) {
/* 191 */         result = KickResult.NO_PROJECTUSER;
/*     */       }
/* 193 */       if (Main.getVaroGame().isStarting() && Spawn.getSpawn(this.owner) == null) {
/* 194 */         result = KickResult.NO_PROJECTUSER;
/*     */       } }
/*     */     
/* 197 */     if (Bukkit.hasWhitelist() && !Bukkit.getWhitelistedPlayers().contains(player)) {
/* 198 */       result = KickResult.SERVER_NOT_PUBLISHED;
/*     */     }
/* 200 */     if (player.isBanned()) {
/* 201 */       result = KickResult.BANNED;
/*     */     }
/* 203 */     if (VersionUtils.getOnlinePlayer().size() >= Bukkit.getMaxPlayers()) {
/* 204 */       result = KickResult.SERVER_FULL;
/*     */     }
/* 206 */     if (result != KickResult.ALLOW && result != KickResult.MASS_RECORDING_JOIN && result != KickResult.SPECTATOR && result != KickResult.FINALE_JOIN && ((
/* 207 */       player.hasPermission("varo.alwaysjoin") && ConfigSetting.IGNORE_JOINSYSTEMS_AS_OP.getValueAsBoolean()) || (!Main.getVaroGame().hasStarted() && player.isOp()))) {
/* 208 */       if (Main.getVaroGame().hasStarted())
/* 209 */         if (result == KickResult.DEAD || !this.owner.isRegistered()) {
/* 210 */           setState(PlayerState.SPECTATOR);
/*     */         } else {
/* 212 */           this.owner.setAdminIgnore(true);
/*     */         }  
/* 214 */       result = KickResult.ALLOW;
/*     */     } 
/*     */     
/* 217 */     return result;
/*     */   }
/*     */   
/*     */   public int getKills() {
/* 221 */     return this.kills;
/*     */   }
/*     */   
/*     */   public Date getLastEnemyContact() {
/* 225 */     return this.lastEnemyContact;
/*     */   }
/*     */   
/*     */   public Date getLastJoined() {
/* 229 */     return this.lastJoined;
/*     */   }
/*     */   
/*     */   public Location getLastLocation() {
/* 233 */     return this.lastLocation;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 237 */     return this.owner.getName();
/*     */   }
/*     */   
/*     */   public VaroInventory getPlayerBackpack() {
/* 241 */     return this.playerBackpack;
/*     */   }
/*     */   
/*     */   public InventoryBackup getRestoreBackup() {
/* 245 */     return this.restoreBackup;
/*     */   }
/*     */   
/*     */   public ArrayList<VaroSaveable> getSaveables() {
/* 249 */     if (this.owner.getTeam() != null) {
/* 250 */       return this.owner.getTeam().getSaveables();
/*     */     }
/* 252 */     return this.saveables;
/*     */   }
/*     */   
/*     */   public ArrayList<VaroSaveable> getSaveablesRaw() {
/* 256 */     return this.saveables;
/*     */   }
/*     */   
/*     */   public int getSessions() {
/* 260 */     return this.sessions;
/*     */   }
/*     */   
/*     */   public int getSessionsPlayed() {
/* 264 */     return this.sessionsPlayed;
/*     */   }
/*     */   
/*     */   public PlayerState getState() {
/* 268 */     return this.state;
/*     */   }
/*     */   
/*     */   public String[] getStatsListed() {
/* 272 */     String colorcode = Main.getColorCode();
/* 273 */     SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
/* 274 */     this.lastLocation = this.owner.isOnline() ? this.owner.getPlayer().getLocation() : this.lastLocation;
/*     */     
/* 276 */     return new String[] { "§7ID§8: " + colorcode + this.owner.getId(), "§7UUID§8: " + colorcode + this.owner.getUuid(), "§7Team§8: " + colorcode + ((this.owner.getTeam() != null) ? this.owner.getTeam().getDisplay() : "/"), "§7Rank§8: " + colorcode + ((this.owner.getRank() != null) ? this.owner.getRank().getDisplay() : "/"), "§7Sessions§8: " + colorcode + this.sessions, "§7Sessions Played§8: " + colorcode + this.sessionsPlayed, "§7Countdown§8: " + colorcode + this.countdown, "§7Kills§8: " + colorcode + this.kills, "§7WillClearInventory§8: " + colorcode + this.willClear, "§7ShowScoreboard§8: " + colorcode + this.showScoreboard, "§7LastLocation§8: " + colorcode + ((this.lastLocation != null) ? (new LocationFormat(this.lastLocation)).format(String.valueOf(colorcode) + "x§7, " + colorcode + "y§7, " + colorcode + "z§7 in " + colorcode + "world") : "/"), "§7TimeUntilAddSession§8: " + colorcode + ((this.timeUntilAddSession != null) ? dateFormat.format(Long.valueOf(this.timeUntilAddSession.getTime())) : "/"), "§7FirstTimeJoined§8: " + colorcode + ((this.firstTimeJoined != null) ? dateFormat.format(this.firstTimeJoined) : "/"), "§7LastTimeJoined§8: " + colorcode + ((this.lastJoined != null) ? dateFormat.format(this.lastJoined) : "/"), "§7LastEnemyContact§8: " + colorcode + ((this.lastEnemyContact != null) ? dateFormat.format(this.lastEnemyContact) : "/"), "§7DiedAt§8: " + colorcode + ((this.diedAt == null) ? "/" : dateFormat.format(this.diedAt)), "§7YouTubeLink§8: " + colorcode + ((this.youtubeLink != null) ? this.youtubeLink : "/"), "§7YouTubeVideos§8: " + colorcode + ((this.videos == null) ? 0 : this.videos.size()), "§7StrikeAmount§8: " + colorcode + ((this.strikes == null) ? 0 : this.strikes.size()), "§7State§8: " + colorcode + this.state.getName() };
/*     */   }
/*     */   
/*     */   public ArrayList<Strike> getStrikes() {
/* 280 */     return this.strikes;
/*     */   }
/*     */   
/*     */   public Date getTimeUntilAddSession() {
/* 284 */     return this.timeUntilAddSession;
/*     */   }
/*     */   
/*     */   public KickResult getVaroKickResult() {
/* 288 */     GregorianCalendar curr = new GregorianCalendar();
/* 289 */     KickResult result = KickResult.ALLOW;
/* 290 */     if (this.sessions > 0) {
/* 291 */       result = KickResult.ALLOW;
/*     */     }
/* 293 */     else if (ConfigSetting.SESSIONS_PER_DAY.getValueAsInt() > 0) {
/* 294 */       if (ConfigSetting.PRE_PRODUCE_SESSIONS.getValueAsInt() > 0) {
/* 295 */         result = KickResult.NO_PREPRODUCES_LEFT;
/*     */       } else {
/* 297 */         result = KickResult.NO_SESSIONS_LEFT;
/*     */       } 
/*     */     } else {
/* 300 */       result = KickResult.NO_TIME;
/*     */     } 
/*     */ 
/*     */     
/* 304 */     if (VaroEvent.getEvent(VaroEventType.MASS_RECORDING).isEnabled()) {
/* 305 */       result = KickResult.MASS_RECORDING_JOIN;
/*     */     }
/* 307 */     if (Main.getVaroGame().getFinaleJoinStart()) {
/* 308 */       result = KickResult.FINALE_JOIN;
/*     */     }
/*     */     
/* 311 */     if (Main.isBootedUp() && 
/* 312 */       !Main.getDataManager().getOutsideTimeChecker().canJoin()) {
/* 313 */       result = KickResult.NOT_IN_TIME;
/*     */     }
/* 315 */     for (Strike strike : this.strikes) {
/* 316 */       if (strike.getBanUntil() != null && 
/* 317 */         curr.before(strike.getBanUntil()))
/* 318 */         result = KickResult.STRIKE_BAN; 
/*     */     } 
/* 320 */     if (!isAlive()) {
/* 321 */       result = KickResult.DEAD;
/*     */     }
/* 323 */     if (isSpectator()) {
/* 324 */       result = KickResult.SPECTATOR;
/*     */     }
/* 326 */     return result;
/*     */   }
/*     */   
/*     */   public ArrayList<YouTubeVideo> getVideos() {
/* 330 */     return this.videos;
/*     */   }
/*     */   
/*     */   public int getWins() {
/* 334 */     return this.wins;
/*     */   }
/*     */   
/*     */   public String getYoutubeLink() {
/* 338 */     return this.youtubeLink;
/*     */   }
/*     */   
/*     */   public boolean hasFullTime() {
/* 342 */     return (this.countdown == ConfigSetting.PLAY_TIME.getValueAsInt() * 60);
/*     */   }
/*     */   
/*     */   public boolean hasTimeLeft() {
/* 346 */     return (this.countdown >= 1 && this.countdown != ConfigSetting.PLAY_TIME.getValueAsInt() * 60);
/*     */   }
/*     */   
/*     */   public boolean hasVideo(String videoId) {
/* 350 */     for (YouTubeVideo video : this.videos) {
/* 351 */       if (video.getVideoId().equals(videoId))
/* 352 */         return true; 
/*     */     } 
/* 354 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isAlive() {
/* 358 */     if (this.state == PlayerState.ALIVE) {
/* 359 */       return true;
/*     */     }
/* 361 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isShowActionbarTime() {
/* 365 */     return this.showActionbarTime;
/*     */   }
/*     */   
/*     */   public boolean isShowScoreboard() {
/* 369 */     return this.showScoreboard;
/*     */   }
/*     */   
/*     */   public boolean isSpectator() {
/* 373 */     return (this.state == PlayerState.SPECTATOR);
/*     */   }
/*     */   
/*     */   public boolean isWillClear() {
/* 377 */     return this.willClear;
/*     */   }
/*     */   
/*     */   public void loadDefaults() {
/* 381 */     loadStartDefaults();
/* 382 */     this.kills = 0;
/* 383 */     this.youtubeLink = null;
/* 384 */     this.wins = 0;
/* 385 */     this.state = PlayerState.ALIVE;
/*     */     
/* 387 */     removeTeamAndRank();
/*     */     
/* 389 */     if (this.owner.isOnline()) {
/* 390 */       Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 394 */               Stats.this.lastLocation = Stats.this.owner.getPlayer().getLocation();
/*     */             }
/* 396 */           },  1L);
/*     */     } else {
/* 398 */       this.lastLocation = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void loadStartDefaults() {
/* 403 */     if (this.owner.getTeam() != null) {
/* 404 */       this.owner.getTeam().loadDefaults();
/*     */     }
/* 406 */     this.videos = new ArrayList<>();
/* 407 */     this.strikes = new ArrayList<>();
/* 408 */     this.saveables = new ArrayList<>();
/* 409 */     this.inventoryBackups = new ArrayList<>();
/* 410 */     this.playerBackpack = new VaroInventory(ConfigSetting.BACKPACK_PLAYER_SIZE.getValueAsInt());
/*     */     
/* 412 */     this.willClear = false;
/* 413 */     this.showScoreboard = true;
/* 414 */     this.diedAt = null;
/* 415 */     this.timeUntilAddSession = null;
/*     */     
/* 417 */     this.firstTimeJoined = new Date();
/* 418 */     this.lastJoined = new Date();
/* 419 */     this.lastEnemyContact = new Date();
/* 420 */     if (ConfigSetting.SESSIONS_PER_DAY.getValueAsInt() > 0) {
/* 421 */       this.sessions = ConfigSetting.SESSIONS_PER_DAY.getValueAsInt();
/*     */     } else {
/* 423 */       this.sessions = 1;
/*     */     } 
/* 425 */     if (ConfigSetting.PRE_PRODUCE_SESSIONS.getValueAsInt() > 0) {
/* 426 */       this.sessions += ConfigSetting.PRE_PRODUCE_SESSIONS.getValueAsInt();
/*     */     }
/* 428 */     this.sessionsPlayed = 0;
/* 429 */     this.countdown = ConfigSetting.PLAY_TIME.getValueAsInt() * 60;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {}
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {}
/*     */   
/*     */   public void remove() {
/* 439 */     if (this.videos != null) {
/* 440 */       this.videos.forEach(video -> video.remove());
/*     */     }
/* 442 */     if (this.saveables != null) {
/* 443 */       this.saveables.forEach(saveable -> saveable.remove());
/*     */     }
/* 445 */     if (this.inventoryBackups != null) {
/* 446 */       this.inventoryBackups.forEach(b -> b.remove());
/*     */     }
/* 448 */     setState(PlayerState.DEAD);
/*     */   }
/*     */   
/*     */   public void removeCountdown() {
/* 452 */     this.countdown = ConfigSetting.PLAY_TIME.getValueAsInt() * 60;
/*     */   }
/*     */   
/*     */   public void removeInventoryBackup(InventoryBackup backup) {
/* 456 */     backup.remove();
/* 457 */     this.inventoryBackups.remove(backup);
/*     */   }
/*     */   
/*     */   public void removeSaveable(VaroSaveable saveable) {
/* 461 */     this.saveables.remove(saveable);
/*     */   }
/*     */   
/*     */   public void removeStrike(Strike strike) {
/* 465 */     if (VaroAPI.getEventManager().executeEvent((VaroAPIEvent)new PlayerStrikeRemoveEvent(strike))) {
/*     */       return;
/*     */     }
/* 468 */     int strikeNumber = strike.getStrikeNumber();
/* 469 */     this.strikes.remove(strike);
/*     */     
/* 471 */     for (Strike aStrike : this.strikes) {
/* 472 */       if (aStrike.getStrikeNumber() > strikeNumber) {
/* 473 */         aStrike.decreaseStrikeNumber();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeStrikes() {
/* 479 */     this.strikes.clear();
/*     */   }
/*     */   
/*     */   public void removeTeamAndRank() {
/* 483 */     if (this.owner.getTeam() != null) {
/* 484 */       this.owner.getTeam().removeMember(this.owner);
/*     */     }
/* 486 */     if (this.owner.getRank() != null)
/* 487 */       this.owner.setRank(null); 
/*     */   }
/*     */   
/*     */   public void removeVideo(YouTubeVideo video) {
/* 491 */     this.videos.remove(video);
/*     */   }
/*     */   
/*     */   public void setBan() {
/* 495 */     this.sessions--;
/*     */     
/* 497 */     if (ConfigSetting.SESSIONS_PER_DAY.getValueAsInt() <= 0) {
/* 498 */       this.timeUntilAddSession = DateUtils.addHours(new Date(), ConfigSetting.JOIN_AFTER_HOURS.getValueAsInt());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCountdown(int time) {
/* 503 */     this.countdown = time;
/*     */   }
/*     */   
/*     */   public void setDiedAt(Date diedAt) {
/* 507 */     this.diedAt = diedAt;
/*     */   }
/*     */   
/*     */   public void setFirstTimeJoined(Date firstTimeJoined) {
/* 511 */     this.firstTimeJoined = firstTimeJoined;
/*     */   }
/*     */   
/*     */   public void setKills(int kills) {
/* 515 */     this.kills = kills;
/* 516 */     this.owner.update();
/* 517 */     Main.getVaroGame().getTopScores().update();
/*     */   }
/*     */   
/*     */   public void setLastEnemyContact(Date lastEnemyContact) {
/* 521 */     this.lastEnemyContact = lastEnemyContact;
/*     */   }
/*     */   
/*     */   public void setLastJoined(Date lastJoined) {
/* 525 */     this.lastJoined = lastJoined;
/*     */   }
/*     */   
/*     */   public void setLastLocation(Location lastLocation) {
/* 529 */     this.lastLocation = lastLocation;
/*     */   }
/*     */   
/*     */   public void setOwner(VaroPlayer owner) {
/* 533 */     this.owner = owner;
/*     */   }
/*     */   
/*     */   public void setRestoreBackup(InventoryBackup restoreBackup) {
/* 537 */     this.restoreBackup = restoreBackup;
/*     */   }
/*     */   
/*     */   public void setSessions(int sessions) {
/* 541 */     this.sessions = sessions;
/*     */   }
/*     */   
/*     */   public void setSessionsPlayed(int sessionsPlayed) {
/* 545 */     this.sessionsPlayed = sessionsPlayed;
/*     */   }
/*     */   
/*     */   public void setShowActionbarTime(boolean showActionbarTime) {
/* 549 */     this.showActionbarTime = showActionbarTime;
/*     */   }
/*     */   
/*     */   public void setShowScoreboard(boolean showScoreboard) {
/* 553 */     this.showScoreboard = showScoreboard;
/*     */   }
/*     */   
/*     */   public void setState(PlayerState state) {
/* 557 */     if (VaroAPI.getEventManager().executeEvent((VaroAPIEvent)new PlayerStateChangeEvent(this.owner, state))) {
/*     */       return;
/*     */     }
/* 560 */     this.state = state;
/* 561 */     if (state == PlayerState.DEAD) {
/* 562 */       this.diedAt = new Date();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeUntilAddSession(Date timeUntilNewSession) {
/* 568 */     this.timeUntilAddSession = timeUntilNewSession;
/*     */   }
/*     */   
/*     */   public void setWillClear(boolean willClear) {
/* 572 */     this.willClear = willClear;
/*     */   }
/*     */   
/*     */   public void setWins(int wins) {
/* 576 */     this.wins = wins;
/*     */   }
/*     */   
/*     */   public void setYoutubeLink(String youtubeLink) {
/* 580 */     this.youtubeLink = youtubeLink;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\entity\player\stats\Stats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */