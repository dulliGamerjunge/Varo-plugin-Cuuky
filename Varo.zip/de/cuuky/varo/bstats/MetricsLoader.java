/*    */ package de.cuuky.varo.bstats;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MetricsLoader
/*    */ {
/*    */   private static final int BSTATS_ID = 6639;
/*    */   private Metrics metrics;
/*    */   
/*    */   public MetricsLoader(JavaPlugin instance) {
/* 19 */     loadMetrics(instance);
/*    */   }
/*    */   
/*    */   private void loadMetrics(JavaPlugin instance) {
/*    */     try {
/* 24 */       this.metrics = new Metrics((Plugin)instance, 6639);
/* 25 */       this.metrics.addCustomChart(new Metrics.SimpleBarChart("functionsUsed", new Callable<Map<String, Integer>>()
/*    */             {
/*    */               public Map<String, Integer> call() throws Exception
/*    */               {
/* 29 */                 Map<String, Integer> map = new HashMap<>(); byte b; int i; ConfigSetting[] arrayOfConfigSetting;
/* 30 */                 for (i = (arrayOfConfigSetting = ConfigSetting.values()).length, b = 0; b < i; ) { ConfigSetting entry = arrayOfConfigSetting[b];
/* 31 */                   if (entry.getValue() instanceof Boolean) {
/* 32 */                     map.put(entry.getPath(), Integer.valueOf(entry.getValueAsBoolean() ? 1 : 0));
/*    */                   }
/*    */                   b++; }
/*    */                 
/* 36 */                 return map;
/*    */               }
/*    */             }));
/*    */       
/* 40 */       this.metrics.addCustomChart(new Metrics.MultiLineChart("functionsValues", new Callable<Map<String, Integer>>()
/*    */             {
/*    */               public Map<String, Integer> call() throws Exception {
/* 43 */                 Map<String, Integer> valueMap = new HashMap<>(); byte b; int i; ConfigSetting[] arrayOfConfigSetting;
/* 44 */                 for (i = (arrayOfConfigSetting = ConfigSetting.values()).length, b = 0; b < i; ) { ConfigSetting entry = arrayOfConfigSetting[b];
/* 45 */                   if (entry.getValue() instanceof Integer) {
/* 46 */                     valueMap.put(entry.getPath(), Integer.valueOf(entry.getValueAsInt()));
/*    */                   }
/*    */                   b++; }
/*    */                 
/* 50 */                 return valueMap;
/*    */               }
/*    */             }));
/* 53 */     } catch (Throwable e) {
/* 54 */       e.printStackTrace();
/* 55 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Failed to send data to bStats! (Wrong server version?)");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\bstats\MetricsLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */