package de.cuuky.varo.serialize.identifier;

public interface VaroSerializeable {
  void onDeserializeEnd();
  
  void onSerializeStart();
}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\serialize\identifier\VaroSerializeable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */