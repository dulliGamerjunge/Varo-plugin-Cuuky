package de.cuuky.varo.serialize.identifier;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface VaroSerializeField {
  Class<? extends VaroSerializeable> arrayClass() default NullClass.class;
  
  String enumValue() default "ENUM";
  
  String path() default "PATH";
}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\serialize\identifier\VaroSerializeField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */