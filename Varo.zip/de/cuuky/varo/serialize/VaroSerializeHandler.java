/*    */ package de.cuuky.varo.serialize;
/*    */ 
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import java.io.File;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroSerializeHandler
/*    */ {
/*    */   protected static Map<String, YamlConfiguration> configs;
/*    */   protected static Map<VaroSerializeable, String> enumsRepl;
/*    */   protected static Map<String, File> files;
/*    */   protected static List<VaroSerializeObject> handler;
/* 24 */   protected static final String NULL_REPLACE = "nullReplace";
/*    */   static {
/* 26 */     handler = new ArrayList<>();
/* 27 */     enumsRepl = new HashMap<>();
/* 28 */     configs = new HashMap<>();
/* 29 */     files = new HashMap<>();
/*    */   }
/*    */   
/*    */   protected static VaroSerializeable getEnumByString(String en) {
/* 33 */     for (VaroSerializeable var : enumsRepl.keySet()) {
/* 34 */       if (en.equals(enumsRepl.get(var)))
/* 35 */         return var; 
/*    */     } 
/* 37 */     return null;
/*    */   }
/*    */   
/*    */   protected static VaroSerializeObject getHandler(Class<?> clazz) {
/* 41 */     for (VaroSerializeObject handl : handler) {
/* 42 */       if (handl.getClazz().equals(clazz))
/* 43 */         return handl; 
/*    */     } 
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   protected static String getStringByEnum(VaroSerializeable ser) {
/* 49 */     for (VaroSerializeable var : enumsRepl.keySet()) {
/* 50 */       if (ser.equals(var))
/* 51 */         return enumsRepl.get(var); 
/*    */     } 
/* 53 */     return null;
/*    */   }
/*    */   protected static void registerClass(Class<? extends VaroSerializeable> clazz) {}
/*    */   
/*    */   protected static void registerEnum(Class<? extends VaroSerializeable> clazz) {
/*    */     byte b;
/*    */     int i;
/*    */     Field[] arrayOfField;
/* 61 */     for (i = (arrayOfField = clazz.getDeclaredFields()).length, b = 0; b < i; ) { Field field = arrayOfField[b];
/* 62 */       VaroSerializeField anno = field.<VaroSerializeField>getAnnotation(VaroSerializeField.class);
/* 63 */       if (anno != null)
/*    */         
/*    */         try {
/*    */           
/* 67 */           enumsRepl.put((VaroSerializeable)field.get(clazz), anno.enumValue());
/* 68 */         } catch (IllegalArgumentException e) {
/* 69 */           e.printStackTrace();
/* 70 */         } catch (IllegalAccessException e) {
/* 71 */           e.printStackTrace();
/*    */         }  
/*    */       b++; }
/*    */   
/*    */   }
/*    */   public static void saveAll() {
/* 77 */     for (VaroSerializeObject handl : handler) {
/* 78 */       if (handl.getConfiguration() != null)
/* 79 */         handl.onSave(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\serialize\VaroSerializeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */