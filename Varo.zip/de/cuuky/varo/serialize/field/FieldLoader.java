/*    */ package de.cuuky.varo.serialize.field;
/*    */ 
/*    */ import de.cuuky.varo.serialize.identifier.NullClass;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldLoader
/*    */ {
/* 18 */   private Map<String, Field> fields = new HashMap<>();
/* 19 */   private Map<Field, Class<? extends VaroSerializeable>> arrayTypes = new HashMap<>();
/*    */   public FieldLoader(Class<?> clazz) {
/* 21 */     Field[] declFields = clazz.getDeclaredFields(); byte b; int i; Field[] arrayOfField1;
/* 22 */     for (i = (arrayOfField1 = declFields).length, b = 0; b < i; ) { Field field = arrayOfField1[b];
/* 23 */       if (field.getAnnotation(VaroSerializeField.class) != null) {
/*    */ 
/*    */         
/* 26 */         VaroSerializeField anno = field.<VaroSerializeField>getAnnotation(VaroSerializeField.class);
/*    */         
/* 28 */         this.fields.put(anno.path(), field);
/*    */         
/* 30 */         if (Collection.class.isAssignableFrom(field.getType()) && anno.arrayClass() != NullClass.class)
/* 31 */           this.arrayTypes.put(field, anno.arrayClass()); 
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   } public Map<Field, Class<? extends VaroSerializeable>> getArrayTypes() {
/* 36 */     return this.arrayTypes;
/*    */   }
/*    */   
/*    */   public Map<String, Field> getFields() {
/* 40 */     return this.fields;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\serialize\field\FieldLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */