/*    */ package de.cuuky.varo.serialize.serializer.serializeable.serializeables;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import de.cuuky.varo.serialize.serializer.VaroDeserializer;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerialize;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerializeLoopType;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.bukkit.configuration.MemorySection;
/*    */ 
/*    */ 
/*    */ public class CollectionSerializeable
/*    */   extends VaroSerialize
/*    */ {
/*    */   public CollectionSerializeable() {
/* 18 */     super(VaroSerializeLoopType.CONTINUE);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(Field field, Object obj, MemorySection section, String path, VaroSerializeObject object) {
/* 23 */     if (Collection.class.isAssignableFrom(field.getType())) {
/* 24 */       Class<?> clazz = (Class)object.getFieldLoader().getArrayTypes().get(field);
/* 25 */       if (clazz != null) {
/* 26 */         VaroSerializeObject handl = getHandler((Class)object.getFieldLoader().getArrayTypes().get(field));
/* 27 */         if (handl != null) {
/* 28 */           ArrayList<VaroSerializeable> newList = new ArrayList<>();
/* 29 */           if (obj instanceof MemorySection) {
/* 30 */             MemorySection listSection = (MemorySection)obj;
/* 31 */             for (String listStr : listSection.getKeys(true)) {
/* 32 */               Object listEntry = listSection.get(listStr);
/* 33 */               if (!(listEntry instanceof MemorySection) || listStr.contains(".")) {
/*    */                 continue;
/*    */               }
/* 36 */               VaroDeserializer des = new VaroDeserializer((MemorySection)listEntry, handl);
/* 37 */               newList.add(des.deserialize());
/*    */             } 
/*    */           } 
/*    */ 
/*    */           
/* 42 */           return newList;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 47 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\serialize\serializer\serializeable\serializeables\CollectionSerializeable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */