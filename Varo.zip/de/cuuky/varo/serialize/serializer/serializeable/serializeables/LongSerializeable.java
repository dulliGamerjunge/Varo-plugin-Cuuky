/*    */ package de.cuuky.varo.serialize.serializer.serializeable.serializeables;
/*    */ 
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerialize;
/*    */ import de.cuuky.varo.serialize.serializer.serializeable.VaroSerializeLoopType;
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ public class LongSerializeable
/*    */   extends VaroSerialize
/*    */ {
/*    */   public LongSerializeable() {
/* 11 */     super(VaroSerializeLoopType.LOOP);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(Field field, Object obj) {
/* 16 */     if (!field.getType().isPrimitive() || !(obj instanceof String)) {
/* 17 */       return null;
/*    */     }
/* 19 */     return Long.valueOf((String)obj);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\serialize\serializer\serializeable\serializeables\LongSerializeable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */