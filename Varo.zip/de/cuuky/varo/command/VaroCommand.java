/*     */ package de.cuuky.varo.command;
/*     */ 
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VaroCommand
/*     */ {
/*  50 */   private static ArrayList<VaroCommand> varoCommands = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] aliases;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String permission;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String description;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VaroCommand(String name, String description, String permission, String... aliases) {
/*  94 */     this.name = name;
/*  95 */     this.aliases = aliases;
/*  96 */     this.description = description;
/*  97 */     this.permission = permission;
/*     */     
/*  99 */     varoCommands.add(this);
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 103 */     return this.description;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 107 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getPermission() {
/* 111 */     return this.permission;
/*     */   }
/*     */   
/*     */   public boolean isAlias(String s) {
/* 115 */     if (this.aliases == null)
/* 116 */       return false;  byte b; int i;
/*     */     String[] arrayOfString;
/* 118 */     for (i = (arrayOfString = this.aliases).length, b = 0; b < i; ) { String alias = arrayOfString[b];
/* 119 */       if (alias.equalsIgnoreCase(s))
/* 120 */         return true;  b++; }
/*     */     
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void onCommand(CommandSender paramCommandSender, VaroPlayer paramVaroPlayer, Command paramCommand, String paramString, String[] paramArrayOfString);
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String description) {
/* 132 */     this.description = description;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 136 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VaroCommand getCommand(String command) {
/* 145 */     for (VaroCommand chunkCommand : varoCommands) {
/* 146 */       if (!chunkCommand.getName().equalsIgnoreCase(command) && !chunkCommand.isAlias(command)) {
/*     */         continue;
/*     */       }
/* 149 */       return chunkCommand;
/*     */     } 
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<VaroCommand> getVaroCommand() {
/* 158 */     return varoCommands;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\VaroCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */