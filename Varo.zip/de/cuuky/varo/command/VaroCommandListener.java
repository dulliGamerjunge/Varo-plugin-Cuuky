/*    */ package de.cuuky.varo.command;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class VaroCommandListener
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 17 */     if (args.length < 1) {
/* 18 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "§lVaro §7§lCommands:");
/* 19 */       for (VaroCommand varoCommand : VaroCommand.getVaroCommand())
/* 20 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo " + varoCommand.getName() + "§8: §7" + varoCommand.getDescription()); 
/* 21 */       return false;
/*    */     } 
/*    */     
/* 24 */     VaroCommand command = VaroCommand.getCommand(args[0]);
/* 25 */     if (command == null) {
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Kommando '" + Main.getColorCode() + args[0] + "§7' nicht gefunden!");
/* 27 */       return false;
/*    */     } 
/*    */     
/* 30 */     if (command.getPermission() != null && !sender.hasPermission(command.getPermission())) {
/* 31 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 32 */       return false;
/*    */     } 
/*    */     
/* 35 */     command.onCommand(sender, (sender instanceof Player) ? VaroPlayer.getPlayer((Player)sender) : null, cmd, label, JavaUtils.removeString(args, 0));
/* 36 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\VaroCommandListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */