/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.list.enchantment.EnchantmentList;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.EnchantmentStorageMeta;
/*     */ 
/*     */ 
/*     */ public class EnchantmentCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public EnchantmentCommand() {
/*  21 */     super("enchantment", "Einstellungen zu den Verzauberungslisten", "varo.enchantment", new String[] { "enchantments", "enchant", "enchants" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  26 */     if (vp == null) {
/*  27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du musst ein Spieler sein!");
/*     */       
/*     */       return;
/*     */     } 
/*  31 */     if (args.length == 0) {
/*  32 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----- " + Main.getColorCode() + "Enchantments §7-----");
/*  33 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " enchantment §7<enchantmentlist> [Remove / Add / List]");
/*  34 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " item §7list");
/*  35 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Tipp: §7Der /varo item Befehl blockt alle Items.");
/*  36 */       sender.sendMessage(Main.getPrefix());
/*  37 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Dieser Command fuegt alle Verzauberungungen des Items, das du in der Hand haeltst, der Liste hinzu.");
/*  38 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Alternativ sind auch Buecher moeglich");
/*  39 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7--------------------");
/*     */       
/*     */       return;
/*     */     } 
/*  43 */     if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
/*  44 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Liste aller " + Main.getColorCode() + "Enchantmentlisten§7:");
/*  45 */       for (EnchantmentList enchantmentList : EnchantmentList.getEnchantmentLists()) {
/*  46 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + enchantmentList.getLocation());
/*     */       }
/*     */       return;
/*     */     } 
/*  50 */     if (args.length < 2) {
/*  51 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Falsche Argumente! " + Main.getColorCode() + label + " enchant");
/*     */       
/*     */       return;
/*     */     } 
/*  55 */     EnchantmentList list = EnchantmentList.getEnchantmentList(args[0]);
/*  56 */     if (list == null) {
/*  57 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Liste " + args[0] + " nicht gefunden!");
/*     */       
/*     */       return;
/*     */     } 
/*  61 */     if (args[1].equalsIgnoreCase("list")) {
/*  62 */       if (list.getEnchantments().size() < 1) {
/*  63 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Keine Verzauberungen gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*  67 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Liste aller Verzauberungen von " + Main.getColorCode() + list.getLocation() + "§7:");
/*  68 */       for (String enc1 : list.getEnchantments()) {
/*  69 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + enc1);
/*     */       }
/*     */       return;
/*     */     } 
/*  73 */     Player player = vp.getPlayer();
/*  74 */     if (player.getItemInHand() == null || player.getItemInHand().getType() == Material.AIR) {
/*  75 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du hast kein Item in der Hand!");
/*     */       
/*     */       return;
/*     */     } 
/*  79 */     ItemStack item = player.getItemInHand();
/*  80 */     Map<Enchantment, Integer> encs = null;
/*  81 */     if (item.getItemMeta() instanceof EnchantmentStorageMeta) {
/*  82 */       EnchantmentStorageMeta meta = (EnchantmentStorageMeta)item.getItemMeta();
/*  83 */       encs = meta.getStoredEnchants();
/*     */     } else {
/*  85 */       encs = item.getItemMeta().getEnchants();
/*     */     } 
/*  87 */     if (encs.size() == 0) {
/*  88 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Es wurden keine Enchantments auf deinem Item/Buch gefunden!");
/*     */       
/*     */       return;
/*     */     } 
/*  92 */     for (Enchantment enc : encs.keySet()) {
/*  93 */       if (args[1].contains("add")) {
/*  94 */         if (list.hasEnchantment(enc, ((Integer)encs.get(enc)).intValue())) {
/*  95 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Verzauberung '" + enc.getName() + " (" + encs.get(enc) + ")' steht bereits auf dieser Liste!");
/*     */           
/*     */           return;
/*     */         } 
/*  99 */         list.addEnchantment(enc, ((Integer)encs.get(enc)).intValue());
/* 100 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Verzauberung " + enc.getName() + " (" + encs.get(enc) + ") erfolgreich zu " + list.getLocation() + " hinzugefuegt!"); continue;
/* 101 */       }  if (args[1].equalsIgnoreCase("remove")) {
/* 102 */         if (!list.hasEnchantment(enc, ((Integer)encs.get(enc)).intValue())) {
/* 103 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Verzauberung '" + enc.getName() + " (" + encs.get(enc) + ")' steht nicht auf dieser Liste!");
/*     */           
/*     */           return;
/*     */         } 
/* 107 */         list.removeEnchantment(enc, ((Integer)encs.get(enc)).intValue());
/* 108 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Verzauberung " + enc.getName() + " (" + encs.get(enc) + ") erfolgreich von " + list.getLocation() + " entfernt!"); continue;
/* 109 */       }  if (args[1].equalsIgnoreCase("list")) {
/* 110 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Liste aller Verzauberungen von " + Main.getColorCode() + list.getLocation() + "§7:");
/* 111 */         for (String enc1 : list.getEnchantments())
/* 112 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + enc1);  continue;
/*     */       } 
/* 114 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " enchantment §7<enchantmentlist> [Remove / Add / List]");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\EnchantmentCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */