/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.spawns.Spawn;
/*     */ import de.cuuky.varo.utils.varo.LocationFormat;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ public class SpawnsCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public SpawnsCommand() {
/*  17 */     super("spawns", "Hauptbefehl fuer die Spawns, in welchen die Spieler spawnen", "varo.spawns", new String[] { "spawnholes", "spawn", "holes" });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  23 */     if (args.length == 0) {
/*  24 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "§lSpawn Command§7§l:");
/*  25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo spawns§7 set <Zahl/Spieler>");
/*  26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo spawns§7 delete <Zahl/Spieler> - (Loescht den Spawneintrag und den Spawn in der Welt)");
/*  27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo spawns§7 player <Zahl> <set/remove> [Spieler]");
/*  28 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo spawns§7 list");
/*  29 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo spawns§7 generate <radius>/auto <amount>/player/team [Half-Step-Materiall] [Side-Block-Material]");
/*  30 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "------");
/*  31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "/varo spawns generate kann dir deine Spawns entweder nach Anzahl oder den eingetragenen Teams oder Spielern generieren.\n" + "Der Unterschied zwischen 'player' und 'team' ist, dass bei 'team' auch die Teams bei der Sortierung beruecksichtigt werden.");
/*  32 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Example for number: §7/varo spawns generate 30 40 STONE_SLAB");
/*  33 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Example for players: §7/varo spawns generate auto team");
/*  34 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "------");
/*     */       
/*     */       return;
/*     */     } 
/*  38 */     if (args[0].equalsIgnoreCase("generate")) {
/*  39 */       if (!(sender instanceof Player)) {
/*  40 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du musst ein Spieler sein!");
/*     */         
/*     */         return;
/*     */       } 
/*  44 */       if (args.length < 3) {
/*  45 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo spawns§7 generate <radius> <amount>/player/teams [Half-Step-Materiall] [Side-Block-Material]");
/*     */         
/*     */         return;
/*     */       } 
/*  49 */       String material = null;
/*  50 */       if (args.length == 4) {
/*  51 */         material = String.valueOf(args[3]);
/*     */       }
/*  53 */       String sideBlockMaterial = null;
/*  54 */       if (args.length == 5) {
/*  55 */         sideBlockMaterial = String.valueOf(args[4]);
/*     */       }
/*     */       try {
/*  58 */         Integer.valueOf(args[1]);
/*  59 */       } catch (Exception e) {
/*     */         try {
/*  61 */           if (args[1].equalsIgnoreCase("auto") || args[1].equalsIgnoreCase("automatic"))
/*  62 */             if (args[2].equalsIgnoreCase("player") || args[2].equalsIgnoreCase("team")) {
/*  63 */               args[1] = String.valueOf((int)(VaroPlayer.getAlivePlayer().size() * 0.85D));
/*     */             } else {
/*  65 */               args[1] = String.valueOf((int)(Integer.valueOf(args[2]).intValue() * 0.85D));
/*     */             }  
/*  67 */         } catch (Exception e1) {
/*  68 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Beim erstellen der Spawns ist ein Fehler aufgetreten! Richtige Werte angegeben?");
/*  69 */           e1.printStackTrace();
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */       try {
/*  75 */         if (args[2].equalsIgnoreCase("player") || args[2].equalsIgnoreCase("team")) {  }
/*     */         else
/*     */         {  }
/*     */       
/*  79 */       } catch (Exception e) {
/*  80 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Beim erstellen der Spawns ist ein Fehler aufgetreten! Richtige Werte angegeben?");
/*  81 */         e.printStackTrace();
/*     */         
/*     */         return;
/*     */       } 
/*  85 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Die Spawns wurden mit der Anzahl " + Main.getColorCode() + args[2] + "§7, dem Radius " + Main.getColorCode() + args[1] + "§7, dem Block-Material " + Main.getColorCode() + ((args.length >= 4) ? args[3] : "STONE_BRICK_SLAB") + " §7und dem Seitenblock-Material " + Main.getColorCode() + ((args.length >= 5) ? args[4] : "DIRT") + " §7generiert!"); return;
/*     */     } 
/*  87 */     if (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("place")) {
/*  88 */       if (!(sender instanceof Player)) {
/*  89 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Not for console!");
/*     */         
/*     */         return;
/*     */       } 
/*  93 */       Player player = (Player)sender;
/*  94 */       if (args.length == 1) {
/*  95 */         Spawn spawn = new Spawn(player.getLocation());
/*  96 */         player.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Spawn " + spawn.getNumber() + " §7erfolgreich erstellt!");
/*  97 */       } else if (args.length == 2) {
/*  98 */         int spawnNumber = -1;
/*     */         try {
/* 100 */           spawnNumber = Integer.valueOf(args[1]).intValue();
/* 101 */           if (spawnNumber <= 0) {
/* 102 */             player.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn Zahl muss positiv sein!");
/*     */             return;
/*     */           } 
/* 105 */         } catch (NumberFormatException numberFormatException) {}
/*     */         
/* 107 */         if (spawnNumber != -1) {
/* 108 */           Spawn oldSpawn = Spawn.getSpawn(spawnNumber);
/* 109 */           if (oldSpawn != null) {
/* 110 */             oldSpawn.delete();
/* 111 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der alte Spawn mit der ID " + Main.getColorCode() + spawnNumber + " §7wurde entfernt, um fuer den neuen Platz zu machen.");
/*     */           } 
/*     */           
/* 114 */           Spawn spawn = new Spawn(spawnNumber, player.getLocation());
/* 115 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn " + Main.getColorCode() + spawn.getNumber() + " §7gesetzt!");
/*     */         } else {
/* 117 */           VaroPlayer varoplayer = VaroPlayer.getPlayer(args[1]);
/* 118 */           if (varoplayer == null) {
/* 119 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler oder Zahl nicht gueltig!");
/*     */             
/*     */             return;
/*     */           } 
/* 123 */           Spawn oldSpawn = Spawn.getSpawn(varoplayer);
/* 124 */           if (oldSpawn != null) {
/* 125 */             oldSpawn.delete();
/* 126 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der alte Spawn mit der ID " + Main.getColorCode() + oldSpawn.getNumber() + " §7wurde entfernt, um fuer den neuen Platz zu machen.");
/*     */           } 
/*     */           
/* 129 */           Spawn spawn = new Spawn(varoplayer, player.getLocation());
/* 130 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spielerspawn " + Main.getColorCode() + spawn.getNumber() + " §7fuer den Spieler " + Main.getColorCode() + spawn.getPlayer().getName() + " §7gesetzt!");
/*     */         } 
/*     */       } else {
/* 133 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "/varo spawns set [Zahl/Spieler]");
/*     */       }  return;
/* 135 */     }  if (args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("delete")) {
/* 136 */       Spawn spawn; if (!(sender instanceof Player)) {
/* 137 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Not for console!");
/*     */         
/*     */         return;
/*     */       } 
/* 141 */       if (args.length != 2) {
/* 142 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "/varo spawns " + args[0] + " [Zahl/Spieler/@a]");
/*     */         
/*     */         return;
/*     */       } 
/* 146 */       if (args[1].equalsIgnoreCase("@a")) {
/* 147 */         for (Spawn spawn1 : Spawn.getSpawnsClone()) {
/* 148 */           spawn1.delete();
/*     */         }
/* 150 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Alle Spawns erfolgreich entfernt!");
/*     */         
/*     */         return;
/*     */       } 
/* 154 */       Player player = (Player)sender;
/* 155 */       int spawnNumber = -1;
/*     */       try {
/* 157 */         spawnNumber = Integer.valueOf(args[1]).intValue();
/* 158 */         if (spawnNumber <= 0) {
/* 159 */           player.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn Zahl muss positiv sein!");
/*     */           return;
/*     */         } 
/* 162 */       } catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */       
/* 165 */       if (spawnNumber != -1) {
/* 166 */         spawn = Spawn.getSpawn(spawnNumber);
/* 167 */         if (spawn == null) {
/* 168 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn mit der ID" + Main.getColorCode() + spawnNumber + " nicht gefunden!");
/*     */           
/*     */           return;
/*     */         } 
/* 172 */         spawn.delete();
/* 173 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn " + Main.getColorCode() + spawn.getNumber() + " §7entfernt!");
/*     */       } else {
/* 175 */         VaroPlayer varoplayer = VaroPlayer.getPlayer(args[1]);
/* 176 */         if (varoplayer == null) {
/* 177 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler oder Zahl nicht gueltig!");
/*     */           
/*     */           return;
/*     */         } 
/* 181 */         spawn = Spawn.getSpawn(varoplayer);
/* 182 */         if (spawn == null) {
/* 183 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn von dem Spieler " + Main.getColorCode() + varoplayer.getName() + " nicht gefunden!");
/*     */           
/*     */           return;
/*     */         } 
/* 187 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn von " + Main.getColorCode() + varoplayer.getName() + " §7entfernt!");
/*     */       } 
/* 189 */       spawn.delete(); return;
/*     */     } 
/* 191 */     if (args[0].equalsIgnoreCase("player")) {
/* 192 */       if (args.length < 3) {
/* 193 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo spawns§7 player <Zahl/@a> <set/remove> [Spieler]");
/*     */         
/*     */         return;
/*     */       } 
/* 197 */       int spawnNumber = -1;
/*     */       try {
/* 199 */         spawnNumber = Integer.valueOf(args[1]).intValue();
/* 200 */         if (spawnNumber <= 0) {
/* 201 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn Zahl muss positiv sein!");
/*     */           return;
/*     */         } 
/* 204 */       } catch (NumberFormatException numberFormatException) {}
/*     */       
/* 206 */       Spawn spawn = Spawn.getSpawn(spawnNumber);
/* 207 */       if (spawn == null && !args[1].equals("@a") && args[2].equalsIgnoreCase("set")) {
/* 208 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spawn konnte nicht gefunden werden!");
/*     */         
/*     */         return;
/*     */       } 
/* 212 */       if (args[2].equalsIgnoreCase("set")) {
/* 213 */         if (args.length < 4) {
/* 214 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo spawns§7 player <Zahl> set [Spieler]");
/*     */           
/*     */           return;
/*     */         } 
/* 218 */         VaroPlayer varoplayer = VaroPlayer.getPlayer(args[3]);
/* 219 */         if (varoplayer == null) {
/* 220 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler oder Zahl nicht gueltig!");
/*     */           
/*     */           return;
/*     */         } 
/* 224 */         spawn.setPlayer(varoplayer);
/* 225 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler von Spawn " + Main.getColorCode() + spawn.getNumber() + " §7erfolgreich auf " + Main.getColorCode() + spawn.getPlayer().getName() + " §7gesetzt!");
/* 226 */       } else if (args[2].equalsIgnoreCase("remove")) {
/* 227 */         if (args[1].equals("@a")) {
/* 228 */           for (Spawn spaw : Spawn.getSpawns()) {
/* 229 */             spaw.setPlayer(null);
/*     */           }
/* 231 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler von allen Spawns entfernt!");
/*     */           
/*     */           return;
/*     */         } 
/* 235 */         spawn.setPlayer(null);
/*     */         
/* 237 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler von Spawn " + Main.getColorCode() + spawn.getNumber() + " §7erfolgreich entfernt!");
/*     */       } 
/*     */     } else {
/* 240 */       if (args[0].equalsIgnoreCase("list")) {
/* 241 */         if (Spawn.getSpawns().isEmpty()) {
/* 242 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Keine Spawns gefunden!");
/*     */           
/*     */           return;
/*     */         } 
/* 246 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§lEine Liste aller " + Main.getColorCode() + "§lSpawns§7§l:");
/* 247 */         for (Spawn spawn : Spawn.getSpawns()) {
/* 248 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Spawn " + spawn.getNumber() + "§7: ");
/* 249 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Location: " + (new LocationFormat(spawn.getLocation())).format("§7X§8: " + Main.getColorCode() + "x §7Y§8: " + Main.getColorCode() + "y §7Z§8: " + Main.getColorCode() + "z §7in " + Main.getColorCode() + "world"));
/* 250 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Spieler: " + Main.getColorCode() + ((spawn.getPlayer() != null) ? spawn.getPlayer().getName() : "Keinen"));
/* 251 */           sender.sendMessage(Main.getPrefix());
/*     */         } 
/*     */         return;
/*     */       } 
/* 255 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Not found! /varo spawns");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\SpawnsCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */