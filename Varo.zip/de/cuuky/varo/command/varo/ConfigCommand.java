/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.utils.JavaUtils;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public ConfigCommand() {
/* 19 */     super("config", "Hauptbefehl fuer die Config", "varo.config", new String[] { "configuration" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer player, Command cmd, String label, String[] args) {
/* 24 */     if (args.length == 0) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----- " + Main.getColorCode() + "Config §7-----");
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/config set §7<key> <value>");
/* 27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/config search <Keyword>");
/* 28 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/config menu");
/* 29 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/config reload");
/* 30 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/config reset");
/* 31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----------------------");
/*    */       
/*    */       return;
/*    */     } 
/* 35 */     if (args[0].equalsIgnoreCase("reload") || args[0].equalsIgnoreCase("refresh")) {
/* 36 */       Main.getDataManager().reloadConfig();
/* 37 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Erfolgreich " + Main.getColorCode() + "alle Listen§7, die " + Main.getColorCode() + "Messages §7und die " + Main.getColorCode() + "Config §7neu geladen!");
/* 38 */     } else if (args[0].equalsIgnoreCase("set")) {
/* 39 */       if (args.length != 3) {
/* 40 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/config §7set <key> <value>"); return;
/*    */       }  byte b;
/*    */       int i;
/*    */       ConfigSetting[] arrayOfConfigSetting;
/* 44 */       for (i = (arrayOfConfigSetting = ConfigSetting.values()).length, b = 0; b < i; ) { ConfigSetting entry = arrayOfConfigSetting[b];
/* 45 */         if (!entry.getPath().equalsIgnoreCase(args[1])) {
/*    */           b++; continue;
/*    */         } 
/* 48 */         Object arg = JavaUtils.getStringObject(args[2]);
/* 49 */         entry.setValue(arg, true);
/*    */         
/* 51 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Erfolgreich den Eintrag '§a" + entry.getPath() + "§7' auf '§a" + entry.getValue() + "§7' gesetzt!");
/*    */         
/*    */         return; }
/*    */       
/* 55 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Den Eintrag " + Main.getColorCode() + args[1] + "§7 gibt es nicht in der Config!");
/* 56 */     } else if (args[0].equalsIgnoreCase("reset")) {
/* 57 */       byte b; int i; ConfigSetting[] arrayOfConfigSetting; for (i = (arrayOfConfigSetting = ConfigSetting.values()).length, b = 0; b < i; ) { ConfigSetting entry = arrayOfConfigSetting[b];
/* 58 */         entry.setValue(entry.getDefaultValue(), true); b++; }
/*    */       
/* 60 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Erfolgreich alle Eintraege zurueckgesetzt!");
/* 61 */     } else if (args[0].equalsIgnoreCase("menu")) {
/* 62 */       if (!(sender instanceof org.bukkit.entity.Player)) {
/* 63 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Nicht fuer die Konsole!");
/*    */ 
/*    */         
/*    */         return;
/*    */       } 
/* 68 */     } else if (args[0].equalsIgnoreCase("search")) {
/* 69 */       if (args.length != 2) {
/* 70 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "/config search <Keyword>");
/*    */         
/*    */         return;
/*    */       } 
/* 74 */       String needle = args[1];
/* 75 */       ArrayList<ConfigSetting> foundSettings = new ArrayList<>(); byte b; int i;
/*    */       ConfigSetting[] arrayOfConfigSetting;
/* 77 */       for (i = (arrayOfConfigSetting = ConfigSetting.values()).length, b = 0; b < i; ) { ConfigSetting setting = arrayOfConfigSetting[b];
/* 78 */         if (setting.getFullPath().toLowerCase().contains(needle))
/*    */         {
/*    */           
/* 81 */           foundSettings.add(setting); } 
/*    */         b++; }
/*    */       
/* 84 */       if (foundSettings.isEmpty()) {
/* 85 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Fuer " + Main.getColorCode() + needle + " §7konnte kein ConfigEintrag gefunden werden!");
/*    */         
/*    */         return;
/*    */       } 
/* 89 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§lFolgende Einstellungen wurden gefunden:");
/* 90 */       for (ConfigSetting setting : foundSettings)
/* 91 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + setting.getFullPath() + " §8- §7" + JavaUtils.getArgsToString(setting.getDescription(), " ")); 
/*    */     } else {
/* 93 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Command '" + args[0] + "' not found! §7Type /config for help.");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\ConfigCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */