/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class ActionbarCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public ActionbarCommand() {
/* 13 */     super("actionbar", "Aktiviert/Deaktiviert die Actionbar-Zeit", "varo.actionbar", new String[] { "ab" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 18 */     if (vp == null) {
/* 19 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du musst ein Spieler sein!");
/*    */       
/*    */       return;
/*    */     } 
/* 23 */     if (vp.getStats().isShowActionbarTime()) {
/* 24 */       vp.getStats().setShowActionbarTime(false);
/* 25 */       vp.sendMessage(String.valueOf(Main.getPrefix()) + "Du siehst nun nicht mehr die Zeit in der Actionbar!");
/*    */     } else {
/* 27 */       vp.getStats().setShowActionbarTime(true);
/* 28 */       vp.sendMessage(String.valueOf(Main.getPrefix()) + "Du siehst nun die Zeit in der Actionbar!");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\ActionbarCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */