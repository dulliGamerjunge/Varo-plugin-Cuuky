/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import java.awt.Color;
/*     */ import net.dv8tion.jda.api.entities.User;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiscordCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public DiscordCommand() {
/*  21 */     super("discord", "Der Hauptbefehl fuer den DiscordBot", null, new String[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  26 */     if (args.length == 0) {
/*  27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----- " + Main.getColorCode() + "Discord-Commands §7-----");
/*  28 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo discord verify");
/*     */       
/*  30 */       if (sender.hasPermission("varo.discord")) {
/*  31 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo discord getLink §7<Spieler>");
/*  32 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo discord unlink §7<Spieler>");
/*  33 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo discord bypassRegister §7<Spieler> <true/false>");
/*  34 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo discord sendMessage §7<Nachricht>");
/*  35 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo discord reload");
/*  36 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo discord shutdown");
/*  37 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo discord settings");
/*     */       } 
/*  39 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7--------------------------");
/*     */       
/*     */       return;
/*     */     } 
/*  43 */     if (Main.getBotLauncher().getDiscordbot() == null) {
/*  44 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der DiscordBot wurde beim Start nicht aufgesetzt!");
/*     */       
/*     */       return;
/*     */     } 
/*  48 */     if (args[0].equalsIgnoreCase("verify")) {
/*  49 */       if (!(sender instanceof Player)) {
/*  50 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Nicht fure die Konsole!");
/*     */         
/*     */         return;
/*     */       } 
/*  54 */       BotRegister botRegister = (BotRegister.getRegister(vp.getUuid()) == null) ? new BotRegister(vp.getUuid(), true) : BotRegister.getRegister(vp.getUuid());
/*  55 */       botRegister.setPlayerName(vp.getName());
/*  56 */       if (args.length == 1) {
/*  57 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Deine Discord-Verifizierung ist " + (botRegister.isActive() ? "§aaktiv" : "§cinaktiv"));
/*  58 */         if (!botRegister.isActive()) {
/*  59 */           sender.sendMessage(botRegister.getKickMessage());
/*     */         } else {
/*  61 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Account: " + Main.getColorCode() + botRegister.getMember().getNickname());
/*  62 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Gib §c/varo discord verify remove §7um die Verifizierung zu entfernen!");
/*     */         } 
/*  64 */       } else if (args[1].equals("remove")) {
/*  65 */         if (!botRegister.isActive()) {
/*  66 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du bist noch nicht verifiziert!");
/*     */           
/*     */           return;
/*     */         } 
/*  70 */         botRegister.delete();
/*  71 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Verifzierung erfolgreich entfernt!");
/*     */       } 
/*     */       return;
/*     */     } 
/*  75 */     if (sender.hasPermission("varo.discord")) {
/*  76 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/varo discord " + args[0] + " not found! §7Type /discord for help. (Insufficient permissions?)");
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     BotRegister reg = null;
/*     */     try {
/*  82 */       reg = BotRegister.getBotRegisterByPlayerName(args[1]);
/*  83 */     } catch (Exception exception) {}
/*     */     
/*  85 */     if (args[0].equalsIgnoreCase("getLink") || args[0].equalsIgnoreCase("link")) {
/*  86 */       if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/*  87 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das Verifzierungs-System wurde in der Config deaktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/*  91 */       if (Main.getBotLauncher().getDiscordbot() == null || !Main.getBotLauncher().getDiscordbot().isEnabled()) {
/*  92 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der DiscordBot wurde nicht aktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/*  96 */       if (reg == null) {
/*  97 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Spieler §7" + args[1] + " §7hat den Server noch nie betreten!");
/*     */         
/*     */         return;
/*     */       } 
/* 101 */       User user = Main.getBotLauncher().getDiscordbot().getJda().getUserById(reg.getUserId());
/* 102 */       if (user == null) {
/* 103 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7User fuer diesen Spieler nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/* 107 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Discord Account von " + args[1] + " heisst: " + Main.getColorCode() + user.getName() + "§7 und die ID lautet " + Main.getColorCode() + user.getId() + "§7!");
/* 108 */     } else if (args[0].equalsIgnoreCase("unlink")) {
/* 109 */       if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/* 110 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das Verifzierungs-System wurde in der Config deaktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/* 114 */       if (Main.getBotLauncher().getDiscordbot() == null || !Main.getBotLauncher().getDiscordbot().isEnabled()) {
/* 115 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der DiscordBot wurde nicht aktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/* 119 */       if (reg == null) {
/* 120 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Spieler §7" + args[1] + " §7hat den Server noch nie betreten!");
/*     */         
/*     */         return;
/*     */       } 
/* 124 */       reg.setUserId(-1L);
/* 125 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Discord Account wurde erfolgreich von §7" + args[1] + "§7 entkoppelt!");
/* 126 */       if (Bukkit.getPlayerExact(reg.getPlayerName()) != null)
/* 127 */         Bukkit.getPlayerExact(reg.getPlayerName()).kickPlayer(reg.getKickMessage()); 
/* 128 */     } else if (args[0].equalsIgnoreCase("bypassRegister") || args[0].equalsIgnoreCase("bypass")) {
/* 129 */       if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/* 130 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das Verifzierungs-System wurde in der Config deaktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/* 134 */       if (Main.getBotLauncher().getDiscordbot() == null || !Main.getBotLauncher().getDiscordbot().isEnabled()) {
/* 135 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der DiscordBot wurde nicht aktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/* 139 */       if (reg == null) {
/* 140 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Spieler §7" + args[1] + " §7hat den Server noch nie betreten!");
/*     */         
/*     */         return;
/*     */       } 
/* 144 */       if (args.length != 3) {
/* 145 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/varo discord bypass <Spieler> <true/false>");
/*     */         
/*     */         return;
/*     */       } 
/* 149 */       if (args[2].equalsIgnoreCase("true") || args[2].equalsIgnoreCase("false"))
/* 150 */       { reg.setBypass(args[2].equalsIgnoreCase("true"));
/* 151 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[1] + "§7 bypasst jetzt " + (reg.isBypass() ? "" : "§7nicht mehr§7") + " das Register-System!"); }
/*     */       else
/* 153 */       { sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/varo discord bypass <add/remove> <Spielername>"); } 
/* 154 */     } else if (args[0].equalsIgnoreCase("reload")) {
/* 155 */       Main.getBotLauncher().getDiscordbot().disconnect();
/* 156 */       Main.getBotLauncher().getDiscordbot().connect();
/* 157 */       for (Player pl : Bukkit.getOnlinePlayers()) {
/* 158 */         if (ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean() && BotRegister.getBotRegisterByPlayerName(pl.getName()) == null)
/* 159 */           pl.kickPlayer("§7Das Discord Verify System wurde aktiviert!"); 
/* 160 */       }  sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7DiscordBot §aerfolgreich §7neu geladen!");
/* 161 */     } else if (args[0].equalsIgnoreCase("settings")) {
/* 162 */       if (!(sender instanceof Player)) {
/* 163 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Only for players!");
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/* 168 */     } else if (args[0].equalsIgnoreCase("shutdown")) {
/* 169 */       if (Main.getBotLauncher().getDiscordbot().getJda() == null) {
/* 170 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der §bDiscordBot §7ist nicht online!");
/*     */         
/*     */         return;
/*     */       } 
/* 174 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§bDiscordBot §7erfolgreich heruntergefahren!");
/* 175 */       Main.getBotLauncher().getDiscordbot().disconnect();
/* 176 */     } else if (args[0].equalsIgnoreCase("sendMessage")) {
/* 177 */       if (Main.getBotLauncher().getDiscordbot() == null || !Main.getBotLauncher().getDiscordbot().isEnabled()) {
/* 178 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der DiscordBot wurde nicht aktiviert!");
/*     */         
/*     */         return;
/*     */       } 
/* 182 */       if (Main.getBotLauncher().getDiscordbot().getEventChannel() == null) {
/* 183 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Dem Bot wurde kein eventChannel gegeben!");
/*     */         
/*     */         return;
/*     */       } 
/* 187 */       String message = ""; byte b; int i; String[] arrayOfString;
/* 188 */       for (i = (arrayOfString = args).length, b = 0; b < i; ) { String ar = arrayOfString[b];
/* 189 */         if (!ar.equals(args[0]))
/*     */         {
/* 191 */           if (message.equals("")) {
/* 192 */             message = ar;
/*     */           } else {
/* 194 */             message = String.valueOf(message) + " " + ar;
/*     */           }  }  b++; }
/*     */       
/* 197 */       Main.getBotLauncher().getDiscordbot().sendMessage(message, "MESSAGE", Color.YELLOW, Main.getBotLauncher().getDiscordbot().getEventChannel());
/*     */     } else {
/* 199 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/varo discord " + args[0] + " not found! §7Type /discord for help.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\DiscordCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */