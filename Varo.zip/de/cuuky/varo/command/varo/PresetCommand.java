/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.preset.PresetLoader;
/*    */ import java.io.File;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ public class PresetCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public PresetCommand() {
/* 16 */     super("preset", "Command fuer die Presets", "varo.preset", new String[] { "presettings", "presets" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 21 */     if (args.length == 0) {
/* 22 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo preset §7load <PresetPath>");
/* 23 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo preset §7save <PresetPath>");
/* 24 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo preset §7list");
/*    */       
/*    */       return;
/*    */     } 
/* 28 */     if (args[0].equalsIgnoreCase("load"))
/* 29 */     { if (args.length != 2) {
/* 30 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo preset §7load <PresetPath>");
/*    */         
/*    */         return;
/*    */       } 
/* 34 */       PresetLoader loader = new PresetLoader(args[1]);
/* 35 */       if (!loader.getFile().isDirectory()) {
/* 36 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + args[1] + " nicht gefunden!");
/*    */         
/*    */         return;
/*    */       } 
/* 40 */       loader.loadSettings();
/* 41 */       Main.getDataManager().reloadConfig();
/* 42 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Einstellungen '" + args[1] + "' erfolgreich geladen!"); }
/* 43 */     else if (args[0].equalsIgnoreCase("save"))
/* 44 */     { if (args.length != 2) {
/* 45 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo preset §7save <PresetPath>");
/*    */         
/*    */         return;
/*    */       } 
/* 49 */       PresetLoader loader = new PresetLoader(args[1]);
/* 50 */       loader.copyCurrentSettingsTo();
/* 51 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Derzeitige Einstellungen erfolgreich unter '" + args[1] + "' gespeichert!"); }
/* 52 */     else if (args[0].equalsIgnoreCase("list"))
/* 53 */     { File file = new File("plugins/Varo/presets");
/* 54 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§lListe aller Presets:"); byte b; int i; File[] arrayOfFile;
/* 55 */       for (i = (arrayOfFile = file.listFiles()).length, b = 0; b < i; ) { File f = arrayOfFile[b];
/* 56 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + f.getName()); b++; }
/*    */        }
/* 58 */     else { sender.sendMessage(String.valueOf(Main.getPrefix()) + "Command not found! /varo preset"); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\PresetCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */