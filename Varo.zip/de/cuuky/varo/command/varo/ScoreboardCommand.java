/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.scoreboard.DisplaySlot;
/*    */ 
/*    */ public class ScoreboardCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public ScoreboardCommand() {
/* 15 */     super("scoreboard", "Aktiviert/Deaktiviert das Scoreboard", "varo.scoreboard", new String[] { "sb" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 20 */     if (vp == null) {
/* 21 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du musst ein Spieler sein!");
/*    */       
/*    */       return;
/*    */     } 
/* 25 */     if (!ConfigSetting.SCOREBOARD.getValueAsBoolean()) {
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Scoreboards wurden deaktiviert!");
/*    */       
/*    */       return;
/*    */     } 
/* 30 */     if (vp.getStats().isShowScoreboard()) {
/* 31 */       vp.getPlayer().getScoreboard().clearSlot(DisplaySlot.SIDEBAR);
/* 32 */       vp.sendMessage(String.valueOf(Main.getPrefix()) + "Du siehst nun nicht mehr das Scoreboard!");
/* 33 */       vp.getStats().setShowScoreboard(false);
/*    */     } else {
/* 35 */       vp.getStats().setShowScoreboard(true);
/* 36 */       Main.getDataManager().getScoreboardHandler().sendScoreBoard(vp);
/* 37 */       vp.sendMessage(String.valueOf(Main.getPrefix()) + "Du siehst nun das Scoreboard!");
/* 38 */       if (vp.getNametag() != null) {
/* 39 */         vp.getNametag().giveAll();
/*    */       }
/*    */     } 
/* 42 */     vp.update();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\ScoreboardCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */