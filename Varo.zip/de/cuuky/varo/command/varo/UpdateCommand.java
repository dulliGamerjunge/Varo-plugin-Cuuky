/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.spigot.FileDownloader;
/*     */ import de.cuuky.varo.spigot.updater.VaroUpdateResultSet;
/*     */ import de.cuuky.varo.spigot.updater.VaroUpdater;
/*     */ import java.io.File;
/*     */ import java.net.URLDecoder;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   private String oldFileName;
/*     */   private boolean pluginNameChanged;
/*     */   private boolean resetOldDirectory;
/*     */   
/*     */   public UpdateCommand() {
/*  25 */     super("update", "Installiert automatisch die neueste Version", "varo.update", new String[0]); } private void deleteDirectory(File file) {
/*     */     byte b;
/*     */     int i;
/*     */     File[] arrayOfFile;
/*  29 */     for (i = (arrayOfFile = file.listFiles()).length, b = 0; b < i; ) { File listFile = arrayOfFile[b];
/*  30 */       if (listFile.isDirectory()) {
/*  31 */         deleteDirectory(listFile);
/*     */       }
/*  33 */       listFile.delete();
/*     */       b++; }
/*     */     
/*  36 */     file.delete();
/*     */   }
/*     */ 
/*     */   
/*     */   private void update(CommandSender sender, VaroUpdateResultSet resultSet) {
/*     */     try {
/*  42 */       FileDownloader fd = new FileDownloader("http://api.spiget.org/v2/resources/" + VaroUpdater.getRescourceId() + "/download", "plugins/Varo.jar");
/*     */       
/*  44 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Starte Download...");
/*     */       
/*  46 */       fd.startDownload();
/*  47 */     } catch (Exception e) {
/*  48 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cEs bgab einen kritischen Fehler beim Download des Plugins.");
/*  49 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Empfohlen wird ein manuelles Updaten des Plugins: https://www.spigotmc.org/resources/71075/");
/*  50 */       System.out.println("Es gab einen kritischen Fehler beim Download des Plugins.");
/*  51 */       System.out.println("---------- Stack Trace ----------");
/*  52 */       e.printStackTrace();
/*  53 */       System.out.println("---------- Stack Trace ----------");
/*     */       
/*     */       return;
/*     */     } 
/*  57 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Update erfolgreich installiert");
/*     */ 
/*     */     
/*  60 */     if (this.resetOldDirectory) {
/*  61 */       System.out.println("Das Verzeichnis der alten Pluginversion wird geloescht.");
/*  62 */       File directory = new File("plugins/Varo/");
/*  63 */       deleteDirectory(directory);
/*     */     } 
/*     */ 
/*     */     
/*  67 */     if (this.pluginNameChanged) {
/*  68 */       System.out.println("Da sich der Pluginname veraendert hat, wird die alte Pluginversion geloescht.");
/*  69 */       File oldPlugin = new File("plugins/" + this.oldFileName);
/*  70 */       oldPlugin.delete();
/*     */     } 
/*     */     
/*  73 */     Bukkit.getServer().shutdown();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  78 */     VaroUpdateResultSet resultSet = Main.getVaroUpdater().checkForUpdates(false);
/*  79 */     VaroUpdateResultSet.UpdateResult result = resultSet.getUpdateResult();
/*  80 */     String updateVersion = resultSet.getVersionName();
/*     */     
/*  82 */     if (args.length == 0 || (!args[0].equalsIgnoreCase("normal") && !args[0].equalsIgnoreCase("reset"))) {
/*  83 */       if (result == VaroUpdateResultSet.UpdateResult.UPDATE_AVAILABLE) {
/*  84 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c Es existiert eine neuere Version: " + updateVersion);
/*  85 */         sender.sendMessage("");
/*  86 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7§lUpdate Befehle:");
/*  87 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo update normal §7- Updated die Version, aber behaelt alle Daten");
/*  88 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo update reset §7- Updated die Version und loescht alle Daten");
/*  89 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cWichtig: §7Der Updater spiget.org hat manchmal eine alte Version als Download. Falls sich nach dem Update die Version nicht geaendert haben sollte, musst du manuell updaten.");
/*     */       } else {
/*  91 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Es wurde keine neue Version gefunden. Sollte dies ein Fehler sein, aktualisiere manuell.");
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     if (args[0].equalsIgnoreCase("normal")) {
/*  97 */       this.resetOldDirectory = false;
/*  98 */     } else if (args[0].equalsIgnoreCase("reset")) {
/*  99 */       this.resetOldDirectory = true;
/*     */     } 
/*     */     
/* 102 */     this.pluginNameChanged = false;
/* 103 */     this.oldFileName = (new File(Main.class.getProtectionDomain().getCodeSource().getLocation().getPath())).getName();
/*     */     
/*     */     try {
/* 106 */       this.oldFileName = URLDecoder.decode(this.oldFileName, "UTF-8");
/* 107 */     } catch (Exception e) {
/* 108 */       this.oldFileName = this.oldFileName.replace("%20", " ");
/*     */     } 
/*     */     
/* 111 */     if (!this.oldFileName.equals(String.valueOf(Main.getInstance().getDescription().getName()) + ".jar")) {
/* 112 */       this.pluginNameChanged = true;
/*     */     }
/* 114 */     Main.getDataManager().setDoSave(false);
/*     */     
/* 116 */     if (result == VaroUpdateResultSet.UpdateResult.UPDATE_AVAILABLE) {
/* 117 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Update wird installiert...");
/* 118 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Backup wird erstellt...");
/*     */       
/* 120 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Unter Umstaenden wird nicht die neuste Version heruntergeladen, sollte dies der Fall sein, installieren die neue Version bitte manuell.");
/* 121 */       update(sender, resultSet);
/*     */     } else {
/* 123 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das Plugin ist bereits auf dem neuesten Stand!");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\UpdateCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */