/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.plugin.PluginDescriptionFile;
/*    */ 
/*    */ 
/*    */ public class InfoCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public InfoCommand() {
/* 18 */     super("info", "Zeigt Info ueber das Plugin & Server", null, new String[] { "plugin", "server", "support" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 23 */     PluginDescriptionFile pdf = Main.getInstance().getDescription();
/*    */     
/* 25 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----------------------");
/* 26 */     sender.sendMessage(Main.getPrefix());
/* 27 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "§lVaro Plugin§7:");
/* 28 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Author§7: " + (String)pdf.getAuthors().get(0));
/* 29 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Authors§7: " + Main.getContributors());
/* 30 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Version§7: " + pdf.getVersion());
/* 31 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Commands§7: " + pdf.getCommands().size());
/* 32 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Server-Version§7: " + Bukkit.getServer().getVersion());
/* 33 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "System OS§7: " + System.getProperty("os.name"));
/* 34 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "System Version§7: " + System.getProperty("os.version"));
/* 35 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Java Version§7: " + System.getProperty("java.version"));
/* 36 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Date§7: " + (new SimpleDateFormat("dd.MM.yyyy HH:mm")).format(new Date()));
/* 37 */     sender.sendMessage(Main.getPrefix());
/* 38 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----------------------");
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\InfoCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */