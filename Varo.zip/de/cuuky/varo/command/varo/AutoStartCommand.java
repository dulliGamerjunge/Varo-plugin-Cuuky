/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.game.start.AutoStart;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoStartCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public AutoStartCommand() {
/*  23 */     super("autostart", "Startet das Varo automatisch", "varo.autostart", new String[] { "as" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  28 */     if (Main.getVaroGame().hasStarted()) {
/*  29 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getProjectName() + " §7wurde bereits gestartet!");
/*     */       
/*     */       return;
/*     */     } 
/*  33 */     if (args.length == 0) {
/*  34 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7-------- " + Main.getColorCode() + "AutoStart §7-------");
/*  35 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo autostart §7info");
/*  36 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo autostart §7set <Hour> <Minute> <Day> <Month> <Year>");
/*  37 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo autostart §7remove");
/*  38 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo autostart §7delay <Minutes>");
/*  39 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7------------------------");
/*     */       
/*     */       return;
/*     */     } 
/*  43 */     if (args[0].equalsIgnoreCase("set")) {
/*  44 */       int min, hour, day, month, year; if (Main.getVaroGame().getAutoStart() != null) {
/*  45 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Entferne erst den AutoStart, bevor du einen neuen setzt!");
/*     */         
/*     */         return;
/*     */       } 
/*  49 */       if (args.length != 6) {
/*  50 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/autostart §7set <Hour> <Minute> <Day> <Month> <Year>");
/*     */         
/*     */         return;
/*     */       } 
/*  54 */       if (args[5].length() == 2) {
/*  55 */         args[5] = String.valueOf(20) + args[5];
/*     */       }
/*     */       
/*     */       try {
/*  59 */         min = Integer.parseInt(args[2]);
/*  60 */         hour = Integer.parseInt(args[1]);
/*  61 */         day = Integer.parseInt(args[3]);
/*  62 */         month = Integer.parseInt(args[4]) - 1;
/*  63 */         year = Integer.parseInt(args[5]);
/*  64 */       } catch (NumberFormatException e) {
/*  65 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Eines der Argumente war §ckeine §7Zahl!");
/*     */         
/*     */         return;
/*     */       } 
/*  69 */       Calendar start = new GregorianCalendar(year, month, day, hour, min, 0);
/*  70 */       if ((new GregorianCalendar()).after(start)) {
/*  71 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das " + Main.getColorCode() + "Datum §7darf nicht in der Vergangenheit sein!");
/*     */         
/*     */         return;
/*     */       } 
/*  75 */       Main.getVaroGame().setAutoStart(new AutoStart(start)); return;
/*     */     } 
/*  77 */     if (args[0].equalsIgnoreCase("remove")) {
/*  78 */       if (Main.getVaroGame().getAutoStart() == null) {
/*  79 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Es wurde noch kein " + Main.getColorCode() + "Autostart §7festegelegt!");
/*     */         
/*     */         return;
/*     */       } 
/*  83 */       Main.getVaroGame().getAutoStart().stop();
/*  84 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "AutoStart §7erfolgreich entfernt!");
/*  85 */     } else if (args[0].equalsIgnoreCase("delay")) {
/*  86 */       int min; if (Main.getVaroGame().getAutoStart() == null) {
/*  87 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Es wurde noch kein " + Main.getColorCode() + "Autostart §7festegelegt!");
/*     */         
/*     */         return;
/*     */       } 
/*  91 */       if (args.length < 2) {
/*  92 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/autostart delay §7<Delay in Minutes>");
/*     */         
/*     */         return;
/*     */       } 
/*  96 */       int delay = -1;
/*     */       try {
/*  98 */         min = Integer.parseInt(args[1]);
/*  99 */       } catch (NumberFormatException e) {
/* 100 */         NumberFormatException numberFormatException1; sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[1] + " §7ist keine Zahl!");
/*     */         
/*     */         return;
/*     */       } 
/* 104 */       if (min < 1) {
/* 105 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der Delay darf nicht kleiner als 1 sein!");
/*     */         
/*     */         return;
/*     */       } 
/* 109 */       Main.getVaroGame().getAutoStart().delay(min);
/* 110 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Start wurde um " + Main.getColorCode() + min + " §7Minuten verzoegert!");
/* 111 */     } else if (args[0].equalsIgnoreCase("info")) {
/* 112 */       if (Main.getVaroGame().getAutoStart() == null) {
/* 113 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "AutoStart nicht aktiv");
/*     */       } else {
/* 115 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "AutoStart §aaktiv§7:");
/* 116 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Datum: §7" + (new SimpleDateFormat("dd.MM.yyyy HH.mm")).format(Main.getVaroGame().getAutoStart().getStart()));
/* 117 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "AutoSort: §7" + ConfigSetting.DO_SORT_AT_START.getValueAsBoolean());
/* 118 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "AutoRandomteamgroesse: §7" + ConfigSetting.DO_RANDOMTEAM_AT_START.getValueAsInt());
/*     */       } 
/*     */     } else {
/* 121 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Not found! Type " + Main.getColorCode() + "/autostart §7for help!");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\AutoStartCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */