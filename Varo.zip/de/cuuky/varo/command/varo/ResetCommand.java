/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Chunk;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ public class ResetCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public ResetCommand() {
/*  22 */     super("reset", "Setzt ausgewaehlte Teile des Servers zurueck", "varo.reset", new String[0]); } private void deleteDirectory(File file) {
/*     */     byte b;
/*     */     int i;
/*     */     File[] arrayOfFile;
/*  26 */     for (i = (arrayOfFile = file.listFiles()).length, b = 0; b < i; ) { File listFile = arrayOfFile[b];
/*  27 */       if (listFile.isDirectory()) {
/*  28 */         deleteDirectory(listFile);
/*     */       }
/*  30 */       listFile.delete();
/*     */       b++; }
/*     */     
/*  33 */     file.delete();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  38 */     if (args.length == 0) {
/*  39 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo reset §7<Modifier1> <Modifier2> ...");
/*  40 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Modifier 1: §7Resettet den kompletten Plugin Ordner");
/*  41 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Modifier 2: §7Resettet logs + stats (keine configs)");
/*  42 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Modifier 3: §7Loescht alle Welten");
/*  43 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Example: §7/varo reset 2 3 - Loescht alle Stats und Welten");
/*  44 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cWarnung: §7Der Server wird nach dem Vorgang gestoppt");
/*     */       
/*     */       return;
/*     */     } 
/*  48 */     for (Player pl : VersionUtils.getOnlinePlayer()) {
/*  49 */       pl.kickPlayer("§cRESET");
/*     */     }
/*  51 */     Main.getDataManager().save();
/*  52 */     List<Integer> success = new ArrayList<>();
/*  53 */     List<File> toDelete = new ArrayList<>(); byte b; int i; String[] arrayOfString;
/*  54 */     for (i = (arrayOfString = args).length, b = 0; b < i; ) { String arg = arrayOfString[b];
/*  55 */       int mod = -1;
/*     */       try {
/*  57 */         mod = Integer.valueOf(arg).intValue();
/*  58 */       } catch (NumberFormatException e) {
/*  59 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + arg + " ist keine Zahl!");
/*     */       } 
/*     */ 
/*     */       
/*  63 */       switch (mod) {
/*     */         case 1:
/*  65 */           toDelete.add(new File("plugins/Varo/"));
/*     */           break;
/*     */         case 2:
/*  68 */           toDelete.add(new File("plugins/Varo/logs/"));
/*  69 */           toDelete.add(new File("plugins/Varo/stats/"));
/*     */           break;
/*     */         case 3:
/*  72 */           for (World world : Bukkit.getWorlds()) {
/*  73 */             world.setAutoSave(false);
/*  74 */             Bukkit.unloadWorld(world, false); byte b1; int j; Chunk[] arrayOfChunk;
/*  75 */             for (j = (arrayOfChunk = world.getLoadedChunks()).length, b1 = 0; b1 < j; ) { Chunk chunk = arrayOfChunk[b1];
/*  76 */               chunk.unload(false); b1++; }
/*     */             
/*  78 */             deleteDirectory(world.getWorldFolder());
/*     */           } 
/*     */           break;
/*     */         default:
/*  82 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Modifier §c" + arg + " §7nicht gefunden!");
/*     */           break;
/*     */       } 
/*     */       
/*  86 */       success.add(Integer.valueOf(mod));
/*     */       b++; }
/*     */     
/*  89 */     if (!toDelete.isEmpty()) {
/*  90 */       Main.getDataManager().setDoSave(false);
/*  91 */       for (File file : toDelete) {
/*  92 */         if (file.isDirectory()) {
/*  93 */           deleteDirectory(file); continue;
/*     */         } 
/*  95 */         file.delete();
/*     */       } 
/*     */     } 
/*     */     
/*  99 */     if (!success.isEmpty())
/* 100 */       Bukkit.getServer().shutdown(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\ResetCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */