/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LobbyCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   private ArrayList<UUID> uuid;
/*    */   
/*    */   public LobbyCommand() {
/* 20 */     super("lobby", "Einstellungen zur Lobby", "varo.lobby", new String[0]);
/*    */     
/* 22 */     this.uuid = new ArrayList<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 27 */     if (!(sender instanceof Player)) {
/* 28 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Only for Players");
/*    */       
/*    */       return;
/*    */     } 
/* 32 */     if (args.length == 0) {
/* 33 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7------ " + Main.getColorCode() + "Lobby §7------");
/* 34 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/lobby build §7<size> <height>");
/* 35 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/lobby setSpawn");
/* 36 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/lobby removeSpawn");
/* 37 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7-----------------------");
/*    */       
/*    */       return;
/*    */     } 
/* 41 */     if (args[0].equalsIgnoreCase("build") || args[0].equalsIgnoreCase("create")) {
/* 42 */       if (args.length != 3) {
/* 43 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/lobby build §7<size> <height>");
/*    */         
/*    */         return;
/*    */       } 
/* 47 */       Player p = (Player)sender;
/* 48 */       if (!this.uuid.contains(p.getUniqueId())) {
/* 49 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Dieser Command wird eine " + Main.getColorCode() + "Lobby §7um dich herum spawnen, was du nicht rueckgaengig machen kannst.");
/* 50 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Fuehre diesen Command am besten " + Main.getColorCode() + "Hoch in der Luft §7aus.");
/* 51 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Gib den Command nochmal ein, um zu " + Main.getColorCode() + "bestaetigen§7.");
/* 52 */         this.uuid.add(p.getUniqueId());
/*    */         
/*    */         return;
/*    */       } 
/* 56 */       int height = 12;
/* 57 */       int size = 25;
/*    */       try {
/* 59 */         size = Integer.valueOf(args[1]).intValue();
/* 60 */         height = Integer.valueOf(args[2]).intValue();
/* 61 */       } catch (Exception e) {
/* 62 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Die Hoehe und die Groesse muessen eine Zahl sein!");
/*    */         
/*    */         return;
/*    */       } 
/* 66 */       this.uuid.remove(p.getUniqueId());
/* 67 */       Main.getVaroGame().setLobby(p.getLocation());
/*    */     } else {
/* 69 */       if (args[0].equalsIgnoreCase("setSpawn") || args[0].equalsIgnoreCase("set")) {
/* 70 */         Main.getVaroGame().setLobby(((Player)sender).getLocation());
/* 71 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Location fuer die " + Main.getColorCode() + "Lobby §7erfolgreich gesetzt!"); return;
/*    */       } 
/* 73 */       if (args[0].equalsIgnoreCase("removeSpawn") || args[0].equalsIgnoreCase("remove")) {
/* 74 */         Main.getVaroGame().setLobby(null);
/* 75 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Location fuer die " + Main.getColorCode() + "Lobby §7erfolgreich entfernt!");
/*    */         return;
/*    */       } 
/* 78 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Not found. §7Type /lobby for help.");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\LobbyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */