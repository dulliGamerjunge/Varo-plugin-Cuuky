/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.list.VaroList;
/*     */ import de.cuuky.varo.list.item.ItemList;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class ItemCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public ItemCommand() {
/*  20 */     super("item", "Blockt oder erlaubt Items", "varo.item", new String[] { "itemlist" });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  25 */     if (vp == null) {
/*  26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du musst ein Spieler sein!");
/*     */       
/*     */       return;
/*     */     } 
/*  30 */     if (args.length == 0) {
/*  31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----- " + Main.getColorCode() + "Item §7-----");
/*  32 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " item §7<itemlist> Add <Anzahl>");
/*  33 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " item §7<itemlist> Remove [@a/Anzahl]");
/*  34 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " item §7list");
/*  35 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Tipp: §7Der /varo enchant Befehl blockt alle Enchantments, die auf deinem derzeitigen Item sind.");
/*  36 */       sender.sendMessage(Main.getPrefix());
/*  37 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Dieser Command fuegt die Sachen der Listen hinzu, die du in der Hand haeltst.");
/*  38 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7-----------------");
/*     */       
/*     */       return;
/*     */     } 
/*  42 */     if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
/*  43 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Liste aller " + Main.getColorCode() + "Itemlisten§7:");
/*  44 */       for (VaroList varoList : ItemList.getItemLists()) {
/*  45 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + varoList.getLocation());
/*     */       }
/*     */       return;
/*     */     } 
/*  49 */     if (args.length < 2) {
/*  50 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Falsche Argumente! " + Main.getColorCode() + label + " item <liste> <Add/Remove> [Anzahl]");
/*     */       
/*     */       return;
/*     */     } 
/*  54 */     ItemList list = ItemList.getItemList(args[0]);
/*     */     
/*  56 */     if (list == null) {
/*  57 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Liste " + args[0] + " nicht gefunden!");
/*     */       
/*     */       return;
/*     */     } 
/*  61 */     if (args[1].equalsIgnoreCase("list")) {
/*  62 */       if (list.getItems().size() < 1) {
/*  63 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Keine Items gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*  67 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Liste aller Items von " + Main.getColorCode() + list.getLocation() + "§7:");
/*  68 */       for (ItemStack stack : list.getItems()) {
/*  69 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + stack.toString());
/*     */       }
/*     */       return;
/*     */     } 
/*  73 */     Player player = vp.getPlayer();
/*  74 */     if (player.getItemInHand() == null || player.getItemInHand().getType() == Material.AIR) {
/*  75 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du hast kein Item in der Hand!");
/*     */       
/*     */       return;
/*     */     } 
/*  79 */     ItemStack item = player.getItemInHand();
/*  80 */     if (args[1].equalsIgnoreCase("add")) {
/*  81 */       int Anzahl = 1;
/*  82 */       if (args.length > 2) {
/*     */         try {
/*  84 */           Anzahl = Integer.parseInt(args[2]);
/*  85 */         } catch (NumberFormatException e) {
/*  86 */           Anzahl = 1;
/*     */         } 
/*     */       }
/*  89 */       ArrayList<ItemList> multipleAdd = ItemList.getItemListsMultipleAdd();
/*  90 */       if (multipleAdd.contains(list)) {
/*  91 */         for (int i = 0; i < Anzahl; i++) {
/*  92 */           list.addItem(item);
/*     */         }
/*  94 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Item erfolgreich " + String.valueOf(Anzahl) + " mal zu " + list.getLocation() + " hinzugefuegt!");
/*     */       } else {
/*  96 */         if (list.hasItem(item)) {
/*  97 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Auf dieser Liste kann ein item nicht mehrmals stehen.\n" + Main.getPrefix() + "Das item steht bereits auf dieser Liste.");
/*     */           return;
/*     */         } 
/* 100 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Item erfolgreich zu " + list.getLocation() + " hinzugefuegt!");
/* 101 */         list.addItem(item);
/*     */       }
/*     */     
/*     */     }
/* 105 */     else if (args[1].equalsIgnoreCase("remove")) {
/* 106 */       if (!list.hasItem(item)) {
/* 107 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Item steht nicht auf dieser Liste!");
/*     */         
/*     */         return;
/*     */       } 
/* 111 */       int Anzahl = 1;
/*     */       
/* 113 */       if (args.length > 2) {
/* 114 */         if (args[2].equalsIgnoreCase("@a")) {
/* 115 */           while (list.hasItem(item)) {
/* 116 */             list.removeItem(item);
/*     */           }
/* 118 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Item erfolgreich komplett von " + list.getLocation() + " entfernt!");
/*     */           return;
/*     */         } 
/*     */         try {
/* 122 */           Anzahl = Integer.parseInt(args[2]);
/* 123 */         } catch (NumberFormatException e) {
/* 124 */           Anzahl = 1;
/*     */         } 
/*     */       } 
/*     */       
/* 128 */       for (int i = 0; i < Anzahl; i++) {
/* 129 */         if (!list.hasItem(item)) {
/* 130 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Item steht nur " + String.valueOf(i) + " mal auf der Liste.\n" + Main.getPrefix() + "Item wurde komplett von der Liste entfernt.");
/*     */           return;
/*     */         } 
/* 133 */         list.removeItem(item);
/*     */       } 
/*     */       
/* 136 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Item erfolgreich " + Anzahl + " mal von " + list.getLocation() + " entfernt!");
/*     */     } else {
/* 138 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " item §7<itemlist> Add <Anzahl>");
/* 139 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + label + " item §7<itemlist> Remove [@a/Anzahl]");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\ItemCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */