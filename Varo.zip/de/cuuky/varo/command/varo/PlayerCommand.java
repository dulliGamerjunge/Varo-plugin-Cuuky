/*     */ package de.cuuky.varo.command.varo;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.utils.UUIDUtils;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerCommand
/*     */   extends VaroCommand
/*     */ {
/*     */   public PlayerCommand() {
/*  18 */     super("player", "Verwaltet die Spieler", "varo.player", new String[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  23 */     if (args.length == 0) {
/*  24 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7----- " + Main.getColorCode() + "Player §7-----");
/*  25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player §7<Spieler>");
/*  26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player add §7<Spieler1> <Spieler2> ...");
/*  27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player remove §7<Spieler / @a>");
/*  28 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player respawn §7<Spieler / @a>");
/*  29 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player kill §7<Spieler / @a>");
/*  30 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player reset §7<Spieler / @a>");
/*  31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player list");
/*  32 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7------------------");
/*     */       
/*     */       return;
/*     */     } 
/*  36 */     if (args.length == 1 && VaroPlayer.getPlayer(args[0]) != null) {
/*  37 */       if (!(sender instanceof org.bukkit.entity.Player)) {
/*  38 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du musst Spieler sein, um diesen Command nutzen zu koennen!");
/*     */         
/*     */         return;
/*     */       } 
/*  42 */       VaroPlayer varoPlayer = VaroPlayer.getPlayer(args[0]);
/*  43 */       if (varoPlayer == null) {
/*  44 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  52 */     VaroPlayer vps = null;
/*  53 */     if (args.length > 1) {
/*  54 */       vps = VaroPlayer.getPlayer(args[1]);
/*     */     }
/*  56 */     if (args[0].equalsIgnoreCase("reset")) {
/*  57 */       if (args.length >= 2 && args[1].equalsIgnoreCase("@a")) {
/*  58 */         for (VaroPlayer pl : VaroPlayer.getVaroPlayer()) {
/*  59 */           if (pl.isOnline())
/*  60 */             pl.getPlayer().kickPlayer("§cDein Account wurde resettet!\n§7Joine erneut, um dich zu registrieren."); 
/*  61 */           pl.getStats().loadDefaults();
/*  62 */           if (pl.getTeam() != null) {
/*  63 */             pl.getTeam().removeMember(pl);
/*     */           }
/*     */         } 
/*     */         return;
/*     */       } 
/*  68 */       if (vps == null) {
/*  69 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Spieler nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*  73 */       if (vps.isOnline()) {
/*  74 */         vps.getPlayer().kickPlayer("§7Dein Account wurde resettet!\nJoine erneut, um dich zu registrieren.");
/*     */       }
/*  76 */       if (vps.isOnline())
/*  77 */         vps.getPlayer().kickPlayer("§cDein Account wurde resettet!\n§7Joine erneut, um dich zu registrieren."); 
/*  78 */       vps.getStats().loadDefaults();
/*  79 */       if (vps.getTeam() != null)
/*  80 */         vps.getTeam().removeMember(vps); 
/*  81 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Account von §c" + vps.getName() + " §7wurde erfolgreich resettet!"); return;
/*     */     } 
/*  83 */     if (args[0].equalsIgnoreCase("kill")) {
/*  84 */       if (args.length >= 2 && args[1].equalsIgnoreCase("@a")) {
/*  85 */         for (VaroPlayer pl : VaroPlayer.getVaroPlayer()) {
/*  86 */           if (pl.isOnline()) {
/*  87 */             pl.getPlayer().setHealth(0.0D); continue;
/*     */           } 
/*  89 */           pl.getStats().setState(PlayerState.DEAD);
/*     */         } 
/*     */         return;
/*     */       } 
/*  93 */       if (vps == null) {
/*  94 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Spieler nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/*  98 */       if (vps.getStats().getState() == PlayerState.DEAD) {
/*  99 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Dieser Spieler ist bereits tot!");
/*     */         
/*     */         return;
/*     */       } 
/* 103 */       if (vps.isOnline()) {
/* 104 */         vps.getPlayer().setHealth(0.0D);
/*     */       } else {
/* 106 */         vps.getStats().setState(PlayerState.DEAD);
/*     */       } 
/* 108 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + vps.getName() + " §7erfolgreich getoetet!"); return;
/*     */     } 
/* 110 */     if (args[0].equalsIgnoreCase("remove")) {
/* 111 */       if (args.length >= 2 && args[1].equalsIgnoreCase("@a")) {
/* 112 */         for (VaroPlayer pl : VaroPlayer.getVaroPlayer()) {
/* 113 */           if (pl.isOnline()) {
/* 114 */             pl.getPlayer().kickPlayer(ConfigMessages.JOIN_KICK_NOT_USER_OF_PROJECT.getValue());
/*     */           }
/* 116 */           pl.delete();
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 121 */       if (vps == null) {
/* 122 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Spieler nicht gefunden!");
/*     */         
/*     */         return;
/*     */       } 
/* 126 */       if (vps.isOnline()) {
/* 127 */         vps.getPlayer().kickPlayer(ConfigMessages.JOIN_KICK_NOT_USER_OF_PROJECT.getValue());
/*     */       }
/* 129 */       vps.delete();
/* 130 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[1] + " §7wurde erfolgreich aus " + Main.getColorCode() + Main.getProjectName() + " §7entfernt!"); return;
/*     */     } 
/* 132 */     if (args[0].equalsIgnoreCase("add"))
/* 133 */     { if (args.length <= 1) {
/* 134 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player add §7<Spieler1> <Spieler2> ..."); return;
/*     */       }  byte b;
/*     */       int i;
/*     */       String[] arrayOfString;
/* 138 */       for (i = (arrayOfString = args).length, b = 0; b < i; ) { String arg = arrayOfString[b];
/* 139 */         if (!arg.equals(args[0]))
/*     */         {
/*     */           
/* 142 */           if (VaroPlayer.getPlayer(arg) != null)
/* 143 */           { sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + arg + " §7existiert bereits!"); }
/*     */           else
/*     */           { String uuid;
/*     */ 
/*     */             
/*     */             try {
/* 149 */               uuid = UUIDUtils.getUUID(arg).toString();
/* 150 */             } catch (Exception e) {
/* 151 */               sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c" + arg + " wurde nicht gefunden.");
/*     */               
/*     */               try {
/* 154 */                 String newName = UUIDUtils.getNamesChanged(arg);
/* 155 */                 sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cEin Spieler, der in den letzten 30 Tagen " + arg + " hiess, hat sich in §7" + newName + " §cumbenannt.");
/* 156 */                 sender.sendMessage(String.valueOf(Main.getPrefix()) + "Benutze \"/varo team add\", um diese Person einem Team hinzuzufuegen.");
/* 157 */               } catch (Exception f) {
/* 158 */                 sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cIn den letzten 30 Tagen gab es keinen Spieler mit diesem Namen.");
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 164 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + arg + " §7wurde erfolgreich zu " + Main.getColorCode() + Main.getProjectName() + " §7hinzugefuegt!"); }  }  b++; }
/*     */        }
/* 166 */     else { if (args[0].equalsIgnoreCase("respawn")) {
/* 167 */         if (args.length >= 2 && args[1].equalsIgnoreCase("@a")) {
/* 168 */           for (VaroPlayer pl : VaroPlayer.getVaroPlayer())
/* 169 */             pl.getStats().setState(PlayerState.ALIVE); 
/* 170 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Erfolgreich alle Spieler wiederbelebt!");
/*     */           
/*     */           return;
/*     */         } 
/* 174 */         if (vps == null) {
/* 175 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Spieler nicht gefunden!");
/*     */           
/*     */           return;
/*     */         } 
/* 179 */         if (vps.getStats().isAlive()) {
/* 180 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§a" + vps.getName() + " §7lebt bereits!");
/*     */           
/*     */           return;
/*     */         } 
/* 184 */         vps.getStats().setState(PlayerState.ALIVE);
/* 185 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§a" + vps.getName() + " §7erfolgreich wiederbelebt!"); return;
/*     */       } 
/* 187 */       if (args[0].equalsIgnoreCase("list")) {
/* 188 */         if (VaroPlayer.getVaroPlayer().isEmpty()) {
/* 189 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Kein Spieler gefunden!");
/*     */           
/*     */           return;
/*     */         } 
/* 193 */         int playerNumber = VaroPlayer.getVaroPlayer().size();
/* 194 */         int playerPages = 1 + playerNumber / 50;
/*     */         
/* 196 */         int lastPlayerOnPage = 50;
/* 197 */         int page = 1;
/*     */         
/* 199 */         if (args.length != 1) {
/*     */           try {
/* 201 */             page = Integer.parseInt(args[1]);
/* 202 */           } catch (NumberFormatException e) {
/* 203 */             String uuid; page = 1;
/*     */           } 
/*     */           
/* 206 */           lastPlayerOnPage = page * 50;
/*     */         } 
/*     */         
/* 209 */         if (page == playerPages) {
/* 210 */           lastPlayerOnPage = playerNumber;
/*     */         }
/*     */         
/* 213 */         if (page > playerPages) {
/* 214 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Keine Seite " + page + " der Spieler gefunden!");
/*     */           
/*     */           return;
/*     */         } 
/* 218 */         if (playerPages == 1) {
/* 219 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§lListe aller " + Main.getColorCode() + " §lSpieler§7§l:");
/*     */         } else {
/* 221 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§lListe der " + Main.getColorCode() + " §lSpieler§7§l " + ((page - 1) * 50 + 1) + " bis " + lastPlayerOnPage + ":");
/*     */         } 
/*     */         
/* 224 */         for (int i = (page - 1) * 50; i < lastPlayerOnPage; i++) {
/* 225 */           VaroPlayer player = VaroPlayer.getVaroPlayer().get(i);
/* 226 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "§l" + (i + 1) + "§7: " + Main.getColorCode() + player.getName());
/*     */         } 
/*     */         
/* 229 */         int lastPlayerNextSite = 0;
/* 230 */         if (page + 1 < playerPages) {
/* 231 */           lastPlayerNextSite = (page + 1) * 50;
/* 232 */         } else if (page + 1 == playerPages) {
/* 233 */           lastPlayerNextSite = playerPages;
/*     */         } 
/* 235 */         if (page < playerPages)
/* 236 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo player list " + (page + 1) + " §7fuer " + Main.getColorCode() + "Spieler §7 " + (page * 50 + 1) + " bis " + lastPlayerNextSite); 
/*     */       } else {
/* 238 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Player/Command not found! §7Type /player for more.");
/*     */       }  }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\PlayerCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */