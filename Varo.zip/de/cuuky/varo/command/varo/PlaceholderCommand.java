/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.placeholder.MessagePlaceholder;
/*    */ import de.cuuky.varo.configuration.placeholder.placeholder.GeneralMessagePlaceholder;
/*    */ import de.cuuky.varo.configuration.placeholder.placeholder.PlayerMessagePlaceholder;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ public class PlaceholderCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public PlaceholderCommand() {
/* 19 */     super("placeholder", "Zeigt alle Platzhalter fuer messages, scoreboard etc.", "varo.placeholder", new String[] { "ph" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 24 */     if (args.length == 0) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getProjectName() + " §7Placeholder Befehle:");
/* 26 */       sender.sendMessage(Main.getPrefix());
/* 27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo placeholder §7info <name> §8- §7Zeigt Wert und Info vom gegebenen Placeholder");
/* 28 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo placeholder §7general §8- §7Zeigt alle ueberall anwendbaren Placeholder");
/* 29 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo placeholder §7player §8- §7Zeigt alle im Spielerkontext anwendbaren Placeholder");
/* 30 */       sender.sendMessage(Main.getPrefix());
/* 31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Player-Beispiele: Killmessage, Scoreboard, Kickmessage, Tab");
/*    */       
/*    */       return;
/*    */     } 
/* 35 */     if (args[0].equalsIgnoreCase("info") || args[0].equalsIgnoreCase("get")) {
/* 36 */       if (args.length != 2) {
/* 37 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo placeholder §7get <name> §8- §7Zeigt Wert vom gegebenen Placeholder");
/*    */         
/*    */         return;
/*    */       } 
/* 41 */       MessagePlaceholder mp = null;
/* 42 */       for (MessagePlaceholder mp1 : MessagePlaceholder.getPlaceholders()) {
/* 43 */         if (mp1.getIdentifier().replace("%", "").equalsIgnoreCase(args[1].replace("%", ""))) {
/* 44 */           mp = mp1;
/*    */         }
/*    */       } 
/*    */       
/* 48 */       if (mp == null) {
/* 49 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Placeholder nicht gefunden!");
/*    */         
/*    */         return;
/*    */       } 
/* 53 */       String value = "/";
/* 54 */       if (mp instanceof PlayerMessagePlaceholder) {
/* 55 */         if (vp != null)
/* 56 */           value = "(" + vp.getName() + ") " + ((PlayerMessagePlaceholder)mp).replacePlaceholder(mp.getIdentifier(), vp); 
/* 57 */       } else if (mp instanceof GeneralMessagePlaceholder) {
/* 58 */         value = ((GeneralMessagePlaceholder)mp).replacePlaceholder(mp.getIdentifier());
/*    */       } else {
/* 60 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Undefinierter Placeholder gefunden!?");
/*    */         
/*    */         return;
/*    */       } 
/* 64 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + mp.getIdentifier() + " §7Info§8:");
/* 65 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Wert§8: " + Main.getColorCode() + value);
/* 66 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Refresh-Delay§8: " + Main.getColorCode() + mp.getDefaultRefresh() + "s");
/*    */       
/*    */       return;
/*    */     } 
/* 70 */     ArrayList<MessagePlaceholder> placeholders = new ArrayList<>();
/* 71 */     if (args[0].equalsIgnoreCase("general")) {
/* 72 */       for (MessagePlaceholder mp : MessagePlaceholder.getPlaceholders())
/* 73 */       { if (mp instanceof GeneralMessagePlaceholder && ConfigSetting.getEntryByPath(mp.getIdentifier().replace("%", "")) == null)
/* 74 */           placeholders.add(mp);  } 
/* 75 */     } else if (args[0].equalsIgnoreCase("player")) {
/* 76 */       for (MessagePlaceholder mp : MessagePlaceholder.getPlaceholders()) {
/* 77 */         if (mp instanceof PlayerMessagePlaceholder)
/* 78 */           placeholders.add(mp); 
/*    */       } 
/*    */     } 
/* 81 */     if (placeholders.isEmpty()) {
/* 82 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Falsche Argumente! §c/varo ph");
/*    */       
/*    */       return;
/*    */     } 
/* 86 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "- Placeholder -");
/* 87 */     for (MessagePlaceholder mp : placeholders) {
/* 88 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + mp.getIdentifier() + " §8- §7" + mp.getDescription());
/*    */     }
/* 90 */     if (args[0].equalsIgnoreCase("general")) {
/* 91 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "%topplayer-<RANK>% §8- §7Ersetzt durch den Spieler, der an RANK auf dem Leaderboard ist");
/* 92 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "%topplayerkills-<RANK>% §8- §7Ersetzt durch die Kills des Spielers, der an RANK auf dem Leaderboard ist");
/* 93 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "%topteam-<RANK>% §8- §7Ersetzt durch das Team, das an RANK auf dem Leaderboard ist");
/* 94 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "%topteamkills-<RANK>% §8- §7Ersetzt durch die Kills des Teams, das an RANK auf dem Leaderboard ist");
/* 95 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Zusätzlich werden alle Einstellungen mit %<ConfigEintrag>% ersetzt");
/*    */     } 
/*    */     
/* 98 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "----------------");
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\PlaceholderCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */