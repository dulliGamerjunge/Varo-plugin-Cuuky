/*     */ package de.cuuky.varo.command.varo;
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.command.VaroCommand;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.listener.helper.cancelable.CancelAbleType;
/*     */ import de.cuuky.varo.listener.helper.cancelable.VaroCancelAble;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class FinaleCommand extends VaroCommand {
/*     */   private int startScheduler;
/*     */   private int countdown;
/*     */   private FinalState status;
/*     */   
/*     */   private enum FinalState {
/*  21 */     COUNTDOWN_PHASE,
/*  22 */     JOIN_PHASE,
/*  23 */     NONE,
/*  24 */     STARTED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FinaleCommand() {
/*  32 */     super("finale", "Hauptcommand fuer das Managen des Finales", "varo.finale", new String[0]);
/*     */     
/*  34 */     this.status = FinalState.NONE;
/*     */   }
/*     */   
/*     */   private void finaleStart() {
/*  38 */     this.status = FinalState.STARTED;
/*     */     
/*  40 */     Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "§cDAS FINALE STARTET!");
/*  41 */     if (ConfigSetting.FINALE_PROTECTION_TIME.getValueAsInt() > 0) {
/*  42 */       Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "§7Es gibt " + ConfigSetting.FINALE_PROTECTION_TIME.getValueAsInt() + " Sekunden Schutzzeit.");
/*  43 */       Main.getVaroGame().setProtection(new ProtectionTime(ConfigSetting.FINALE_PROTECTION_TIME.getValueAsInt()));
/*     */     } else {
/*  45 */       Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "§7Es gibt keine Schutzzeit");
/*     */     } 
/*     */     
/*  48 */     for (VaroPlayer player : VaroPlayer.getVaroPlayer()) {
/*  49 */       VaroCancelAble.removeCancelAble(player, CancelAbleType.FREEZE);
/*  50 */       if (player.getPlayer() != null && 
/*  51 */         player.getPlayer().isOnline()) {
/*  52 */         player.getPlayer().teleport(Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld().getSpawnLocation());
/*     */         
/*     */         continue;
/*     */       } 
/*  56 */       if (ConfigSetting.PLAYER_SPECTATE_IN_FINALE.getValueAsBoolean()) {
/*  57 */         player.getStats().setState(PlayerState.SPECTATOR); continue;
/*     */       } 
/*  59 */       player.getStats().setState(PlayerState.DEAD);
/*     */     } 
/*     */ 
/*     */     
/*  63 */     Main.getVaroGame().getVaroWorldHandler().setBorderSize(ConfigSetting.BORDER_SIZE_IN_FINALE.getValueAsInt(), 0L, null);
/*  64 */     Main.getVaroGame().setFinaleJoinStart(false);
/*     */     
/*  66 */     int playerNumber = VaroPlayer.getOnlinePlayer().size();
/*  67 */     Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, "DAS FINALE STARTET!\nEs nehmen " + playerNumber + "Spieler teil.");
/*     */   }
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/*  72 */     if (args.length == 0 || (!args[0].equalsIgnoreCase("joinstart") && !args[0].equalsIgnoreCase("hauptstart") && !args[0].equalsIgnoreCase("abort") && !args[0].equalsIgnoreCase("abbruch") && args[0].equalsIgnoreCase("abbrechen") && args[0].equalsIgnoreCase("stop"))) {
/*  73 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getProjectName() + " §7Finale Befehle:");
/*  74 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo finale joinStart");
/*  75 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo finale hauptStart [Countdown]");
/*  76 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo finale abort");
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     if (args[0].equalsIgnoreCase("joinstart")) {
/*  81 */       if (this.status == FinalState.JOIN_PHASE) {
/*  82 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der JoinStart wurde bereits aktiviert."); return;
/*     */       } 
/*  84 */       if (this.status == FinalState.COUNTDOWN_PHASE) {
/*  85 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der Finale-Countdown wurde bereits aktiviert."); return;
/*     */       } 
/*  87 */       if (this.status == FinalState.STARTED) {
/*  88 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Das Finale wurde bereits gestartet.");
/*     */         
/*     */         return;
/*     */       } 
/*  92 */       for (VaroPlayer player : VaroPlayer.getOnlineAndAlivePlayer()) {
/*  93 */         Player pl = player.getPlayer();
/*  94 */         if (pl.isOp()) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 100 */         if (pl.isOnline()) {
/* 101 */           player.sendMessage(String.valueOf(Main.getPrefix()) + "Das Finale beginnt bald. Bis zum Finalestart wurden alle gefreezed.");
/*     */         }
/*     */       } 
/* 104 */       Main.getVaroGame().setFinaleJoinStart(true);
/* 105 */       this.status = FinalState.JOIN_PHASE;
/* 106 */       ConfigSetting.PLAY_TIME.setValue(Integer.valueOf(-1), true);
/*     */       
/* 108 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Es koennen nun alle zum Finale joinen.");
/* 109 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Es wird empfohlen, mindestens 5 Minuten zu warten, bis das Finale gestartet wird.");
/* 110 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§c§lWARNUNG: §cBeim Starten mit §7§l/varo finale hauptStart§7 werden alle Spieler, die nicht online sind, getoetet.");
/*     */       
/* 112 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, "Man kann nun zum Finale joinen!");
/*     */       return;
/*     */     } 
/* 115 */     if (args[0].equalsIgnoreCase("hauptstart") || args[0].equalsIgnoreCase("mainstart")) {
/* 116 */       if (this.status == FinalState.NONE) {
/* 117 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der Join-Start wurde noch nicht aktiviert. Dies muss vor dem Hauptstart geschehen."); return;
/*     */       } 
/* 119 */       if (this.status == FinalState.COUNTDOWN_PHASE) {
/* 120 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Der Finale-Countdown laeuft bereits."); return;
/*     */       } 
/* 122 */       if (this.status == FinalState.STARTED) {
/* 123 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Das Finale wurde bereits gestartet.");
/*     */         
/*     */         return;
/*     */       } 
/* 127 */       this.countdown = 0;
/* 128 */       if (args.length != 1) {
/*     */         try {
/* 130 */           this.countdown = Integer.parseInt(args[1]);
/* 131 */         } catch (NumberFormatException e) {
/* 132 */           this.countdown = 0;
/*     */         } 
/*     */       }
/* 135 */       if (this.countdown != 0) {
/* 136 */         this.status = FinalState.COUNTDOWN_PHASE;
/* 137 */         this.startScheduler = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getInstance(), new Runnable()
/*     */             {
/*     */               public void run() {
/* 140 */                 if (FinaleCommand.this.countdown != 0) {
/* 141 */                   Bukkit.broadcastMessage(String.valueOf(Main.getPrefix()) + "Das Finale startet in " + FinaleCommand.this.countdown + " Sekunden!");
/*     */                 } else {
/* 143 */                   FinaleCommand.this.finaleStart();
/* 144 */                   Bukkit.getScheduler().cancelTask(FinaleCommand.this.startScheduler);
/*     */                 } 
/* 146 */                 FinaleCommand.this.countdown = FinaleCommand.this.countdown - 1;
/*     */               }
/* 148 */             },  0L, 20L);
/*     */       } else {
/* 150 */         finaleStart();
/*     */       } 
/*     */       return;
/*     */     } 
/* 154 */     if (args[0].equalsIgnoreCase("abort") || args[0].equalsIgnoreCase("abbruch") || args[0].equalsIgnoreCase("abbrechen") || args[0].equalsIgnoreCase("stop")) {
/* 155 */       if (this.status == FinalState.NONE || this.status == FinalState.JOIN_PHASE) {
/* 156 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Es gibt keinen Countdown zum Abbrechen."); return;
/*     */       } 
/* 158 */       if (this.status == FinalState.STARTED) {
/* 159 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Das Finale wurde bereits gestartet.");
/*     */         
/*     */         return;
/*     */       } 
/* 163 */       Bukkit.getScheduler().cancelTask(this.startScheduler);
/* 164 */       this.status = FinalState.JOIN_PHASE;
/* 165 */       Bukkit.broadcastMessage("§7Der Finale-Start wurde §cabgebrochen§7!");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\FinaleCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */