/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class TestCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public TestCommand() {
/* 13 */     super("test", "Test lol", "varo.test", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 18 */     Main.getDataManager().getDailyTimer().doDailyChecks();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\TestCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */