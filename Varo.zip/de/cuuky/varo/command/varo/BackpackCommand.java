/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.team.VaroTeam;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class BackpackCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public BackpackCommand() {
/* 15 */     super("backpack", "Öffnet das Backpack von dir oder einem Spieler", null, new String[] { "bp" });
/*    */   }
/*    */   
/*    */   private void playerBackPack(CommandSender sender, VaroPlayer vp, String[] args, int number) {
/* 19 */     if (vp.getPlayer().isOp() && args.length > number) {
/* 20 */       VaroPlayer p = VaroPlayer.getPlayer(args[number]);
/* 21 */       if (p != null) {
/* 22 */         vp.getPlayer().openInventory(p.getStats().getPlayerBackpack().getInventory());
/*    */       } else {
/* 24 */         sender.sendMessage("Der Spieler " + args[number] + " existiert nicht.");
/* 25 */         sender.sendMessage("Daher kann dessen Rucksack dir nicht angezeigt werden.");
/*    */       } 
/*    */       
/*    */       return;
/*    */     } 
/* 30 */     vp.getPlayer().openInventory(vp.getStats().getPlayerBackpack().getInventory());
/*    */   }
/*    */ 
/*    */   
/*    */   private void teamBackPack(CommandSender sender, VaroPlayer vp, String[] args, int number) {
/* 35 */     if (vp.getPlayer().isOp() && args.length > number) {
/* 36 */       VaroTeam t = VaroTeam.getTeam(args[number]);
/* 37 */       if (t != null) {
/* 38 */         vp.getPlayer().openInventory(t.getTeamBackPack().getInventory());
/*    */       } else {
/* 40 */         sender.sendMessage("Das Team " + args[number] + " existiert nicht.");
/* 41 */         sender.sendMessage("Daher kann dessen Teamrucksack dir nicht angezeigt werden.");
/*    */       } 
/*    */       return;
/*    */     } 
/* 45 */     if (vp.getTeam() == null) {
/* 46 */       sender.sendMessage("Du bist in keinem Team. Daher hast du kein Team-Backpack.");
/*    */     } else {
/* 48 */       vp.getPlayer().openInventory(vp.getTeam().getTeamBackPack().getInventory());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 55 */     if (!Main.getVaroGame().hasStarted()) {
/* 56 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spiel wurde noch nicht gestartet!");
/*    */       
/*    */       return;
/*    */     } 
/* 60 */     if (vp == null) {
/* 61 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du musst ein Spieler sein!");
/*    */       
/*    */       return;
/*    */     } 
/* 65 */     if (ConfigSetting.BACKPACK_PLAYER_ENABLED.getValueAsBoolean() && ConfigSetting.BACKPACK_TEAM_ENABLED.getValueAsBoolean()) {
/* 66 */       if (args.length == 0 || (!args[0].equalsIgnoreCase("player") && !args[0].equalsIgnoreCase("team"))) {
/* 67 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Es wurden sowohl Spieler als auch Team-Backpacks aktiviert");
/* 68 */         if (vp.getPlayer().isOp()) {
/* 69 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo bp player §7[Player]");
/* 70 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo bp team §7[Team]");
/*    */         } else {
/* 72 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo bp player");
/* 73 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/varo bp team");
/*    */         } 
/* 75 */       } else if (args[0].equalsIgnoreCase("player")) {
/* 76 */         playerBackPack(sender, vp, args, 1);
/*    */       } else {
/* 78 */         teamBackPack(sender, vp, args, 1);
/*    */       } 
/* 80 */     } else if (ConfigSetting.BACKPACK_PLAYER_ENABLED.getValueAsBoolean() && !ConfigSetting.BACKPACK_TEAM_ENABLED.getValueAsBoolean()) {
/* 81 */       playerBackPack(sender, vp, args, 0);
/* 82 */     } else if (!ConfigSetting.BACKPACK_PLAYER_ENABLED.getValueAsBoolean() && ConfigSetting.BACKPACK_TEAM_ENABLED.getValueAsBoolean()) {
/* 83 */       teamBackPack(sender, vp, args, 0);
/*    */     } else {
/* 85 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Rucksaecke sind nicht aktiviert!");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\BackpackCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */