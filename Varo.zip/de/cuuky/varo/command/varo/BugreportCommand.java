/*    */ package de.cuuky.varo.command.varo;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.command.VaroCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.recovery.recoveries.VaroBugreport;
/*    */ import de.cuuky.varo.spigot.updater.VaroUpdateResultSet;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class BugreportCommand
/*    */   extends VaroCommand
/*    */ {
/*    */   public BugreportCommand() {
/* 15 */     super("bugreport", "Hift bei der Fehlersuche und beim Reporten von Bugs", "varo.bug", new String[] { "bug", "bughelp", "error" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onCommand(CommandSender sender, VaroPlayer vp, Command cmd, String label, String[] args) {
/* 20 */     if (Main.getVaroUpdater().getLastResult().getUpdateResult() == VaroUpdateResultSet.UpdateResult.UPDATE_AVAILABLE) {
/* 21 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du kannst keine Bugreports von einer alten Plugin-Version machen!");
/* 22 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Derzeitige Version: §c" + Main.getInstance().getDescription().getVersion());
/* 23 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Neueste Version: §a" + Main.getVaroUpdater().getLastResult().getVersionName());
/* 24 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§a/varo update");
/*    */       
/*    */       return;
/*    */     } 
/* 28 */     VaroBugreport bugreport = new VaroBugreport();
/*    */     
/* 30 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Bugreport wurde unter §c" + bugreport.getZipFile().getName() + " §7gespeichert!");
/* 31 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Bitte sende diesen auf den Discord in den Support!");
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\varo\BugreportCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */