/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FreezeCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 19 */     if (!sender.hasPermission("varo.freeze")) {
/* 20 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 21 */       return false;
/*    */     } 
/*    */     
/* 24 */     if (args.length != 1) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/freeze <Player/@a>");
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/unfreeze <Player/@a>");
/* 27 */       return false;
/*    */     } 
/*    */     
/* 30 */     if (args[0].equalsIgnoreCase("@a")) {
/* 31 */       for (VaroPlayer varoPlayer : VaroPlayer.getOnlinePlayer()) {
/* 32 */         if (varoPlayer.getPlayer().isOp());
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 38 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Erfolgreich alle Spieler gefreezed!");
/* 39 */       return false;
/*    */     } 
/*    */     
/* 42 */     if (Bukkit.getPlayerExact(args[0]) == null) {
/* 43 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7nicht gefunden!");
/* 44 */       return false;
/*    */     } 
/*    */     
/* 47 */     Player player = Bukkit.getPlayerExact(args[0]);
/* 48 */     VaroPlayer vp = VaroPlayer.getPlayer(player);
/* 49 */     if (player.isOp()) {
/* 50 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Ein Admin kann nicht gefreezed werden!");
/* 51 */       return false;
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 56 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7erfolgreich gefreezed!");
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\FreezeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */