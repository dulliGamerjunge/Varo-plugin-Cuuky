/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ 
/*    */ public class InvSeeCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 16 */     if (!sender.hasPermission("varo.invsee")) {
/* 17 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 18 */       return false;
/*    */     } 
/*    */     
/* 21 */     if (args.length != 1) {
/* 22 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/Invsee <Player>");
/* 23 */       return false;
/*    */     } 
/*    */     
/* 26 */     if (!(sender instanceof Player)) {
/* 27 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Nicht fuer die Konsole!");
/* 28 */       return false;
/*    */     } 
/*    */     
/* 31 */     if (Bukkit.getPlayerExact(args[0]) == null) {
/* 32 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7nicht gefunden!");
/* 33 */       return false;
/*    */     } 
/*    */     
/* 36 */     Player p = (Player)sender;
/* 37 */     p.openInventory((Inventory)Bukkit.getPlayerExact(args[0]).getInventory());
/* 38 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\InvSeeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */