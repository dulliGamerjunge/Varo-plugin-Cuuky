/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class SpawnCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args) {
/* 17 */     Location loc = Main.getVaroGame().getVaroWorldHandler().getMainWorld().getWorld().getSpawnLocation();
/* 18 */     if (!(sender instanceof Player)) {
/* 19 */       if (loc == null)
/* 20 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Main World not found!"); 
/* 21 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SPAWN_WORLD.getValue().replace("%x%", (new StringBuilder(String.valueOf(loc.getBlockX()))).toString()).replace("%y%", (new StringBuilder(String.valueOf(loc.getBlockY()))).toString()).replace("%z%", (new StringBuilder(String.valueOf(loc.getBlockZ()))).toString()));
/* 22 */       return false;
/*    */     } 
/*    */     
/* 25 */     if (args.length != 0) {
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/spawn");
/* 27 */       return false;
/*    */     } 
/*    */     
/* 30 */     Player player = (Player)sender;
/* 31 */     loc = player.getWorld().getSpawnLocation();
/*    */     
/* 33 */     if (player.getWorld().getEnvironment() == World.Environment.THE_END) {
/* 34 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Im Ende kann dir der Spawn nicht angegeben werden.");
/* 35 */       return false;
/* 36 */     }  if (player.getWorld().getEnvironment() == World.Environment.NETHER) {
/* 37 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SPAWN_NETHER.getValue().replace("%x%", (new StringBuilder(String.valueOf(loc.getBlockX()))).toString()).replace("%y%", (new StringBuilder(String.valueOf(loc.getBlockY()))).toString()).replace("%z%", (new StringBuilder(String.valueOf(loc.getBlockZ()))).toString()));
/* 38 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SPAWN_DISTANCE_NETHER.getValue().replace("%distance%", String.valueOf((int)player.getLocation().distance(loc))));
/*    */     } else {
/* 40 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SPAWN_WORLD.getValue().replace("%x%", (new StringBuilder(String.valueOf(loc.getBlockX()))).toString()).replace("%y%", (new StringBuilder(String.valueOf(loc.getBlockY()))).toString()).replace("%z%", (new StringBuilder(String.valueOf(loc.getBlockZ()))).toString()));
/* 41 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.SPAWN_DISTANCE.getValue().replace("%distance%", String.valueOf((int)player.getLocation().distance(loc))));
/*    */     } 
/*    */     
/* 44 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\SpawnCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */