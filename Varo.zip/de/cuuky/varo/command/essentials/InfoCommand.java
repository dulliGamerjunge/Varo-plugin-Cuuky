/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class InfoCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 17 */     if (!sender.hasPermission("varo.info")) {
/* 18 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 19 */       return false;
/*    */     } 
/*    */     
/* 22 */     if (args.length == 0) {
/* 23 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/info §7<Spieler>");
/* 24 */       return false;
/*    */     } 
/*    */     
/* 27 */     Player player = Bukkit.getPlayerExact(args[0]);
/* 28 */     if (player == null) {
/* 29 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Spieler nicht gefunden!");
/* 30 */       return false;
/*    */     } 
/*    */     
/* 33 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "§l" + player.getName() + "§7:");
/* 34 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Leben: " + Main.getColorCode() + VersionUtils.getHearts(player) + "§7/20.0");
/* 35 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Hunger: " + Main.getColorCode() + player.getFoodLevel() + "§7/20.0");
/* 36 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Level: " + Main.getColorCode() + player.getLevel());
/* 37 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Location: x:" + Main.getColorCode() + player.getLocation().getBlockX() + "§7, y:" + Main.getColorCode() + player.getLocation().getBlockY() + "§7, z:" + Main.getColorCode() + player.getLocation().getBlockZ());
/* 38 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "IP: " + Main.getColorCode() + player.getAddress().getAddress().toString());
/* 39 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\InfoCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */