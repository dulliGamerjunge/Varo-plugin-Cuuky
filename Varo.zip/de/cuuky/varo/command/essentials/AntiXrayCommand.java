/*     */ package de.cuuky.varo.command.essentials;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AntiXrayCommand
/*     */   implements CommandExecutor
/*     */ {
/*     */   private boolean antiXrayActivated;
/*     */   private byte xrayAvailable;
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/*  25 */     if (!sender.hasPermission("varo.xray")) {
/*  26 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/*  27 */       return false;
/*     */     } 
/*  29 */     this.antiXrayActivated = false;
/*     */     
/*  31 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_8)) {
/*  32 */       this.xrayAvailable = 0;
/*  33 */     } else if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_13)) {
/*  34 */       this.xrayAvailable = 1;
/*     */     } else {
/*  36 */       this.xrayAvailable = 2;
/*     */     } 
/*     */     
/*  39 */     if (VersionUtils.getSpigot() == null && 
/*  40 */       this.xrayAvailable != 1) {
/*  41 */       this.xrayAvailable = 2;
/*     */     }
/*  43 */     YamlConfiguration spigotConfig = null;
/*  44 */     if (this.xrayAvailable == 0) {
/*     */       try {
/*  46 */         Method m = VersionUtils.getSpigot().getClass().getMethod("getConfig", new Class[0]);
/*  47 */         m.setAccessible(true);
/*  48 */         spigotConfig = (YamlConfiguration)m.invoke(VersionUtils.getSpigot(), new Object[0]);
/*  49 */         m.setAccessible(false);
/*  50 */       } catch (Exception e) {
/*  51 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*  54 */     if (this.xrayAvailable == 0) {
/*  55 */       String enabled = spigotConfig.getString("world-settings.default.anti-xray.enabled");
/*  56 */       String engineMode = spigotConfig.getString("world-settings.default.anti-xray.engine-mode");
/*  57 */       if (enabled == null || engineMode == null) {
/*  58 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cEs gab einen Fehler mit dem Anti-Xray-System.");
/*  59 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Dies kann daran liegen, dass du eine nicht-unterstuetzte Serverversion benutzt.");
/*  60 */         return false;
/*     */       } 
/*  62 */       if (!enabled.contentEquals("true") || !engineMode.contentEquals("2")) {
/*  63 */         this.antiXrayActivated = false;
/*     */       } else {
/*  65 */         this.antiXrayActivated = true;
/*     */       } 
/*     */     } 
/*     */     
/*  69 */     if (this.xrayAvailable == 1) {
/*  70 */       File file = new File("plugins/Orebfuscator4", "config.yml");
/*  71 */       if (file.exists()) {
/*  72 */         YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
/*  73 */         String enabled = config.getString("Booleans.Enabled");
/*  74 */         String engineMode = config.getString("Integers.EngineMode");
/*  75 */         if (!enabled.contentEquals("true") || !engineMode.contentEquals("2")) {
/*  76 */           this.antiXrayActivated = false;
/*     */         } else {
/*  78 */           this.antiXrayActivated = true;
/*     */         } 
/*     */       } else {
/*  81 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Das Anti-Xray-Plugin wird installiert und der Server danach heruntergefahren.");
/*     */         
/*  83 */         boolean xrayDownload = Main.getDataManager().getPluginLoader().loadAdditionalPlugin(22818, "Anti-Xray.jar");
/*     */         
/*  85 */         if (!xrayDownload) {
/*  86 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Es gab einen kritischen Fehler beim Download des Plugins.");
/*  87 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du kannst dir das externe Plugin hier manuell herunterladen: https://www.spigotmc.org/resources/22818/");
/*  88 */           return false;
/*     */         } 
/*     */         
/*  91 */         Bukkit.getServer().shutdown();
/*  92 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/*  96 */     if (this.xrayAvailable == 2) {
/*  97 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "In deiner Serverversion ist kein Anti-Xray verfuegbar.");
/*  98 */       return false;
/*     */     } 
/*     */     
/* 101 */     if (args.length != 1 || (!args[0].equalsIgnoreCase("on") && !args[0].equalsIgnoreCase("off"))) {
/* 102 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Anti-Xray momentan §l" + (this.antiXrayActivated ? "aktiviert" : "deaktiviert"));
/* 103 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/antixray on - Aktiviert den Schutz vor X-Ray");
/* 104 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/antixray off - Deaktiviert den Schutz vor X-Ray");
/* 105 */       return false;
/*     */     } 
/*     */     
/* 108 */     if (args[0].equalsIgnoreCase("on")) {
/* 109 */       if (this.antiXrayActivated) {
/* 110 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das Anti-Xray ist bereits aktiviert.");
/* 111 */         return false;
/*     */       } 
/* 113 */       if (this.xrayAvailable == 0) {
/* 114 */         spigotConfig.set("world-settings.default.anti-xray.enabled", Boolean.valueOf(true));
/* 115 */         spigotConfig.set("world-settings.default.anti-xray.engine-mode", Integer.valueOf(2));
/*     */         
/*     */         try {
/* 118 */           spigotConfig.save("spigot.yml");
/* 119 */         } catch (IOException e) {
/* 120 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cFehler: §7Das Anti-Xray konnte nicht aktiviert werden.");
/* 121 */           return false;
/*     */         } 
/* 123 */       } else if (this.xrayAvailable == 1) {
/* 124 */         Bukkit.dispatchCommand(sender, "ofc enable");
/* 125 */         Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "ofc engine 2");
/*     */       } 
/*     */       
/* 128 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das Anti-Xray wurde aktiviert.");
/*     */     }
/* 130 */     else if (args[0].equalsIgnoreCase("off")) {
/* 131 */       if (!this.antiXrayActivated) {
/* 132 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das Anti-Xray ist bereits deaktiviert.");
/* 133 */         return false;
/*     */       } 
/* 135 */       if (this.xrayAvailable == 0) {
/* 136 */         spigotConfig.set("world-settings.default.anti-xray.enabled", Boolean.valueOf(true));
/* 137 */         spigotConfig.set("world-settings.default.anti-xray.engine-mode", Integer.valueOf(1));
/*     */         
/*     */         try {
/* 140 */           spigotConfig.save("spigot.yml");
/* 141 */         } catch (IOException e) {
/* 142 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§cFehler: §7Das Anti-Xray konnte nicht deaktiviert werden.");
/* 143 */           return false;
/*     */         } 
/* 145 */       } else if (this.xrayAvailable == 1) {
/* 146 */         Bukkit.dispatchCommand(sender, "ofc disable");
/*     */       } 
/*     */       
/* 149 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Das Anti-Xray wurde deaktiviert.");
/*     */     } 
/*     */ 
/*     */     
/* 153 */     Bukkit.getServer().shutdown();
/* 154 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\AntiXrayCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */