/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.version.BukkitVersion;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class GamemodeCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 19 */     if (!sender.hasPermission("varo.gamemode")) {
/* 20 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 21 */       return false;
/*    */     } 
/*    */ 
/*    */     
/* 25 */     if (args.length <= 2 && args.length != 0) {
/* 26 */       Player player; GameMode gm; if (args.length == 1) {
/* 27 */         if (!(sender instanceof Player)) {
/* 28 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/gamemode [Player/@a]");
/* 29 */           return false;
/*    */         } 
/* 31 */         player = (Player)sender;
/*    */       }
/* 33 */       else if (args[1].equalsIgnoreCase("@a")) {
/* 34 */         player = null;
/*    */       } else {
/* 36 */         player = Bukkit.getPlayerExact(args[1]);
/* 37 */         if (player == null) {
/* 38 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Spieler " + args[1] + "§7 nicht gefunden.");
/* 39 */           return false;
/*    */         } 
/*    */       } 
/*    */       
/* 43 */       int mode = 0;
/*    */       try {
/* 45 */         mode = Integer.valueOf(args[0]).intValue();
/* 46 */       } catch (Exception e) {
/* 47 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast keinen gueltigen Gamemode angegeben!");
/* 48 */         return false;
/*    */       } 
/*    */ 
/*    */       
/* 52 */       switch (mode) {
/*    */         case 0:
/* 54 */           gm = GameMode.SURVIVAL;
/*    */           break;
/*    */         case 1:
/* 57 */           gm = GameMode.CREATIVE;
/*    */           break;
/*    */         case 2:
/* 60 */           gm = GameMode.ADVENTURE;
/*    */           break;
/*    */         case 3:
/* 63 */           if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/* 64 */             sender.sendMessage(String.valueOf(Main.getPrefix()) + "Nicht verfuegbar vor der 1.8!");
/* 65 */             return false;
/*    */           } 
/*    */           
/* 68 */           gm = GameMode.valueOf("SPECTATOR");
/*    */           break;
/*    */         
/*    */         default:
/* 72 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Die Zahl muss 0-3 betragen!");
/* 73 */           return false;
/*    */       } 
/*    */       
/* 76 */       if (player != null) {
/* 77 */         player.setGameMode(gm);
/*    */         
/* 79 */         if (args.length == 1) {
/* 80 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du bist nun im Gamemode " + Main.getColorCode() + gm.toString() + "§7!");
/*    */         } else {
/* 82 */           sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + player.getName() + " ist nun im Gamemode " + Main.getColorCode() + gm.toString() + "§7!");
/*    */         } 
/*    */       } else {
/* 85 */         for (Player p : Bukkit.getOnlinePlayers()) {
/* 86 */           p.setGameMode(gm);
/*    */         }
/* 88 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Alle Spieler sind nun im Gamemode " + Main.getColorCode() + gm.toString() + "§7!");
/*    */       } 
/*    */     } else {
/*    */       
/* 92 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/gamemode <Mode> [Player]");
/*    */     } 
/* 94 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\GamemodeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */