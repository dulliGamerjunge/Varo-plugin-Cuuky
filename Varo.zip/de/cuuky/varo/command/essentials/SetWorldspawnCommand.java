/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.version.types.Sounds;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class SetWorldspawnCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
/* 16 */     if (!(sender instanceof Player)) {
/* 17 */       System.out.println("Nicht fuer die Konsole");
/* 18 */       return false;
/*    */     } 
/*    */     
/* 21 */     Player p = (Player)sender;
/* 22 */     if (!p.hasPermission("Varo.setup")) {
/* 23 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 24 */       return false;
/*    */     } 
/*    */     
/* 27 */     if (args.length != 0) {
/* 28 */       p.sendMessage(String.valueOf(Main.getPrefix()) + "§7/setworldspawn");
/* 29 */       return false;
/*    */     } 
/*    */     
/* 32 */     p.getWorld().setSpawnLocation(p.getLocation().getBlockX(), p.getLocation().getBlockY(), p.getLocation().getBlockZ());
/* 33 */     Main.getVaroGame().getVaroWorldHandler().getVaroWorld(p.getWorld()).getVaroBorder().setBorderCenter(p.getLocation());
/* 34 */     p.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "Weltspawn §7erfolgreich gesetzt!");
/* 35 */     p.playSound(p.getLocation(), Sounds.NOTE_BASS_DRUM.bukkitSound(), 1.0F, 1.0F);
/* 36 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\SetWorldspawnCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */