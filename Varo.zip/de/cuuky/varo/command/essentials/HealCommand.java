/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ 
/*    */ public class HealCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 16 */     if (!sender.hasPermission("varo.heal")) {
/* 17 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 18 */       return false;
/*    */     } 
/*    */     
/* 21 */     if (args.length == 0) {
/* 22 */       if (!(sender instanceof Player)) {
/* 23 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/heal [Player/@a]");
/* 24 */         return false;
/*    */       } 
/*    */       
/* 27 */       Player p = (Player)sender;
/* 28 */       p.setHealth(20.0D);
/* 29 */       p.getActivePotionEffects().forEach(effect -> paramPlayer.removePotionEffect(effect.getType()));
/* 30 */       p.setFoodLevel(20);
/* 31 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du wurdest erfolgreich §ageheilt§7!");
/* 32 */     } else if (args.length == 1) {
/* 33 */       if (Bukkit.getPlayerExact(args[0]) == null) {
/* 34 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7nicht gefunden!");
/* 35 */         return false;
/*    */       } 
/*    */       
/* 38 */       if (args[0].equalsIgnoreCase("@a")) {
/* 39 */         for (Player player : Bukkit.getOnlinePlayers()) {
/* 40 */           player.setHealth(20.0D);
/* 41 */           player.getActivePotionEffects().forEach(effect -> paramPlayer.removePotionEffect(effect.getType()));
/* 42 */           player.setFoodLevel(20);
/*    */         } 
/* 44 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "§aAlle Spieler §7erfolgreich geheilt!");
/* 45 */         return false;
/*    */       } 
/*    */       
/* 48 */       Player p = Bukkit.getPlayerExact(args[0]);
/* 49 */       p.setHealth(20.0D);
/* 50 */       p.getActivePotionEffects().forEach(effect -> paramPlayer.removePotionEffect(effect.getType()));
/* 51 */       p.setFoodLevel(20);
/* 52 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§a" + args[0] + " §7erfolgreich geheilt!");
/*    */     } else {
/* 54 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/heal [Player]");
/* 55 */     }  return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\HealCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */