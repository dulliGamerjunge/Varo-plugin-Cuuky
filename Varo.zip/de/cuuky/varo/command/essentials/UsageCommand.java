/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.threads.LagCounter;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ public class UsageCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
/* 16 */     if (!sender.hasPermission("varo.usage")) {
/* 17 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 18 */       return false;
/*    */     } 
/*    */     
/* 21 */     Runtime r = Runtime.getRuntime();
/* 22 */     sender.sendMessage("§7-----------§7 §c§lSERVER-USAGE §7-----------");
/* 23 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7System OS: §c" + System.getProperty("os.name"));
/* 24 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7System Version: §c" + System.getProperty("os.version"));
/* 25 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Java Version: §c" + System.getProperty("java.version"));
/* 26 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Bukkit/Spigot Version: §c" + Bukkit.getVersion());
/* 27 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Plugin Version: §c" + Main.getInstance().getDescription().getVersion());
/* 28 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Total memory usage: §c" + ((r.totalMemory() - r.freeMemory()) / 1048576L) + "MB§7!");
/* 29 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Total memory available: §c" + (r.maxMemory() / 1048576L) + "MB§7!");
/* 30 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7TPS: §c" + (Math.round(LagCounter.getTPS() * 100.0D) / 100.0D));
/* 31 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\UsageCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */