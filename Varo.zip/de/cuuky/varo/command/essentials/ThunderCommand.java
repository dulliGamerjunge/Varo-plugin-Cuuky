/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class ThunderCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 17 */     if (!sender.hasPermission("varo.thunder")) {
/* 18 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 19 */       return false;
/*    */     } 
/*    */     
/* 22 */     World world = (sender instanceof Player) ? ((Player)sender).getWorld() : Bukkit.getWorlds().get(0);
/*    */     
/* 24 */     world.setStorm(true);
/* 25 */     world.setThundering(true);
/* 26 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "Wechsle zu Gewitter...");
/* 27 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\ThunderCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */