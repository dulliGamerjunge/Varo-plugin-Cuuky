/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProtectCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 19 */     if (!sender.hasPermission("varo.protect")) {
/* 20 */       sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 21 */       return false;
/*    */     } 
/*    */     
/* 24 */     if (args.length != 1) {
/* 25 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/protect <Player/@a>");
/* 26 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7/unprotect <Player/@a>");
/* 27 */       return false;
/*    */     } 
/*    */     
/* 30 */     if (args[0].equalsIgnoreCase("@a")) {
/* 31 */       for (VaroPlayer varoPlayer : VaroPlayer.getOnlinePlayer());
/*    */ 
/*    */       
/* 34 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "Erfolgreich alle Spieler protected!");
/* 35 */       return false;
/*    */     } 
/*    */     
/* 38 */     if (Bukkit.getPlayerExact(args[0]) == null) {
/* 39 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7nicht gefunden!");
/* 40 */       return false;
/*    */     } 
/*    */     
/* 43 */     Player player = Bukkit.getPlayerExact(args[0]);
/* 44 */     VaroPlayer vp = VaroPlayer.getPlayer(player);
/*    */ 
/*    */     
/* 47 */     sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7" + args[0] + " §7erfolgreich protected!");
/* 48 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\ProtectCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */