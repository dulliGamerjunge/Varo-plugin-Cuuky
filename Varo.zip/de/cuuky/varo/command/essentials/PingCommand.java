/*    */ package de.cuuky.varo.command.essentials;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class PingCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String ping, String[] args) {
/* 17 */     if (args.length == 0) {
/* 18 */       if (!(sender instanceof Player)) {
/* 19 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + "Du musst ein Spieler sein!");
/* 20 */         return false;
/*    */       } 
/*    */       
/* 23 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.OTHER_PING.getValue().replace("%ping%", String.valueOf(VaroPlayer.getPlayer((Player)sender).getNetworkManager().getPing())));
/* 24 */     } else if (args.length == 1) {
/* 25 */       if (!sender.hasPermission("varo.ping")) {
/* 26 */         sender.sendMessage(ConfigMessages.NOPERMISSION_NO_PERMISSION.getValue());
/* 27 */         return false;
/*    */       } 
/*    */       
/* 30 */       Player p = Bukkit.getPlayerExact(args[0]);
/* 31 */       if (p == null) {
/* 32 */         sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + args[0] + " §7nicht gefunden!");
/* 33 */         return false;
/*    */       } 
/*    */       
/* 36 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + "§7Der Ping von " + Main.getColorCode() + args[0] + " §7betraegt " + Main.getColorCode() + String.valueOf(VaroPlayer.getPlayer(p).getNetworkManager().getPing()) + "ms§7!");
/*    */     } else {
/* 38 */       sender.sendMessage(String.valueOf(Main.getPrefix()) + Main.getColorCode() + "/ping §7[Player]");
/*    */     } 
/* 40 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\command\essentials\PingCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */