/*    */ package de.cuuky.varo.report;
/*    */ 
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*    */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Material;
/*    */ 
/*    */ public enum ReportReason
/*    */   implements VaroSerializeable
/*    */ {
/* 11 */   CHAT(
/* 12 */     "Chat", Materials.OAK_WOOD.parseMaterial(), "Benutze dies, falls jemand sich gegen die Chatregeln verhaelt."),
/*    */   
/* 14 */   HACKING(
/* 15 */     "Hacking", Materials.TNT.parseMaterial(), "Benutze dies, falls jemand hackt oder exploited."),
/*    */   
/* 17 */   TEAMING(
/* 18 */     "Teaming", Materials.DIRT.parseMaterial(), "Benutze dies, falls Personen aus unterschiedlichen Teams teamen."),
/*    */   
/* 20 */   TROLLING(
/* 21 */     "Trolling", Materials.BLACK_WOOL.parseMaterial(), "Benutze dies, falls jemand trollt."),
/*    */   
/* 23 */   XRAY(
/* 24 */     "Xray", Materials.STONE.parseMaterial(), "Benutze dies, falls jemand Xray benutzt.");
/*    */   
/*    */   private String description;
/*    */   private Material material;
/*    */   private String name;
/*    */   
/*    */   ReportReason(String s, Material mat, String desc) {
/* 31 */     this.name = s;
/* 32 */     this.material = mat;
/* 33 */     this.description = desc;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 37 */     return this.description;
/*    */   }
/*    */   
/*    */   public Material getMaterial() {
/* 41 */     return this.material;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 45 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDeserializeEnd() {}
/*    */   
/*    */   public static ReportReason getByName(String name) {
/*    */     byte b;
/*    */     int i;
/*    */     ReportReason[] arrayOfReportReason;
/* 55 */     for (i = (arrayOfReportReason = values()).length, b = 0; b < i; ) { ReportReason reasons = arrayOfReportReason[b];
/* 56 */       if (reasons.getName().equals(name))
/* 57 */         return reasons; 
/*    */       b++; }
/*    */     
/* 60 */     return null;
/*    */   }
/*    */   
/*    */   public void onSerializeStart() {}
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\report\ReportReason.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */