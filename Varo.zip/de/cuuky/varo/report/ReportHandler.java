/*    */ package de.cuuky.varo.report;
/*    */ 
/*    */ import de.cuuky.varo.serialize.VaroSerializeObject;
/*    */ 
/*    */ public class ReportHandler
/*    */   extends VaroSerializeObject {
/*    */   static {
/*  8 */     registerEnum(ReportReason.class);
/*    */   }
/*    */   
/*    */   public ReportHandler() {
/* 12 */     super(Report.class, "/stats/reports.yml");
/*    */     
/* 14 */     load();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onSave() {
/* 19 */     clearOld();
/*    */     
/* 21 */     for (Report report : Report.getReports()) {
/* 22 */       save(String.valueOf(report.getId()), report, getConfiguration());
/*    */     }
/* 24 */     saveFile();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\report\ReportHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */