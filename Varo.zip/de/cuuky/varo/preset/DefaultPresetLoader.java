/*    */ package de.cuuky.varo.preset;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipInputStream;
/*    */ 
/*    */ 
/*    */ public class DefaultPresetLoader
/*    */ {
/*    */   public DefaultPresetLoader() {
/* 14 */     copyDefaultPresets();
/*    */   }
/*    */   
/*    */   private void copyDefaultPresets() {
/*    */     try {
/* 19 */       ZipInputStream zip = new ZipInputStream(new FileInputStream(Main.getInstance().getThisFile()));
/*    */       
/* 21 */       ZipEntry e = null;
/* 22 */       while ((e = zip.getNextEntry()) != null) {
/* 23 */         String name = e.getName();
/* 24 */         e.isDirectory();
/* 25 */         if (name.startsWith("presets")) {
/* 26 */           File file = new File("plugins/Varo/" + name);
/* 27 */           if (e.isDirectory()) {
/* 28 */             file.mkdir();
/*    */             
/*    */             continue;
/*    */           } 
/* 32 */           if (!file.exists()) {
/* 33 */             (new File(file.getParent())).mkdirs();
/* 34 */             file.createNewFile();
/*    */ 
/*    */ 
/*    */             
/* 38 */             FileOutputStream out = new FileOutputStream(file);
/*    */             
/* 40 */             byte[] byteBuff = new byte[1024];
/* 41 */             int bytesRead = 0;
/* 42 */             while ((bytesRead = zip.read(byteBuff)) != -1) {
/* 43 */               out.write(byteBuff, 0, bytesRead);
/*    */             }
/*    */             
/* 46 */             out.flush();
/* 47 */             out.close();
/*    */           } 
/*    */         } 
/*    */       } 
/* 51 */       zip.close();
/* 52 */     } catch (Exception e) {
/* 53 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\preset\DefaultPresetLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */