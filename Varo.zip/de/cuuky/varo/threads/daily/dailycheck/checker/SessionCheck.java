/*    */ package de.cuuky.varo.threads.daily.dailycheck.checker;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ import de.cuuky.varo.threads.daily.dailycheck.Checker;
/*    */ 
/*    */ public class SessionCheck
/*    */   extends Checker {
/*    */   public void check() {
/*    */     int preProduceSessions;
/* 14 */     if (ConfigSetting.SESSIONS_PER_DAY.getValueAsInt() <= 0) {
/*    */       return;
/*    */     }
/*    */     
/* 18 */     int normalSessions = ConfigSetting.SESSIONS_PER_DAY.getValueAsInt();
/*    */     
/* 20 */     if (ConfigSetting.PRE_PRODUCE_SESSIONS.getValueAsInt() > 0) {
/* 21 */       preProduceSessions = ConfigSetting.PRE_PRODUCE_SESSIONS.getValueAsInt();
/*    */     } else {
/* 23 */       preProduceSessions = 0;
/*    */     } 
/*    */     
/* 26 */     for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/*    */       
/* 28 */       vp.getStats().setSessions(vp.getStats().getSessions() + normalSessions);
/*    */       
/* 30 */       if (!ConfigSetting.CATCH_UP_SESSIONS.getValueAsBoolean() && vp.getStats().getSessions() > normalSessions + preProduceSessions) {
/* 31 */         vp.getStats().setSessions(normalSessions + preProduceSessions);
/*    */       }
/*    */     } 
/*    */     
/* 35 */     if (ConfigSetting.CATCH_UP_SESSIONS.getValueAsBoolean()) {
/* 36 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_NEW_SESSIONS_FOR_ALL.getValue().replace("%newSessions%", String.valueOf(ConfigSetting.SESSIONS_PER_DAY.getValueAsInt())));
/*    */     } else {
/* 38 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, ConfigMessages.ALERT_NEW_SESSIONS.getValue().replace("%newSessions%", String.valueOf(ConfigSetting.SESSIONS_PER_DAY.getValueAsInt())));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\threads\daily\dailycheck\checker\SessionCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */