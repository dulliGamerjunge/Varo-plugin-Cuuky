/*    */ package de.cuuky.varo.threads.daily.dailycheck.checker;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ import de.cuuky.varo.threads.daily.dailycheck.Checker;
/*    */ import de.cuuky.varo.utils.varo.LocationFormat;
/*    */ import java.util.Date;
/*    */ import org.apache.commons.lang.time.DateUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoordsCheck
/*    */   extends Checker
/*    */ {
/*    */   public void check() {
/* 18 */     if (!ConfigSetting.POST_COORDS_DAYS.isIntActivated()) {
/*    */       return;
/*    */     }
/* 21 */     if (Main.getVaroGame().getLastCoordsPost() == null) {
/* 22 */       Main.getVaroGame().setLastCoordsPost(new Date());
/*    */       
/*    */       return;
/*    */     } 
/* 26 */     if ((new Date()).after(DateUtils.addDays(Main.getVaroGame().getLastCoordsPost(), ConfigSetting.POST_COORDS_DAYS.getValueAsInt()))) {
/* 27 */       String post = "";
/* 28 */       for (VaroPlayer vp : VaroPlayer.getAlivePlayer()) {
/* 29 */         post = String.valueOf(post) + (post.isEmpty() ? "Liste der Koordinaten aller Spieler:\n\n" : "\n") + vp.getName() + ((vp.getTeam() != null) ? (" (#" + vp.getTeam().getName() + ")") : "") + ": " + ((vp.getStats().getLastLocation() != null) ? (new LocationFormat(vp.getStats().getLastLocation())).format("X:x Y:y Z:z in world") : "/");
/*    */       }
/* 31 */       Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.ALERT, post);
/* 32 */       Main.getVaroGame().setLastCoordsPost(new Date());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\threads\daily\dailycheck\checker\CoordsCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */