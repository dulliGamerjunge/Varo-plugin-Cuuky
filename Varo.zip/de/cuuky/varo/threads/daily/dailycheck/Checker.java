/*    */ package de.cuuky.varo.threads.daily.dailycheck;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ public abstract class Checker
/*    */ {
/*    */   protected long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
/*  9 */     long diffInMillies = date2.getTime() - date1.getTime();
/* 10 */     return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
/*    */   }
/*    */   
/*    */   public abstract void check();
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\threads\daily\dailycheck\Checker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */