/*    */ package de.cuuky.varo.threads;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.version.VersionUtils;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class SmartLagDetector
/*    */   implements Runnable
/*    */ {
/*    */   private ArrayList<Double> lastTps;
/*    */   private long lastPost;
/*    */   private boolean ramCleared;
/*    */   
/*    */   public SmartLagDetector(JavaPlugin instance) {
/* 19 */     this.lastTps = new ArrayList<>();
/*    */     
/* 21 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)instance, new LagCounter(), 100L, 1L);
/* 22 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)instance, this, 1200L, 30L);
/*    */   }
/*    */   
/*    */   private void checkPerformance() {
/* 26 */     this.lastPost++;
/* 27 */     if (this.lastPost == 30L) {
/* 28 */       this.lastPost = 0L;
/*    */     } else {
/*    */       return;
/*    */     } 
/* 32 */     double size = 0.0D, summ = 0.0D;
/* 33 */     for (int index = 0; index <= 30 && 
/* 34 */       index < this.lastTps.size(); index++) {
/*    */ 
/*    */       
/* 37 */       double tps = ((Double)this.lastTps.toArray()[index]).doubleValue();
/*    */       
/* 39 */       size++;
/* 40 */       summ += tps;
/*    */     } 
/*    */     
/* 43 */     double tpsUsage = summ / size;
/* 44 */     if (tpsUsage <= 14.0D) {
/* 45 */       warnAdmins("§4The CPU-Performance of the server is running low! §cLags could appear!");
/*    */     }
/* 47 */     Runtime r = Runtime.getRuntime();
/* 48 */     double ramUsage = (r.totalMemory() - r.freeMemory()) / r.maxMemory();
/* 49 */     if (ramUsage >= 0.95D) {
/* 50 */       if (this.ramCleared) {
/* 51 */         warnAdmins("§4the RAM of the server is fully used and the plugin couldn't manage to clear it!");
/*    */       }
/* 53 */       System.gc();
/* 54 */       this.ramCleared = true;
/*    */     } else {
/* 56 */       this.ramCleared = false;
/*    */     } 
/*    */   }
/*    */   private void warnAdmins(String message) {
/* 60 */     for (Player player : VersionUtils.getOnlinePlayer()) {
/* 61 */       if (!player.hasPermission("varo.warnperformance")) {
/*    */         continue;
/*    */       }
/* 64 */       player.sendMessage(String.valueOf(Main.getPrefix()) + message);
/* 65 */       player.sendMessage(String.valueOf(Main.getPrefix()) + "§cType /performance for more info and help");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 71 */     this.lastTps.add(Double.valueOf(LagCounter.getTPS()));
/*    */     
/* 73 */     checkPerformance();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\threads\SmartLagDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */