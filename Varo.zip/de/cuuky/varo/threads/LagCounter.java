/*    */ package de.cuuky.varo.threads;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LagCounter
/*    */   implements Runnable
/*    */ {
/*  8 */   public static int TICK_COUNT = 0;
/*  9 */   public static long[] TICKS = new long[600];
/* 10 */   public static long LAST_TICK = 0L;
/*    */   
/*    */   public static double getTPS() {
/* 13 */     return getTPS(100);
/*    */   }
/*    */   
/*    */   public static double getTPS(int ticks) {
/* 17 */     if (TICK_COUNT < ticks) {
/* 18 */       return 20.0D;
/*    */     }
/* 20 */     int target = (TICK_COUNT - 1 - ticks) % TICKS.length;
/* 21 */     long elapsed = System.currentTimeMillis() - TICKS[target];
/*    */     
/* 23 */     return ticks / elapsed / 1000.0D;
/*    */   }
/*    */   
/*    */   public static long getElapsed(int tickID) {
/* 27 */     TICKS.length;
/*    */     
/* 29 */     long time = TICKS[tickID % TICKS.length];
/* 30 */     return System.currentTimeMillis() - time;
/*    */   }
/*    */   
/*    */   public void run() {
/* 34 */     TICKS[TICK_COUNT % TICKS.length] = System.currentTimeMillis();
/*    */     
/* 36 */     TICK_COUNT++;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\threads\LagCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */