/*     */ package de.cuuky.varo.alert;
/*     */ 
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeField;
/*     */ import de.cuuky.varo.serialize.identifier.VaroSerializeable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Alert
/*     */   implements VaroSerializeable
/*     */ {
/*  14 */   private static ArrayList<Alert> alerts = new ArrayList<>();
/*     */   
/*     */   @VaroSerializeField(path = "created")
/*     */   private Date created;
/*     */   
/*     */   @VaroSerializeField(path = "id")
/*     */   private int id;
/*     */   
/*     */   @VaroSerializeField(path = "message")
/*     */   private String message;
/*     */   
/*     */   @VaroSerializeField(path = "open")
/*     */   private boolean open;
/*     */   
/*     */   @VaroSerializeField(path = "type")
/*     */   private AlertType type;
/*     */ 
/*     */   
/*     */   public Alert() {
/*  33 */     alerts.add(this);
/*     */   }
/*     */   
/*     */   public Alert(AlertType type, String message) {
/*  37 */     this.type = type;
/*  38 */     this.message = message;
/*  39 */     this.id = generateId();
/*  40 */     this.open = true;
/*  41 */     this.created = new Date();
/*     */     
/*  43 */     alerts.add(this);
/*     */   }
/*     */   
/*     */   private int generateId() {
/*  47 */     int i = alerts.size() + 1;
/*  48 */     while (getAlert(i) != null) {
/*  49 */       i++;
/*     */     }
/*  51 */     return i;
/*     */   }
/*     */   
/*     */   public Date getCreated() {
/*  55 */     return this.created;
/*     */   }
/*     */   
/*     */   public int getId() {
/*  59 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/*  63 */     return this.message;
/*     */   }
/*     */   
/*     */   public AlertType getType() {
/*  67 */     return this.type;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/*  71 */     return this.open;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeserializeEnd() {}
/*     */ 
/*     */   
/*     */   public void onSerializeStart() {}
/*     */   
/*     */   public void setOpen(boolean open) {
/*  81 */     this.open = open;
/*     */   }
/*     */   
/*     */   public void switchOpenState() {
/*  85 */     this.open = !this.open;
/*     */   }
/*     */   
/*     */   public static Alert getAlert(int id) {
/*  89 */     for (Alert alert : alerts) {
/*  90 */       if (alert.getId() == id)
/*  91 */         return alert; 
/*     */     } 
/*  93 */     return null;
/*     */   }
/*     */   
/*     */   public static ArrayList<Alert> getAlerts() {
/*  97 */     return alerts;
/*     */   }
/*     */   
/*     */   public static ArrayList<Alert> getAlerts(AlertType type) {
/* 101 */     ArrayList<Alert> typed = new ArrayList<>();
/* 102 */     for (Alert alert : alerts) {
/* 103 */       if (alert.getType() == type)
/* 104 */         typed.add(alert); 
/*     */     } 
/* 106 */     return typed;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList<Alert> getClosedAlerts() {
/* 111 */     ArrayList<Alert> closed = new ArrayList<>();
/* 112 */     for (Alert alert : alerts) {
/* 113 */       if (!alert.isOpen())
/* 114 */         closed.add(alert); 
/*     */     } 
/* 116 */     return closed;
/*     */   }
/*     */   
/*     */   public static ArrayList<Alert> getOpenAlerts() {
/* 120 */     ArrayList<Alert> open = new ArrayList<>();
/* 121 */     for (Alert alert : alerts) {
/* 122 */       if (alert.isOpen())
/* 123 */         open.add(alert); 
/*     */     } 
/* 125 */     return open;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\alert\Alert.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */