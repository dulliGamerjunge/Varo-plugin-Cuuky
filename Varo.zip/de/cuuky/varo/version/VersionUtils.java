/*    */ package de.cuuky.varo.version;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VersionUtils
/*    */ {
/* 17 */   private static String nmsClass = "net.minecraft.server." + Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3];
/* 18 */   private static BukkitVersion version = BukkitVersion.getVersion(nmsClass); private static Object spigot;
/*    */   static {
/*    */     try {
/* 21 */       spigot = Bukkit.getServer().getClass().getDeclaredMethod("spigot", new Class[0]).invoke(Bukkit.getServer(), new Object[0]);
/* 22 */     } catch (Exception exception) {}
/*    */     
/*    */     try {
/* 25 */       chatSerializer = Class.forName(String.valueOf(getNmsClass()) + ".IChatBaseComponent$ChatSerializer");
/* 26 */     } catch (ClassNotFoundException e) {
/*    */       try {
/* 28 */         chatSerializer = Class.forName(String.valueOf(getNmsClass()) + ".ChatSerializer");
/* 29 */       } catch (ClassNotFoundException classNotFoundException) {}
/*    */     } 
/*    */   }
/*    */   private static Class<?> chatSerializer;
/*    */   public static Class<?> getChatSerializer() {
/* 34 */     return chatSerializer;
/*    */   }
/*    */   
/*    */   public static double getHearts(Player player) {
/* 38 */     return player.getHealth();
/*    */   }
/*    */   
/*    */   public static String getNmsClass() {
/* 42 */     return nmsClass;
/*    */   }
/*    */   
/*    */   public static Object getSpigot() {
/* 46 */     return spigot;
/*    */   }
/*    */   
/*    */   public static ArrayList<Player> getOnlinePlayer() {
/* 50 */     ArrayList<Player> list = new ArrayList<>();
/* 51 */     for (Player p : Bukkit.getOnlinePlayers()) {
/* 52 */       list.add(p);
/*    */     }
/* 54 */     return list;
/*    */   }
/*    */   
/*    */   public static BukkitVersion getVersion() {
/* 58 */     return version;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\version\VersionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */