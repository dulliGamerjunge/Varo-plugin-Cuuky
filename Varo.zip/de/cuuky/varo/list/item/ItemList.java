/*     */ package de.cuuky.varo.list.item;
/*     */ 
/*     */ import de.cuuky.varo.list.VaroList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class ItemList
/*     */   extends VaroList
/*     */ {
/*     */   protected ArrayList<ItemStack> items;
/*     */   
/*     */   public ItemList(String location) {
/*  15 */     super(location);
/*     */   }
/*     */   
/*     */   protected ItemStack fixItem(ItemStack item) {
/*  19 */     item = item.clone();
/*  20 */     item.setAmount(1);
/*  21 */     if (isDamageable(item))
/*  22 */       item.setDurability((short)0); 
/*  23 */     return item;
/*     */   }
/*     */   
/*     */   protected boolean isDamageable(ItemStack item) {
/*  27 */     if (item == null) {
/*  28 */       return false;
/*     */     }
/*  30 */     String[] split = item.getType().toString().split("_");
/*  31 */     int length = split.length; String str;
/*  32 */     switch ((str = split[length - 1]).hashCode()) { case -1850133582: if (!str.equals("SHEARS")) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  60 */         return true;case -1849815901: if (!str.equals("SHOVEL")) break;  return true;case -1776664470: if (!str.equals("LEGGINGS")) break;  return true;case -829199152: if (!str.equals("TURTLE_HELMET")) break;  return true;case -342000110: if (!str.equals("TRIDENT")) break;  return true;case 65262: if (!str.equals("AXE")) break;  return true;case 71710: if (!str.equals("HOE")) break;  return true;case 63384481: if (!str.equals("BOOTS")) break;  return true;case 79322589: if (!str.equals("SWORD")) break;  return true;case 139953965: if (!str.equals("PICKAXE")) break;  return true;case 1456344605: if (!str.equals("HORSE_ARMOR")) break;  return true;case 1555044533: if (!str.equals("CHESTPLATE")) break;  return true;case 2048333745: if (!str.equals("ELYTRA"))
/*     */           break;  return true;case 2127362157: if (!str.equals("HELMET"))
/*  62 */           break;  return true; }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addItem(ItemStack item) {
/*  67 */     this.items.add(fixItem(item));
/*     */     
/*  69 */     saveList();
/*     */   }
/*     */   
/*     */   public boolean hasItem(ItemStack item) {
/*  73 */     return this.items.contains(fixItem(item));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLoad(List<?> list) {
/*  78 */     this.items = new ArrayList<>();
/*     */     
/*  80 */     for (Object id : list) {
/*     */       try {
/*  82 */         ItemStack c = (ItemStack)id;
/*  83 */         this.items.add(c);
/*  84 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeItem(ItemStack item) {
/*  91 */     this.items.remove(fixItem(item));
/*     */     
/*  93 */     saveList();
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<?> getAsList() {
/*  98 */     return this.items;
/*     */   }
/*     */   
/*     */   public ArrayList<ItemStack> getItems() {
/* 102 */     return this.items;
/*     */   }
/*     */   
/*     */   public static ItemList getItemList(String list) {
/* 106 */     for (ItemList iList : getItemLists()) {
/* 107 */       if (iList.getLocation().equalsIgnoreCase(list))
/* 108 */         return iList; 
/*     */     } 
/* 110 */     return null;
/*     */   }
/*     */   
/*     */   public static ArrayList<ItemList> getItemLists() {
/* 114 */     ArrayList<ItemList> iList = new ArrayList<>();
/*     */     
/* 116 */     for (VaroList vlist : VaroList.getLists()) {
/* 117 */       if (vlist instanceof ItemList)
/* 118 */         iList.add((ItemList)vlist); 
/*     */     } 
/* 120 */     return iList;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList<ItemList> getItemListsMultipleAdd() {
/* 125 */     ArrayList<ItemList> itemLists = getItemLists();
/* 126 */     ArrayList<ItemList> multipleAdd = new ArrayList<>();
/* 127 */     for (ItemList list : itemLists) {
/* 128 */       String str; switch ((str = list.getLocation()).hashCode()) { case -1267325601: if (!str.equals("ChestItems")) {
/*     */             continue;
/*     */           }
/*     */           
/* 132 */           multipleAdd.add(list);case 399998110: if (!str.equals("StartItems")) continue;  multipleAdd.add(list);case 1826204108: if (!str.equals("DeathItems")) continue;  multipleAdd.add(list); }
/*     */     
/*     */     } 
/* 135 */     return multipleAdd;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\list\item\ItemList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */