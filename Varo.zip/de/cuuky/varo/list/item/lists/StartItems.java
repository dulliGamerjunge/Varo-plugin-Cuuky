/*    */ package de.cuuky.varo.list.item.lists;
/*    */ 
/*    */ import de.cuuky.varo.list.item.ItemList;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class StartItems
/*    */   extends ItemList
/*    */ {
/*    */   public StartItems() {
/* 14 */     super("StartItems");
/*    */     
/* 16 */     if (!this.items.isEmpty()) {
/*    */       return;
/*    */     }
/* 19 */     this.items.add(Materials.AIR.parseItem());
/*    */   }
/*    */   
/*    */   public void giveToAll() {
/* 23 */     for (Player player : Bukkit.getOnlinePlayers()) {
/* 24 */       for (ItemStack item : this.items) {
/* 25 */         player.getInventory().addItem(new ItemStack[] { item });
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\list\item\lists\StartItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */