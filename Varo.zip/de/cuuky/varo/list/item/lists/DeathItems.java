/*    */ package de.cuuky.varo.list.item.lists;
/*    */ 
/*    */ import de.cuuky.varo.list.item.ItemList;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ 
/*    */ public class DeathItems
/*    */   extends ItemList {
/*    */   public DeathItems() {
/*  9 */     super("DeathItems");
/*    */     
/* 11 */     if (!this.items.isEmpty()) {
/*    */       return;
/*    */     }
/* 14 */     this.items.add(Materials.AIR.parseItem());
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\list\item\lists\DeathItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */