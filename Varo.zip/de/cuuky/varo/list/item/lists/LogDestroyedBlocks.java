/*    */ package de.cuuky.varo.list.item.lists;
/*    */ 
/*    */ import de.cuuky.varo.list.item.ItemList;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class LogDestroyedBlocks
/*    */   extends ItemList
/*    */ {
/*    */   public LogDestroyedBlocks() {
/* 13 */     super("BlockLogger");
/*    */     
/* 15 */     if (!this.items.isEmpty()) {
/*    */       return;
/*    */     }
/* 18 */     this.items.add(Materials.DIAMOND_ORE.parseItem());
/* 19 */     this.items.add(Materials.LAPIS_ORE.parseItem());
/* 20 */     this.items.add(Materials.GOLD_ORE.parseItem());
/*    */   }
/*    */   
/*    */   public boolean shallLog(Block block) {
/* 24 */     for (ItemStack item : this.items) {
/* 25 */       if (block.getType() == item.getType() && block.getData() == item.getData().getData())
/* 26 */         return true; 
/*    */     } 
/* 28 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\list\item\lists\LogDestroyedBlocks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */