/*    */ package de.cuuky.varo.list.item.lists;
/*    */ 
/*    */ import de.cuuky.varo.list.item.ItemList;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ 
/*    */ public class ChestItems
/*    */   extends ItemList
/*    */ {
/*    */   public ChestItems() {
/* 10 */     super("ChestItems");
/*    */     
/* 12 */     if (!this.items.isEmpty()) {
/*    */       return;
/*    */     }
/* 15 */     this.items.add(Materials.WOODEN_AXE.parseItem());
/* 16 */     this.items.add(Materials.SUGAR_CANE.parseItem());
/* 17 */     this.items.add(Materials.APPLE.parseItem());
/* 18 */     this.items.add(Materials.PORKCHOP.parseItem());
/* 19 */     this.items.add(Materials.OAK_WOOD.parseItem());
/* 20 */     this.items.add(Materials.STICK.parseItem());
/* 21 */     this.items.add(Materials.COBBLESTONE.parseItem());
/* 22 */     this.items.add(Materials.SAND.parseItem());
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\list\item\lists\ChestItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */