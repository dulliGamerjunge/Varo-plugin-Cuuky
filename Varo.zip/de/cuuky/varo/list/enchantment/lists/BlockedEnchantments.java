/*    */ package de.cuuky.varo.list.enchantment.lists;
/*    */ 
/*    */ import de.cuuky.varo.list.enchantment.EnchantmentList;
/*    */ import org.bukkit.enchantments.Enchantment;
/*    */ 
/*    */ 
/*    */ public class BlockedEnchantments
/*    */   extends EnchantmentList
/*    */ {
/*    */   public BlockedEnchantments() {
/* 11 */     super("BlockedEnchantments");
/*    */     
/* 13 */     if (!this.enchantments.isEmpty()) {
/*    */       return;
/*    */     }
/* 16 */     this.enchantments.add(String.valueOf(Enchantment.ARROW_INFINITE.getName()) + ":1");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBlocked(Enchantment ench, int amplifier) {
/* 21 */     if (this.enchantments.contains(String.valueOf(ench.getName()) + ":" + amplifier)) {
/* 22 */       return true;
/*    */     }
/* 24 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\list\enchantment\lists\BlockedEnchantments.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */