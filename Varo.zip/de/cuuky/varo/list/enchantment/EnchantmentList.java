/*    */ package de.cuuky.varo.list.enchantment;
/*    */ 
/*    */ import de.cuuky.varo.list.VaroList;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.enchantments.Enchantment;
/*    */ 
/*    */ 
/*    */ public class EnchantmentList
/*    */   extends VaroList
/*    */ {
/*    */   protected ArrayList<String> enchantments;
/*    */   
/*    */   public EnchantmentList(String location) {
/* 15 */     super(location);
/*    */   }
/*    */   
/*    */   public void addEnchantment(Enchantment enc, int amplifier) {
/* 19 */     this.enchantments.add(String.valueOf(enc.getName()) + ":" + amplifier);
/*    */     
/* 21 */     saveList();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onLoad(List<?> list) {
/* 26 */     this.enchantments = new ArrayList<>();
/*    */     
/* 28 */     for (Object id : list)
/* 29 */       this.enchantments.add((String)id); 
/*    */   }
/*    */   
/*    */   public void removeEnchantment(Enchantment enc, int amplifier) {
/* 33 */     this.enchantments.remove(String.valueOf(enc.getName()) + ":" + amplifier);
/*    */     
/* 35 */     saveList();
/*    */   }
/*    */ 
/*    */   
/*    */   public ArrayList<String> getAsList() {
/* 40 */     return this.enchantments;
/*    */   }
/*    */   
/*    */   public ArrayList<String> getEnchantments() {
/* 44 */     return this.enchantments;
/*    */   }
/*    */   
/*    */   public boolean hasEnchantment(Enchantment enc, int amplifier) {
/* 48 */     return this.enchantments.contains(String.valueOf(enc.getName()) + ":" + amplifier);
/*    */   }
/*    */   
/*    */   public static EnchantmentList getEnchantmentList(String list) {
/* 52 */     for (EnchantmentList eList : getEnchantmentLists()) {
/* 53 */       if (eList.getLocation().equalsIgnoreCase(list))
/* 54 */         return eList; 
/*    */     } 
/* 56 */     return null;
/*    */   }
/*    */   
/*    */   public static ArrayList<EnchantmentList> getEnchantmentLists() {
/* 60 */     ArrayList<EnchantmentList> eList = new ArrayList<>();
/*    */     
/* 62 */     for (VaroList vlist : VaroList.getLists()) {
/* 63 */       if (vlist instanceof EnchantmentList)
/* 64 */         eList.add((EnchantmentList)vlist); 
/*    */     } 
/* 66 */     return eList;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\list\enchantment\EnchantmentList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */