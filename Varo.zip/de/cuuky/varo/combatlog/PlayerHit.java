/*     */ package de.cuuky.varo.combatlog;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerHit
/*     */ {
/*     */   private static class HitListener
/*     */     implements Listener
/*     */   {
/*     */     private HitListener() {}
/*     */     
/*     */     @EventHandler(priority = EventPriority.HIGHEST)
/*     */     public void onHit(EntityDamageByEntityEvent event) {
/*  29 */       if (!(event.getEntity() instanceof Player) || !(event.getDamager() instanceof Player)) {
/*     */         return;
/*     */       }
/*  32 */       if (!Main.getVaroGame().isRunning() || event.isCancelled()) {
/*     */         return;
/*     */       }
/*  35 */       VaroPlayer vp = VaroPlayer.getPlayer(((Player)event.getEntity()).getName());
/*  36 */       VaroPlayer vp1 = VaroPlayer.getPlayer(((Player)event.getDamager()).getName());
/*     */       
/*  38 */       if (vp.getTeam() == null || vp1.getTeam() == null || vp.getTeam().equals(vp1.getTeam())) {
/*     */         return;
/*     */       }
/*  41 */       Date current = new Date();
/*  42 */       vp.getStats().setLastEnemyContact(current);
/*  43 */       vp1.getStats().setLastEnemyContact(current);
/*     */       
/*  45 */       if (!ConfigSetting.COMBATLOG_TIME.isIntActivated()) {
/*     */         return;
/*     */       }
/*  48 */       Player player1 = (Player)event.getDamager();
/*  49 */       Player player2 = (Player)event.getEntity();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private static ArrayList<PlayerHit> hits = new ArrayList<>();
/*     */   static {
/*  60 */     Bukkit.getPluginManager().registerEvents(new HitListener(null), (Plugin)Main.getInstance());
/*     */   }
/*     */   
/*     */   private int task;
/*     */   private Player player;
/*     */   private Player opponent;
/*     */   
/*     */   public PlayerHit(Player player, Player opponent) {
/*  68 */     if (!hasOld(player)) {
/*  69 */       player.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.COMBAT_IN_FIGHT.getValue());
/*     */     }
/*  71 */     this.player = player;
/*  72 */     this.opponent = opponent;
/*     */     
/*  74 */     scheduleOvertime();
/*     */     
/*  76 */     hits.add(this);
/*     */   }
/*     */   
/*     */   private void scheduleOvertime() {
/*  80 */     this.task = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  84 */             PlayerHit.this.over();
/*     */           }
/*  86 */         },  (ConfigSetting.COMBATLOG_TIME.getValueAsInt() * 20));
/*     */   }
/*     */   
/*     */   public boolean hasOld(Player p) {
/*  90 */     for (PlayerHit hit : hits) {
/*  91 */       if (!hit.getPlayer().equals(p)) {
/*     */         continue;
/*     */       }
/*  94 */       hit.remove();
/*  95 */       return true;
/*     */     } 
/*     */     
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   public void over() {
/* 102 */     this.player.sendMessage(String.valueOf(Main.getPrefix()) + ConfigMessages.COMBAT_NOT_IN_FIGHT.getValue());
/* 103 */     remove();
/*     */   }
/*     */   
/*     */   public void remove() {
/* 107 */     Bukkit.getScheduler().cancelTask(this.task);
/* 108 */     hits.remove(this);
/*     */   }
/*     */   
/*     */   public Player getOpponent() {
/* 112 */     return this.opponent;
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/* 116 */     return this.player;
/*     */   }
/*     */   
/*     */   public static PlayerHit getHit(Player p) {
/* 120 */     for (PlayerHit hit : hits) {
/* 121 */       if (!hit.getPlayer().equals(p)) {
/*     */         continue;
/*     */       }
/* 124 */       return hit;
/*     */     } 
/*     */     
/* 127 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\combatlog\PlayerHit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */