/*    */ package de.cuuky.varo.listener.logging;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ 
/*    */ public class DestroyedBlocksListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onOreBreak(BlockBreakEvent event) {
/* 15 */     if (!ConfigSetting.BLOCK_DESTROY_LOGGER.getValueAsBoolean()) {
/*    */       return;
/*    */     }
/* 18 */     if (event.isCancelled()) {
/*    */       return;
/*    */     }
/* 21 */     Main.getDataManager().getVaroLoggerManager().getBlockLogger().println(event.getBlock(), event.getPlayer());
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\logging\DestroyedBlocksListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */