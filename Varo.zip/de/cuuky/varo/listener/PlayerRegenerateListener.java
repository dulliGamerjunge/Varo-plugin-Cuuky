/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityRegainHealthEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class PlayerRegenerateListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onHealthRegenerate(final EntityRegainHealthEvent event) {
/* 19 */     if (!(event.getEntity() instanceof Player)) {
/*    */       return;
/*    */     }
/* 22 */     if (event.isCancelled()) {
/*    */       return;
/*    */     }
/* 25 */     if (event.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED && 
/* 26 */       ConfigSetting.NO_SATIATION_REGENERATE.getValueAsBoolean()) {
/* 27 */       event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 31 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 35 */             VaroPlayer vp = VaroPlayer.getPlayer((Player)event.getEntity());
/*    */             
/* 37 */             if (vp.getNametag() != null)
/* 38 */               VaroPlayer.getPlayer((Player)event.getEntity()).getNametag().heartsChanged(); 
/*    */           }
/* 40 */         },  1L);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\PlayerRegenerateListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */