/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ 
/*    */ public class NoPortalListener
/*    */   implements Listener
/*    */ {
/*    */   public boolean netherPortalNearby(Location location, int radius) {
/* 16 */     for (int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
/* 17 */       for (int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
/* 18 */         for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
/* 19 */           if (location.getWorld().getBlockAt(x, y, z).getType().name().contains("PORTAL"))
/* 20 */             return true; 
/*    */         } 
/*    */       } 
/*    */     } 
/* 24 */     return false;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onBlockBreak(BlockBreakEvent event) {
/* 29 */     if (!ConfigSetting.BLOCK_USER_PORTALS.getValueAsBoolean()) {
/*    */       return;
/*    */     }
/* 32 */     if (event.getPlayer().hasPermission("varo.portals")) {
/*    */       return;
/*    */     }
/* 35 */     if (!event.getBlock().getType().equals(Material.OBSIDIAN)) {
/*    */       return;
/*    */     }
/* 38 */     if (!netherPortalNearby(event.getBlock().getLocation(), 1)) {
/*    */       return;
/*    */     }
/* 41 */     event.setCancelled(true);
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onInteract(PlayerInteractEvent event) {
/* 47 */     if (!ConfigSetting.BLOCK_USER_PORTALS.getValueAsBoolean()) {
/*    */       return;
/*    */     }
/* 50 */     if (!event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
/*    */       return;
/*    */     }
/* 53 */     if (event.getPlayer().hasPermission("varo.portals")) {
/*    */       return;
/*    */     }
/* 56 */     if (event.getPlayer().getItemInHand() == null) {
/*    */       return;
/*    */     }
/* 59 */     if (!event.getPlayer().getItemInHand().getType().equals(Material.FLINT_AND_STEEL) && !event.getPlayer().getItemInHand().getType().equals(Material.WATER_BUCKET)) {
/*    */       return;
/*    */     }
/* 62 */     if (event.getPlayer().getItemInHand().getType().equals(Material.WATER_BUCKET) && !netherPortalNearby(event.getClickedBlock().getLocation(), 1)) {
/*    */       return;
/*    */     }
/* 65 */     if (!event.getClickedBlock().getType().equals(Material.OBSIDIAN)) {
/*    */       return;
/*    */     }
/* 68 */     event.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\NoPortalListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */