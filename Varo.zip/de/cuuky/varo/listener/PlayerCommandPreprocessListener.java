/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ 
/*    */ public class PlayerCommandPreprocessListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
/* 13 */     String lowerMessage = event.getMessage().toLowerCase();
/* 14 */     if (lowerMessage.startsWith("/pl") || lowerMessage.startsWith("/plugins") || lowerMessage.startsWith("/?") || lowerMessage.startsWith("/bukkit:?") || lowerMessage.startsWith("/bukkit:pl") || lowerMessage.startsWith("/bukkit:plugins") || lowerMessage.startsWith("/help") || lowerMessage.startsWith("/bukkit:help") || lowerMessage.startsWith("/me") || lowerMessage.startsWith("/minecraft:me") || lowerMessage.startsWith("/tell") || lowerMessage.startsWith("/minecraft:tell") || lowerMessage.startsWith("/icanhasbukkit") || lowerMessage.startsWith("/version") || lowerMessage.startsWith("/bukkit:version") || lowerMessage.startsWith("/ver") || lowerMessage.startsWith("/about") || lowerMessage.startsWith("/bukkit:about")) {
/*    */       
/* 16 */       if (event.getPlayer().hasPermission("varo.readInfo")) {
/*    */         return;
/*    */       }
/* 19 */       if (Main.getVaroGame().isRunning() && 
/* 20 */         lowerMessage.contains("tell")) {
/*    */         return;
/*    */       }
/* 23 */       event.setCancelled(true);
/* 24 */       event.getPlayer().sendMessage(String.valueOf(Main.getPrefix()) + "§7Nein.");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\PlayerCommandPreprocessListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */