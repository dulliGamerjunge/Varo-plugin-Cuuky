/*    */ package de.cuuky.varo.listener.helper;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class ChatMessage
/*    */ {
/* 10 */   private static ArrayList<ChatMessage> messages = new ArrayList<>();
/*    */   
/*    */   private String message;
/*    */   private Player player;
/*    */   private Date written;
/*    */   
/*    */   public ChatMessage(Player player, String message) {
/* 17 */     this.player = player;
/* 18 */     this.message = message;
/* 19 */     this.written = new Date();
/*    */     
/* 21 */     messages.add(this);
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 25 */     return this.message;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 29 */     return this.player;
/*    */   }
/*    */   
/*    */   public Date getWritten() {
/* 33 */     return this.written;
/*    */   }
/*    */   
/*    */   public static ChatMessage getMessage(Player player) {
/* 37 */     for (ChatMessage cmessage : messages) {
/* 38 */       if (cmessage.getPlayer().equals(player)) {
/*    */         continue;
/*    */       }
/* 41 */       return cmessage;
/*    */     } 
/*    */     
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\helper\ChatMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */