/*    */ package de.cuuky.varo.listener.helper.cancelable;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaroCancelAble
/*    */ {
/* 15 */   private static ArrayList<VaroCancelAble> cancelables = new ArrayList<>();
/*    */   
/*    */   protected VaroPlayer player;
/*    */   
/*    */   protected Runnable timerHook;
/*    */   protected CancelAbleType type;
/*    */   
/*    */   public VaroCancelAble(CancelAbleType type, VaroPlayer player) {
/* 23 */     this.player = player;
/* 24 */     this.type = type;
/*    */     
/* 26 */     removeOld();
/*    */     
/* 28 */     cancelables.add(this);
/*    */   }
/*    */   
/*    */   public VaroCancelAble(CancelAbleType type, VaroPlayer player, int time) {
/* 32 */     this.player = player;
/* 33 */     this.type = type;
/*    */     
/* 35 */     removeOld();
/* 36 */     schedule(time);
/*    */     
/* 38 */     cancelables.add(this);
/*    */   }
/*    */   
/*    */   private void remove() {
/* 42 */     cancelables.remove(this);
/*    */   }
/*    */   
/*    */   private void removeOld() {
/* 46 */     removeCancelAble(this.player, this.type);
/*    */   }
/*    */   
/*    */   private void schedule(int time) {
/* 50 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 54 */             VaroCancelAble.this.timerHook.run();
/* 55 */             VaroCancelAble.this.remove();
/*    */           }
/* 57 */         },  (time * 20));
/*    */   }
/*    */   
/*    */   public VaroPlayer getPlayer() {
/* 61 */     return this.player;
/*    */   }
/*    */   
/*    */   public CancelAbleType getType() {
/* 65 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setTimerHook(Runnable runnable) {
/* 69 */     this.timerHook = runnable;
/*    */   }
/*    */   
/*    */   public static VaroCancelAble getCancelAble(VaroPlayer player, CancelAbleType type) {
/* 73 */     for (VaroCancelAble able : cancelables) {
/* 74 */       if (able.getPlayer().equals(player) && able.getType().equals(type))
/* 75 */         return able; 
/*    */     } 
/* 77 */     return null;
/*    */   }
/*    */   
/*    */   public static void removeCancelAble(VaroPlayer player, CancelAbleType type) {
/* 81 */     for (int i = 0; i < cancelables.size(); i++) {
/* 82 */       VaroCancelAble able = cancelables.get(i);
/* 83 */       if (able.getPlayer().equals(player) && able.getType().equals(type)) {
/* 84 */         able.remove();
/* 85 */         i--;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\helper\cancelable\VaroCancelAble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */