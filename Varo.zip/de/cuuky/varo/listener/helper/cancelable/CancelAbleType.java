/*   */ package de.cuuky.varo.listener.helper.cancelable;
/*   */ 
/*   */ public enum CancelAbleType
/*   */ {
/* 5 */   FREEZE,
/* 6 */   MUTE,
/* 7 */   PROTECTION;
/*   */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\helper\cancelable\CancelAbleType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */