/*    */ package de.cuuky.varo.listener.helper;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.logger.logger.ChatLogger;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrivateMessage
/*    */ {
/* 13 */   private static ArrayList<PrivateMessage> messages = new ArrayList<>();
/*    */   
/*    */   private String message;
/*    */   private Player reciever;
/*    */   private Player sender;
/*    */   private Date written;
/*    */   
/*    */   public PrivateMessage(Player reciever, Player sender, String message) {
/* 21 */     this.reciever = reciever;
/* 22 */     this.sender = sender;
/* 23 */     this.message = message;
/* 24 */     this.written = new Date();
/*    */     
/* 26 */     Main.getDataManager().getVaroLoggerManager().getChatLogger().println(ChatLogger.ChatLogType.PRIVATE_CHAT, String.valueOf(sender.getName()) + " >> " + reciever.getName() + ": " + message);
/*    */     
/* 28 */     messages.add(this);
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 32 */     return this.message;
/*    */   }
/*    */   
/*    */   public Player getReciever() {
/* 36 */     return this.reciever;
/*    */   }
/*    */   
/*    */   public Player getSender() {
/* 40 */     return this.sender;
/*    */   }
/*    */   
/*    */   public Date getWritten() {
/* 44 */     return this.written;
/*    */   }
/*    */   
/*    */   public static PrivateMessage getMessage(Player player) {
/* 48 */     for (PrivateMessage pmessage : messages) {
/* 49 */       if (pmessage.getReciever().equals(player)) {
/*    */         continue;
/*    */       }
/* 52 */       return pmessage;
/*    */     } 
/*    */     
/* 55 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\helper\PrivateMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */