/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class HealtLoseListener
/*    */   implements Listener {
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onHealthLose(final EntityDamageEvent event) {
/* 17 */     if (!(event.getEntity() instanceof Player)) {
/*    */       return;
/*    */     }
/* 20 */     if (event.isCancelled()) {
/*    */       return;
/*    */     }
/* 23 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 27 */             VaroPlayer vp = VaroPlayer.getPlayer((Player)event.getEntity());
/*    */             
/* 29 */             if (vp.getNametag() != null)
/* 30 */               VaroPlayer.getPlayer((Player)event.getEntity()).getNametag().heartsChanged(); 
/*    */           }
/* 32 */         },  1L);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\HealtLoseListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */