/*    */ package de.cuuky.varo.listener.saveable;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*    */ import org.bukkit.block.Chest;
/*    */ import org.bukkit.block.DoubleChest;
/*    */ import org.bukkit.block.Furnace;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.inventory.InventoryMoveItemEvent;
/*    */ 
/*    */ 
/*    */ public class InventoryMoveListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onInventoryMove(InventoryMoveItemEvent e) {
/* 18 */     if (!Main.getVaroGame().hasStarted()) {
/*    */       return;
/*    */     }
/* 21 */     if (!(e.getInitiator().getHolder() instanceof org.bukkit.block.Hopper)) {
/*    */       return;
/*    */     }
/* 24 */     if (!(e.getSource().getHolder() instanceof Chest) && !(e.getSource().getHolder() instanceof Furnace) && !(e.getSource().getHolder() instanceof DoubleChest)) {
/*    */       return;
/*    */     }
/* 27 */     if (e.getSource().getHolder() instanceof Chest) {
/* 28 */       Chest chest = (Chest)e.getSource().getHolder();
/* 29 */       if (VaroSaveable.getByLocation(chest.getLocation()) != null) {
/* 30 */         e.setCancelled(true);
/*    */         return;
/*    */       } 
/* 33 */     } else if (e.getSource().getHolder() instanceof DoubleChest) {
/* 34 */       DoubleChest dc = (DoubleChest)e.getSource().getHolder();
/* 35 */       Chest r = (Chest)dc.getRightSide();
/* 36 */       Chest l = (Chest)dc.getLeftSide();
/* 37 */       if (VaroSaveable.getByLocation(l.getLocation()) != null || VaroSaveable.getByLocation(r.getLocation()) != null) {
/* 38 */         e.setCancelled(true);
/*    */         return;
/*    */       } 
/*    */     } else {
/* 42 */       Furnace f = (Furnace)e.getSource().getHolder();
/* 43 */       if (VaroSaveable.getByLocation(f.getLocation()) != null) {
/* 44 */         e.setCancelled(true);
/*    */         return;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\saveable\InventoryMoveListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */