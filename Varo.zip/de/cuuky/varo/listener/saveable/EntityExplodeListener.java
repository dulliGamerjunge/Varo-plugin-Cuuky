/*    */ package de.cuuky.varo.listener.saveable;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.stats.stat.inventory.VaroSaveable;
/*    */ import java.util.Iterator;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityExplodeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityExplodeListener
/*    */   implements Listener
/*    */ {
/*    */   private boolean chestNearby(Location location) {
/* 20 */     for (int x = location.getBlockX() - 1; x <= location.getBlockX() + 1; x++) {
/* 21 */       for (int y = location.getBlockY() - 1; y <= location.getBlockY() + 1; y++) {
/* 22 */         for (int z = location.getBlockZ() - 1; z <= location.getBlockZ() + 1; z++) {
/* 23 */           Location loc = new Location(location.getWorld(), x, y, z);
/* 24 */           if (VaroSaveable.getByLocation(loc) != null)
/* 25 */             return true; 
/*    */         } 
/*    */       } 
/*    */     } 
/* 29 */     return false;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityExplode(EntityExplodeEvent event) {
/* 34 */     if (!Main.getVaroGame().hasStarted()) {
/* 35 */       event.setCancelled(true);
/*    */       
/*    */       return;
/*    */     } 
/* 39 */     Iterator<Block> iter = event.blockList().iterator();
/* 40 */     while (iter.hasNext()) {
/* 41 */       Block block = iter.next();
/* 42 */       if (block.getState() instanceof org.bukkit.block.Chest || block.getState() instanceof org.bukkit.block.Furnace) {
/* 43 */         if (VaroSaveable.getByLocation(block.getLocation()) != null)
/* 44 */           iter.remove();  continue;
/* 45 */       }  if (block.getState() instanceof org.bukkit.block.Sign && 
/* 46 */         chestNearby(block.getLocation()))
/* 47 */         iter.remove(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\saveable\EntityExplodeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */