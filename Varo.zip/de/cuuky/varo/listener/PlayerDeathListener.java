/*     */ package de.cuuky.varo.listener;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.combatlog.PlayerHit;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*     */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*     */ import de.cuuky.varo.listener.helper.cancelable.CancelAbleType;
/*     */ import de.cuuky.varo.listener.helper.cancelable.VaroCancelAble;
/*     */ import de.cuuky.varo.logger.logger.EventLogger;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class PlayerDeathListener
/*     */   implements Listener {
/*     */   private void checkHealth(Player killer) {
/*  27 */     int healthAdd = ConfigSetting.KILLER_ADD_HEALTH_ON_KILL.getValueAsInt();
/*  28 */     if (healthAdd > 0) {
/*  29 */       double hearts = VersionUtils.getHearts(killer) + healthAdd;
/*  30 */       if (hearts > 20.0D) {
/*  31 */         killer.setHealth(20.0D);
/*     */       } else {
/*  33 */         killer.setHealth(hearts);
/*  34 */       }  killer.sendMessage(String.valueOf(Main.getPrefix()) + "§7Du hast durch den Kill an §4" + (healthAdd / 2) + "§7 Herzen regeneriert bekommen!");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void kickDeadPlayer(final VaroPlayer deadPlayer, final VaroPlayer killerPlayer) {
/*  39 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  43 */             if (!deadPlayer.isOnline()) {
/*     */               return;
/*     */             }
/*  46 */             if (killerPlayer == null) {
/*  47 */               deadPlayer.getPlayer().kickPlayer(ConfigMessages.DEATH_KICK_DEAD.getValue(deadPlayer));
/*     */             } else {
/*  49 */               deadPlayer.getPlayer().kickPlayer(ConfigMessages.DEATH_KICK_KILLED.getValue(deadPlayer).replace("%killer%", killerPlayer.getName()));
/*     */             }  }
/*  51 */         }1L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDeath(PlayerDeathEvent event) {
/*  56 */     Player deadPlayer = event.getEntity();
/*  57 */     Player killerPlayer = event.getEntity().getKiller();
/*  58 */     final VaroPlayer deadP = VaroPlayer.getPlayer(deadPlayer);
/*  59 */     final VaroPlayer killer = (killerPlayer == null) ? null : VaroPlayer.getPlayer(killerPlayer);
/*  60 */     event.setDeathMessage(null);
/*     */     
/*  62 */     if (Main.getVaroGame().hasStarted()) {
/*  63 */       PlayerHit hit = PlayerHit.getHit(deadPlayer);
/*  64 */       if (hit != null) {
/*  65 */         hit.over();
/*     */       }
/*  67 */       deadPlayer.getWorld().strikeLightningEffect(deadPlayer.getLocation());
/*  68 */       for (ItemStack stack : Main.getDataManager().getListManager().getDeathItems().getItems()) {
/*  69 */         if (stack.getType() != Material.AIR)
/*  70 */           deadPlayer.getWorld().dropItemNaturally(deadPlayer.getLocation(), stack); 
/*     */       } 
/*  72 */       for (int i = 0; i < 3; i++) {
/*  73 */         deadPlayer.getWorld().playEffect(deadPlayer.getLocation(), Effect.MOBSPAWNER_FLAMES, 1);
/*     */       }
/*  75 */       if (deadP.getTeam() == null || deadP.getTeam().getLifes() <= 1.0D) {
/*  76 */         if (killerPlayer == null) {
/*  77 */           Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.DEATH, ConfigMessages.ALERT_DISCORD_DEATH.getValue(deadP).replace("%death%", deadPlayer.getName()).replace("%reason%", deadPlayer.getLastDamageCause().getCause().toString()));
/*  78 */           Bukkit.broadcastMessage(ConfigMessages.DEATH_DEAD.getValue(deadP).replace("%death%", deadPlayer.getName()).replace("%reason%", deadPlayer.getLastDamageCause().getCause().toString()));
/*     */         } else {
/*  80 */           PlayerHit hit1 = PlayerHit.getHit(killerPlayer);
/*  81 */           if (hit1 != null) {
/*  82 */             hit1.over();
/*     */           }
/*  84 */           if (killer.getTeam() != null && ConfigSetting.ADD_TEAM_LIFE_ON_KILL.isIntActivated()) {
/*     */             try {
/*  86 */               killer.getTeam().setLifes(killer.getTeam().getLifes() + ConfigSetting.ADD_TEAM_LIFE_ON_KILL.getValueAsDouble());
/*  87 */             } catch (Exception e) {
/*  88 */               killer.getTeam().setLifes(killer.getTeam().getLifes() + ConfigSetting.ADD_TEAM_LIFE_ON_KILL.getValueAsInt());
/*     */             } 
/*  90 */             killer.sendMessage(ConfigMessages.DEATH_KILL_LIFE_ADD.getValue());
/*     */           } 
/*     */           
/*  93 */           Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.KILL, ConfigMessages.ALERT_DISCORD_KILL.getValue(deadP).replace("%death%", deadPlayer.getName()).replace("%killer%", killerPlayer.getName()));
/*  94 */           Bukkit.broadcastMessage(ConfigMessages.DEATH_KILLED_BY.getValue(deadP).replace("%death%", deadPlayer.getName()).replace("%killer%", killerPlayer.getName()));
/*     */           
/*  96 */           killer.onEvent(BukkitEventType.KILL);
/*  97 */           checkHealth(killerPlayer);
/*     */         } 
/*     */         
/* 100 */         deadP.onEvent(BukkitEventType.KILLED);
/*     */         
/* 102 */         if (!ConfigSetting.PLAYER_SPECTATE_AFTER_DEATH.getValueAsBoolean())
/* 103 */         { if (ConfigSetting.KICK_DELAY_AFTER_DEATH.isIntActivated()) {
/* 104 */             Bukkit.broadcastMessage(ConfigMessages.QUIT_KICK_IN_SECONDS.getValue(deadP).replace("%countdown%", String.valueOf(ConfigSetting.KICK_DELAY_AFTER_DEATH.getValueAsInt())));
/* 105 */             deadP.getStats().setState(PlayerState.SPECTATOR);
/* 106 */             deadP.setSpectacting();
/* 107 */             Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*     */                 {
/*     */                   public void run()
/*     */                   {
/* 111 */                     deadP.getStats().setState(PlayerState.DEAD);
/* 112 */                     PlayerDeathListener.this.kickDeadPlayer(deadP, killer);
/* 113 */                     Bukkit.broadcastMessage(ConfigMessages.QUIT_KICK_DELAY_OVER.getValue(deadP));
/*     */                   }
/* 115 */                 }(ConfigSetting.KICK_DELAY_AFTER_DEATH.getValueAsInt() * 20));
/*     */           } else {
/* 117 */             kickDeadPlayer(deadP, killer);
/*     */           }  }
/* 119 */         else { deadP.setSpectacting();
/* 120 */           deadP.getStats().setState(PlayerState.SPECTATOR);
/* 121 */           deadP.update(); }
/*     */       
/*     */       } else {
/* 124 */         if (ConfigSetting.RESPAWN_PROTECTION.isIntActivated()) {
/* 125 */           VaroCancelAble prot = new VaroCancelAble(CancelAbleType.PROTECTION, deadP, ConfigSetting.RESPAWN_PROTECTION.getValueAsInt());
/* 126 */           Bukkit.broadcastMessage(ConfigMessages.DEATH_RESPAWN_PROTECTION.getValue(deadP).replace("%seconds%", String.valueOf(ConfigSetting.RESPAWN_PROTECTION.getValueAsInt())));
/* 127 */           prot.setTimerHook(new Runnable()
/*     */               {
/*     */                 public void run()
/*     */                 {
/* 131 */                   Bukkit.broadcastMessage(ConfigMessages.DEATH_RESPAWN_PROTECTION_OVER.getValue(deadP));
/*     */                 }
/*     */               });
/*     */         } 
/*     */         
/* 136 */         deadP.getTeam().setLifes(deadP.getTeam().getLifes() - 1.0D);
/* 137 */         Bukkit.broadcastMessage(ConfigMessages.DEATH_LIFE_LOST.getValue(deadP));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\PlayerDeathListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */