/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerAchievementAwardedEvent;
/*    */ 
/*    */ public class PlayerAchievementListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void on(PlayerAchievementAwardedEvent event) {
/* 12 */     event.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\PlayerAchievementListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */