/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.combatlog.CombatlogCheck;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import de.cuuky.varo.entity.player.disconnect.VaroPlayerDisconnect;
/*    */ import de.cuuky.varo.entity.player.event.BukkitEventType;
/*    */ import de.cuuky.varo.entity.player.stats.stat.PlayerState;
/*    */ import de.cuuky.varo.game.state.GameState;
/*    */ import de.cuuky.varo.logger.logger.EventLogger;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ public class PlayerQuitListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onPlayerQuit(PlayerQuitEvent event) {
/* 24 */     Player player = event.getPlayer();
/* 25 */     VaroPlayer vplayer = VaroPlayer.getPlayer(player);
/* 26 */     event.setQuitMessage(null);
/*    */ 
/*    */     
/* 29 */     if (vplayer.getStats().isSpectator() || vplayer.isAdminIgnore()) {
/* 30 */       event.setQuitMessage(ConfigMessages.QUIT_SPECTATOR.getValue(vplayer));
/* 31 */       vplayer.onEvent(BukkitEventType.QUIT);
/*    */       
/*    */       return;
/*    */     } 
/* 35 */     if (Main.getVaroGame().getGameState() == GameState.STARTED) {
/*    */       
/* 37 */       if (ConfigSetting.PLAY_TIME.isIntActivated() && (
/* 38 */         vplayer.getStats().getState() == PlayerState.DEAD || !vplayer.getStats().hasTimeLeft())) {
/* 39 */         vplayer.onEvent(BukkitEventType.QUIT);
/* 40 */         if (vplayer.getStats().getState() != PlayerState.DEAD) {
/* 41 */           Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_KICKED_PLAYER.getValue(vplayer));
/*    */         }
/*    */         
/*    */         return;
/*    */       } 
/* 46 */       CombatlogCheck check = new CombatlogCheck(event);
/* 47 */       if (check.isCombatLog()) {
/* 48 */         vplayer.onEvent(BukkitEventType.QUIT);
/*    */         
/*    */         return;
/*    */       } 
/*    */       
/* 53 */       if (vplayer.getStats().hasTimeLeft()) {
/* 54 */         if (ConfigSetting.DISCONNECT_PER_SESSION.isIntActivated()) {
/* 55 */           VaroPlayerDisconnect dc = VaroPlayerDisconnect.getDisconnect(player);
/* 56 */           if (dc == null)
/* 57 */             dc = new VaroPlayerDisconnect(player); 
/* 58 */           dc.addDisconnect();
/*    */           
/* 60 */           if (dc.check()) {
/* 61 */             vplayer.onEvent(BukkitEventType.QUIT);
/*    */             
/*    */             return;
/*    */           } 
/*    */         } 
/* 66 */         VaroPlayerDisconnect.disconnected(vplayer.getName());
/* 67 */         Bukkit.broadcastMessage(ConfigMessages.QUIT_WITH_REMAINING_TIME.getValue(vplayer));
/* 68 */         Main.getDataManager().getVaroLoggerManager().getEventLogger().println(EventLogger.LogType.JOIN_LEAVE, ConfigMessages.ALERT_PLAYER_DC_TO_EARLY.getValue(vplayer));
/* 69 */         vplayer.onEvent(BukkitEventType.QUIT);
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 74 */     vplayer.onEvent(BukkitEventType.QUIT);
/* 75 */     event.setQuitMessage(ConfigMessages.QUIT_MESSAGE.getValue(vplayer));
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\PlayerQuitListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */