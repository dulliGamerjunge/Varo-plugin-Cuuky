/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerRespawnEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class PlayerRespawnListener
/*    */   implements Listener {
/*    */   @EventHandler
/*    */   public void onPlayerRespawn(final PlayerRespawnEvent event) {
/* 15 */     Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 19 */             VaroPlayer.getPlayer(event.getPlayer()).setNormalAttackSpeed();
/*    */           }
/* 21 */         },  20L);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\PlayerRespawnListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */