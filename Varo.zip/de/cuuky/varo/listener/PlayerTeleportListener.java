/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerTeleportEvent;
/*    */ 
/*    */ public class PlayerTeleportListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onTeleport(PlayerTeleportEvent event) {
/* 15 */     if (event.getCause().equals(PlayerTeleportEvent.TeleportCause.NETHER_PORTAL) && 
/* 16 */       event.getFrom().getWorld().getEnvironment() == World.Environment.NORMAL && event.getTo().getWorld().getEnvironment() == World.Environment.NETHER && 
/* 17 */       event.getFrom().distance(event.getFrom().getWorld().getSpawnLocation()) < 500.0D) {
/* 18 */       event.getTo().getWorld().setSpawnLocation(event.getTo().getBlockX(), event.getTo().getBlockY(), event.getTo().getBlockZ());
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 23 */     VaroPlayer vp = VaroPlayer.getPlayer(event.getPlayer());
/* 24 */     if ((!vp.getStats().isSpectator() && !vp.isAdminIgnore()) || event.getPlayer().isOp()) {
/*    */       return;
/*    */     }
/* 27 */     if (event.getTo().getY() >= ConfigSetting.MINIMAL_SPECTATOR_HEIGHT.getValueAsInt()) {
/*    */       return;
/*    */     }
/* 30 */     event.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\PlayerTeleportListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */