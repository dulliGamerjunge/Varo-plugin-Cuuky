/*     */ package de.cuuky.varo.listener;
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.bot.discord.VaroDiscordBot;
/*     */ import de.cuuky.varo.bot.discord.register.BotRegister;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.stats.KickResult;
/*     */ import java.util.Date;
/*     */ import net.dv8tion.jda.api.entities.User;
/*     */ import org.bukkit.BanEntry;
/*     */ import org.bukkit.BanList;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerLoginEvent;
/*     */ 
/*     */ public class PlayerLoginListener implements Listener {
/*     */   @EventHandler
/*     */   public void onPlayerLogin(PlayerLoginEvent event) {
/*     */     Date current;
/*     */     long milli, sec, min, hr;
/*     */     String seconds;
/*     */     long l1;
/*     */     String minutes;
/*     */     long l2;
/*     */     String hours;
/*     */     long l3;
/*  28 */     Player player = event.getPlayer();
/*  29 */     VaroPlayer vp = (VaroPlayer.getPlayer(player) == null) ? new VaroPlayer(player) : VaroPlayer.getPlayer(player);
/*     */     
/*  31 */     VaroDiscordBot discordBot = Main.getBotLauncher().getDiscordbot();
/*  32 */     if (ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean() && discordBot != null && discordBot.getJda() != null) {
/*  33 */       BotRegister reg = BotRegister.getRegister(event.getPlayer().getUniqueId().toString());
/*  34 */       if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM_OPTIONAL.getValueAsBoolean()) {
/*  35 */         if (reg == null) {
/*  36 */           reg = new BotRegister(event.getPlayer().getUniqueId().toString(), true);
/*  37 */           reg.setPlayerName(event.getPlayer().getName());
/*  38 */           event.disallow(PlayerLoginEvent.Result.KICK_OTHER, reg.getKickMessage()); return;
/*     */         } 
/*  40 */         if (reg.isBypass()) {
/*  41 */           event.allow();
/*  42 */         } else if (!reg.isActive()) {
/*  43 */           event.disallow(PlayerLoginEvent.Result.KICK_OTHER, reg.getKickMessage());
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*  48 */       if (reg != null) {
/*  49 */         reg.setPlayerName(event.getPlayer().getName());
/*     */         try {
/*  51 */           User user = discordBot.getJda().getUserById(reg.getUserId());
/*  52 */           if (user == null || !discordBot.getMainGuild().isMember(user)) {
/*  53 */             if (!ConfigSetting.DISCORDBOT_VERIFYSYSTEM_OPTIONAL.getValueAsBoolean()) {
/*  54 */               event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.BOTS_DISCORD_NO_SERVER_USER.getValue());
/*  55 */               vp.setPlayer(null);
/*     */               return;
/*     */             } 
/*  58 */             reg.delete();
/*     */           } 
/*  60 */         } catch (Exception e2) {
/*  61 */           System.err.println("[Varo] Es wurde keine Server ID angegeben oder die ID des Spielers ist falsch!");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  66 */     if (VaroUtils.check(vp, event))
/*     */       return; 
/*  68 */     KickResult kickResult = vp.getStats().getKickResult(player);
/*  69 */     switch (kickResult) {
/*     */       case NO_PROJECTUSER:
/*  71 */         event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.JOIN_KICK_NOT_USER_OF_PROJECT.getValue(vp));
/*     */         return;
/*     */       case BANNED:
/*  74 */         for (BanEntry entry : Bukkit.getBanList(BanList.Type.NAME).getBanEntries()) {
/*  75 */           if (entry.getTarget().equals(player.getName())) {
/*  76 */             event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.JOIN_KICK_BANNED.getValue(vp).replace("%reason%", entry.getReason()));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         return;
/*     */       case DEAD:
/*  82 */         event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.DEATH_KICK_DEAD.getValue());
/*     */         return;
/*     */       case STRIKE_BAN:
/*  85 */         event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.JOIN_KICK_STRIKE_BAN.getValue(vp).replace("%hours%", String.valueOf(ConfigSetting.STRIKE_BAN_AFTER_STRIKE_HOURS.getValueAsInt())));
/*     */         return;
/*     */       case NOT_IN_TIME:
/*  88 */         event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.SERVER_MODT_CANT_JOIN_HOURS.getValue().replace("%minHour%", String.valueOf(ConfigSetting.ONLY_JOIN_BETWEEN_HOURS_HOUR1.getValueAsInt())).replace("%maxHour%", String.valueOf(ConfigSetting.ONLY_JOIN_BETWEEN_HOURS_HOUR2.getValueAsInt())));
/*     */         return;
/*     */       case SERVER_FULL:
/*  91 */         event.disallow(PlayerLoginEvent.Result.KICK_FULL, ConfigMessages.JOIN_KICK_SERVER_FULL.getValue(vp));
/*     */         return;
/*     */       case NO_SESSIONS_LEFT:
/*  94 */         event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.JOIN_KICK_NO_SESSIONS_LEFT.getValue(vp));
/*     */         return;
/*     */       case NO_PREPRODUCES_LEFT:
/*  97 */         event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.JOIN_KICK_NO_PREPRODUCES_LEFT.getValue());
/*     */         return;
/*     */       case NO_TIME:
/* 100 */         current = new Date();
/* 101 */         milli = vp.getStats().getTimeUntilAddSession().getTime() - current.getTime();
/* 102 */         sec = milli / 1000L % 60L;
/* 103 */         min = milli / 1000L / 60L % 60L;
/* 104 */         hr = milli / 1000L / 60L / 60L % 24L;
/* 105 */         seconds = "";
/* 106 */         minutes = "";
/* 107 */         hours = "";
/* 108 */         if (String.valueOf(sec).length() == 1) {
/* 109 */           seconds = "0" + sec;
/*     */         } else {
/* 111 */           l1 = sec;
/* 112 */         }  if (String.valueOf(min).length() == 1) {
/* 113 */           minutes = "0" + min;
/*     */         } else {
/* 115 */           l2 = min;
/* 116 */         }  if (String.valueOf(hr).length() == 1) {
/* 117 */           hours = "0" + hr;
/*     */         } else {
/* 119 */           l3 = hr;
/*     */         } 
/* 121 */         event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.JOIN_KICK_NO_TIME_LEFT.getValue().replace("%timeHours%", String.valueOf(ConfigSetting.JOIN_AFTER_HOURS.getValueAsInt())).replace("%stunden%", l3).replace("%minuten%", l2).replace("%sekunden%", l1));
/*     */         return;
/*     */       case SERVER_NOT_PUBLISHED:
/* 124 */         event.disallow(PlayerLoginEvent.Result.KICK_OTHER, ConfigMessages.JOIN_KICK_NOT_STARTED.getValue(vp));
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 129 */     event.allow();
/* 130 */     if (!vp.isRegistered())
/* 131 */       vp.register(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\PlayerLoginListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */