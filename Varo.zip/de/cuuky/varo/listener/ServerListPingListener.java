/*    */ package de.cuuky.varo.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessages;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.server.ServerListPingEvent;
/*    */ 
/*    */ public class ServerListPingListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onServerListPing(ServerListPingEvent event) {
/* 16 */     int slots = ConfigSetting.FAKE_MAX_SLOTS.getValueAsInt();
/* 17 */     if (slots != -1) {
/* 18 */       event.setMaxPlayers(slots);
/*    */     }
/* 20 */     if (ConfigSetting.CHANGE_MOTD.getValueAsBoolean()) {
/* 21 */       if (!Main.getVaroGame().hasStarted()) {
/* 22 */         if (Bukkit.getServer().hasWhitelist()) {
/* 23 */           event.setMotd(ConfigMessages.SERVER_MODT_NOT_OPENED.getValue());
/*    */         } else {
/* 25 */           event.setMotd(ConfigMessages.SERVER_MODT_OPEN.getValue());
/*    */         } 
/*    */         return;
/*    */       } 
/* 29 */       if (!ConfigSetting.ONLY_JOIN_BETWEEN_HOURS.getValueAsBoolean() || Main.getDataManager().getOutsideTimeChecker().canJoin() || !Main.getVaroGame().hasStarted()) {
/* 30 */         event.setMotd(ConfigMessages.SERVER_MODT_OPEN.getValue());
/*    */         
/*    */         return;
/*    */       } 
/* 34 */       if (!Main.getDataManager().getOutsideTimeChecker().canJoin())
/* 35 */         event.setMotd(ConfigMessages.SERVER_MODT_CANT_JOIN_HOURS.getValue().replace("%minHour%", String.valueOf(ConfigSetting.ONLY_JOIN_BETWEEN_HOURS_HOUR1.getValueAsInt())).replace("%maxHour%", String.valueOf(ConfigSetting.ONLY_JOIN_BETWEEN_HOURS_HOUR2.getValueAsInt()))); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\listener\ServerListPingListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */