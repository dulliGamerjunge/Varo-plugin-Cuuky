/*     */ package de.cuuky.varo.recovery;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ 
/*     */ public class FileZipper
/*     */ {
/*     */   private static final int BUFFER_SIZE = 4096;
/*     */   protected File zipFile;
/*     */   
/*     */   public FileZipper(File zipFile) {
/*  23 */     this.zipFile = zipFile;
/*     */   }
/*     */   
/*     */   private void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
/*  27 */     File oldFile = new File(filePath);
/*  28 */     if (oldFile.exists()) {
/*  29 */       oldFile.delete();
/*     */     }
/*  31 */     BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
/*  32 */     byte[] bytesIn = new byte[4096];
/*  33 */     int read = 0;
/*  34 */     while ((read = zipIn.read(bytesIn)) != -1) {
/*  35 */       bos.write(bytesIn, 0, read);
/*     */     }
/*  37 */     bos.close();
/*     */   }
/*     */   
/*     */   public void zip(ArrayList<File> files, Path rootFrom) {
/*     */     try {
/*  42 */       File file1 = new File(this.zipFile.getParent());
/*  43 */       if (!file1.isDirectory())
/*  44 */         file1.mkdirs(); 
/*  45 */       if (!this.zipFile.exists())
/*  46 */         this.zipFile.createNewFile(); 
/*  47 */     } catch (IOException e1) {
/*  48 */       e1.printStackTrace();
/*     */     } 
/*     */     
/*  51 */     String zipFileName = this.zipFile.getPath();
/*     */     try {
/*  53 */       ZipOutputStream outputStream = new ZipOutputStream(new FileOutputStream(zipFileName));
/*     */       
/*  55 */       for (File toZip : files) {
/*  56 */         if (toZip.getName().endsWith(".zip")) {
/*     */           continue;
/*     */         }
/*     */         try {
/*  60 */           Path orgPath = Paths.get(toZip.getPath(), new String[0]);
/*  61 */           Path zipFilePath = rootFrom.relativize(orgPath);
/*     */           
/*  63 */           outputStream.putNextEntry(new ZipEntry(zipFilePath.toString()));
/*  64 */           byte[] buffer = Files.readAllBytes(orgPath);
/*  65 */           outputStream.write(buffer, 0, buffer.length);
/*  66 */           outputStream.closeEntry();
/*  67 */         } catch (Exception e) {
/*  68 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */       
/*  72 */       outputStream.close();
/*  73 */     } catch (IOException e) {
/*  74 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean unzip(String destDirectory) {
/*     */     try {
/*  80 */       File destDir = new File(destDirectory);
/*  81 */       if (!destDir.exists())
/*  82 */         destDir.mkdir(); 
/*  83 */       ZipInputStream zipIn = new ZipInputStream(new FileInputStream(this.zipFile));
/*  84 */       ZipEntry entry = zipIn.getNextEntry();
/*  85 */       while (entry != null) {
/*  86 */         String filePath = String.valueOf(destDirectory) + File.separator + entry.getName();
/*  87 */         if (!entry.isDirectory()) {
/*  88 */           extractFile(zipIn, filePath);
/*     */         } else {
/*  90 */           File dir = new File(filePath);
/*  91 */           dir.mkdir();
/*     */         } 
/*  93 */         zipIn.closeEntry();
/*  94 */         entry = zipIn.getNextEntry();
/*     */       } 
/*  96 */       zipIn.close();
/*  97 */       return true;
/*  98 */     } catch (Exception e) {
/*  99 */       e.printStackTrace();
/* 100 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public File getZipFile() {
/* 105 */     return this.zipFile;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\recovery\FileZipper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */