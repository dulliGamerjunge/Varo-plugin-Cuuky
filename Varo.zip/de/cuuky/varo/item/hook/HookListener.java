/*    */ package de.cuuky.varo.item.hook;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.player.PlayerDropItemEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*    */ 
/*    */ public class HookListener
/*    */   implements Listener {
/*    */   @EventHandler
/*    */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 17 */     if (event.getItem() == null) {
/*    */       return;
/*    */     }
/* 20 */     ItemHook hook = ItemHook.getItemHook(event.getItem(), event.getPlayer());
/* 21 */     if (hook == null) {
/*    */       return;
/*    */     }
/* 24 */     hook.getHookListener().onInteract(event);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
/* 29 */     if (event.getPlayer().getItemInHand() == null || event.getRightClicked() == null) {
/*    */       return;
/*    */     }
/* 32 */     ItemHook hook = ItemHook.getItemHook(event.getPlayer().getItemInHand(), event.getPlayer());
/* 33 */     if (hook == null) {
/*    */       return;
/*    */     }
/* 36 */     hook.getHookListener().onInteractEntity(event);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerDamageEntity(EntityDamageByEntityEvent event) {
/* 41 */     if (!(event.getEntity() instanceof Player) || !(event.getDamager() instanceof Player) || ((Player)event.getDamager()).getItemInHand() == null) {
/*    */       return;
/*    */     }
/* 44 */     Player damager = (Player)event.getDamager();
/* 45 */     ItemHook hook = ItemHook.getItemHook(damager.getItemInHand(), damager);
/* 46 */     if (hook == null) {
/*    */       return;
/*    */     }
/* 49 */     hook.getHookListener().onEntityHit(event);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onItemMove(InventoryClickEvent event) {
/* 54 */     ItemHook hook = ItemHook.getItemHook(event.getCurrentItem(), (Player)event.getWhoClicked());
/* 55 */     if (hook != null && !hook.isDragable())
/* 56 */       event.setCancelled(true); 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onItemDrop(PlayerDropItemEvent event) {
/* 61 */     ItemHook hook = ItemHook.getItemHook(event.getItemDrop().getItemStack(), event.getPlayer());
/* 62 */     if (hook != null && !hook.isDropable())
/* 63 */       event.setCancelled(true); 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onItemPick(PlayerPickupItemEvent event) {
/* 68 */     ItemHook hook = ItemHook.getItemHook(event.getItem().getItemStack(), event.getPlayer());
/* 69 */     if (hook != null && !hook.isDropable())
/* 70 */       event.setCancelled(true); 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\item\hook\HookListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */