package de.cuuky.varo.item.hook;

import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public interface ItemHookListener {
  void onEntityHit(EntityDamageByEntityEvent paramEntityDamageByEntityEvent);
  
  void onInteract(PlayerInteractEvent paramPlayerInteractEvent);
  
  void onInteractEntity(PlayerInteractEntityEvent paramPlayerInteractEntityEvent);
}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\item\hook\ItemHookListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */