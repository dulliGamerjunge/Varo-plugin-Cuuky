/*    */ package de.cuuky.varo.mysql;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ 
/*    */ 
/*    */ public class MySQLClient
/*    */ {
/*    */   private boolean connected;
/*    */   private Connection connection;
/*    */   private String host;
/*    */   
/*    */   public MySQLClient() {
/* 19 */     if (!ConfigSetting.DISCORDBOT_USE_VERIFYSTSTEM_MYSQL.getValueAsBoolean()) {
/*    */       return;
/*    */     }
/* 22 */     this.host = ConfigSetting.DISCORDBOT_VERIFY_HOST.getValueAsString();
/* 23 */     this.database = ConfigSetting.DISCORDBOT_VERIFY_DATABASE.getValueAsString();
/* 24 */     this.user = ConfigSetting.DISCORDBOT_VERIFY_USER.getValueAsString();
/* 25 */     this.password = ConfigSetting.DISCORDBOT_VERIFY_PASSWORD.getValueAsString();
/* 26 */     this.connected = false;
/*    */     
/* 28 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Connecting to MySQL...");
/* 29 */     connect();
/*    */     
/* 31 */     if (this.connected)
/* 32 */       update("CREATE TABLE IF NOT EXISTS verify(uuid VARCHAR(255) NOT NULL, userid long, code int, bypass boolean, name VARCHAR(255) NOT NULL);"); 
/*    */   }
/*    */   private String database; private String user; private String password;
/*    */   public void close() {
/* 36 */     if (this.connection == null) {
/*    */       return;
/*    */     }
/*    */     try {
/* 40 */       this.connection.close();
/* 41 */     } catch (SQLException sQLException) {}
/*    */     
/* 43 */     this.connected = false;
/*    */   }
/*    */   
/*    */   public void connect() {
/*    */     try {
/* 48 */       this.connection = DriverManager.getConnection("jdbc:mysql://" + this.host + ":3306/" + this.database + "?autoReconnect=true", this.user, this.password);
/* 49 */       this.connected = true;
/* 50 */     } catch (SQLException e) {
/* 51 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "MYSQL USERNAME, IP ODER PASSWORT FALSCH! -> Disabled");
/*    */       return;
/*    */     } 
/*    */   }
/*    */   
/*    */   public ResultSet getQuery(String qry) {
/* 57 */     ResultSet rs = null;
/*    */     
/*    */     try {
/* 60 */       Statement st = this.connection.createStatement();
/* 61 */       rs = st.executeQuery(qry);
/* 62 */     } catch (SQLException e) {
/* 63 */       e.printStackTrace();
/* 64 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Connection to MySQL-Database lost!");
/* 65 */       connect();
/*    */     } 
/*    */     
/* 68 */     return rs;
/*    */   }
/*    */   
/*    */   public void update(String qry) {
/*    */     try {
/* 73 */       Statement st = this.connection.createStatement();
/* 74 */       st.executeUpdate(qry);
/* 75 */       st.close();
/* 76 */     } catch (SQLException e) {
/* 77 */       e.printStackTrace();
/* 78 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Connection to MySQL-Database lost!");
/* 79 */       connect();
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isConnected() {
/* 84 */     return this.connected;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\mysql\MySQLClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */