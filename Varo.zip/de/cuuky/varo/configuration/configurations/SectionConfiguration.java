package de.cuuky.varo.configuration.configurations;

import java.util.ArrayList;

public interface SectionConfiguration {
  String getName();
  
  String getDescription();
  
  ArrayList<SectionEntry> getEntries();
}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\configuration\configurations\SectionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */