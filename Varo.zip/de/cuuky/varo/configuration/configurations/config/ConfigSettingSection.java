/*    */ package de.cuuky.varo.configuration.configurations.config;
/*    */ 
/*    */ import de.cuuky.varo.configuration.configurations.SectionConfiguration;
/*    */ import de.cuuky.varo.configuration.configurations.SectionEntry;
/*    */ import de.cuuky.varo.version.types.Materials;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Material;
/*    */ 
/*    */ 
/*    */ public enum ConfigSettingSection
/*    */   implements SectionConfiguration
/*    */ {
/* 13 */   ACTIVITY("Activity", Material.FURNACE, "Hier kannst du Einstellungen zur Aktivitaet eines Spielers vornehmen."),
/* 14 */   AUTOSETUP("Autosetup", Materials.CLOCK.parseMaterial(), "Hier kannst das Autosetup einstellen!"),
/* 15 */   BACKPACKS("Backpacks", Material.CHEST, "Alle Einstellungen zur Rucksaecken"),
/* 16 */   BORDER("Border", Materials.DISPENSER.parseMaterial(), "Hier kannst du Einstellungen zur Border vornehmen."),
/* 17 */   CHAT("Chat", Materials.WRITABLE_BOOK.parseMaterial(), "Hier kannst du Einstellungen zum Chat vornehmen"),
/* 18 */   COMBATLOG("Combatlog", Material.DIAMOND_SWORD, "Hier kannst du einstellen, was passiert,\nwenn ein Spieler sich waehrend des Kampfes ausloggt."),
/* 19 */   DEATH("Death", Materials.SKELETON_SKULL.parseMaterial(), "Hier kannst du Einstellungen zum Tod eines Spielers vornehmen."),
/* 20 */   DISCONNECT("Disconnect", Material.COAL, "Hier kannst du einstellen, was passiert,\nwenn ein Spieler zu frueh disconnected."),
/* 21 */   DISCORD("Discord", Material.DISPENSER, "Hier kannst du Einstellungen zum DiscordBot vornehmen."),
/* 22 */   FINALE("Finale", Materials.END_PORTAL_FRAME.parseMaterial(), "Hier kannst du Einstellungen zum Finale des Projektes vornehmen."),
/* 23 */   GUI("Gui", Materials.COMPASS.parseMaterial(), "Hier kannst du Einstellungen zur Gui vornehmen."),
/* 24 */   JOIN_SYSTEMS("JoinSystems", Materials.RED_BED.parseMaterial(), "Hier kannst du einstellen, wann und wie oft Spieler joinen duerfen."),
/* 25 */   MAIN("Main", Material.LEVER, "Hier kannst du alle Haupteinstellungen vornehmen."),
/* 26 */   OFFLINEVILLAGER("OfflineVillager", Materials.EMERALD.parseMaterial(), "Einstellungen zu den OfflineVillagern"),
/* 27 */   OTHER("Other", Material.REDSTONE, "Hier findest du alle restlichen Einstellungen."),
/* 28 */   PROTECTIONS("Protections", Material.DIAMOND_CHESTPLATE, "Hier kannst du alle Einstellungen zu Schutzzeiten vornehmen."),
/* 29 */   REPORT("Report", Materials.REDSTONE_TORCH.parseMaterial(), "Hier kannst du Einstellungen zum Report-System vornehmen."),
/* 30 */   SERVER_LIST("Serverlist", Materials.SIGN.parseMaterial(), "Hier kannst du die Anzeige des Servers in der Serverliste konfigurieren."),
/* 31 */   START("Start", Material.ACTIVATOR_RAIL, "Hier kannst du Einstellungen zum Start deines Plugins vornehmen."),
/* 32 */   STRIKE("Strike", Materials.PAPER.parseMaterial(), "Hier kannst du Einstellungen zu den Strikes vornehmen."),
/* 33 */   TEAMS("Teams", Material.BOOK, "Hier kannst du Einstellungen zu Teams vornehmen."),
/* 34 */   TELEGRAM("Telegram", Materials.MAP.parseMaterial(), "Alle Einstellungen zum Telegram-Bot."),
/* 35 */   WORLD("World", Material.GRASS, "Hier kannst du Einstellungen zur Welt vornehmen."),
/* 36 */   YOUTUBE("YouTube", Material.MAP, "Hier kannst du Einstellungen zu den Videos deines Projektes vornehmen.");
/*    */   private String name;
/*    */   private String description;
/*    */   private Material material;
/*    */   
/*    */   ConfigSettingSection(String name, Material material, String description) {
/* 42 */     this.name = name;
/* 43 */     this.material = material;
/* 44 */     this.description = description;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 49 */     return this.description;
/*    */   }
/*    */   
/*    */   public Material getMaterial() {
/* 53 */     return this.material;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 58 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public ArrayList<SectionEntry> getEntries() {
/* 63 */     ArrayList<SectionEntry> temp = new ArrayList<>(); byte b; int i; ConfigSetting[] arrayOfConfigSetting;
/* 64 */     for (i = (arrayOfConfigSetting = ConfigSetting.values()).length, b = 0; b < i; ) { ConfigSetting entry = arrayOfConfigSetting[b];
/* 65 */       if (entry.getSection().equals(this))
/*    */       {
/*    */         
/* 68 */         temp.add(entry); } 
/*    */       b++; }
/*    */     
/* 71 */     return temp;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\configuration\configurations\config\ConfigSettingSection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */