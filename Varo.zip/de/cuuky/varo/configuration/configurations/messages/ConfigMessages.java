/*     */ package de.cuuky.varo.configuration.configurations.messages;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.SectionConfiguration;
/*     */ import de.cuuky.varo.configuration.configurations.SectionEntry;
/*     */ import de.cuuky.varo.configuration.placeholder.placeholder.GeneralMessagePlaceholder;
/*     */ import de.cuuky.varo.configuration.placeholder.placeholder.PlayerMessagePlaceholder;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.team.VaroTeam;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public enum ConfigMessages
/*     */   implements SectionEntry {
/*  15 */   ALERT_AUTOSTART_AT(
/*     */     
/*  17 */     ConfigMessageSection.ALERTS, "BOTS_ALERT.autostartAt", "%projectname% wird am %date% starten!"),
/*  18 */   ALERT_BORDER_CHANGED(ConfigMessageSection.ALERTS, "BOTS_ALERT.borderChanged", "Die Border wurde auf %size% gesetzt!"),
/*  19 */   ALERT_BORDER_DECREASED_DEATH(ConfigMessageSection.ALERTS, "BOTS_ALERT.borderDecrease.death", "Die Border wurde um %size% aufgrund eines Todes verringert!"),
/*  20 */   ALERT_BORDER_DECREASED_TIME_DAYS(ConfigMessageSection.ALERTS, "BOTS_ALERT.borderDecrease.days", "Die Border wurde um %size% verkleinert. Naechste Verkleinerung in %days% Tagen!"),
/*  21 */   ALERT_BORDER_DECREASED_TIME_MINUTE(ConfigMessageSection.ALERTS, "BOTS_ALERT.borderDecrease.minutes", "Die Border wurde um %size% verringert! Naechste Verkleinerung in %minutes% Minuten!"),
/*  22 */   ALERT_COMBAT_LOG(ConfigMessageSection.ALERTS, "BOTS_ALERT.combatlog", "%player% hat sich im Kampf ausgeloggt!"),
/*  23 */   ALERT_COMBAT_LOG_STRIKE(ConfigMessageSection.ALERTS, "BOTS_ALERT.combatlogStrike", "%player% hat sich im Kampf ausgeloggt und hat somit einen Strike erhalten!"),
/*  24 */   ALERT_DISCONNECT_TOO_OFTEN(ConfigMessageSection.ALERTS, "BOTS_ALERT.disconnectTooOften", "%player% hat das Spiel zu oft verlassen, weswegen seine Session entfernt wurde!"),
/*  25 */   ALERT_DISCORD_DEATH(ConfigMessageSection.ALERTS, "BOTS_ALERT.death", "%player% ist gestorben! Grund: %reason%"),
/*  26 */   ALERT_DISCORD_KILL(ConfigMessageSection.ALERTS, "BOTS_ALERT.kill", "%player% wurde von %killer% getoetet!"),
/*  27 */   ALERT_FIRST_STRIKE(ConfigMessageSection.ALERTS, "BOTS_ALERT.firstStrike", "%player% hat nun einen Strike. Der Strike wurde von %striker% gegeben. Begruendung: %reason%\nAufgrund dessen sind hier die derzeiten Koordinaten: %pos%!"),
/*  28 */   ALERT_FIRST_STRIKE_NEVER_ONLINE(ConfigMessageSection.ALERTS, "BOTS_ALERT.firstStrikeNeverOnline", "%player% hat nun einen Strike. Der Strike wurde von %striker% gegeben. Begruendung: %reason%\nDer Spieler war noch nicht online und wird an den Spawn-Koordinaten spawnen: %pos%!"),
/*  29 */   ALERT_GAME_STARTED(ConfigMessageSection.ALERTS, "BOTS_ALERT.gameStarted", "%projectname% wurde gestartet!"),
/*  30 */   ALERT_GENERAL_STRIKE(ConfigMessageSection.ALERTS, "BOTS_ALERT.generalStrike", "%player% hat nun den %strikeNumber%ten Strike! Der Strike wurde von %striker% gegeben. Begruendung: %reason%"),
/*  31 */   ALERT_JOIN_FINALE(ConfigMessageSection.ALERTS, "BOTS_ALERT.finale", "%player% &7hat den Server zum Finale betreten."),
/*  32 */   ALERT_KICKED_PLAYER(ConfigMessageSection.ALERTS, "BOTS_ALERT.kickedPlayer", "%player% wurde gekickt!"),
/*  33 */   ALERT_NEW_SESSIONS(ConfigMessageSection.ALERTS, "BOTS_ALERT.newSessions", "Es wurden %newSessions% neue Folgen an die Spieler gegeben!"),
/*  34 */   ALERT_NEW_SESSIONS_FOR_ALL(ConfigMessageSection.ALERTS, "BOTS_ALERT.newSessionsForAll", "Alle haben %newSessions% neue Folgen bekommen!"),
/*  35 */   ALERT_NO_BLOODLUST(ConfigMessageSection.ALERTS, "BOTS_ALERT.noBloodlust", "%player% hat nun %days% Tage nicht gekaempft, was das Limit ueberschritten hat!"),
/*  36 */   ALERT_NO_BLOODLUST_STRIKE(ConfigMessageSection.ALERTS, "BOTS_ALERT.noBloodlustStrike", "%player% hat nun %days% Tage nicht gekaempft, weswegen %player% jetzt gestriket wurde!"),
/*  37 */   ALERT_NOT_JOIN(ConfigMessageSection.ALERTS, "BOTS_ALERT.notJoin", "%player% war nun %days% Tage nicht online, was das Limit ueberschritten hat!"),
/*  38 */   ALERT_NOT_JOIN_STRIKE(ConfigMessageSection.ALERTS, "BOTS_ALERT.notJoinStrike", "%player% war nun %days% Tage nicht online, weswegen %player% jetzt gestriket wurde!"),
/*  39 */   ALERT_PLAYER_DC_TO_EARLY(ConfigMessageSection.ALERTS, "BOTS_ALERT.playerQuitToEarly", "%player% hat das Spiel vorzeitig verlassen! %player% hat noch %seconds% Sekunden Spielzeit ueber!"),
/*  40 */   ALERT_PLAYER_JOIN_MASSREC(ConfigMessageSection.ALERTS, "BOTS_ALERT.playerJoinMassrec", "%player% hat den Server in der Massenaufnahme betreten und spielt nun die %episodesPlayedPlus1%te Folge"),
/*  41 */   ALERT_PLAYER_JOIN_NORMAL(ConfigMessageSection.ALERTS, "BOTS_ALERT.playerJoinNormal", "%player% hat das Spiel betreten!"),
/*  42 */   ALERT_PLAYER_JOINED(ConfigMessageSection.ALERTS, "BOTS_ALERT.playerJoined", "%player% hat den Server betreten und spielt nun die %episodesPlayedPlus1%te Folge!"),
/*  43 */   ALERT_PLAYER_QUIT(ConfigMessageSection.ALERTS, "BOTS_ALERT.playerQuit", "%player% hat das Spiel verlassen!"),
/*  44 */   ALERT_PLAYER_RECONNECT(ConfigMessageSection.ALERTS, "BOTS_ALERT.playerReconnect", "%player% hatte das Spiel vorzeitig verlassen und ist rejoint! %player% hat noch %seconds% Sekunden verbleibend!"),
/*  45 */   ALERT_SECOND_STRIKE(ConfigMessageSection.ALERTS, "BOTS_ALERT.secondStrike", "%player% hat nun zwei Strikes. Der Strike wurde von %striker% gegeben. Begruendung: %reason%\nAufgrund dessen wurde das Inventar geleert!"),
/*  46 */   ALERT_SWITCHED_NAME(ConfigMessageSection.ALERTS, "BOTS_ALERT.switchedName", "%player% hat den Namen gewechselt und ist nun unter %newName% bekannt!"),
/*  47 */   ALERT_TELEPORTED_TO_MIDDLE(ConfigMessageSection.ALERTS, "BOTS_ALERT.teleportedToMiddle", "%player% wurde zur Mitte teleportiert!"),
/*  48 */   ALERT_THRID_STRIKE(ConfigMessageSection.ALERTS, "BOTS_ALERT.thirdStrike", "%player% hat nun drei Strikes. Der Strike wurde von %striker% gegeben. Begruendung: %reason%\nDamit ist %player% aus %projectname% ausgeschieden!"),
/*  49 */   ALERT_WINNER(ConfigMessageSection.ALERTS, "BOTS_ALERT.win.player", "%player% hat %projectname% gewonnen! Gratulation!"),
/*  50 */   ALERT_WINNER_TEAM(ConfigMessageSection.ALERTS, "BOTS_ALERT.win.team", "%winnerPlayers% haben %projectname% gewonnen! Gratulation!"),
/*     */   
/*  52 */   BOTS_DISCORD_NOT_REGISTERED_DISCORD(
/*     */     
/*  54 */     ConfigMessageSection.BOTS, "notRegisteredDiscord", "&cDu bist noch nicht mit dem Discord authentifiziert!\n&7Um dich zu authentifizieren, schreibe in den #verify -Channel &c'varo verify <Deine ID>' &7auf dem Discord!\nLink zum Discordserver: &c%discordLink%\n&7Deine ID lautet: &c%code%"),
/*  55 */   BOTS_DISCORD_NO_SERVER_USER(ConfigMessageSection.BOTS, "noServerUser", "&cDein Account ist nicht auf dem Discord!%nextLine%&7Joine dem Discord und versuche es erneut."),
/*     */   
/*  57 */   BORDER_MINIMUM_REACHED(
/*     */     
/*  59 */     ConfigMessageSection.BORDER, "minimumReached", "&cDie Border hat ihr Minimum erreicht!"),
/*  60 */   BORDER_DECREASE_DAYS(ConfigMessageSection.BORDER, "decreaseDays", "&7Die Border wird jetzt um &c%size% &7Bloecke mit &c%speed% &7Bloecken/s verkleinert. &7Naechste Verkleinerung in &c%days% &7Tagen!"),
/*  61 */   BORDER_DECREASE_DEATH(ConfigMessageSection.BORDER, "decreaseDeath", "&7Die Border wird jetzt um &c%size% &7Bloecke mit &c%speed% &7Bloecken/s aufgrund eines Todes verkleinert."),
/*  62 */   BORDER_MINUTE_TIME_UPDATE(ConfigMessageSection.BORDER, "minuteTimeUpdate", "&7Die Border wird in &c%minutes%&7:&c%seconds% &7verkleinert!"),
/*  63 */   BORDER_DECREASE_MINUTES(ConfigMessageSection.BORDER, "decreaseMinutes", "&7Die Border wird jetzt um &c%size% &7Bloecke mit &c%speed% &7Bloecken/s verkleinert. &7Naechste Verkleinerung in &c%days% &7Minuten!"),
/*  64 */   BORDER_DISTANCE(ConfigMessageSection.BORDER, "distanceToBorder", "&7Distanz zur Border: %colorcode%%size% &7Bloecke"),
/*  65 */   BORDER_COMMAND_SET_BORDER(ConfigMessageSection.BORDER, "borderSet", "&7Die Border wurde auf %colorcode%%size% &7gesetzt!"),
/*     */   
/*  67 */   CHAT_FORMAT(
/*     */     
/*  69 */     ConfigMessageSection.CHAT, "format", "§7%player% §8» §f"),
/*  70 */   CHAT_TEAMCHAT_FORMAT(ConfigMessageSection.CHAT, "teamchatFormat", "&7[%team%&7] %player% &8» &f%message%"),
/*  71 */   CHAT_MUTED(ConfigMessageSection.CHAT, "muted", "&7Du wurdest gemutet!"),
/*  72 */   CHAT_WHEN_START(ConfigMessageSection.CHAT, "chatOnStart", "&7Du kannst erst ab dem Start wieder schreiben!"),
/*     */   
/*  74 */   COMBAT_FRIENDLY_FIRE(
/*     */     
/*  76 */     ConfigMessageSection.COMBAT, "friendlyfire", "§7Dieser Spieler ist in deinem Team!"),
/*  77 */   COMBAT_IN_FIGHT(ConfigMessageSection.COMBAT, "inFight", "&7Du bist nun im Kampf, logge dich &4NICHT &7aus!"),
/*  78 */   COMBAT_LOGGED_OUT(ConfigMessageSection.COMBAT, "loggedOut", "&c%player% &7hat den Server waehrend eines Kampfes verlassen!"),
/*  79 */   COMBAT_NOT_IN_FIGHT(ConfigMessageSection.COMBAT, "notInFight", "§7Du bist nun nicht mehr im &cKampf&7!"),
/*     */   
/*  81 */   SPAWN_WORLD(
/*     */     
/*  83 */     ConfigMessageSection.SPAWN, "spawn", "%colorcode%Koordinaten&7 vom Spawn: %colorcode%%x%&7, %colorcode%%y%&7, %colorcode%%z%"),
/*  84 */   SPAWN_NETHER(ConfigMessageSection.SPAWN, "spawnNether", "%colorcode%Koordinaten&7 vom Portal zur Oberwelt: %colorcode%%x%&7, %colorcode%%y%&7, %colorcode%%z%"),
/*  85 */   SPAWN_DISTANCE(ConfigMessageSection.SPAWN, "spawnDistance", "&7Du bist %colorcode%%distance% &7Bloecke vom Spawn entfernt!"),
/*  86 */   SPAWN_DISTANCE_NETHER(ConfigMessageSection.SPAWN, "spawnDistanceNether", "&7Du bist %colorcode%%distance% &7Bloecke vom Portal zur Oberwelt entfernt!"),
/*     */   
/*  88 */   DEATH_DEAD(
/*     */     
/*  90 */     ConfigMessageSection.DEATH, "killMessage", "&c%player% &7ist gestorben. &7Grund: &c%reason%"),
/*  91 */   DEATH_KILLED_BY(ConfigMessageSection.DEATH, "killed", "%colorcode%%player% &7wurde von &c%killer% &7getoetet!"),
/*  92 */   DEATH_LIFE_LOST(ConfigMessageSection.DEATH, "teamLifeLost", "%player% hat nun noch %colorcode%%teamLifes% &7Teamleben!"),
/*  93 */   DEATH_RESPAWN_PROTECTION(ConfigMessageSection.DEATH, "respawnProtection", "&c%player% hat nun ein Leben weniger und ist fuer %seconds% unverwundbar!"),
/*  94 */   DEATH_RESPAWN_PROTECTION_OVER(ConfigMessageSection.DEATH, "respawnProtectionOver", "&c%player% ist nun wieder verwundbar!"),
/*  95 */   DEATH_KILL_LIFE_ADD(ConfigMessageSection.DEATH, "killLifeAdd", "Dein Team hat aufgrund eines Kills ein Teamleben erhalten!"),
/*     */   
/*  97 */   GAME_START_COUNTDOWN(
/*     */     
/*  99 */     ConfigMessageSection.GAME, "start.startCountdown", "%projectname% &7startet in %colorcode%%countdown% &7Sekunde(n)!"),
/* 100 */   GAME_VARO_START(ConfigMessageSection.GAME, "start.varoStart", "%projectname% &7wurde gestartet! &5Viel Erfolg!"),
/* 101 */   GAME_VARO_START_TITLE(ConfigMessageSection.GAME, "start.startTitle", "%colorcode%%countdown%\n&7Viel Glueck!"),
/* 102 */   GAME_WIN(ConfigMessageSection.GAME, "win.single", "&5%player% &7hat %projectname% &7gewonnen! &5Gratulation!"),
/* 103 */   GAME_WIN_TEAM(ConfigMessageSection.GAME, "win.team", "&5%winnerPlayers% &7haben %projectname% &7gewonnen! &5Gratulation!"),
/*     */   
/* 105 */   JOIN_MESSAGE(
/*     */     
/* 107 */     ConfigMessageSection.JOINMESSAGE, "join", "%prefix%&a%player% &7hat den Server betreten!"),
/* 108 */   JOIN_FINALE(ConfigMessageSection.JOINMESSAGE, "finale", "%prefix%&a%player% &7hat den Server zum Finale betreten."),
/* 109 */   JOIN_MASS_RECORDING(ConfigMessageSection.JOINMESSAGE, "massrecording", "%prefix%&a%player% &7hat den Server in der Massenaufnahme betreten und ist in %colorcode%%protectionTime% &7Sekunden angreifbar!"),
/* 110 */   JOIN_NO_MOVE_IN_PROTECTION(ConfigMessageSection.JOINMESSAGE, "notMoveinProtection", "&7Du kannst dich nicht bewegen, solange du noch in der %colorcode%Schutzzeit &7bist!"),
/* 111 */   JOIN_PROTECTION_OVER(ConfigMessageSection.JOINMESSAGE, "joinProtectionOver", "%prefix%&a%player% &7ist nun angreifbar!"),
/* 112 */   JOIN_PROTECTION_TIME(ConfigMessageSection.JOINMESSAGE, "joinProtectionTime", "%prefix%&a%player% &7hat den Server betreten und ist in %colorcode%%protectionTime% &7Sekunden angreifbar!"),
/* 113 */   JOIN_SPECTATOR(ConfigMessageSection.JOINMESSAGE, "spectator", "&a%player% &7hat den Server als Spectator betreten!"),
/* 114 */   JOIN_WITH_REMAINING_TIME(ConfigMessageSection.JOINMESSAGE, "joinWithRemainingTime", "%prefix%&a%player% &7hatte den Server zu frueh verlassen und hat jetzt noch %colorcode%%seconds% &7Sekunden uebrig! Verbleibende &cDisconnects&7: &c%remainingDisconnects%"),
/*     */ 
/*     */   
/* 117 */   QUIT_MESSAGE(
/*     */     
/* 119 */     ConfigMessageSection.QUITMESSAGE, "quit", "%prefix%&c%player%&7 hat den Server verlassen!"),
/* 120 */   QUIT_DISCONNECT_SESSION_END(ConfigMessageSection.QUITMESSAGE, "disconnectKilled", "&c%player% &7hat das Spiel verlassen und ist seit &c%banTime% &7Minute(n) nicht mehr online.%nextLine%&7Damit ist er aus %projectname% &7ausgeschieden!"),
/* 121 */   QUIT_SPECTATOR(ConfigMessageSection.QUITMESSAGE, "spectator", "&c%player% &7hat den Server als Spectator verlassen!"),
/* 122 */   QUIT_TOO_OFTEN(ConfigMessageSection.QUITMESSAGE, "quitTooOften", "&c%player% &7hat den Server zu oft verlassen und dadurch seine Sitzung verloren."),
/* 123 */   QUIT_WITH_REMAINING_TIME(ConfigMessageSection.QUITMESSAGE, "quitRemainingTime", "%prefix%&c%player% &7hat den Server vorzeitig verlassen!"),
/* 124 */   QUIT_KICK_BROADCAST(ConfigMessageSection.QUITMESSAGE, "broadcast", "%colorcode%%player% &7wurde gekickt!"),
/* 125 */   QUIT_KICK_DELAY_OVER(ConfigMessageSection.QUITMESSAGE, "protectionOver", "%colorcode%%player% &7wurde aufgrund seines Todes jetzt gekickt!"),
/* 126 */   QUIT_KICK_IN_SECONDS(ConfigMessageSection.QUITMESSAGE, "kickInSeconds", "%colorcode%%player% &7wird in %colorcode%%countdown% &7Sekunde(n) gekickt!"),
/* 127 */   QUIT_KICK_PLAYER_NEARBY(ConfigMessageSection.QUITMESSAGE, "noKickPlayerNearby", "&cEs befindet sich ein Spieler &4%distance% &cBloecke in deiner Naehe!%nextLine%&7Um gekickt zu werden, entferne dich von diesem Spieler!"),
/* 128 */   QUIT_KICK_SERVER_CLOSE_SOON(ConfigMessageSection.QUITMESSAGE, "serverCloseSoon", "&7Der Server schliesst in &c%minutes% &7Minuten!"),
/*     */   
/* 130 */   DEATH_KICK_DEAD(
/*     */     
/* 132 */     ConfigMessageSection.KICK, "kickedKilled", "&cDu bist gestorben! %nextLine% &7Damit bist du aus %projectname% &7ausgeschieden"),
/* 133 */   DEATH_KICK_KILLED(ConfigMessageSection.KICK, "killedKick", "&7Du wurdest von &c%killer% &7getoetet! %nextLine% &7Damit bist du aus %projectname% &7ausgeschieden!"),
/* 134 */   JOIN_KICK_NOT_USER_OF_PROJECT(ConfigMessageSection.KICK, "notUserOfTheProject", "&7Du bist kein Teilnehmer dieses %projectname%&7's!"),
/* 135 */   JOIN_KICK_SERVER_FULL(ConfigMessageSection.KICK, "serverFull", "&cDer Server ist voll!%nextLine%&7Sprich mit dem Owner, falls das das ein Irrtum sein sollte!"),
/* 136 */   JOIN_KICK_STRIKE_BAN(ConfigMessageSection.KICK, "strikeBan", "&cDu wurdest aufgrund deines letzten Strikes fuer %hours% gebannt!\nVersuche es spaeter erneut"),
/* 137 */   JOIN_KICK_BANNED(ConfigMessageSection.KICK, "banned", "&4Du bist vom Server gebannt!\n&7Melde dich bei einem Admin, falls dies ein Fehler sein sollte.\n&7Grund: &c%reason%"),
/* 138 */   JOIN_KICK_NO_PREPRODUCES_LEFT(ConfigMessageSection.KICK, "noPreproduceLeft", "&cDu hast bereits vorproduziert! %nextLine%&7Versuche es morgen erneut."),
/* 139 */   JOIN_KICK_NO_SESSIONS_LEFT(ConfigMessageSection.KICK, "noSessionLeft", "&cDu hast keine Sessions mehr uebrig! %nextLine%&7Warte bis morgen, damit du wieder spielen kannst!"),
/* 140 */   JOIN_KICK_NO_TIME_LEFT(ConfigMessageSection.KICK, "noTimeLeft", "&cDu darfst nur alle &4%timeHours% &cStunden regulaer spielen! %nextLine%&7Du kannst erst in &c%stunden%&7:&c%minuten%&7:&c%sekunden% &7wieder joinen!"),
/* 141 */   JOIN_KICK_NOT_STARTED(ConfigMessageSection.KICK, "notStarted", "&cDer Server wurde noch nicht eroeffnet! %nextLine%&7Gedulde dich noch ein wenig!"),
/* 142 */   KICK_SESSION_OVER(ConfigMessageSection.KICK, "kickMessage", "&cDeine Aufnahmezeit ist abgelaufen, %nextLine%&7deswegen wurdest du gekickt!"),
/* 143 */   KICK_MASS_REC_SESSION_OVER(ConfigMessageSection.KICK, "kickMessageMassRec", "&cDie Massenaufnahme ist beendet, %nextLine%&7deswegen wurdest du gekickt!"),
/* 144 */   KICK_TOO_MANY_STRIKES(ConfigMessageSection.KICK, "tooManyStrikes", "&7Du hast zu viele Strikes bekommen und wurdest daher aus dem Projekt %projectname% &7entfernt."),
/* 145 */   KICK_COMMAND(ConfigMessageSection.KICK, "kick", "%colorcode%%player% &7wurde gekickt!"),
/*     */   
/* 147 */   LABYMOD_DISABLED(
/*     */     
/* 149 */     ConfigMessageSection.LABYMOD, "labyModDisabled", "&7Alle deine LabyMod Funktionen wurden deaktiviert!"),
/* 150 */   LABYMOD_KICK(ConfigMessageSection.LABYMOD, "labyMod", "&cLabyMod isn't allowed on this server."),
/*     */   
/* 152 */   SERVER_MODT_CANT_JOIN_HOURS(
/*     */     
/* 154 */     ConfigMessageSection.MOTD, "cantJoinHours", "&cDu kannst nur zwischen &4%minHour% &cund &4%maxHour%&c Uhr joinen! %nextLine%&7Versuche es spaeter erneut! &7%currHour%&7:&7%currMin%&7:&7%currSec%"),
/* 155 */   SERVER_MODT_NOT_OPENED(ConfigMessageSection.MOTD, "serverNotOpened", "&cDer Server wurde noch nicht fuer alle geoeffnet! %nextLine%&7Versuche es spaeter erneut!"),
/* 156 */   SERVER_MODT_OPEN(ConfigMessageSection.MOTD, "serverOpen", "&aSei nun bei %projectname% &adabei! \n&7Viel Spass!"),
/*     */   
/* 158 */   NAMETAG_NORMAL(
/*     */     
/* 160 */     ConfigMessageSection.NAMETAG, "normalNametagPrefix", "&7"),
/* 161 */   NAMETAG_SUFFIX(ConfigMessageSection.NAMETAG, "normalSuffix", "&c %kills%"),
/* 162 */   NAMETAG_TEAM_PREFIX(ConfigMessageSection.NAMETAG, "nametagWithTeam", "%colorcode%%team% &7"),
/*     */   
/* 164 */   CHEST_NOT_TEAM_CHEST(
/*     */     
/* 166 */     ConfigMessageSection.CHEST, "notTeamChest", "&7Diese Kiste gehoert %colorcode%%player%&7!"),
/* 167 */   CHEST_NOT_TEAM_FURNACE(ConfigMessageSection.CHEST, "notTeamFurnace", "&7Dieser Ofen gehoert %colorcode%%player%&7!"),
/* 168 */   CHEST_REMOVED_SAVEABLE(ConfigMessageSection.CHEST, "removedChest", "&7Du hast diese/n %saveable% %colorcode%erfolgreich &7entfernt!"),
/* 169 */   CHEST_SAVED_SAVEABLE(ConfigMessageSection.CHEST, "newChestSaved", "&7Eine neue Kiste wurde gesichert!"),
/*     */   
/* 171 */   NOPERMISSION_NO_PERMISSION(
/*     */     
/* 173 */     ConfigMessageSection.NOPERMISSION, "noPermission", "%colorcode%Dazu bist du nicht berechtigt!"),
/* 174 */   NOPERMISSION_NOT_ALLOWED_CRAFT(ConfigMessageSection.NOPERMISSION, "notAllowedCraft", "&7Das darfst du nicht craften, benutzen oder brauen!"),
/* 175 */   NOPERMISSION_NO_LOWER_FLIGHT(ConfigMessageSection.NOPERMISSION, "noLowerFlight", "&7Niedriger darfst du nicht fliegen!"),
/*     */   
/* 177 */   PROTECTION_NO_MOVE_START(
/*     */     
/* 179 */     ConfigMessageSection.PROTECTION, "noMoveStart", "§7Du kannst dich nicht bewegen, solange das Projekt noch nicht gestartet wurde."),
/* 180 */   PROTECTION_START(ConfigMessageSection.PROTECTION, "start", "&7Die &cSchutzzeit &7startet jetzt und wird &c%seconds% &7Sekunden anhalten!"),
/* 181 */   PROTECTION_TIME_OVER(ConfigMessageSection.PROTECTION, "protectionOver", "&7Die &cSchutzzeit &7ist nun vorrueber!"),
/* 182 */   PROTECTION_TIME_UPDATE(ConfigMessageSection.PROTECTION, "protectionUpdate", "&7Die &cSchutzzeit &7ist in &c%minutes%&7:&c%seconds% &7vorrueber!"),
/* 183 */   PROTECTION_TIME_RUNNING(ConfigMessageSection.PROTECTION, "timeRunning", "&7Die %colorcode%Schutzzeit &7laeuft noch!"),
/*     */   
/* 185 */   SORT_NO_HOLE_FOUND(
/*     */     
/* 187 */     ConfigMessageSection.SORT, "noHoleFound", "Es konnte fuer dich kein Loch gefunden werden!"),
/* 188 */   SORT_NO_HOLE_FOUND_TEAM(ConfigMessageSection.SORT, "noHoleFoundTeam", "Es konnte fuer dich kein Loch bei deinen Teampartnern gefunden werden."),
/* 189 */   SORT_NUMBER_HOLE(ConfigMessageSection.SORT, "numberHoleTeleport", "Du wurdest in das Loch %colorcode%%number% &7teleportiert!"),
/* 190 */   SORT_OWN_HOLE(ConfigMessageSection.SORT, "ownHoleTeleport", "Du wurdest in dein Loch einsortiert!"),
/* 191 */   SORT_SPECTATOR_TELEPORT(ConfigMessageSection.SORT, "spectatorTeleport", "Du wurdest, da du Spectator bist, zum Spawn teleportiert!"),
/* 192 */   SORT_SORTED(ConfigMessageSection.SORT, "sorted", "&7Du wurdest in das Loch %colorcode%%zahl% &7teleportiert!"),
/*     */   
/* 194 */   TABLIST_PLAYER_WITH_TEAM(
/*     */     
/* 196 */     ConfigMessageSection.TABLIST, "player.withTeam", "%colorcode%%team% &8| &7%player%  &c%kills%"),
/* 197 */   TABLIST_PLAYER_WITH_TEAM_RANK(ConfigMessageSection.TABLIST, "player.withTeamAndRank", "&7%rank% &8| %colorcode%%team% &8| &7%player%  &c%kills%"),
/* 198 */   TABLIST_PLAYER_WITHOUT_TEAM(ConfigMessageSection.TABLIST, "player.withoutTeam", "&7%player%  &c%kills%"),
/* 199 */   TABLIST_PLAYER_WITHOUT_TEAM_RANK(ConfigMessageSection.TABLIST, "player.withoutTeamWithRank", "&7%rank% &8| &7%player%  &c%kills%"),
/*     */   
/* 201 */   TEAMREQUEST_ENTER_TEAMNAME(
/*     */     
/* 203 */     ConfigMessageSection.TEAMREQUEST, "enterTeamName", "%colorcode%&lGib jetzt den Teamnamen fuer dich und %invited% ein:"),
/* 204 */   TEAMREQUEST_MAX_TEAMNAME_LENGTH(ConfigMessageSection.TEAMREQUEST, "maxTeamnameLength", "Dein Teamname darf maximal %colorcode%%maxLength% &7Zeichen enthalten!"),
/* 205 */   TEAMREQUEST_NO_COLORCODE(ConfigMessageSection.TEAMREQUEST, "noColorCode", "Dein Teamname darf keine Farbcodes enthalten!"),
/* 206 */   TEAMREQUEST_NO_HASHTAG(ConfigMessageSection.TEAMREQUEST, "noHashtag", "Dein Teamname darf kein '#' enthalten. (Wird automatisch hinzugefuegt)"),
/* 207 */   TEAMREQUEST_PLAYER_NOT_ONLINE(ConfigMessageSection.TEAMREQUEST, "playerNotOnline", "%colorcode%%invitor% ist nicht mehr online!"),
/* 208 */   TEAMREQUEST_REVOKED(ConfigMessageSection.TEAMREQUEST, "invationRevoked", "Einladung erfolgreich zurueckgezogen!"),
/* 209 */   TEAMREQUEST_TEAM_FULL(ConfigMessageSection.TEAMREQUEST, "teamIsFull", "%invited% konnte dem Team nicht beitreten - es ist bereits voll."),
/* 210 */   TEAMREQUEST_TEAM_REQUEST_RECIEVED(ConfigMessageSection.TEAMREQUEST, "teamRequestRecieved", "%colorcode%%invitor% &7hat dich in ein Team eingeladen (/varo tr)!"),
/* 211 */   TEAMREQUEST_INVITED_TEAM(ConfigMessageSection.TEAMREQUEST, "invitedInTeam", "&7Du hast %colorcode%%invited% &7in das Team %colorcode%%team% &7eingeladen!"),
/* 212 */   TEAMREQUEST_NO_TEAMNAME(ConfigMessageSection.TEAMREQUEST, "noteamname", "&7Du hast noch &7keinen &7Teamnamen!"),
/*     */   
/* 214 */   SPAWNS_SPAWN_NUMBER(
/*     */     
/* 216 */     ConfigMessageSection.SPAWNS, "spawnNameTag.number", "&7Spawn %colorcode%%number%"),
/* 217 */   SPAWNS_SPAWN_PLAYER(ConfigMessageSection.SPAWNS, "spawnNameTag.player", "&7Spawn von %colorcode%%player%"),
/*     */   
/* 219 */   OTHER_CONFIG(
/*     */     
/* 221 */     ConfigMessageSection.OTHER, "configReload", "&7Die %colorcode%Config &7wurde neu geladen"),
/* 222 */   OTHER_PING(ConfigMessageSection.OTHER, "ping", "&7Dein %colorcode%Ping &7betraegt: %colorcode%%ping%&7ms"); private ConfigMessageSection section;
/*     */   private String defaultValue;
/*     */   private String path;
/*     */   private String value;
/*     */   
/*     */   ConfigMessages(ConfigMessageSection section, String path, String value) {
/* 228 */     this.path = path;
/* 229 */     this.section = section;
/* 230 */     this.value = value;
/* 231 */     this.defaultValue = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue() {
/* 236 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFullPath() {
/* 241 */     return String.valueOf(this.section.getName()) + "." + this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 246 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getDescription() {
/* 251 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SectionConfiguration getSection() {
/* 256 */     return this.section;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(Object value) {
/* 261 */     this.value = String.valueOf(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 266 */     return getValue(this.value);
/*     */   }
/*     */   
/*     */   public String getValue(VaroPlayer vp) {
/* 270 */     return getValue(this.value, vp);
/*     */   }
/*     */   
/*     */   private static ArrayList<Integer> getConvNumbers(String line, String key) {
/* 274 */     ArrayList<Integer> list = new ArrayList<>();
/*     */     
/* 276 */     boolean first = true; byte b; int i; String[] arrayOfString;
/* 277 */     for (i = (arrayOfString = line.split(key)).length, b = 0; b < i; ) { String split0 = arrayOfString[b];
/* 278 */       if (first) {
/* 279 */         first = false;
/* 280 */         if (!line.startsWith(key)) {
/*     */           continue;
/*     */         }
/*     */       } 
/* 284 */       String[] split1 = split0.split("%", 2);
/*     */       
/* 286 */       if (split1.length == 2) {
/*     */         try {
/* 288 */           list.add(Integer.valueOf(Integer.parseInt(split1[0])));
/* 289 */         } catch (NumberFormatException numberFormatException) {}
/*     */       }
/*     */       
/*     */       continue;
/*     */       b++; }
/*     */     
/* 295 */     return list;
/*     */   }
/*     */   
/*     */   public static String getValue(String value) {
/* 299 */     String replaced = value;
/*     */     Iterator<Integer> iterator;
/* 301 */     for (iterator = getConvNumbers(replaced, "%topplayer-").iterator(); iterator.hasNext(); ) { int rank = ((Integer)iterator.next()).intValue();
/* 302 */       VaroPlayer player = Main.getVaroGame().getTopScores().getPlayer(rank);
/* 303 */       replaced = replaced.replace("%topplayer-" + rank + "%", (player == null) ? "-" : player.getName()); }
/*     */ 
/*     */     
/* 306 */     for (iterator = getConvNumbers(replaced, "%topplayerkills-").iterator(); iterator.hasNext(); ) { int rank = ((Integer)iterator.next()).intValue();
/* 307 */       VaroPlayer player = Main.getVaroGame().getTopScores().getPlayer(rank);
/* 308 */       replaced = replaced.replace("%topplayerkills-" + rank + "%", (player == null) ? "0" : String.valueOf(player.getStats().getKills())); }
/*     */ 
/*     */     
/* 311 */     for (iterator = getConvNumbers(replaced, "%topteam-").iterator(); iterator.hasNext(); ) { int rank = ((Integer)iterator.next()).intValue();
/* 312 */       VaroTeam team = Main.getVaroGame().getTopScores().getTeam(rank);
/* 313 */       replaced = replaced.replace("%topteam-" + rank + "%", (team == null) ? "-" : team.getName()); }
/*     */ 
/*     */     
/* 316 */     for (iterator = getConvNumbers(replaced, "%topteamkills-").iterator(); iterator.hasNext(); ) { int rank = ((Integer)iterator.next()).intValue();
/* 317 */       VaroTeam team = Main.getVaroGame().getTopScores().getTeam(rank);
/* 318 */       replaced = replaced.replace("%topteamkills-" + rank + "%", (team == null) ? "0" : String.valueOf(team.getKills())); }
/*     */ 
/*     */     
/* 321 */     return GeneralMessagePlaceholder.replacePlaceholders(replaced);
/*     */   }
/*     */   
/*     */   public static String getValue(String value, VaroPlayer vp) {
/* 325 */     return PlayerMessagePlaceholder.replacePlaceholders(getValue(value), vp);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\configuration\configurations\messages\ConfigMessages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */