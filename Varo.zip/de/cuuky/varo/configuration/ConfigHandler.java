/*     */ package de.cuuky.varo.configuration;
/*     */ 
/*     */ import com.google.common.io.Files;
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.SectionConfiguration;
/*     */ import de.cuuky.varo.configuration.configurations.SectionEntry;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSettingSection;
/*     */ import de.cuuky.varo.configuration.configurations.messages.ConfigMessageSection;
/*     */ import de.cuuky.varo.utils.JavaUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigHandler
/*     */ {
/*     */   private static final String VARO_DIR = "plugins/Varo/";
/*     */   private static final String CONFIG_PATH = "plugins/Varo/config";
/*     */   private static final String MESSAGE_PATH = "plugins/Varo/messages";
/*     */   private HashMap<String, YamlConfiguration> configurations;
/*     */   private HashMap<String, File> files;
/*     */   private boolean legacyFound;
/*     */   
/*     */   public ConfigHandler() {
/*  30 */     this.configurations = new HashMap<>();
/*  31 */     this.files = new HashMap<>();
/*  32 */     this.legacyFound = false;
/*     */     
/*  34 */     loadConfigurations();
/*     */   }
/*     */   
/*     */   private void loadConfigurations() {
/*  38 */     loadConfiguration((SectionConfiguration[])ConfigSettingSection.values(), "plugins/Varo/config");
/*  39 */     loadConfiguration((SectionConfiguration[])ConfigMessageSection.values(), "plugins/Varo/messages");
/*     */     
/*  41 */     if (this.legacyFound) {
/*  42 */       moveLegacyFiles();
/*     */     }
/*  44 */     testConfig();
/*     */   }
/*     */   
/*     */   private void loadConfiguration(SectionConfiguration[] sections, String filepath) {
/*  48 */     checkLegacyConfiguration(sections, filepath); byte b; int i;
/*     */     SectionConfiguration[] arrayOfSectionConfiguration;
/*  50 */     for (i = (arrayOfSectionConfiguration = sections).length, b = 0; b < i; ) { SectionConfiguration section = arrayOfSectionConfiguration[b];
/*  51 */       File file = new File(filepath, String.valueOf(section.getName().toLowerCase()) + ".yml");
/*  52 */       YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
/*     */       
/*  54 */       boolean save = false;
/*  55 */       config.options().copyDefaults(true);
/*     */       
/*  57 */       String header = getConfigHeader(section);
/*  58 */       if (!header.equals(config.options().header())) {
/*  59 */         config.options().header(getConfigHeader(section));
/*  60 */         save = true;
/*     */       } 
/*     */       
/*  63 */       ArrayList<String> entryNames = new ArrayList<>();
/*  64 */       for (SectionEntry entry : section.getEntries()) {
/*  65 */         if (!config.contains(entry.getPath())) {
/*  66 */           save = true;
/*     */         }
/*  68 */         config.addDefault(entry.getPath(), entry.getDefaultValue());
/*  69 */         entry.setValue(config.get(entry.getPath()));
/*  70 */         entryNames.add(entry.getPath());
/*     */       } 
/*     */       
/*  73 */       for (String path : config.getKeys(true)) {
/*  74 */         if (entryNames.contains(path) || config.isConfigurationSection(path)) {
/*     */           continue;
/*     */         }
/*  77 */         System.out.println(String.valueOf(Main.getConsolePrefix()) + "Removed " + path + " because it was removed from the plugin");
/*  78 */         config.set(path, null);
/*  79 */         save = true;
/*     */       } 
/*     */       
/*  82 */       if (save) {
/*  83 */         saveFile(config, file);
/*     */       }
/*  85 */       this.files.put(section.getName(), file);
/*  86 */       this.configurations.put(section.getName(), config);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void moveLegacyFiles() {
/*  91 */     String legacyDirName = "plugins/Varo/legacy/";
/*  92 */     File legacyDir = new File(legacyDirName);
/*  93 */     if (!legacyDir.isDirectory())
/*  94 */       legacyDir.mkdirs();  byte b; int i;
/*     */     File[] arrayOfFile;
/*  96 */     for (i = (arrayOfFile = (new File("plugins/Varo/")).listFiles()).length, b = 0; b < i; ) { File file = arrayOfFile[b];
/*  97 */       if (file.isFile())
/*     */         
/*     */         try {
/*     */           
/* 101 */           Files.copy(file, new File(String.valueOf(legacyDirName) + "legacy_" + file.getName()));
/*     */           
/* 103 */           file.delete();
/* 104 */         } catch (IOException e) {
/* 105 */           e.printStackTrace();
/*     */         }  
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void checkLegacyConfiguration(SectionConfiguration[] sections, String filepath) {
/* 111 */     File file = new File(String.valueOf(filepath) + ".yml");
/* 112 */     YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
/*     */     
/* 114 */     if (!file.exists()) {
/*     */       return;
/*     */     }
/* 117 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Found legacy configuration! Loading " + file.getName() + "..."); byte b; int i; SectionConfiguration[] arrayOfSectionConfiguration;
/* 118 */     for (i = (arrayOfSectionConfiguration = sections).length, b = 0; b < i; ) { SectionConfiguration section = arrayOfSectionConfiguration[b];
/* 119 */       File sectionFile = new File(filepath, String.valueOf(section.getName().toLowerCase()) + ".yml");
/* 120 */       YamlConfiguration sectionConfig = YamlConfiguration.loadConfiguration(sectionFile);
/*     */       
/* 122 */       for (SectionEntry entry : section.getEntries()) {
/* 123 */         if (!config.contains(entry.getFullPath())) {
/*     */           continue;
/*     */         }
/* 126 */         entry.setValue(config.get(entry.getFullPath()));
/* 127 */         sectionConfig.set(entry.getPath(), entry.getValue());
/*     */       } 
/*     */       
/*     */       try {
/* 131 */         sectionConfig.save(sectionFile);
/* 132 */       } catch (IOException e) {
/* 133 */         e.printStackTrace();
/*     */       } 
/*     */       b++; }
/*     */     
/* 137 */     this.legacyFound = true;
/*     */   }
/*     */   
/*     */   private void saveFile(YamlConfiguration config, File file) {
/*     */     try {
/* 142 */       config.save(file);
/* 143 */     } catch (IOException e) {
/* 144 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void saveValue(SectionEntry entry) {
/* 149 */     YamlConfiguration config = this.configurations.get(entry.getSection().getName());
/* 150 */     config.set(entry.getPath(), entry.getValue());
/*     */     
/* 152 */     saveFile(config, this.files.get(entry.getSection().getName()));
/*     */   }
/*     */   
/*     */   public void reload() {
/* 156 */     this.configurations.clear();
/* 157 */     this.files.clear();
/*     */     
/* 159 */     loadConfigurations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getConfigHeader(SectionConfiguration section) {
/* 166 */     String header = "WARNUNG: DIE RICHTIGE CONFIG BEFINDET SICH UNTEN, NICHT DIE '#' VOR DEN EINTRÄGEN WEGNEHMEN!\n Hier ist die Beschreibung der Config:";
/* 167 */     String desc = "\n----------- " + section.getName() + " -----------" + "\nBeschreibung: " + section.getDescription() + "\n";
/*     */     
/* 169 */     for (SectionEntry entry : section.getEntries()) {
/* 170 */       if (entry.getDescription() == null) {
/*     */         break;
/*     */       }
/* 173 */       String description = JavaUtils.getArgsToString(entry.getDescription(), "\n  ");
/* 174 */       desc = String.valueOf(desc) + "\r\n" + " " + entry.getPath() + ":\n  " + description + "\n  Default-Value: " + entry.getDefaultValue() + "\r\n";
/*     */     } 
/*     */     
/* 177 */     return String.valueOf(header) + desc + "-------------------------\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testConfig() {
/* 184 */     boolean shutdown = false;
/* 185 */     if (ConfigSetting.BACKPACK_PLAYER_SIZE.getValueAsInt() > 54 || ConfigSetting.BACKPACK_TEAM_SIZE.getValueAsInt() > 54) {
/* 186 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "CONFIGFEHLER! Die Groesse des Rucksackes darf nicht mehr als 54 betragen.");
/* 187 */       shutdown = true;
/*     */     } 
/*     */     
/* 190 */     if (shutdown) {
/* 191 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Das Plugin wird heruntergefahren, da Fehler in der Config existieren.");
/* 192 */       Bukkit.getServer().shutdown();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\configuration\ConfigHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */