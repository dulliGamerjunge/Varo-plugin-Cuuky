package de.cuuky.varo.configuration.placeholder.placeholder.util;

public class DateInfo {
  public static final int YEAR = 0;
  
  public static final int MONTH = 1;
  
  public static final int DAY = 2;
  
  public static final int HOUR = 3;
  
  public static final int MINUTES = 4;
  
  public static final int SECONDS = 5;
}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\configuration\placeholder\placeholde\\util\DateInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */