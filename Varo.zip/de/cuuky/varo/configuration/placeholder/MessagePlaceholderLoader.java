/*     */ package de.cuuky.varo.configuration.placeholder;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import de.cuuky.varo.configuration.placeholder.placeholder.GeneralMessagePlaceholder;
/*     */ import de.cuuky.varo.configuration.placeholder.placeholder.PlayerMessagePlaceholder;
/*     */ import de.cuuky.varo.entity.player.VaroPlayer;
/*     */ import de.cuuky.varo.entity.player.disconnect.VaroPlayerDisconnect;
/*     */ import de.cuuky.varo.utils.PermissionUtils;
/*     */ import de.cuuky.varo.version.BukkitVersion;
/*     */ import de.cuuky.varo.version.VersionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessagePlaceholderLoader
/*     */ {
/*     */   public MessagePlaceholderLoader() {
/*  18 */     loadMessagePlaceHolder();
/*  19 */     loadPlayerPlaceholder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadMessagePlaceHolder() {
/*     */     byte b;
/*     */     int i;
/*     */     ConfigSetting[] arrayOfConfigSetting;
/* 168 */     for (i = (arrayOfConfigSetting = ConfigSetting.values()).length, b = 0; b < i; ) { ConfigSetting setting = arrayOfConfigSetting[b]; b++; }
/*     */   
/*     */   }
/*     */   
/*     */   private void loadPlayerPlaceholder() {}
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\configuration\placeholder\MessagePlaceholderLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */