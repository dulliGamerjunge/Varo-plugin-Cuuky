/*    */ package de.cuuky.varo.bot.discord.listener;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import de.cuuky.varo.bot.discord.DiscordBotCommand;
/*    */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*    */ import java.awt.Color;
/*    */ import net.dv8tion.jda.api.events.GenericEvent;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ import net.dv8tion.jda.api.hooks.EventListener;
/*    */ 
/*    */ 
/*    */ public class DiscordBotEventListener
/*    */   implements EventListener
/*    */ {
/*    */   private MessageReceivedEvent lastEvent;
/*    */   
/*    */   public boolean isAliases(String command, String[] aliases) {
/*    */     byte b;
/*    */     int i;
/*    */     String[] arrayOfString;
/* 21 */     for (i = (arrayOfString = aliases).length, b = 0; b < i; ) { String s = arrayOfString[b];
/* 22 */       if (command.toLowerCase().equals(s.toLowerCase()))
/* 23 */         return true;  b++; }
/*    */     
/* 25 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(GenericEvent event) {
/* 30 */     if (!(event instanceof MessageReceivedEvent)) {
/*    */       return;
/*    */     }
/* 33 */     MessageReceivedEvent messageEvent = (MessageReceivedEvent)event;
/*    */     try {
/* 35 */       if (messageEvent.getAuthor().equals(Main.getBotLauncher().getDiscordbot().getJda().getSelfUser()))
/*    */         return; 
/* 37 */     } catch (NullPointerException e) {
/*    */       return;
/*    */     } 
/*    */     
/* 41 */     if (this.lastEvent != null && 
/* 42 */       this.lastEvent.getMessageId().equals(messageEvent.getMessageId())) {
/*    */       return;
/*    */     }
/* 45 */     this.lastEvent = messageEvent;
/* 46 */     String message = messageEvent.getMessage().getContentDisplay();
/* 47 */     if (!message.toLowerCase().startsWith(ConfigSetting.DISCORDBOT_COMMANDTRIGGER.getValueAsString().toLowerCase().replace(" ", ""))) {
/*    */       return;
/*    */     }
/* 50 */     if (message.replace(" ", "").equalsIgnoreCase(ConfigSetting.DISCORDBOT_COMMANDTRIGGER.getValueAsString().replace(" ", ""))) {
/* 51 */       messageEvent.getTextChannel().sendMessage("Type '" + ConfigSetting.DISCORDBOT_COMMANDTRIGGER.getValueAsString() + "help' for help.").queue();
/*    */       
/*    */       return;
/*    */     } 
/* 55 */     String replace = ConfigSetting.DISCORDBOT_COMMANDTRIGGER.getValueAsString();
/* 56 */     String command = message.toUpperCase().replaceFirst("(?i)" + replace.toUpperCase(), "").split(" ")[0];
/* 57 */     String[] args = message.toUpperCase().replaceFirst(String.valueOf(replace.toUpperCase()) + command.toUpperCase() + " ", "").split(" ");
/*    */     
/* 59 */     for (DiscordBotCommand cmd : DiscordBotCommand.getCommands()) {
/* 60 */       if (!cmd.getName().equalsIgnoreCase(command) && !isAliases(command, cmd.getAliases())) {
/*    */         continue;
/*    */       }
/* 63 */       cmd.onEnable(args, messageEvent);
/*    */       
/*    */       return;
/*    */     } 
/* 67 */     Main.getBotLauncher().getDiscordbot().sendMessage("Command '" + command + "' not found!", "ERROR", Color.RED, messageEvent.getTextChannel());
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\bot\discord\listener\DiscordBotEventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */