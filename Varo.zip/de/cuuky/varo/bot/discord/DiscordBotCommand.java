/*    */ package de.cuuky.varo.bot.discord;
/*    */ 
/*    */ import de.cuuky.varo.Main;
/*    */ import java.util.ArrayList;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DiscordBotCommand
/*    */ {
/* 26 */   private static ArrayList<DiscordBotCommand> commands = new ArrayList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   private String[] aliases;
/*    */ 
/*    */ 
/*    */   
/*    */   private String desc;
/*    */ 
/*    */ 
/*    */   
/*    */   private String name;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DiscordBotCommand(String name, String[] aliases, String description) {
/* 44 */     this.name = name;
/* 45 */     this.desc = description;
/* 46 */     this.aliases = aliases;
/*    */     
/* 48 */     commands.add(this);
/*    */   }
/*    */   
/*    */   public String[] getAliases() {
/* 52 */     return this.aliases;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 56 */     return this.desc;
/*    */   }
/*    */   
/*    */   public VaroDiscordBot getDiscordBot() {
/* 60 */     return Main.getBotLauncher().getDiscordbot();
/*    */   }
/*    */   
/*    */   public String getName() {
/* 64 */     return this.name;
/*    */   }
/*    */   
/*    */   public abstract void onEnable(String[] paramArrayOfString, MessageReceivedEvent paramMessageReceivedEvent);
/*    */   
/*    */   public static ArrayList<DiscordBotCommand> getCommands() {
/* 70 */     return commands;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\bot\discord\DiscordBotCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */