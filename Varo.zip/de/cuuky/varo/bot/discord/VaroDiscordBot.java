/*     */ package de.cuuky.varo.bot.discord;
/*     */ 
/*     */ import de.cuuky.varo.Main;
/*     */ import de.cuuky.varo.bot.VaroBot;
/*     */ import de.cuuky.varo.bot.discord.listener.DiscordBotEventListener;
/*     */ import de.cuuky.varo.configuration.configurations.config.ConfigSetting;
/*     */ import java.awt.Color;
/*     */ import java.io.File;
/*     */ import java.util.Random;
/*     */ import net.dv8tion.jda.api.EmbedBuilder;
/*     */ import net.dv8tion.jda.api.JDA;
/*     */ import net.dv8tion.jda.api.JDABuilder;
/*     */ import net.dv8tion.jda.api.OnlineStatus;
/*     */ import net.dv8tion.jda.api.entities.Activity;
/*     */ import net.dv8tion.jda.api.entities.Guild;
/*     */ import net.dv8tion.jda.api.entities.TextChannel;
/*     */ import net.dv8tion.jda.api.exceptions.PermissionException;
/*     */ 
/*     */ public class VaroDiscordBot
/*     */   implements VaroBot {
/*     */   private JDA jda;
/*     */   private long registerChannel;
/*     */   private long eventChannel;
/*     */   
/*     */   private Color getRandomColor() {
/*  26 */     Random random = new Random();
/*  27 */     return new Color(random.nextFloat(), random.nextFloat(), random.nextFloat());
/*     */   }
/*     */   private long announcementChannel; private long resultChannel; private long pingRole;
/*     */   
/*     */   public void connect() {
/*  32 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "Activating discord bot... (Errors maybe will appear - don't mind them)");
/*  33 */     JDABuilder builder = new JDABuilder(ConfigSetting.DISCORDBOT_TOKEN.getValueAsString());
/*  34 */     builder.setActivity(Activity.playing(ConfigSetting.DISCORDBOT_GAMESTATE.getValueAsString()));
/*  35 */     builder.setAutoReconnect(true);
/*  36 */     builder.setRequestTimeoutRetry(true);
/*  37 */     builder.setStatus(OnlineStatus.ONLINE);
/*     */     
/*     */     try {
/*  40 */       this.jda = builder.build();
/*  41 */       this.jda.addEventListener(new Object[] { new DiscordBotEventListener() });
/*  42 */     } catch (Exception|Error e) {
/*  43 */       e.printStackTrace();
/*  44 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Couldn't connect to Discord");
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/*  49 */       System.out.println(String.valueOf(Main.getConsolePrefix()) + "Waiting for the bot to be ready...");
/*  50 */       this.jda.awaitReady();
/*  51 */     } catch (Exception e) {
/*     */       return;
/*     */     } 
/*     */     
/*  55 */     loadChannel();
/*  56 */     System.out.println(String.valueOf(Main.getConsolePrefix()) + "DiscordBot enabled successfully!");
/*     */   }
/*     */   
/*     */   private void loadChannel() {
/*     */     try {
/*  61 */       this.announcementChannel = this.jda.getTextChannelById(ConfigSetting.DISCORDBOT_ANNOUNCEMENT_CHANNELID.getValueAsLong()).getIdLong();
/*     */       
/*  63 */       if (this.announcementChannel == -1L)
/*  64 */         System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not load announcement-channel"); 
/*  65 */     } catch (ClassCastException|IllegalArgumentException|NullPointerException e) {
/*  66 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not load announcement-channel");
/*     */     } 
/*     */     
/*     */     try {
/*  70 */       this.eventChannel = this.jda.getTextChannelById(ConfigSetting.DISCORDBOT_EVENTCHANNELID.getValueAsLong()).getIdLong();
/*  71 */     } catch (ClassCastException|IllegalArgumentException|NullPointerException e) {
/*  72 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not load event-channel");
/*     */     } 
/*     */     
/*     */     try {
/*  76 */       this.resultChannel = this.jda.getTextChannelById(ConfigSetting.DISCORDBOT_RESULT_CHANNELID.getValueAsLong()).getIdLong();
/*     */       
/*  78 */       if (this.resultChannel == -1L)
/*  79 */         System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not load result-channel"); 
/*  80 */     } catch (ClassCastException|IllegalArgumentException|NullPointerException e) {
/*  81 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not load result-channel");
/*     */     } 
/*     */     
/*     */     try {
/*  85 */       if (ConfigSetting.DISCORDBOT_VERIFYSYSTEM.getValueAsBoolean()) {
/*  86 */         this.registerChannel = this.jda.getTextChannelById(ConfigSetting.DISCORDBOT_REGISTERCHANNELID.getValueAsLong()).getIdLong();
/*     */       }
/*  88 */       if (this.registerChannel == -1L)
/*  89 */         System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not load register-channel"); 
/*  90 */     } catch (ClassCastException|IllegalArgumentException|NullPointerException e) {
/*  91 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not load result-channel");
/*     */     } 
/*     */     
/*     */     try {
/*  95 */       this.pingRole = -1L;
/*  96 */       this.pingRole = this.jda.getRoleById(ConfigSetting.DISCORDBOT_ANNOUNCEMENT_PING_ROLEID.getValueAsLong()).getIdLong();
/*     */       
/*  98 */       if (this.pingRole == -1L)
/*  99 */         System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not find role for: " + ConfigSetting.DISCORDBOT_ANNOUNCEMENT_PING_ROLEID.getValueAsLong()); 
/* 100 */     } catch (NullPointerException e) {
/* 101 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Could not find role for: " + ConfigSetting.DISCORDBOT_ANNOUNCEMENT_PING_ROLEID.getValueAsLong());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 107 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/*     */     try {
/* 111 */       this.jda.shutdownNow();
/* 112 */     } catch (Exception|Error e) {
/* 113 */       System.err.println("[Varo] DiscordBot failed shutting down! Maybe you switched the version while the plugin was running?");
/*     */       try {
/* 115 */         this.jda.shutdown();
/* 116 */       } catch (Exception|Error exception) {}
/*     */     } 
/*     */     
/* 119 */     this.jda = null;
/*     */   }
/*     */   
/*     */   public void sendFile(String message, File file, TextChannel channel) {
/* 123 */     channel.sendFile(file, message.replace("_", "\\_"), new net.dv8tion.jda.api.utils.AttachmentOption[0]).queue();
/*     */   }
/*     */   
/*     */   public void sendMessage(String message, String title, Color color, long channelid) {
/* 127 */     TextChannel channel = null;
/*     */     try {
/* 129 */       channel = this.jda.getTextChannelById(channelid);
/* 130 */     } catch (Exception e) {
/* 131 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Failed to print message");
/*     */       
/*     */       return;
/*     */     } 
/* 135 */     EmbedBuilder builder = new EmbedBuilder();
/* 136 */     if (!ConfigSetting.DISCORDBOT_MESSAGE_RANDOM_COLOR.getValueAsBoolean()) {
/* 137 */       builder.setColor(color);
/*     */     } else {
/* 139 */       builder.setColor(getRandomColor());
/* 140 */     }  builder.addField(title, message.replace("_", "\\_"), true);
/*     */     try {
/* 142 */       channel.sendMessage(builder.build()).queue();
/* 143 */     } catch (PermissionException e) {
/* 144 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Bot failed to write a message because of missing permission! MISSING: " + e.getPermission());
/* 145 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "On channel " + channel.getName());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendMessage(String message, String title, Color color, TextChannel channel) {
/* 150 */     EmbedBuilder builder = new EmbedBuilder();
/* 151 */     builder.setColor(color);
/* 152 */     builder.addField(title, message.replace("_", "\\_"), true);
/*     */     try {
/* 154 */       channel.sendMessage(builder.build()).queue();
/* 155 */     } catch (PermissionException e) {
/* 156 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "Bot failed to write a message because of missing permission! MISSING: " + e.getPermission());
/* 157 */       System.err.println(String.valueOf(Main.getConsolePrefix()) + "On channel " + channel.getName());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendRawMessage(String message, TextChannel channel) {
/* 162 */     if (this.jda == null || message.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     try {
/* 166 */       channel.sendMessage(message.replace("_", "\\_")).queue();
/* 167 */     } catch (PermissionException e) {
/* 168 */       System.err.println("Bot failed to write a message because of missing permission! MISSING: " + e.getPermission());
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getMentionRole() {
/* 173 */     if (this.pingRole == -1L) {
/* 174 */       return "@everyone";
/*     */     }
/* 176 */     return this.jda.getRoleById(this.pingRole).getAsMention();
/*     */   }
/*     */   
/*     */   public TextChannel getAnnouncementChannel() {
/* 180 */     return this.jda.getTextChannelById(this.announcementChannel);
/*     */   }
/*     */   
/*     */   public TextChannel getEventChannel() {
/* 184 */     return this.jda.getTextChannelById(this.eventChannel);
/*     */   }
/*     */   
/*     */   public TextChannel getRegisterChannel() {
/* 188 */     return this.jda.getTextChannelById(this.registerChannel);
/*     */   }
/*     */   
/*     */   public TextChannel getResultChannel() {
/* 192 */     return this.jda.getTextChannelById(this.resultChannel);
/*     */   }
/*     */   
/*     */   public Guild getMainGuild() {
/* 196 */     return this.jda.getGuildById(ConfigSetting.DISCORDBOT_SERVERID.getValueAsLong());
/*     */   }
/*     */   
/*     */   public JDA getJda() {
/* 200 */     return this.jda;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 204 */     return (this.jda != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\bot\discord\VaroDiscordBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */