/*    */ package de.cuuky.varo.bot.discord.commands;
/*    */ 
/*    */ import de.cuuky.varo.bot.discord.DiscordBotCommand;
/*    */ import de.cuuky.varo.entity.player.VaroPlayer;
/*    */ import java.awt.Color;
/*    */ import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegisteredCommand
/*    */   extends DiscordBotCommand
/*    */ {
/*    */   public RegisteredCommand() {
/* 16 */     super("registered", new String[] { "registeredplayers, players" }, "Zeigt alle registrierten Spieler an");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable(String[] args, MessageReceivedEvent event) {
/* 21 */     if (VaroPlayer.getVaroPlayer().size() == 0) {
/* 22 */       getDiscordBot().sendMessage("Es sind keine Spieler registriert!", "ERROR", Color.RED, event.getTextChannel());
/*    */       
/*    */       return;
/*    */     } 
/* 26 */     String players = "";
/* 27 */     for (VaroPlayer vp : VaroPlayer.getVaroPlayer()) {
/* 28 */       if (players.equals("")) {
/* 29 */         players = vp.getName(); continue;
/*    */       } 
/* 31 */       players = String.valueOf(players) + ", " + vp.getName();
/*    */     } 
/*    */     
/* 34 */     getDiscordBot().sendRawMessage("REGISTERED (" + VaroPlayer.getVaroPlayer().size() + ") \n\n" + players, event.getTextChannel());
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\bot\discord\commands\RegisteredCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */