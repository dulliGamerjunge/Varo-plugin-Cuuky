package de.cuuky.varo.bot;

public interface VaroBot {
  void connect();
  
  void disconnect();
}


/* Location:              C:\Users\dulli\Downloads\Varo_bypass_by_Dulli (1).jar!\de\cuuky\varo\bot\VaroBot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */