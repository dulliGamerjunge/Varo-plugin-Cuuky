/*    */ package de.cuuky.cfw;
/*    */ 
/*    */ import de.cuuky.cfw.configuration.language.LanguageManager;
/*    */ import de.cuuky.cfw.configuration.placeholder.MessagePlaceholderManager;
/*    */ import de.cuuky.cfw.hooking.HookManager;
/*    */ import de.cuuky.cfw.manager.FrameworkManager;
/*    */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*    */ import de.cuuky.cfw.menu.SuperInventoryManager;
/*    */ import de.cuuky.cfw.serialization.CompatibleLocation;
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.bukkit.configuration.serialization.ConfigurationSerialization;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class CuukyFrameWork {
/*    */   private static final String NAME = "CuukyFrameWork";
/*    */   private static final String VERSION = "0.4.4";
/*    */   private static final String AUTHOR = "Cuuky";
/*    */   
/*    */   static {
/* 22 */     ConfigurationSerialization.registerClass(CompatibleLocation.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private JavaPlugin ownerInstance;
/*    */ 
/*    */   
/*    */   private String consolePrefix;
/*    */ 
/*    */   
/*    */   private Map<FrameworkManagerType, FrameworkManager> manager;
/*    */ 
/*    */ 
/*    */   
/*    */   public CuukyFrameWork(JavaPlugin pluginInstance) {
/* 38 */     this(pluginInstance, new FrameworkManager[0]);
/*    */   }
/*    */   
/*    */   public CuukyFrameWork(JavaPlugin pluginInstance, FrameworkManager... manager) {
/* 42 */     this.consolePrefix = "[" + pluginInstance.getName() + "] [CFW] ";
/*    */     
/* 44 */     System.out.println(String.valueOf(this.consolePrefix) + "Loading " + "CuukyFrameWork" + " v" + "0.4.4" + " by " + "Cuuky" + " for plugin " + pluginInstance.getName() + "...");
/* 45 */     this.ownerInstance = pluginInstance;
/* 46 */     this.manager = new HashMap<>(); byte b; int i;
/*    */     FrameworkManager[] arrayOfFrameworkManager;
/* 48 */     for (i = (arrayOfFrameworkManager = manager).length, b = 0; b < i; ) { FrameworkManager fm = arrayOfFrameworkManager[b];
/* 49 */       System.out.println(String.valueOf(this.consolePrefix) + "Added CustomManager " + fm.getClass() + "!");
/* 50 */       this.manager.put(fm.getType(), fm);
/*    */       b++; }
/*    */   
/*    */   }
/*    */   protected FrameworkManager loadManager(FrameworkManagerType type) {
/* 55 */     FrameworkManager manager = this.manager.get(type);
/* 56 */     if (manager == null) {
/*    */       try {
/* 58 */         this.manager.put(type, manager = type.getManager().getDeclaredConstructor(new Class[] { JavaPlugin.class }).newInstance(new Object[] { this.ownerInstance }));
/* 59 */       } catch (NoSuchMethodException|InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|SecurityException e) {
/* 60 */         e.printStackTrace();
/* 61 */         throw new IllegalStateException(String.valueOf(this.consolePrefix) + "Failed to initialize type " + type.toString() + "!");
/*    */       } 
/*    */     }
/*    */     
/* 65 */     return manager;
/*    */   }
/*    */   
/*    */   public JavaPlugin getPluginInstance() {
/* 69 */     return this.ownerInstance;
/*    */   }
/*    */   
/*    */   public HookManager getHookManager() {
/* 73 */     return (HookManager)loadManager(FrameworkManagerType.HOOKING);
/*    */   }
/*    */   
/*    */   public SuperInventoryManager getInventoryManager() {
/* 77 */     return (SuperInventoryManager)loadManager(FrameworkManagerType.INVENTORY);
/*    */   }
/*    */   
/*    */   public LanguageManager getLanguageManager() {
/* 81 */     return (LanguageManager)loadManager(FrameworkManagerType.LANGUAGE);
/*    */   }
/*    */   
/*    */   public MessagePlaceholderManager getPlaceholderManager() {
/* 85 */     return (MessagePlaceholderManager)loadManager(FrameworkManagerType.PLACEHOLDER);
/*    */   }
/*    */   
/*    */   public CFWSerializeManager getSerializeManager() {
/* 89 */     return (CFWSerializeManager)loadManager(FrameworkManagerType.SERIALIZE);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\CuukyFrameWork.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */