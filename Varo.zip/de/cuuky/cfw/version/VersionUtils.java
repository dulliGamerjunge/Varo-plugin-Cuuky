/*     */ package de.cuuky.cfw.version;
/*     */ 
/*     */ import de.cuuky.cfw.version.minecraft.MinecraftVersion;
/*     */ import de.cuuky.cfw.version.minecraft.utils.ProtocolSupportUtils;
/*     */ import de.cuuky.cfw.version.minecraft.utils.ViaVersionUtils;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionUtils
/*     */ {
/*     */   private static String nmsClass;
/*     */   private static Object spigot;
/*     */   private static Class<?> chatSerializer;
/*     */   private static BukkitVersion version;
/*     */   private static ServerSoftware serverSoftware;
/*  28 */   private static Map<Player, MinecraftVersion> playerVersions = new HashMap<>(); static {
/*  29 */     nmsClass = "net.minecraft.server." + Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3];
/*  30 */     version = BukkitVersion.getVersion(nmsClass);
/*  31 */     serverSoftware = ServerSoftware.getServerSoftware(Bukkit.getVersion(), Bukkit.getName());
/*     */     
/*     */     try {
/*  34 */       spigot = Bukkit.getServer().getClass().getDeclaredMethod("spigot", new Class[0]).invoke(Bukkit.getServer(), new Object[0]);
/*  35 */     } catch (Exception exception) {}
/*     */     
/*     */     try {
/*  38 */       chatSerializer = Class.forName(String.valueOf(getNmsClass()) + ".IChatBaseComponent$ChatSerializer");
/*  39 */     } catch (ClassNotFoundException|NullPointerException e) {
/*     */       try {
/*  41 */         chatSerializer = Class.forName(String.valueOf(getNmsClass()) + ".ChatSerializer");
/*  42 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setMinecraftServerProperty(String key, Object value) {
/*     */     try {
/*  48 */       Class<?> serverClass = Class.forName(String.valueOf(getNmsClass()) + ".MinecraftServer");
/*  49 */       Object server = serverClass.getMethod("getServer", new Class[0]).invoke(null, new Object[0]);
/*  50 */       Object manager = server.getClass().getField("propertyManager").get(server);
/*  51 */       Method method = manager.getClass().getMethod("setProperty", new Class[] { String.class, Object.class });
/*  52 */       method.invoke(manager, new Object[] { key, value });
/*  53 */     } catch (IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException|ClassNotFoundException|NoSuchFieldException|IllegalAccessException e) {
/*  54 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Class<?> getChatSerializer() {
/*  59 */     return chatSerializer;
/*     */   }
/*     */   
/*     */   public static double getHearts(Player player) {
/*  63 */     return player.getHealth();
/*     */   }
/*     */   
/*     */   public static String getNmsClass() {
/*  67 */     return nmsClass;
/*     */   }
/*     */   
/*     */   public static Object getSpigot() {
/*  71 */     return spigot;
/*     */   }
/*     */   
/*     */   public static ArrayList<Player> getOnlinePlayer() {
/*  75 */     ArrayList<Player> list = new ArrayList<>();
/*  76 */     for (Player player : Bukkit.getOnlinePlayers()) {
/*  77 */       list.add(player);
/*     */     }
/*  79 */     return list;
/*     */   }
/*     */   
/*     */   public static MinecraftVersion getMinecraftVersion(Player player) {
/*  83 */     MinecraftVersion version = playerVersions.get(player);
/*  84 */     if (version != null) {
/*  85 */       return version;
/*     */     }
/*  87 */     int protocolId = -1;
/*  88 */     if (ViaVersionUtils.isAvailable()) {
/*  89 */       protocolId = ViaVersionUtils.getVersion(player);
/*  90 */     } else if (ProtocolSupportUtils.isAvailable()) {
/*  91 */       protocolId = ProtocolSupportUtils.getVersion(player);
/*     */     } else {
/*  93 */       System.err.println("[CFW] Cannot get version of player without protocolsupport or viaversion installed");
/*     */     } 
/*  95 */     playerVersions.put(player, version = MinecraftVersion.getMinecraftVersion(protocolId));
/*  96 */     return version;
/*     */   }
/*     */   
/*     */   public static BukkitVersion getVersion() {
/* 100 */     return version;
/*     */   }
/*     */   
/*     */   public static ServerSoftware getServerSoftware() {
/* 104 */     return serverSoftware;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\version\VersionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */