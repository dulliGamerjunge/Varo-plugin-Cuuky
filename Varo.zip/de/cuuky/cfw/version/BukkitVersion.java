/*    */ package de.cuuky.cfw.version;
/*    */ 
/*    */ public enum BukkitVersion
/*    */ {
/*  5 */   ONE_16(16),
/*  6 */   ONE_15(15),
/*  7 */   ONE_14(14),
/*  8 */   ONE_13(13),
/*  9 */   ONE_12(12),
/* 10 */   ONE_11(11),
/* 11 */   ONE_10(10),
/* 12 */   ONE_9(9),
/* 13 */   ONE_8(8),
/* 14 */   ONE_7(7);
/*    */   
/*    */   private int identifier;
/*    */   
/*    */   BukkitVersion(int identifier) {
/* 19 */     this.identifier = identifier;
/*    */   }
/*    */   
/*    */   public boolean isHigherThan(BukkitVersion ver) {
/* 23 */     return (this.identifier > ver.getIdentifier());
/*    */   }
/*    */   
/*    */   public boolean isLowerThan(BukkitVersion ver) {
/* 27 */     return (this.identifier < ver.getIdentifier());
/*    */   }
/*    */   
/*    */   public int getIdentifier() {
/* 31 */     return this.identifier;
/*    */   }
/*    */   
/*    */   public static BukkitVersion getVersion(String versionString) {
/* 35 */     int versionNumber = Integer.valueOf(versionString.split("1_")[1].split("_")[0]).intValue();
/* 36 */     BukkitVersion nextFound = ONE_7; byte b; int i; BukkitVersion[] arrayOfBukkitVersion;
/* 37 */     for (i = (arrayOfBukkitVersion = values()).length, b = 0; b < i; ) { BukkitVersion version = arrayOfBukkitVersion[b];
/* 38 */       if (versionNumber == version.getIdentifier()) {
/* 39 */         return version;
/*    */       }
/* 41 */       if (versionNumber > version.getIdentifier() && 
/* 42 */         nextFound.getIdentifier() <= version.getIdentifier())
/*    */       {
/*    */         
/* 45 */         nextFound = version;
/*    */       }
/*    */       b++; }
/*    */     
/* 49 */     return nextFound;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\version\BukkitVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */