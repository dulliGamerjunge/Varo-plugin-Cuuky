/*     */ package de.cuuky.cfw.version.types;
/*     */ 
/*     */ import org.bukkit.Sound;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Sounds
/*     */ {
/*  37 */   AMBIENCE_CAVE("AMBIENCE_CAVE", new String[] { "AMBIENT_CAVE" }),
/*  38 */   AMBIENCE_RAIN("AMBIENCE_RAIN", new String[] { "WEATHER_RAIN" }),
/*  39 */   AMBIENCE_THUNDER("AMBIENCE_THUNDER", new String[] { "ENTITY_LIGHTNING_THUNDER" }),
/*  40 */   ANVIL_BREAK("ANVIL_BREAK", new String[] { "BLOCK_ANVIL_BREAK" }),
/*  41 */   ANVIL_LAND("ANVIL_LAND", new String[] { "BLOCK_ANVIL_LAND" }),
/*  42 */   ANVIL_USE("ANVIL_USE", new String[] { "BLOCK_ANVIL_USE" }),
/*  43 */   ARROW_HIT("ARROW_HIT", new String[] { "ENTITY_ARROW_HIT" }),
/*  44 */   BAT_DEATH("BAT_DEATH", new String[] { "ENTITY_BAT_DEATH" }),
/*  45 */   BAT_HURT("BAT_HURT", new String[] { "ENTITY_BAT_HURT" }),
/*  46 */   BAT_IDLE("BAT_IDLE", new String[] { "ENTITY_BAT_AMBIENT" }),
/*  47 */   BAT_LOOP("BAT_LOOP", new String[] { "ENTITY_BAT_LOOP" }),
/*  48 */   BAT_TAKEOFF("BAT_TAKEOFF", new String[] { "ENTITY_BAT_TAKEOFF" }),
/*  49 */   BLAZE_BREATH("BLAZE_BREATH", new String[] { "ENTITY_BLAZE_AMBIENT" }),
/*  50 */   BLAZE_DEATH("BLAZE_DEATH", new String[] { "ENTITY_BLAZE_DEATH" }),
/*  51 */   BLAZE_HIT("BLAZE_HIT", new String[] { "ENTITY_BLAZE_HURT" }),
/*  52 */   BURP("BURP", new String[] { "ENTITY_PLAYER_BURP" }),
/*  53 */   CAT_HISS("CAT_HISS", new String[] { "ENTITY_CAT_HISS" }),
/*  54 */   CAT_HIT("CAT_HIT", new String[] { "ENTITY_CAT_HURT" }),
/*  55 */   CAT_MEOW("CAT_MEOW", new String[] { "ENTITY_CAT_AMBIENT" }),
/*  56 */   CAT_PURR("CAT_PURR", new String[] { "ENTITY_CAT_PURR" }),
/*  57 */   CAT_PURREOW("CAT_PURREOW", new String[] { "ENTITY_CAT_PURREOW" }),
/*  58 */   CHEST_CLOSE("CHEST_CLOSE", new String[] { "BLOCK_CHEST_CLOSE" }),
/*  59 */   CHEST_OPEN("CHEST_OPEN", new String[] { "BLOCK_CHEST_OPEN" }),
/*  60 */   CHICKEN_EGG_POP("CHICKEN_EGG_POP", new String[] { "ENTITY_CHICKEN_EGG" }),
/*  61 */   CHICKEN_HURT("CHICKEN_HURT", new String[] { "ENTITY_CHICKEN_HURT" }),
/*  62 */   CHICKEN_IDLE("CHICKEN_IDLE", new String[] { "ENTITY_CHICKEN_AMBIENT" }),
/*  63 */   CHICKEN_WALK("CHICKEN_WALK", new String[] { "ENTITY_CHICKEN_STEP" }),
/*  64 */   CLICK("CLICK", new String[] { "UI_BUTTON_CLICK" }),
/*  65 */   COW_HURT("COW_HURT", new String[] { "ENTITY_COW_HURT" }),
/*  66 */   COW_IDLE("COW_IDLE", new String[] { "ENTITY_COW_AMBIENT" }),
/*  67 */   COW_WALK("COW_WALK", new String[] { "ENTITY_COW_STEP" }),
/*  68 */   CREEPER_DEATH("CREEPER_DEATH", new String[] { "ENTITY_CREEPER_DEATH" }),
/*  69 */   CREEPER_HISS("CREEPER_HISS", new String[] { "ENTITY_CREEPER_PRIMED" }),
/*  70 */   DIG_GRASS("DIG_GRASS", new String[] { "BLOCK_GRASS_BREAK" }),
/*  71 */   DIG_GRAVEL("DIG_GRAVEL", new String[] { "BLOCK_GRAVEL_BREAK" }),
/*  72 */   DIG_SAND("DIG_SAND", new String[] { "BLOCK_SAND_BREAK" }),
/*  73 */   DIG_SNOW("DIG_SNOW", new String[] { "BLOCK_SNOW_BREAK" }),
/*  74 */   DIG_STONE("DIG_STONE", new String[] { "BLOCK_STONE_BREAK" }),
/*  75 */   DIG_WOOD("DIG_WOOD", new String[] { "BLOCK_WOOD_BREAK" }),
/*  76 */   DIG_WOOL("DIG_WOOL", new String[] { "BLOCK_CLOTH_BREAK" }),
/*  77 */   DONKEY_ANGRY("DONKEY_ANGRY", new String[] { "ENTITY_DONKEY_ANGRY" }),
/*  78 */   DONKEY_DEATH("DONKEY_DEATH", new String[] { "ENTITY_DONKEY_DEATH" }),
/*  79 */   DONKEY_HIT("DONKEY_HIT", new String[] { "ENTITY_DONKEY_HURT" }),
/*  80 */   DONKEY_IDLE("DONKEY_IDLE", new String[] { "ENTITY_DONKEY_AMBIENT" }),
/*  81 */   DOOR_CLOSE("DOOR_CLOSE", new String[] { "BLOCK_WOODEN_DOOR_CLOSE" }),
/*  82 */   DOOR_OPEN("DOOR_OPEN", new String[] { "BLOCK_WOODEN_DOOR_OPEN" }),
/*  83 */   DRINK("DRINK", new String[] { "ENTITY_GENERIC_DRINK" }),
/*  84 */   EAT("EAT", new String[] { "ENTITY_GENERIC_EAT" }),
/*  85 */   ENDERDRAGON_DEATH("ENDERDRAGON_DEATH", new String[] { "ENTITY_ENDERDRAGON_DEATH" }),
/*  86 */   ENDERDRAGON_GROWL("ENDERDRAGON_GROWL", new String[] { "ENTITY_ENDERDRAGON_GROWL" }),
/*  87 */   ENDERDRAGON_HIT("ENDERDRAGON_HIT", new String[] { "ENTITY_ENDERDRAGON_HURT" }),
/*  88 */   ENDERDRAGON_WINGS("ENDERDRAGON_WINGS", new String[] { "ENTITY_ENDERDRAGON_FLAP" }),
/*  89 */   ENDERMAN_DEATH("ENDERMAN_DEATH", new String[] { "ENTITY_ENDERMEN_DEATH" }),
/*  90 */   ENDERMAN_HIT("ENDERMAN_HIT", new String[] { "ENTITY_ENDERMEN_HURT" }),
/*  91 */   ENDERMAN_IDLE("ENDERMAN_IDLE", new String[] { "ENTITY_ENDERMEN_AMBIENT" }),
/*  92 */   ENDERMAN_SCREAM("ENDERMAN_SCREAM", new String[] { "ENTITY_ENDERMEN_SCREAM" }),
/*  93 */   ENDERMAN_STARE("ENDERMAN_STARE", new String[] { "ENTITY_ENDERMEN_STARE" }),
/*  94 */   ENDERMAN_TELEPORT("ENDERMAN_TELEPORT", new String[] { "ENTITY_ENDERMEN_TELEPORT" }),
/*  95 */   EXPLODE("EXPLODE", new String[] { "ENTITY_GENERIC_EXPLODE" }),
/*  96 */   FALL_BIG("FALL_BIG", new String[] { "ENTITY_GENERIC_BIG_FALL" }),
/*  97 */   FALL_SMALL("FALL_SMALL", new String[] { "ENTITY_GENERIC_SMALL_FALL" }),
/*  98 */   FIRE("FIRE", new String[] { "BLOCK_FIRE_AMBIENT" }),
/*  99 */   FIRE_IGNITE("FIRE_IGNITE", new String[] { "ITEM_FLINTANDSTEEL_USE" }),
/* 100 */   FIREWORK_BLAST("FIREWORK_BLAST", new String[] { "ENTITY_FIREWORK_BLAST" }),
/* 101 */   FIREWORK_BLAST2("FIREWORK_BLAST2", new String[] { "ENTITY_FIREWORK_BLAST_FAR" }),
/* 102 */   FIREWORK_LARGE_BLAST("FIREWORK_LARGE_BLAST", new String[] { "ENTITY_FIREWORK_LARGE_BLAST" }),
/* 103 */   FIREWORK_LARGE_BLAST2("FIREWORK_LARGE_BLAST2", new String[] { "ENTITY_FIREWORK_LARGE_BLAST_FAR" }),
/* 104 */   FIREWORK_LAUNCH("FIREWORK_LAUNCH", new String[] { "ENTITY_FIREWORK_LAUNCH" }),
/* 105 */   FIREWORK_TWINKLE("FIREWORK_TWINKLE", new String[] { "ENTITY_FIREWORK_TWINKLE" }),
/* 106 */   FIREWORK_TWINKLE2("FIREWORK_TWINKLE2", new String[] { "ENTITY_FIREWORK_TWINKLE_FAR" }),
/* 107 */   FIZZ("FIZZ", new String[] { "BLOCK_FIRE_EXTINGUISH" }),
/* 108 */   FUSE("FUSE", new String[] { "ENTITY_TNT_PRIMED" }),
/* 109 */   GHAST_CHARGE("GHAST_CHARGE", new String[] { "ENTITY_GHAST_WARN" }),
/* 110 */   GHAST_DEATH("GHAST_DEATH", new String[] { "ENTITY_GHAST_DEATH" }),
/* 111 */   GHAST_FIREBALL("GHAST_FIREBALL", new String[] { "ENTITY_GHAST_SHOOT" }),
/* 112 */   GHAST_MOAN("GHAST_MOAN", new String[] { "ENTITY_GHAST_AMBIENT" }),
/* 113 */   GHAST_SCREAM("GHAST_SCREAM", new String[] { "ENTITY_GHAST_SCREAM" }),
/* 114 */   GHAST_SCREAM2("GHAST_SCREAM2", new String[] { "ENTITY_GHAST_HURT" }),
/* 115 */   GLASS("GLASS", new String[] { "BLOCK_GLASS_BREAK" }),
/* 116 */   HORSE_ANGRY("HORSE_ANGRY", new String[] { "ENTITY_HORSE_ANGRY" }),
/* 117 */   HORSE_ARMOR("HORSE_ARMOR", new String[] { "ENTITY_HORSE_ARMOR" }),
/* 118 */   HORSE_BREATHE("HORSE_BREATHE", new String[] { "ENTITY_HORSE_BREATHE" }),
/* 119 */   HORSE_DEATH("HORSE_DEATH", new String[] { "ENTITY_HORSE_DEATH" }),
/* 120 */   HORSE_GALLOP("HORSE_GALLOP", new String[] { "ENTITY_HORSE_GALLOP" }),
/* 121 */   HORSE_HIT("HORSE_HIT", new String[] { "ENTITY_HORSE_HURT" }),
/* 122 */   HORSE_IDLE("HORSE_IDLE", new String[] { "ENTITY_HORSE_AMBIENT" }),
/* 123 */   HORSE_JUMP("HORSE_JUMP", new String[] { "ENTITY_HORSE_JUMP" }),
/* 124 */   HORSE_LAND("HORSE_LAND", new String[] { "ENTITY_HORSE_LAND" }),
/* 125 */   HORSE_SADDLE("HORSE_SADDLE", new String[] { "ENTITY_HORSE_SADDLE" }),
/* 126 */   HORSE_SKELETON_DEATH("HORSE_SKELETON_DEATH", new String[] { "ENTITY_SKELETON_HORSE_DEATH" }),
/* 127 */   HORSE_SKELETON_HIT("HORSE_SKELETON_HIT", new String[] { "ENTITY_SKELETON_HORSE_HURT" }),
/* 128 */   HORSE_SKELETON_IDLE("HORSE_SKELETON_IDLE", new String[] { "ENTITY_SKELETON_HORSE_AMBIENT" }),
/* 129 */   HORSE_SOFT("HORSE_SOFT", new String[] { "ENTITY_HORSE_STEP" }),
/* 130 */   HORSE_WOOD("HORSE_WOOD", new String[] { "ENTITY_HORSE_STEP_WOOD" }),
/* 131 */   HORSE_ZOMBIE_DEATH("HORSE_ZOMBIE_DEATH", new String[] { "ENTITY_ZOMBIE_HORSE_DEATH" }),
/* 132 */   HORSE_ZOMBIE_HIT("HORSE_ZOMBIE_HIT", new String[] { "ENTITY_ZOMBIE_HORSE_HURT" }),
/* 133 */   HORSE_ZOMBIE_IDLE("HORSE_ZOMBIE_IDLE", new String[] { "ENTITY_ZOMBIE_HORSE_AMBIENT" }),
/* 134 */   HURT_FLESH("HURT_FLESH", new String[] { "ENTITY_PLAYER_HURT" }),
/* 135 */   IRONGOLEM_DEATH("IRONGOLEM_DEATH", new String[] { "ENTITY_IRONGOLEM_DEATH" }),
/* 136 */   IRONGOLEM_HIT("IRONGOLEM_HIT", new String[] { "ENTITY_IRONGOLEM_HURT" }),
/* 137 */   IRONGOLEM_THROW("IRONGOLEM_THROW", new String[] { "ENTITY_IRONGOLEM_ATTACK" }),
/* 138 */   IRONGOLEM_WALK("IRONGOLEM_WALK", new String[] { "ENTITY_IRONGOLEM_STEP" }),
/* 139 */   ITEM_BREAK("ITEM_BREAK", new String[] { "ENTITY_ITEM_BREAK" }),
/* 140 */   ITEM_PICKUP("ITEM_PICKUP", new String[] { "ENTITY_ITEM_PICKUP" }),
/* 141 */   LAVA("LAVA", new String[] { "BLOCK_LAVA_AMBIENT" }),
/* 142 */   LAVA_POP("LAVA_POP", new String[] { "BLOCK_LAVA_POP" }),
/* 143 */   LEVEL_UP("LEVEL_UP", new String[] { "ENTITY_PLAYER_LEVELUP" }),
/* 144 */   MAGMACUBE_JUMP("MAGMACUBE_JUMP", new String[] { "ENTITY_MAGMACUBE_JUMP" }),
/* 145 */   MAGMACUBE_WALK("MAGMACUBE_WALK", new String[] { "ENTITY_MAGMACUBE_SQUISH" }),
/* 146 */   MAGMACUBE_WALK2("MAGMACUBE_WALK2", new String[] { "ENTITY_MAGMACUBE_SQUISH" }),
/* 147 */   MINECART_BASE("MINECART_BASE", new String[] { "ENTITY_MINECART_RIDING" }),
/* 148 */   MINECART_INSIDE("MINECART_INSIDE", new String[] { "ENTITY_MINECART_RIDING" }),
/* 149 */   NOTE_BASS("NOTE_BASS", new String[] { "BLOCK_NOTE_BASS", "BLOCK_NOTE_BLOCK_BASS" }),
/* 150 */   NOTE_BASS_DRUM("NOTE_BASS_DRUM", new String[] { "BLOCK_NOTE_BASEDRUM", "BLOCK_NOTE_BLOCK_BASEDRUM" }),
/* 151 */   NOTE_BASS_GUITAR("NOTE_BASS_GUITAR", new String[] { "BLOCK_NOTE_BASS" }),
/* 152 */   NOTE_PIANO("NOTE_PIANO", new String[] { "BLOCK_NOTE_HARP" }),
/* 153 */   NOTE_PLING("NOTE_PLING", new String[] { "BLOCK_NOTE_PLING", "BLOCK_NOTE_BLOCK_PLING" }),
/* 154 */   NOTE_SNARE_DRUM("NOTE_SNARE_DRUM", new String[] { "BLOCK_NOTE_SNARE" }),
/* 155 */   NOTE_STICKS("NOTE_STICKS", new String[] { "BLOCK_NOTE_HAT" }),
/* 156 */   ORB_PICKUP("ORB_PICKUP", new String[] { "ENTITY_EXPERIENCE_ORB_PICKUP" }),
/* 157 */   PIG_DEATH("PIG_DEATH", new String[] { "ENTITY_PIG_DEATH" }),
/* 158 */   PIG_IDLE("PIG_IDLE", new String[] { "ENTITY_PIG_AMBIENT" }),
/* 159 */   PIG_WALK("PIG_WALK", new String[] { "ENTITY_PIG_STEP" }),
/* 160 */   PISTON_EXTEND("PISTON_EXTEND", new String[] { "BLOCK_PISTON_EXTEND" }),
/* 161 */   PISTON_RETRACT("PISTON_RETRACT", new String[] { "BLOCK_PISTON_CONTRACT" }),
/* 162 */   PORTAL("PORTAL", new String[] { "BLOCK_PORTAL_AMBIENT" }),
/* 163 */   PORTAL_TRAVEL("PORTAL_TRAVEL", new String[] { "BLOCK_PORTAL_TRAVEL" }),
/* 164 */   PORTAL_TRIGGER("PORTAL_TRIGGER", new String[] { "BLOCK_PORTAL_TRIGGER" }),
/* 165 */   SHEEP_IDLE("SHEEP_IDLE", new String[] { "ENTITY_SHEEP_AMBIENT" }),
/* 166 */   SHEEP_SHEAR("SHEEP_SHEAR", new String[] { "ENTITY_SHEEP_SHEAR" }),
/* 167 */   SHEEP_WALK("SHEEP_WALK", new String[] { "ENTITY_SHEEP_STEP" }),
/* 168 */   SHOOT_ARROW("SHOOT_ARROW", new String[] { "ENTITY_ARROW_SHOOT" }),
/* 169 */   SILVERFISH_HIT("SILVERFISH_HIT", new String[] { "ENTITY_SILVERFISH_HURT" }),
/* 170 */   SILVERFISH_IDLE("SILVERFISH_IDLE", new String[] { "ENTITY_SILVERFISH_AMBIENT" }),
/* 171 */   SILVERFISH_KILL("SILVERFISH_KILL", new String[] { "ENTITY_SILVERFISH_DEATH" }),
/* 172 */   SILVERFISH_WALK("SILVERFISH_WALK", new String[] { "ENTITY_SILVERFISH_STEP" }),
/* 173 */   SKELETON_DEATH("SKELETON_DEATH", new String[] { "ENTITY_SKELETON_DEATH" }),
/* 174 */   SKELETON_HURT("SKELETON_HURT", new String[] { "ENTITY_SKELETON_HURT" }),
/* 175 */   SKELETON_IDLE("SKELETON_IDLE", new String[] { "ENTITY_SKELETON_AMBIENT" }),
/* 176 */   SKELETON_WALK("SKELETON_WALK", new String[] { "ENTITY_SKELETON_STEP" }),
/* 177 */   SLIME_ATTACK("SLIME_ATTACK", new String[] { "ENTITY_SLIME_ATTACK" }),
/* 178 */   SLIME_WALK("SLIME_WALK", new String[] { "ENTITY_SLIME_JUMP" }),
/* 179 */   SLIME_WALK2("SLIME_WALK2", new String[] { "ENTITY_SLIME_SQUISH" }),
/* 180 */   SPIDER_DEATH("SPIDER_DEATH", new String[] { "ENTITY_SPIDER_DEATH" }),
/* 181 */   SPIDER_IDLE("SPIDER_IDLE", new String[] { "ENTITY_SPIDER_AMBIENT" }),
/* 182 */   SPIDER_WALK("SPIDER_WALK", new String[] { "ENTITY_SPIDER_STEP" }),
/* 183 */   SPLASH("SPLASH", new String[] { "ENTITY_GENERIC_SPLASH" }),
/* 184 */   SPLASH2("SPLASH2", new String[] { "ENTITY_BOBBER_SPLASH" }),
/* 185 */   STEP_GRASS("STEP_GRASS", new String[] { "BLOCK_GRASS_STEP" }),
/* 186 */   STEP_GRAVEL("STEP_GRAVEL", new String[] { "BLOCK_GRAVEL_STEP" }),
/* 187 */   STEP_LADDER("STEP_LADDER", new String[] { "BLOCK_LADDER_STEP" }),
/* 188 */   STEP_SAND("STEP_SAND", new String[] { "BLOCK_SAND_STEP" }),
/* 189 */   STEP_SNOW("STEP_SNOW", new String[] { "BLOCK_SNOW_STEP" }),
/* 190 */   STEP_STONE("STEP_STONE", new String[] { "BLOCK_STONE_STEP" }),
/* 191 */   STEP_WOOD("STEP_WOOD", new String[] { "BLOCK_WOOD_STEP" }),
/* 192 */   STEP_WOOL("STEP_WOOL", new String[] { "BLOCK_CLOTH_STEP" }),
/* 193 */   SUCCESSFUL_HIT("SUCCESSFUL_HIT", new String[] { "ENTITY_PLAYER_ATTACK_STRONG" }),
/* 194 */   SWIM("SWIM", new String[] { "ENTITY_GENERIC_SWIM" }),
/* 195 */   VILLAGER_DEATH("VILLAGER_DEATH", new String[] { "ENTITY_VILLAGER_DEATH" }),
/* 196 */   VILLAGER_HAGGLE("VILLAGER_HAGGLE", new String[] { "ENTITY_VILLAGER_TRADING" }),
/* 197 */   VILLAGER_HIT("VILLAGER_HIT", new String[] { "ENTITY_VILLAGER_HURT" }),
/* 198 */   VILLAGER_IDLE("VILLAGER_IDLE", new String[] { "ENTITY_VILLAGER_AMBIENT" }),
/* 199 */   VILLAGER_NO("VILLAGER_NO", new String[] { "ENTITY_VILLAGER_NO" }),
/* 200 */   VILLAGER_YES("VILLAGER_YES", new String[] { "ENTITY_VILLAGER_YES" }),
/* 201 */   WATER("WATER", new String[] { "BLOCK_WATER_AMBIENT" }),
/* 202 */   WITHER_DEATH("WITHER_DEATH", new String[] { "ENTITY_WITHER_DEATH" }),
/* 203 */   WITHER_HURT("WITHER_HURT", new String[] { "ENTITY_WITHER_HURT" }),
/* 204 */   WITHER_IDLE("WITHER_IDLE", new String[] { "ENTITY_WITHER_AMBIENT" }),
/* 205 */   WITHER_SHOOT("WITHER_SHOOT", new String[] { "ENTITY_WITHER_SHOOT" }),
/* 206 */   WITHER_SPAWN("WITHER_SPAWN", new String[] { "ENTITY_WITHER_SPAWN" }),
/* 207 */   WOLF_BARK("WOLF_BARK", new String[] { "ENTITY_WOLF_AMBIENT" }),
/* 208 */   WOLF_DEATH("WOLF_DEATH", new String[] { "ENTITY_WOLF_DEATH" }),
/* 209 */   WOLF_GROWL("WOLF_GROWL", new String[] { "ENTITY_WOLF_GROWL" }),
/* 210 */   WOLF_HOWL("WOLF_HOWL", new String[] { "ENTITY_WOLF_HOWL" }),
/* 211 */   WOLF_HURT("WOLF_HURT", new String[] { "ENTITY_WOLF_HURT" }),
/* 212 */   WOLF_PANT("WOLF_PANT", new String[] { "ENTITY_WOLF_PANT" }),
/* 213 */   WOLF_SHAKE("WOLF_SHAKE", new String[] { "ENTITY_WOLF_SHAKE" }),
/* 214 */   WOLF_WALK("WOLF_WALK", new String[] { "ENTITY_WOLF_STEP" }),
/* 215 */   WOLF_WHINE("WOLF_WHINE", new String[] { "ENTITY_WOLF_WHINE" }),
/* 216 */   WOOD_CLICK("WOOD_CLICK", new String[] { "BLOCK_WOOD_BUTTON_CLICK_ON" }),
/* 217 */   ZOMBIE_DEATH("ZOMBIE_DEATH", new String[] { "ENTITY_ZOMBIE_DEATH" }),
/* 218 */   ZOMBIE_HURT("ZOMBIE_HURT", new String[] { "ENTITY_ZOMBIE_HURT" }),
/* 219 */   ZOMBIE_IDLE("ZOMBIE_IDLE", new String[] { "ENTITY_ZOMBIE_AMBIENT" }),
/* 220 */   ZOMBIE_INFECT("ZOMBIE_INFECT", new String[] { "ENTITY_ZOMBIE_INFECT" }),
/* 221 */   ZOMBIE_METAL("ZOMBIE_METAL", new String[] { "ENTITY_ZOMBIE_ATTACK_IRON_DOOR" }),
/* 222 */   ZOMBIE_PIG_ANGRY("ZOMBIE_PIG_ANGRY", new String[] { "ENTITY_ZOMBIE_PIG_ANGRY" }),
/* 223 */   ZOMBIE_PIG_DEATH("ZOMBIE_PIG_DEATH", new String[] { "ENTITY_ZOMBIE_PIG_DEATH" }),
/* 224 */   ZOMBIE_PIG_HURT("ZOMBIE_PIG_HURT", new String[] { "ENTITY_ZOMBIE_PIG_HURT" }),
/* 225 */   ZOMBIE_PIG_IDLE("ZOMBIE_PIG_IDLE", new String[] { "ENTITY_ZOMBIE_PIG_AMBIENT" }),
/* 226 */   ZOMBIE_REMEDY("ZOMBIE_REMEDY", new String[] { "ENTITY_ZOMBIE_VILLAGER_CURE" }),
/* 227 */   ZOMBIE_UNFECT("ZOMBIE_UNFECT", new String[] { "ENTITY_ZOMBIE_VILLAGER_CONVERTED" }),
/* 228 */   ZOMBIE_WALK("ZOMBIE_WALK", new String[] { "ENTITY_ZOMBIE_STEP" }),
/* 229 */   ZOMBIE_WOOD("ZOMBIE_WOOD", new String[] { "ENTITY_ZOMBIE_ATTACK_DOOR_WOOD" }),
/* 230 */   ZOMBIE_WOODBREAK("ZOMBIE_WOODBREAK", new String[] { "ENTITY_ZOMBIE_BREAK_DOOR_WOOD" });
/*     */ 
/*     */ 
/*     */   
/* 234 */   private Sound resolvedSound = null; private String[] post19sounds; private String pre19sound;
/*     */   
/*     */   Sounds(String pre19sound, String... post19sounds) {
/* 237 */     this.pre19sound = pre19sound;
/* 238 */     this.post19sounds = post19sounds;
/*     */   }
/*     */   
/*     */   public Sound bukkitSound() {
/* 242 */     if (this.resolvedSound != null) {
/* 243 */       return this.resolvedSound;
/*     */     }
/*     */     try {
/* 246 */       return this.resolvedSound = Sound.valueOf(this.pre19sound);
/* 247 */     } catch (IllegalArgumentException e) {
/* 248 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = this.post19sounds).length, b = 0; b < i; ) { String s = arrayOfString[b];
/*     */         try {
/* 250 */           return this.resolvedSound = Sound.valueOf(s);
/* 251 */         } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */         
/*     */         b++; }
/*     */ 
/*     */       
/* 257 */       throw new IllegalArgumentException("SOUND NOT FOUND");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\version\types\Sounds.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */