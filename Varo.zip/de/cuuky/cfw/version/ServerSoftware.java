/*    */ package de.cuuky.cfw.version;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ public enum ServerSoftware
/*    */ {
/*  9 */   BUKKIT("Bukkit", false, new String[] { "Bukkit" }),
/* 10 */   SPIGOT("Spigot", false, new String[] { "Spigot" }),
/* 11 */   PAPER("PaperSpigot", false, new String[] { "PaperSpigot", "Paper" }),
/* 12 */   TACO("TacoSpigot", false, new String[] { "TacoSpigot" }),
/* 13 */   MAGMA("Magma", true, new String[] { "Magma" }),
/* 14 */   CAULDRON("Cauldron", true, new String[] { "Cauldron" }),
/* 15 */   THERMOS("Thermos", true, new String[] { "Thermos" }),
/* 16 */   URANIUM("Uranium", true, new String[] { "Uranium" }),
/* 17 */   UNKNOWN("Unknown", true, new String[0]); private static List<Character> abc; private String name;
/*    */   private String[] versionnames;
/*    */   private boolean modsupport;
/*    */   
/*    */   static {
/* 22 */     abc = new ArrayList<>(Arrays.asList(new Character[] { Character.valueOf('a'), Character.valueOf('b'), Character.valueOf('c'), Character.valueOf('d'), Character.valueOf('e'), Character.valueOf('f'), Character.valueOf('g'), Character.valueOf('h'), Character.valueOf('i'), Character.valueOf('j'), Character.valueOf('k'), Character.valueOf('l'), Character.valueOf('m'), Character.valueOf('n'), Character.valueOf('o'), Character.valueOf('p'), Character.valueOf('q'), Character.valueOf('r'), Character.valueOf('s'), Character.valueOf('t'), Character.valueOf('u'), Character.valueOf('v'), Character.valueOf('w'), Character.valueOf('x'), Character.valueOf('y'), Character.valueOf('z') }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ServerSoftware(String name, boolean modsupport, String... versionnames) {
/* 30 */     this.name = name;
/* 31 */     this.versionnames = versionnames;
/* 32 */     this.modsupport = modsupport;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 36 */     return this.name;
/*    */   }
/*    */   
/*    */   public String[] getVersionNames() {
/* 40 */     return this.versionnames;
/*    */   }
/*    */   
/*    */   public boolean hasModSupport() {
/* 44 */     return this.modsupport;
/*    */   }
/*    */   
/*    */   public static ServerSoftware getServerSoftware(String version, String name) {
/* 48 */     version = version.toLowerCase();
/* 49 */     name = name.toLowerCase();
/*    */     
/* 51 */     ServerSoftware found = null;
/* 52 */     String foundName = null; byte b; int i; ServerSoftware[] arrayOfServerSoftware;
/* 53 */     for (i = (arrayOfServerSoftware = values()).length, b = 0; b < i; ) { ServerSoftware software = arrayOfServerSoftware[b]; byte b1; int j; String[] arrayOfString;
/* 54 */       for (j = (arrayOfString = software.getVersionNames()).length, b1 = 0; b1 < j; ) { String softwareName = arrayOfString[b1];
/* 55 */         softwareName = softwareName.toLowerCase();
/*    */         
/* 57 */         if (version.contains(softwareName) && (found == null || softwareName.length() >= foundName.length())) {
/*    */ 
/*    */           
/* 60 */           found = software;
/* 61 */           foundName = softwareName;
/*    */         }  b1++; }
/*    */        b++; }
/*    */     
/* 65 */     if (found == null) {
/* 66 */       found = UNKNOWN;
/* 67 */     } else if (found != UNKNOWN) {
/* 68 */       int location = version.indexOf(foundName);
/*    */       
/* 70 */       if (location - 1 > -1 && 
/* 71 */         abc.contains(Character.valueOf(version.charAt(location - 1)))) {
/* 72 */         found = UNKNOWN;
/*    */       }
/* 74 */       if (location + foundName.length() + 1 < version.length() && 
/* 75 */         abc.contains(Character.valueOf(version.charAt(location + foundName.length())))) {
/* 76 */         found = UNKNOWN;
/*    */       }
/*    */     } 
/* 79 */     if (found == UNKNOWN)
/* 80 */       for (i = (arrayOfServerSoftware = values()).length, b = 0; b < i; ) { ServerSoftware software = arrayOfServerSoftware[b]; byte b1; int j; String[] arrayOfString;
/* 81 */         for (j = (arrayOfString = software.getVersionNames()).length, b1 = 0; b1 < j; ) { String softwareName = arrayOfString[b1];
/* 82 */           softwareName = softwareName.toLowerCase();
/*    */           
/* 84 */           if (name.equals(softwareName)) {
/*    */ 
/*    */             
/* 87 */             found = software;
/* 88 */             foundName = softwareName;
/*    */           }  b1++; }
/*    */         
/*    */         b++; }
/*    */        
/* 93 */     return found;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\version\ServerSoftware.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */