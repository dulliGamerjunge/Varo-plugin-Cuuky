/*    */ package de.cuuky.cfw.version.minecraft.utils;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ViaVersionUtils
/*    */ {
/*    */   private static Object api;
/*    */   private static Method getPlayerVersionMethod;
/*    */   
/*    */   static {
/*    */     try {
/* 17 */       api = Class.forName("us.myles.ViaVersion.api.Via").getMethod("getAPI", new Class[0]).invoke(null, new Object[0]);
/* 18 */       getPlayerVersionMethod = api.getClass().getMethod("getPlayerVersion", new Class[] { Player.class });
/* 19 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException|ClassNotFoundException illegalAccessException) {}
/*    */   }
/*    */   
/*    */   public static int getVersion(Player player) {
/* 23 */     if (getPlayerVersionMethod == null) {
/* 24 */       throw new NullPointerException("Could not find VIA API");
/*    */     }
/*    */     try {
/* 27 */       return ((Integer)getPlayerVersionMethod.invoke(api, new Object[] { player })).intValue();
/* 28 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 29 */       e.printStackTrace();
/*    */ 
/*    */       
/* 32 */       return -1;
/*    */     } 
/*    */   }
/*    */   public static boolean isAvailable() {
/* 36 */     return (getPlayerVersionMethod != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\version\minecraf\\utils\ViaVersionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */