/*    */ package de.cuuky.cfw.version.minecraft.utils;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProtocolSupportUtils
/*    */ {
/*    */   private static Method getProtocolVersionMethod;
/*    */   private static Method getIdMethod;
/*    */   
/*    */   static {
/*    */     try {
/* 16 */       getProtocolVersionMethod = Class.forName("protocolsupport.api.ProtocolSupportAPI").getMethod("getProtocolVersion", new Class[] { Player.class });
/* 17 */     } catch (IllegalArgumentException|NoSuchMethodException|SecurityException|ClassNotFoundException illegalArgumentException) {}
/*    */   }
/*    */   
/*    */   public static int getVersion(Player player) {
/* 21 */     if (getProtocolVersionMethod == null) {
/* 22 */       throw new NullPointerException("Could not find ProtocolSupportAPI");
/*    */     }
/*    */     
/*    */     try {
/* 26 */       Object version = getProtocolVersionMethod.invoke(null, new Object[] { player });
/*    */       
/* 28 */       if (getIdMethod == null) {
/* 29 */         getIdMethod = version.getClass().getMethod("getId", new Class[0]);
/*    */       }
/* 31 */       return ((Integer)getIdMethod.invoke(version, new Object[0])).intValue();
/* 32 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/* 33 */       e.printStackTrace();
/*    */ 
/*    */       
/* 36 */       return -1;
/*    */     } 
/*    */   }
/*    */   public static boolean isAvailable() {
/* 40 */     return (getProtocolVersionMethod != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\version\minecraf\\utils\ProtocolSupportUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */