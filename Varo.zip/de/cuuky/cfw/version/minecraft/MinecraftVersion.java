/*    */ package de.cuuky.cfw.version.minecraft;
/*    */ 
/*    */ public enum MinecraftVersion
/*    */ {
/*  5 */   MINECRAFT_1_16_1(
/*    */     
/*  7 */     736, "1.16.1"),
/*  8 */   MINECRAFT_1_16(735, "1.16"),
/*  9 */   MINECRAFT_1_15_2(578, "1.15.2"),
/* 10 */   MINECRAFT_1_15_1(575, "1.15.1"),
/* 11 */   MINECRAFT_1_15(573, "1.15"),
/* 12 */   MINECRAFT_1_14_4(498, "1.14.4"),
/* 13 */   MINECRAFT_1_14_3(490, "1.14.3"),
/* 14 */   MINECRAFT_1_14_2(485, "1.14.2"),
/* 15 */   MINECRAFT_1_14_1(480, "1.14.1"),
/* 16 */   MINECRAFT_1_14(477, "1.14"),
/* 17 */   MINECRAFT_1_13_2(404, "1.13.2"),
/* 18 */   MINECRAFT_1_13_1(401, "1.13.1"),
/* 19 */   MINECRAFT_1_13(393, "1.13"),
/* 20 */   MINECRAFT_1_12_2(340, "1.12.2"),
/* 21 */   MINECRAFT_1_12_1(338, "1.12.1"),
/* 22 */   MINECRAFT_1_12(335, "1.12"),
/* 23 */   MINECRAFT_1_11_1(316, "1.11.2"),
/* 24 */   MINECRAFT_1_11(315, "1.11"),
/* 25 */   MINECRAFT_1_10(210, "1.10"),
/* 26 */   MINECRAFT_1_9_4(110, "1.9.3-1.9.4"),
/* 27 */   MINECRAFT_1_9_2(109, "1.9.2"),
/* 28 */   MINECRAFT_1_9_1(108, "1.9.1"),
/* 29 */   MINECRAFT_1_9(107, "1.9"),
/* 30 */   MINECRAFT_1_8(47, "1.8-1.8.9"),
/* 31 */   MINECRAFT_1_7_10(5, "1.7.6-1.7.10"),
/* 32 */   MINECRAFT_1_7_2(4, "1.7.2-1.7.5"),
/* 33 */   UNKNWON(-1, "Unknown");
/*    */   
/*    */   private int protocolId;
/*    */   private String name;
/*    */   
/*    */   MinecraftVersion(int id, String name) {
/* 39 */     this.name = name;
/* 40 */     this.protocolId = id;
/*    */   }
/*    */   
/*    */   public boolean isHigherThan(MinecraftVersion version) {
/* 44 */     return (this.protocolId > version.getProtocolId());
/*    */   }
/*    */   
/*    */   public boolean isLowerThan(MinecraftVersion version) {
/* 48 */     return (this.protocolId < version.getProtocolId());
/*    */   }
/*    */   
/*    */   public String getName() {
/* 52 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getProtocolId() {
/* 56 */     return this.protocolId;
/*    */   }
/*    */   
/*    */   public static MinecraftVersion getMinecraftVersion(int protocolId) {
/* 60 */     MinecraftVersion version = MINECRAFT_1_7_2; byte b; int i; MinecraftVersion[] arrayOfMinecraftVersion;
/* 61 */     for (i = (arrayOfMinecraftVersion = values()).length, b = 0; b < i; ) { MinecraftVersion mcver = arrayOfMinecraftVersion[b];
/* 62 */       if (protocolId >= mcver.getProtocolId() && mcver.isHigherThan(version))
/* 63 */         version = mcver;  b++; }
/*    */     
/* 65 */     return version; } public static MinecraftVersion getMinecraftVersion(String versionname) {
/*    */     byte b;
/*    */     int i;
/*    */     MinecraftVersion[] arrayOfMinecraftVersion;
/* 69 */     for (i = (arrayOfMinecraftVersion = values()).length, b = 0; b < i; ) { MinecraftVersion mcver = arrayOfMinecraftVersion[b];
/* 70 */       if (mcver.getName().equals(versionname))
/* 71 */         return mcver;  b++; }
/*    */     
/* 73 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\version\minecraft\MinecraftVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */