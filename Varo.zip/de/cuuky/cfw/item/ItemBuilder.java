/*     */ package de.cuuky.cfw.item;
/*     */ 
/*     */ import de.cuuky.cfw.utils.JavaUtils;
/*     */ import de.cuuky.cfw.version.BukkitVersion;
/*     */ import de.cuuky.cfw.version.VersionUtils;
/*     */ import de.cuuky.cfw.version.types.Materials;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemBuilder
/*     */ {
/*     */   private static Method addFlagMethod;
/*     */   private static String[] attributes;
/*     */   private static Class<?> itemFlagClass;
/*     */   private static Object[] itemFlags;
/*     */   
/*     */   static {
/*     */     try {
/*  31 */       loadReflections();
/*  32 */     } catch (Exception e) {
/*  33 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private int amount = 1; private String displayName; private List<String> lore;
/*     */   private Map<Enchantment, Integer> enchantments;
/*     */   
/*     */   public ItemBuilder amount(int amount) {
/*  50 */     this.amount = amount;
/*  51 */     return this;
/*     */   }
/*     */   private String playerName; private ItemStack stack; private Material material;
/*     */   public ItemStack build() {
/*  55 */     if (this.stack == null) {
/*  56 */       this.stack = new ItemStack(this.material);
/*     */     }
/*  58 */     ItemMeta stackMeta = this.stack.getItemMeta();
/*  59 */     if (this.displayName != null && this.stack.getType() != Material.AIR) {
/*  60 */       stackMeta.setDisplayName(this.displayName);
/*     */     }
/*  62 */     if (this.lore != null) {
/*  63 */       stackMeta.setLore(this.lore);
/*     */     }
/*  65 */     if (this.enchantments != null)
/*  66 */       for (Enchantment ent : this.enchantments.keySet()) {
/*  67 */         stackMeta.addEnchant(ent, ((Integer)this.enchantments.get(ent)).intValue(), true);
/*     */       } 
/*  69 */     this.stack.setItemMeta(stackMeta);
/*     */     
/*  71 */     this.stack.setAmount(this.amount);
/*  72 */     return this.stack;
/*     */   }
/*     */   
/*     */   public ItemStack buildSkull() {
/*  76 */     this.stack = Materials.PLAYER_HEAD.parseItem();
/*  77 */     SkullMeta skullMeta = (SkullMeta)this.stack.getItemMeta();
/*     */     
/*  79 */     skullMeta.setDisplayName((this.displayName != null) ? this.displayName : this.playerName);
/*  80 */     skullMeta.setOwner((this.playerName != null) ? this.playerName : this.displayName);
/*     */     
/*  82 */     if (this.lore != null) {
/*  83 */       skullMeta.setLore(this.lore);
/*     */     }
/*  85 */     this.stack.setItemMeta((ItemMeta)skullMeta);
/*  86 */     this.stack.setAmount(this.amount);
/*     */     
/*  88 */     return this.stack;
/*     */   }
/*     */   
/*     */   public ItemBuilder addEnchantment(Enchantment enchantment, int amplifier) {
/*  92 */     if (this.enchantments == null) {
/*  93 */       this.enchantments = new HashMap<>();
/*     */     }
/*  95 */     this.enchantments.put(enchantment, Integer.valueOf(amplifier));
/*  96 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder deleteDamageAnnotation() {
/* 100 */     ItemMeta meta = this.stack.getItemMeta();
/* 101 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       try {
/*     */         byte b;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         int i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         Object[] arrayOfObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 125 */         for (i = (arrayOfObject = itemFlags).length, b = 0; b < i; ) { Object obj = arrayOfObject[b];
/* 126 */           Object[] s = (Object[])Array.newInstance(itemFlagClass, 1);
/* 127 */           Array.set(s, 0, obj);
/*     */           
/* 129 */           addFlagMethod.invoke(meta, new Object[] { s }); b++; }
/*     */       
/* 131 */       } catch (Exception e) {
/* 132 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 136 */     this.stack.setItemMeta(meta);
/* 137 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder material(Material material) {
/* 141 */     this.material = material;
/* 142 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder displayname(String displayname) {
/* 146 */     this.displayName = displayname;
/* 147 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder itemstack(ItemStack stack) {
/* 151 */     this.stack = stack;
/* 152 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(ArrayList<String> lore) {
/* 156 */     this.lore = lore;
/* 157 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(String lore) {
/* 161 */     this.lore = JavaUtils.collectionToArray(new String[] { lore });
/* 162 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder lore(String... lore) {
/* 166 */     this.lore = JavaUtils.collectionToArray(lore);
/* 167 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder player(Player player) {
/* 171 */     this.playerName = player.getName();
/* 172 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder playername(String playername) {
/* 176 */     this.playerName = playername;
/* 177 */     return this;
/*     */   }
/*     */   
/*     */   private static void loadReflections() throws Exception {
/* 181 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/* 182 */       itemFlagClass = Class.forName("org.bukkit.inventory.ItemFlag");
/*     */       
/* 184 */       attributes = new String[] { "HIDE_ATTRIBUTES", "HIDE_DESTROYS", "HIDE_ENCHANTS", "HIDE_PLACED_ON", "HIDE_POTION_EFFECTS", "HIDE_UNBREAKABLE" };
/* 185 */       itemFlags = new Object[attributes.length];
/*     */       
/* 187 */       for (int i = 0; i < attributes.length; i++) {
/*     */         try {
/* 189 */           itemFlags[i] = itemFlagClass.getDeclaredField(attributes[i]).get(null);
/* 190 */         } catch (IllegalArgumentException|IllegalAccessException|NoSuchFieldException|SecurityException e) {
/* 191 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */       
/*     */       try {
/* 196 */         addFlagMethod = Class.forName("org.bukkit.inventory.meta.ItemMeta").getDeclaredMethod("addItemFlags", new Class[] { Array.newInstance(itemFlagClass, 1).getClass() });
/* 197 */         addFlagMethod.setAccessible(true);
/* 198 */       } catch (NoSuchMethodException|SecurityException|NegativeArraySizeException e) {
/* 199 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\item\ItemBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */