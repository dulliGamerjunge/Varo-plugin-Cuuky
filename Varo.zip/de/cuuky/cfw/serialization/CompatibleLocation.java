/*    */ package de.cuuky.cfw.serialization;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.configuration.serialization.ConfigurationSerializable;
/*    */ 
/*    */ public class CompatibleLocation
/*    */   implements ConfigurationSerializable
/*    */ {
/*    */   private Location location;
/*    */   
/*    */   public CompatibleLocation(Location location) {
/* 15 */     this.location = location;
/*    */   }
/*    */   
/*    */   public CompatibleLocation(String world, double x, double y, double z, float yaw, float pitch) {
/* 19 */     this.location = new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
/*    */   }
/*    */   
/*    */   public Location getLocation() {
/* 23 */     return this.location;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> serialize() {
/* 28 */     Map<String, Object> map = new HashMap<>();
/*    */     
/* 30 */     map.put("world", this.location.getWorld().getName());
/* 31 */     map.put("x", Double.valueOf(this.location.getX()));
/* 32 */     map.put("y", Double.valueOf(this.location.getY()));
/* 33 */     map.put("z", Double.valueOf(this.location.getZ()));
/* 34 */     map.put("yaw", Float.valueOf(this.location.getYaw()));
/* 35 */     map.put("pitch", Float.valueOf(this.location.getPitch()));
/*    */     
/* 37 */     return map;
/*    */   }
/*    */   
/*    */   public static CompatibleLocation deserialize(Map<String, Object> args) {
/* 41 */     Number x = (Number)args.get("x"), y = (Number)args.get("y"), z = (Number)args.get("z"), yaw = (Number)args.get("yaw"), pitch = (Number)args.get("pitch");
/*    */     
/* 43 */     return new CompatibleLocation((String)args.get("world"), x.doubleValue(), y.doubleValue(), z.doubleValue(), yaw.floatValue(), pitch.floatValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialization\CompatibleLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */