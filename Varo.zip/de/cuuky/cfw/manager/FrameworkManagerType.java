/*    */ package de.cuuky.cfw.manager;
/*    */ 
/*    */ import de.cuuky.cfw.clientadapter.ClientAdapterManager;
/*    */ import de.cuuky.cfw.configuration.language.LanguageManager;
/*    */ import de.cuuky.cfw.configuration.placeholder.MessagePlaceholderManager;
/*    */ import de.cuuky.cfw.hooking.HookManager;
/*    */ import de.cuuky.cfw.menu.SuperInventoryManager;
/*    */ import de.cuuky.cfw.player.LanguagePlayerManager;
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ 
/*    */ public enum FrameworkManagerType
/*    */ {
/* 13 */   PLACEHOLDER((Class)MessagePlaceholderManager.class),
/* 14 */   LANGUAGE((Class)LanguageManager.class),
/* 15 */   INVENTORY((Class)SuperInventoryManager.class),
/* 16 */   HOOKING((Class)HookManager.class),
/* 17 */   CLIENT_ADAPTER((Class)ClientAdapterManager.class),
/* 18 */   PLAYER((Class)LanguagePlayerManager.class),
/* 19 */   SERIALIZE((Class)CFWSerializeManager.class);
/*    */   
/*    */   private Class<? extends FrameworkManager> manager;
/*    */   
/*    */   FrameworkManagerType(Class<? extends FrameworkManager> manager) {
/* 24 */     this.manager = manager;
/*    */   }
/*    */   
/*    */   public Class<? extends FrameworkManager> getManager() {
/* 28 */     return this.manager;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\manager\FrameworkManagerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */