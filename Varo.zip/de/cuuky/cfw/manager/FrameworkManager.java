/*    */ package de.cuuky.cfw.manager;
/*    */ 
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class FrameworkManager
/*    */ {
/*    */   protected JavaPlugin ownerInstance;
/*    */   protected String consolePrefix;
/*    */   protected FrameworkManagerType type;
/*    */   
/*    */   public FrameworkManager(FrameworkManagerType type, JavaPlugin ownerInstance) {
/* 12 */     this.type = type;
/* 13 */     this.consolePrefix = "[" + ownerInstance.getName() + "] [CFW] ";
/* 14 */     this.ownerInstance = ownerInstance;
/*    */   }
/*    */   
/*    */   public JavaPlugin getOwnerInstance() {
/* 18 */     return this.ownerInstance;
/*    */   }
/*    */   
/*    */   public FrameworkManagerType getType() {
/* 22 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getConsolePrefix() {
/* 26 */     return this.consolePrefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\manager\FrameworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */