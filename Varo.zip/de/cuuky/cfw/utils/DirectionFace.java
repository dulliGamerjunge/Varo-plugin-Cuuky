/*    */ package de.cuuky.cfw.utils;
/*    */ 
/*    */ public enum DirectionFace
/*    */ {
/*  5 */   NORTH("NORTH", 135.0F, -135.0F),
/*  6 */   EAST("EAST", -135.0F, -45.0F),
/*  7 */   SOUTH("SOUTH", -45.0F, 45.0F),
/*  8 */   WEST("WEST", 45.0F, 135.0F);
/*    */   private String identifier;
/*    */   private float start;
/*    */   private float end;
/*    */   
/*    */   DirectionFace(String identifier, float start, float end) {
/* 14 */     this.identifier = identifier;
/* 15 */     this.start = start;
/* 16 */     this.end = end;
/*    */   }
/*    */   
/*    */   public String getIdentifier() {
/* 20 */     return this.identifier;
/*    */   }
/*    */   
/*    */   public boolean isIn(float yaw) {
/* 24 */     return (this.start <= yaw && this.end > yaw);
/*    */   }
/*    */   
/*    */   public double[] modifyValues(double x, double z) {
/* 28 */     switch (this) {
/*    */       case null:
/* 30 */         return new double[] { -z, x };
/*    */       case WEST:
/* 32 */         return new double[] { z, -x };
/*    */       case SOUTH:
/* 34 */         return new double[] { -x, -z };
/*    */     } 
/* 36 */     return new double[] {
/*    */ 
/*    */         
/* 39 */         x, z };
/*    */   }
/*    */   
/*    */   public static DirectionFace getFace(float yaw) {
/* 43 */     yaw = (yaw >= 180.0F) ? (-180.0F + yaw - 180.0F) : yaw; byte b; int i; DirectionFace[] arrayOfDirectionFace;
/* 44 */     for (i = (arrayOfDirectionFace = values()).length, b = 0; b < i; ) { DirectionFace face = arrayOfDirectionFace[b];
/* 45 */       if (face.isIn(yaw))
/* 46 */         return face;  b++; }
/*    */     
/* 48 */     return NORTH;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\DirectionFace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */