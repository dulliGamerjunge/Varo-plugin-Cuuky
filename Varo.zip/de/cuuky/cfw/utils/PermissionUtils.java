/*    */ package de.cuuky.cfw.utils;
/*    */ 
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.plugin.RegisteredServiceProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PermissionUtils
/*    */ {
/*    */   private static Object luckPermsAPI;
/*    */   private static Object userManager;
/*    */   private static Object groupManager;
/*    */   private static Object queryOptions;
/* 19 */   private static HashMap<String, Class<?>> clazzes = new HashMap<>(); static {
/* 20 */     ArrayList<Class<?>> toAdd = new ArrayList<>();
/*    */     
/*    */     try {
/* 23 */       toAdd.add(Class.forName("ru.tehkode.permissions.bukkit.PermissionsEx"));
/* 24 */     } catch (Exception exception) {}
/*    */     
/*    */     try {
/* 27 */       toAdd.add(Class.forName("net.luckperms.api.LuckPerms"));
/* 28 */       toAdd.add(Class.forName("net.luckperms.api.query.QueryOptions"));
/* 29 */     } catch (Exception exception) {}
/*    */     
/* 31 */     for (Class<?> clazz : toAdd) {
/* 32 */       clazzes.put(clazz.getName(), clazz);
/*    */     }
/*    */     try {
/* 35 */       RegisteredServiceProvider<?> provider = Bukkit.getServicesManager().getRegistration(clazzes.get("net.luckperms.api.LuckPerms"));
/* 36 */       luckPermsAPI = null;
/*    */       
/* 38 */       if (provider != null) {
/* 39 */         luckPermsAPI = provider.getProvider();
/*    */       }
/* 41 */       userManager = luckPermsAPI.getClass().getMethod("getUserManager", new Class[0]).invoke(luckPermsAPI, new Object[0]);
/* 42 */       groupManager = luckPermsAPI.getClass().getMethod("getGroupManager", new Class[0]).invoke(luckPermsAPI, new Object[0]);
/* 43 */       queryOptions = ((Class)clazzes.get("net.luckperms.api.query.QueryOptions")).getDeclaredMethod("defaultContextualOptions", new Class[0]).invoke(null, new Object[0]);
/* 44 */     } catch (Exception exception) {}
/*    */   }
/*    */   
/*    */   public static String getLuckPermsPrefix(CustomPlayer player) {
/*    */     try {
/* 49 */       Object user = userManager.getClass().getMethod("getUser", new Class[] { UUID.class }).invoke(userManager, new Object[] { UUID.fromString(player.getUUID()) });
/* 50 */       String groupname = (String)user.getClass().getMethod("getPrimaryGroup", new Class[0]).invoke(user, new Object[0]);
/*    */       
/* 52 */       Object group = groupManager.getClass().getMethod("getGroup", new Class[] { String.class }).invoke(groupManager, new Object[] { groupname });
/* 53 */       Object cachedData = group.getClass().getMethod("getCachedData", new Class[0]).invoke(group, new Object[0]);
/*    */       
/* 55 */       Object metadata = cachedData.getClass().getMethod("getMetaData", new Class[] { clazzes.get("net.luckperms.api.query.QueryOptions") }).invoke(cachedData, new Object[] { queryOptions });
/* 56 */       String prefix = (String)metadata.getClass().getMethod("getPrefix", new Class[0]).invoke(metadata, new Object[0]);
/* 57 */       return (prefix != null) ? prefix.replace("&", "§") : prefix;
/* 58 */     } catch (Throwable throwable) {
/*    */       
/* 60 */       return "";
/*    */     } 
/*    */   }
/*    */   public static String getPermissionsExPrefix(CustomPlayer player) {
/* 64 */     String prefix = null;
/*    */     try {
/* 66 */       Object permissionUser = ((Class)clazzes.get("ru.tehkode.permissions.bukkit.PermissionsEx")).getDeclaredMethod("getUser", new Class[] { String.class }).invoke(null, new Object[] { player.getName() });
/* 67 */       Object[] groups = (Object[])permissionUser.getClass().getDeclaredMethod("getGroups", new Class[0]).invoke(permissionUser, new Object[0]);
/*    */       
/* 69 */       if (groups.length > 1)
/* 70 */       { prefix = (String)groups[0].getClass().getMethod("getPrefix", new Class[0]).invoke(groups[0], new Object[0]); }
/*    */       else
/* 72 */       { prefix = (String)permissionUser.getClass().getMethod("getPrefix", new Class[0]).invoke(permissionUser, new Object[0]); } 
/* 73 */     } catch (Throwable throwable) {}
/*    */     
/* 75 */     return (prefix != null) ? prefix.replace("&", "§") : prefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\PermissionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */