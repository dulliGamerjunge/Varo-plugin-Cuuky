/*    */ package de.cuuky.cfw.utils.listener;
/*    */ 
/*    */ import org.bukkit.entity.Arrow;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ 
/*    */ public class EntityDamageByEntityUtil
/*    */ {
/*    */   private EntityDamageByEntityEvent event;
/*    */   
/*    */   public EntityDamageByEntityUtil(EntityDamageByEntityEvent event) {
/* 12 */     this.event = event;
/*    */   }
/*    */   
/*    */   public Player getDamager() {
/* 16 */     if (this.event.getDamager() instanceof Arrow) {
/* 17 */       if (!(((Arrow)this.event.getDamager()).getShooter() instanceof Player)) {
/* 18 */         return null;
/*    */       }
/* 20 */       return (Player)((Arrow)this.event.getDamager()).getShooter();
/* 21 */     }  if (this.event.getDamager() instanceof Player) {
/* 22 */       return (Player)this.event.getDamager();
/*    */     }
/* 24 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\listener\EntityDamageByEntityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */