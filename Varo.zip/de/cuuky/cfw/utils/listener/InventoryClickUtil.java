/*    */ package de.cuuky.cfw.utils.listener;
/*    */ 
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ 
/*    */ public class InventoryClickUtil
/*    */ {
/*    */   private InventoryClickEvent event;
/*    */   
/*    */   public InventoryClickUtil(InventoryClickEvent event) {
/* 11 */     this.event = event;
/*    */   }
/*    */   
/*    */   public Inventory getInventory() {
/* 15 */     if (this.event.getWhoClicked().getOpenInventory() == null) {
/* 16 */       return null;
/*    */     }
/* 18 */     return this.event.getWhoClicked().getOpenInventory().getTopInventory();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\listener\InventoryClickUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */