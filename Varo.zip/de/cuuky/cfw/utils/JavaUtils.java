/*     */ package de.cuuky.cfw.utils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ public final class JavaUtils
/*     */ {
/*     */   public static ArrayList<String> addIntoEvery(ArrayList<String> input, String into, boolean start) {
/*  17 */     for (int i = 0; i < input.size(); i++) {
/*  18 */       input.set(i, start ? (String.valueOf(into) + (String)input.get(i)) : (String.valueOf(input.get(i)) + into));
/*     */     }
/*  20 */     return input;
/*     */   }
/*     */   
/*     */   public static String[] addIntoEvery(String[] input, String into, boolean start) {
/*  24 */     for (int i = 0; i < input.length; i++) {
/*  25 */       input[i] = start ? (String.valueOf(into) + input[i]) : (String.valueOf(input[i]) + into);
/*     */     }
/*  27 */     return input;
/*     */   }
/*     */   
/*     */   public static String[] arrayToCollection(List<String> strings) {
/*  31 */     String[] newStrings = new String[strings.size()];
/*     */     
/*  33 */     for (int i = 0; i < strings.size(); i++) {
/*  34 */       newStrings[i] = strings.get(i);
/*     */     }
/*  36 */     return newStrings;
/*     */   }
/*     */   
/*     */   public static ArrayList<String> collectionToArray(String[] strings) {
/*  40 */     ArrayList<String> newStrings = new ArrayList<>(); byte b; int i; String[] arrayOfString;
/*  41 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String string = arrayOfString[b];
/*  42 */       newStrings.add(string); b++; }
/*     */     
/*  44 */     return newStrings;
/*     */   }
/*     */   
/*     */   public static String[] combineArrays(String[]... strings) {
/*  48 */     ArrayList<String> string = new ArrayList<>(); byte b; int i;
/*     */     String[][] arrayOfString;
/*  50 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String[] ss = arrayOfString[b]; byte b1; int j; String[] arrayOfString1;
/*  51 */       for (j = (arrayOfString1 = ss).length, b1 = 0; b1 < j; ) { String strin = arrayOfString1[b1];
/*  52 */         string.add(strin); b1++; }
/*     */        b++; }
/*  54 */      return getAsArray(string);
/*     */   }
/*     */   
/*     */   public static String getArgsToString(ArrayList<String> args, String insertBewteen) {
/*  58 */     String command = "";
/*  59 */     for (String arg : args) {
/*  60 */       if (command.equals("")) {
/*  61 */         command = arg; continue;
/*     */       } 
/*  63 */       command = String.valueOf(command) + insertBewteen + arg;
/*     */     } 
/*  65 */     return command;
/*     */   }
/*     */   
/*     */   public static String getArgsToString(String[] args, String insertBewteen) {
/*  69 */     String command = ""; byte b; int i; String[] arrayOfString;
/*  70 */     for (i = (arrayOfString = args).length, b = 0; b < i; ) { String arg = arrayOfString[b];
/*  71 */       if (command.equals("")) {
/*  72 */         command = arg;
/*     */       } else {
/*  74 */         command = String.valueOf(command) + insertBewteen + arg;
/*     */       }  b++; }
/*  76 */      return command;
/*     */   }
/*     */   
/*     */   public static String[] getAsArray(ArrayList<String> string) {
/*  80 */     String[] list = new String[string.size()];
/*  81 */     for (int i = 0; i < string.size(); i++) {
/*  82 */       list[i] = string.get(i);
/*     */     }
/*  84 */     return list;
/*     */   }
/*     */   
/*     */   public static ArrayList<Object> getAsList(String[] lis) {
/*  88 */     ArrayList<Object> list = new ArrayList(); byte b; int i; String[] arrayOfString;
/*  89 */     for (i = (arrayOfString = lis).length, b = 0; b < i; ) { Object u = arrayOfString[b];
/*  90 */       list.add(u); b++; }
/*     */     
/*  92 */     return list;
/*     */   }
/*     */   
/*     */   public static int getNextToNine(int to) {
/*  96 */     int result = 9 - to % 9 + to;
/*  97 */     return (result > 54) ? 54 : result;
/*     */   }
/*     */   
/*     */   public static Object getStringObject(String obj) {
/*     */     try {
/* 102 */       return Integer.valueOf(Integer.parseInt(obj));
/* 103 */     } catch (NumberFormatException numberFormatException) {
/*     */       
/*     */       try {
/* 106 */         return Long.valueOf(Long.parseLong(obj));
/* 107 */       } catch (NumberFormatException numberFormatException1) {
/*     */         
/*     */         try {
/* 110 */           return Double.valueOf(Double.parseDouble(obj));
/* 111 */         } catch (NumberFormatException numberFormatException2) {
/*     */           
/* 113 */           if (obj.equalsIgnoreCase("true") || obj.equalsIgnoreCase("false")) {
/* 114 */             return Boolean.valueOf(obj.equalsIgnoreCase("true"));
/*     */           }
/* 116 */           return obj;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int randomInt(int min, int max) {
/* 127 */     Random rand = new Random();
/* 128 */     int randomNum = rand.nextInt(max - min + 1) + min;
/*     */     
/* 130 */     return randomNum;
/*     */   }
/*     */   
/*     */   public static String[] removeString(String[] string, int loc) {
/* 134 */     String[] ret = new String[string.length - 1];
/* 135 */     int i = 0;
/* 136 */     boolean removed = false; byte b; int j; String[] arrayOfString1;
/* 137 */     for (j = (arrayOfString1 = string).length, b = 0; b < j; ) { String arg = arrayOfString1[b];
/* 138 */       if (i == loc && !removed) {
/* 139 */         removed = true;
/*     */       }
/*     */       else {
/*     */         
/* 143 */         ret[i] = arg;
/* 144 */         i++;
/*     */       }  b++; }
/*     */     
/* 147 */     return ret;
/*     */   }
/*     */   
/*     */   public static String replaceAllColors(String s) {
/* 151 */     String newMessage = "";
/* 152 */     boolean lastPara = false; byte b; int i; char[] arrayOfChar;
/* 153 */     for (i = (arrayOfChar = s.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/* 154 */       if (lastPara) {
/* 155 */         lastPara = false;
/*     */ 
/*     */       
/*     */       }
/* 159 */       else if (c == '§' || c == '&') {
/* 160 */         lastPara = true;
/*     */       }
/*     */       else {
/*     */         
/* 164 */         newMessage = newMessage.isEmpty() ? String.valueOf(c) : (String.valueOf(newMessage) + c);
/*     */       }  b++; }
/*     */     
/* 167 */     return newMessage;
/*     */   }
/*     */   
/*     */   public static String getCurrentDateAsFileable() {
/* 171 */     DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
/* 172 */     Date date = new Date();
/*     */     
/* 174 */     return dateFormat.format(date); } public static void deleteDirectory(File file) {
/*     */     byte b;
/*     */     int i;
/*     */     File[] arrayOfFile;
/* 178 */     for (i = (arrayOfFile = file.listFiles()).length, b = 0; b < i; ) { File listFile = arrayOfFile[b];
/* 179 */       if (listFile.isDirectory()) {
/* 180 */         deleteDirectory(listFile);
/*     */       }
/* 182 */       listFile.delete();
/*     */       b++; }
/*     */     
/* 185 */     file.delete();
/*     */   }
/*     */   
/*     */   public static <T, Z> LinkedHashMap<T, Z> reverseMap(Map<T, Z> map) {
/* 189 */     LinkedHashMap<T, Z> reversed = new LinkedHashMap<>();
/* 190 */     List<T> keys = new ArrayList<>(map.keySet());
/* 191 */     Collections.reverse(keys);
/*     */     
/* 193 */     for (T key : keys) {
/* 194 */       reversed.put(key, map.get(key));
/*     */     }
/* 196 */     return reversed;
/*     */   }
/*     */   
/*     */   public static String[] countdownToTime(int countdown) {
/* 200 */     String[] time = { String.valueOf(countdown / 60), String.valueOf(countdown % 60) };
/*     */     
/* 202 */     for (int i = 0; i < time.length; i++) {
/* 203 */       if (time[i].length() == 1)
/* 204 */         time[i] = "0" + time[i]; 
/*     */     } 
/* 206 */     return time;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\JavaUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */