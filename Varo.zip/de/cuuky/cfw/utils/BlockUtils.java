/*    */ package de.cuuky.cfw.utils;
/*    */ 
/*    */ import de.cuuky.cfw.version.BukkitVersion;
/*    */ import de.cuuky.cfw.version.VersionUtils;
/*    */ import de.cuuky.cfw.version.types.Materials;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.block.BlockFace;
/*    */ import org.bukkit.block.BlockState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockUtils
/*    */ {
/*    */   private static boolean isGrass(Material type) {
/* 17 */     if (!type.toString().contains("GRASS")) {
/* 18 */       return false;
/*    */     }
/* 20 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_11)) {
/* 21 */       return !type.toString().equals("GRASS");
/*    */     }
/* 23 */     return !type.toString().contains("BLOCK");
/*    */   }
/*    */   
/*    */   public static boolean isAir(Block block) {
/* 27 */     if (block == null) {
/* 28 */       return true;
/*    */     }
/* 30 */     Material type = block.getType();
/* 31 */     return !(!isGrass(type) && type != Material.AIR && Materials.POPPY.parseMaterial() != type && type != Materials.SUNFLOWER.parseMaterial() && type != Materials.LILY_PAD.parseMaterial() && !type.name().contains("LEAVES") && !type.name().contains("WOOD") && type != Materials.SNOW.parseMaterial() && !type.name().contains("GLASS") && type != Materials.VINE.parseMaterial());
/*    */   }
/*    */   
/*    */   public static boolean isSame(Materials mat, Block block) {
/* 35 */     if (mat.getData() == block.getData() && mat.parseMaterial().equals(block.getType())) {
/* 36 */       return true;
/*    */     }
/* 38 */     return false;
/*    */   }
/*    */   
/*    */   public static void setBlock(Block block, Materials mat) {
/* 42 */     block.setType(mat.parseMaterial());
/*    */     
/* 44 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_11)) {
/*    */       try {
/* 46 */         block.getClass().getDeclaredMethod("setData", new Class[] { byte.class }).invoke(block, new Object[] { Byte.valueOf((byte)mat.getData()) });
/* 47 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/* 48 */         e.printStackTrace();
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public static Object getBlockData(Block block, Object from) {
/* 54 */     BlockState blockState = block.getState();
/*    */     try {
/* 56 */       return from.getClass().getMethod("getBlockData", new Class[0]).invoke(from, new Object[0]);
/* 57 */     } catch (NoSuchMethodException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|SecurityException e) {
/* 58 */       return blockState.getData();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static BlockFace getAttachedSignFace(Object sign) {
/* 63 */     BlockFace attachedFace = null;
/*    */     try {
/* 65 */       attachedFace = (BlockFace)sign.getClass().getMethod("getAttachedFace", new Class[0]).invoke(sign, new Object[0]);
/* 66 */     } catch (ClassCastException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*    */       try {
/* 68 */         Object facing = sign.getClass().getMethod("getFacing", new Class[0]).invoke(sign, new Object[0]);
/* 69 */         attachedFace = (BlockFace)facing.getClass().getMethod("getOppositeFace", new Class[0]).invoke(facing, new Object[0]);
/* 70 */       } catch (Exception e2) {
/* 71 */         e2.printStackTrace();
/*    */       } 
/*    */     } 
/*    */     
/* 75 */     return attachedFace;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\BlockUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */