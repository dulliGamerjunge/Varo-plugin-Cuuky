/*    */ package de.cuuky.cfw.utils;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ 
/*    */ public class LocationFormat
/*    */ {
/*    */   private Location location;
/*    */   
/*    */   public LocationFormat(Location location) {
/* 10 */     this.location = location;
/*    */   }
/*    */   
/*    */   public String format(String format) {
/* 14 */     return format.replace("x", String.valueOf(this.location.getBlockX())).replace("y", String.valueOf(this.location.getBlockY())).replace("z", String.valueOf(this.location.getBlockZ())).replace("world", this.location.getWorld().getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\LocationFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */