/*    */ package de.cuuky.cfw.utils;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class BukkitUtils
/*    */ {
/*    */   public static void saveTeleport(Player player, Location location) {
/*  9 */     while (!location.getChunk().isLoaded()) {
/* 10 */       location.getChunk().load();
/*    */     }
/* 12 */     Location blockunder = location.clone().add(0.0D, -1.0D, 0.0D);
/* 13 */     player.sendBlockChange(blockunder, blockunder.getBlock().getType(), (byte)1);
/* 14 */     player.teleport(location.clone().add(0.0D, 1.0D, 0.0D));
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\BukkitUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */