/*    */ package de.cuuky.cfw.utils;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.Date;
/*    */ import java.util.Scanner;
/*    */ import java.util.UUID;
/*    */ import org.json.simple.JSONArray;
/*    */ import org.json.simple.JSONObject;
/*    */ import org.json.simple.JSONValue;
/*    */ 
/*    */ 
/*    */ public final class UUIDUtils
/*    */ {
/*    */   private static UUID getUUIDTime(String name, long time) throws Exception {
/*    */     Scanner scanner;
/* 16 */     if (time == -1L) {
/* 17 */       scanner = new Scanner((new URL("https://api.mojang.com/users/profiles/minecraft/" + name)).openStream());
/*    */     } else {
/* 19 */       scanner = new Scanner((new URL("https://api.mojang.com/users/profiles/minecraft/" + name + "?at=" + String.valueOf(time))).openStream());
/*    */     } 
/*    */     
/* 22 */     String input = scanner.nextLine();
/* 23 */     scanner.close();
/*    */     
/* 25 */     JSONObject UUIDObject = (JSONObject)JSONValue.parseWithException(input);
/* 26 */     String uuidString = UUIDObject.get("id").toString();
/* 27 */     String uuidSeperation = uuidString.replaceFirst("([0-9a-fA-F]{8})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]+)", "$1-$2-$3-$4-$5");
/* 28 */     UUID uuid = UUID.fromString(uuidSeperation);
/* 29 */     return uuid;
/*    */   }
/*    */   
/*    */   public static String getNamesChanged(String name) throws Exception {
/* 33 */     Date Date = new Date();
/* 34 */     long Time = Date.getTime() / 1000L;
/*    */     
/* 36 */     UUID UUIDOld = getUUIDTime(name, Time - 2592000L);
/* 37 */     String uuid = UUIDOld.toString().replace("-", "");
/*    */     
/* 39 */     Scanner scanner = new Scanner((new URL("https://api.mojang.com/user/profiles/" + uuid + "/names")).openStream());
/* 40 */     String input = scanner.nextLine();
/* 41 */     scanner.close();
/*    */     
/* 43 */     JSONArray nameArray = (JSONArray)JSONValue.parseWithException(input);
/* 44 */     String playerSlot = nameArray.get(nameArray.size() - 1).toString();
/* 45 */     JSONObject nameObject = (JSONObject)JSONValue.parseWithException(playerSlot);
/* 46 */     String newName = nameObject.get("name").toString();
/* 47 */     return newName;
/*    */   }
/*    */   
/*    */   public static UUID getUUID(String name) throws Exception {
/* 51 */     return getUUIDTime(name, -1L);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cf\\utils\UUIDUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */