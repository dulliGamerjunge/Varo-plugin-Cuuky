/*     */ package de.cuuky.cfw.menu;
/*     */ 
/*     */ import de.cuuky.cfw.item.ItemBuilder;
/*     */ import de.cuuky.cfw.menu.utils.InventoryItemLink;
/*     */ import de.cuuky.cfw.menu.utils.ItemClickHandler;
/*     */ import de.cuuky.cfw.menu.utils.PageAction;
/*     */ import de.cuuky.cfw.version.BukkitVersion;
/*     */ import de.cuuky.cfw.version.VersionUtils;
/*     */ import de.cuuky.cfw.version.types.Materials;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SuperInventory
/*     */ {
/*     */   protected SuperInventoryManager manager;
/*     */   protected String firstTitle;
/*     */   protected String title;
/*     */   protected List<Integer> modifier;
/*     */   protected Inventory inv;
/*     */   protected Player opener;
/*     */   protected boolean hasMorePages;
/*     */   protected boolean isLastPage;
/*     */   protected boolean homePage;
/*     */   
/*     */   public SuperInventory(String title, Player opener, int size, boolean homePage) {
/*  42 */     this.firstTitle = title;
/*  43 */     this.opener = opener;
/*  44 */     this.page = 1;
/*  45 */     this.homePage = homePage;
/*  46 */     this.size = size;
/*  47 */     this.fillInventory = true;
/*  48 */     this.title = getPageUpdate();
/*  49 */     this.inv = Bukkit.createInventory(null, (size != 54 && this.setModifier) ? (size + 9) : size, getPageUpdate());
/*  50 */     this.itemlinks = new ArrayList<>();
/*     */     
/*  52 */     this.forward = (new ItemBuilder()).displayname("§aForwards").itemstack(new ItemStack(Material.ARROW)).build();
/*  53 */     this.backwards = (new ItemBuilder()).displayname("§cBackwards").itemstack(new ItemStack(Material.ARROW)).build();
/*     */     
/*  55 */     this.modifier = new ArrayList<>(Arrays.asList(new Integer[] { Integer.valueOf(this.inv.getSize() - 1), Integer.valueOf(this.inv.getSize() - 9), Integer.valueOf(this.inv.getSize() - 5) }));
/*     */   }
/*     */   protected boolean ignoreNextClose; protected boolean setModifier; protected boolean fillInventory; protected boolean animations; protected int page; protected int size; protected ItemStack forward; protected ItemStack backwards; private List<InventoryItemLink> itemlinks;
/*     */   private void doAnimation() {
/*  59 */     if (!this.animations) {
/*     */       return;
/*     */     }
/*  62 */     final HashMap<Integer, ItemStack> itemlist = new HashMap<>();
/*  63 */     final int animationInvSize = this.setModifier ? (this.inv.getSize() - 9) : this.inv.getSize(); int i;
/*  64 */     for (i = 0; i < animationInvSize; i++) {
/*  65 */       itemlist.put(Integer.valueOf(i), this.inv.getItem(i));
/*     */     }
/*  67 */     for (i = 0; i < animationInvSize; i++)
/*  68 */       this.inv.setItem(i, null); 
/*  69 */     this.opener.updateInventory();
/*     */     
/*  71 */     final int delay = 600 / getSize();
/*     */     
/*  73 */     this.manager.getOwnerInstance().getServer().getScheduler().scheduleAsyncDelayedTask((Plugin)this.manager.getOwnerInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  77 */             int middle = (int)Math.ceil((itemlist.size() / 2));
/*  78 */             for (int radius = 0; middle + radius != itemlist.size() && 
/*  79 */               SuperInventory.this.isOpen(); radius++) {
/*     */ 
/*     */               
/*     */               try {
/*  83 */                 Thread.sleep(delay);
/*  84 */               } catch (InterruptedException e) {
/*  85 */                 e.printStackTrace();
/*     */               } 
/*     */               
/*  88 */               SuperInventory.this.inv.setItem(middle + radius, (ItemStack)itemlist.get(Integer.valueOf(middle + radius)));
/*  89 */               SuperInventory.this.opener.updateInventory();
/*     */               
/*     */               try {
/*  92 */                 Thread.sleep(delay);
/*  93 */               } catch (InterruptedException e) {
/*  94 */                 e.printStackTrace();
/*     */               } 
/*     */               
/*  97 */               SuperInventory.this.inv.setItem(middle - radius, (ItemStack)itemlist.get(Integer.valueOf(middle - radius)));
/*  98 */               SuperInventory.this.opener.updateInventory();
/*     */             } 
/*     */             
/* 101 */             if (animationInvSize % 2 == 0 && SuperInventory.this.isOpen()) {
/*     */               try {
/* 103 */                 Thread.sleep(delay);
/* 104 */               } catch (InterruptedException e) {
/* 105 */                 e.printStackTrace();
/*     */               } 
/* 107 */               SuperInventory.this.inv.setItem(0, (ItemStack)itemlist.get(Integer.valueOf(0)));
/* 108 */               SuperInventory.this.opener.updateInventory();
/*     */             } 
/*     */           }
/* 111 */         }0L);
/*     */   }
/*     */   
/*     */   private void fillSpace() {
/* 115 */     if (!this.fillInventory) {
/*     */       return;
/*     */     }
/* 118 */     for (int i = 0; i < this.inv.getSize(); i++) {
/* 119 */       if (this.inv.getItem(i) == null) {
/* 120 */         this.inv.setItem(i, (new ItemBuilder()).displayname("§c").itemstack(new ItemStack(Materials.BLACK_STAINED_GLASS_PANE.parseMaterial(), 1, (short)15)).build());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String getBack() {
/* 127 */     if (!this.homePage) {
/* 128 */       return "§4Back";
/*     */     }
/* 130 */     return "§4Close";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPageUpdate() {
/* 137 */     String suff = this.hasMorePages ? (" §7" + this.page) : "";
/* 138 */     return String.valueOf(this.firstTitle) + ((this.firstTitle.length() + suff.length() > 32) ? "" : suff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSwitcher() {
/* 145 */     if (!this.setModifier) {
/*     */       return;
/*     */     }
/* 148 */     this.inv.setItem(((Integer)this.modifier.get(2)).intValue(), (new ItemBuilder()).displayname(getBack()).itemstack(getBack().equals("§4Back") ? new ItemStack(Materials.STONE_BUTTON.parseMaterial()) : Materials.REDSTONE.parseItem()).build());
/* 149 */     if (!this.hasMorePages) {
/*     */       return;
/*     */     }
/* 152 */     if (!this.isLastPage) {
/* 153 */       this.inv.setItem(((Integer)this.modifier.get(0)).intValue(), this.forward);
/*     */     }
/* 155 */     if (this.page != 1)
/* 156 */       this.inv.setItem(((Integer)this.modifier.get(1)).intValue(), this.backwards); 
/*     */   }
/*     */   
/*     */   protected void close(boolean unregister) {
/* 160 */     if (!unregister) {
/* 161 */       this.ignoreNextClose = true;
/*     */     } else {
/* 163 */       this.manager.unregisterInventory(this);
/*     */     } 
/* 165 */     this.opener.closeInventory();
/*     */   }
/*     */   
/*     */   protected void linkItemTo(int location, ItemStack stack) {
/* 169 */     this.inv.setItem(location, stack);
/* 170 */     this.itemlinks.add(new InventoryItemLink(stack, location));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void linkItemTo(int location, ItemStack stack, Runnable runnable) {
/* 177 */     this.inv.setItem(location, stack);
/* 178 */     this.itemlinks.add(new InventoryItemLink(stack, location, runnable));
/*     */   }
/*     */   
/*     */   protected void linkItemTo(int location, ItemStack stack, ItemClickHandler handler) {
/* 182 */     this.inv.setItem(location, stack);
/* 183 */     this.itemlinks.add(new InventoryItemLink(stack, location, handler));
/*     */   }
/*     */   
/*     */   public void back() {
/* 187 */     if (!onBackClick())
/* 188 */       close(true); 
/*     */   }
/*     */   
/*     */   public void clear(boolean all) {
/* 192 */     for (int i = 0; i < (this.inv.getContents()).length; i++) {
/* 193 */       if (!this.modifier.contains(Integer.valueOf(i)) || all)
/*     */       {
/*     */         
/* 196 */         this.inv.setItem(i, new ItemStack(Material.AIR)); } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void closeInventory() {
/* 201 */     if (this.ignoreNextClose) {
/* 202 */       this.ignoreNextClose = false;
/*     */       
/*     */       return;
/*     */     } 
/* 206 */     this.manager.unregisterInventory(this);
/* 207 */     this.opener.closeInventory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeLink(ItemStack item, InventoryClickEvent event) {
/* 214 */     for (InventoryItemLink link : this.itemlinks) {
/* 215 */       if (link.isLink(item, event.getRawSlot())) {
/* 216 */         link.execute(event);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getFixedSize(int size) {
/* 223 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_8)) {
/* 224 */       return (size < 1) ? 1 : ((size > 64) ? 64 : size);
/*     */     }
/* 226 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/* 233 */     if (this.manager == null) {
/* 234 */       throw new IllegalStateException("Cannot open inventory without manager defined");
/*     */     }
/* 236 */     (new BukkitRunnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 240 */           SuperInventory.this.isLastPage = SuperInventory.this.onOpen();
/* 241 */           if (!SuperInventory.this.isLastPage) {
/* 242 */             SuperInventory.this.hasMorePages = true;
/*     */           }
/* 244 */           SuperInventory.this.setSwitcher();
/* 245 */           SuperInventory.this.fillSpace();
/*     */           
/* 247 */           if (SuperInventory.this.opener.getOpenInventory() == null || !SuperInventory.this.opener.getOpenInventory().getTopInventory().equals(SuperInventory.this.inv)) {
/* 248 */             SuperInventory.this.opener.openInventory(SuperInventory.this.inv);
/*     */           }
/* 250 */           SuperInventory.this.doAnimation();
/*     */         }
/* 252 */       }).runTask((Plugin)this.manager.getOwnerInstance());
/*     */   }
/*     */   
/*     */   public void pageActionChanged(PageAction action) {
/* 256 */     onInventoryAction(action);
/*     */   }
/*     */   
/*     */   public void pageBackwards() {
/* 260 */     this.page--;
/* 261 */     updateInventory();
/*     */   }
/*     */   
/*     */   public void pageForwards() {
/* 265 */     this.page++;
/* 266 */     updateInventory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reopenSoon() {
/* 273 */     this.manager.getOwnerInstance().getServer().getScheduler().scheduleSyncDelayedTask((Plugin)this.manager.getOwnerInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 277 */             SuperInventory.this.updateInventory();
/*     */           }
/* 279 */         },  1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateInventory() {
/* 286 */     String title = getPageUpdate();
/* 287 */     if (this.opener.getOpenInventory() != null && !this.title.equals(title)) {
/* 288 */       this.ignoreNextClose = true;
/* 289 */       this.opener.closeInventory();
/* 290 */       Inventory newInv = Bukkit.createInventory(null, (this.size != 54) ? (this.size + 9) : this.size, title);
/* 291 */       this.inv = newInv;
/* 292 */       this.title = title;
/*     */     } 
/*     */     
/* 295 */     this.itemlinks.clear();
/* 296 */     clear(true);
/* 297 */     open();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManager(SuperInventoryManager manager) {
/* 318 */     SuperInventory inv = manager.getInventory(this.opener);
/* 319 */     if (inv != null) {
/* 320 */       inv.close(true);
/*     */     }
/* 322 */     this.manager = manager;
/*     */   }
/*     */   
/*     */   public SuperInventoryManager getManager() {
/* 326 */     return this.manager;
/*     */   }
/*     */   
/*     */   public Inventory getInventory() {
/* 330 */     return this.inv;
/*     */   }
/*     */   
/*     */   public Player getOpener() {
/* 334 */     return this.opener;
/*     */   }
/*     */   
/*     */   public int getPage() {
/* 338 */     return this.page;
/*     */   }
/*     */   
/*     */   public int getSize() {
/* 342 */     return this.size;
/*     */   }
/*     */   
/*     */   public String getTitle() {
/* 346 */     return this.title;
/*     */   }
/*     */   
/*     */   public boolean isHomePage() {
/* 350 */     return this.homePage;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 354 */     return this.manager.getInventories().contains(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int calculatePages(int amount, int pageSize) {
/* 361 */     int res = (int)Math.ceil(amount / pageSize);
/* 362 */     if (res == 0)
/* 363 */       res = 1; 
/* 364 */     return res;
/*     */   }
/*     */   
/*     */   public abstract boolean onBackClick();
/*     */   
/*     */   @Deprecated
/*     */   public abstract void onClick(InventoryClickEvent paramInventoryClickEvent);
/*     */   
/*     */   public abstract void onClose(InventoryCloseEvent paramInventoryCloseEvent);
/*     */   
/*     */   public abstract void onInventoryAction(PageAction paramPageAction);
/*     */   
/*     */   public abstract boolean onOpen();
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\menu\SuperInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */