package de.cuuky.cfw.menu.utils;

import org.bukkit.event.inventory.InventoryClickEvent;

public interface ItemClickHandler {
  void onItemClick(InventoryClickEvent paramInventoryClickEvent);
}


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\men\\utils\ItemClickHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */