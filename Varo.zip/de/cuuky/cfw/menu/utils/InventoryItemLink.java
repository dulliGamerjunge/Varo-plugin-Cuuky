/*    */ package de.cuuky.cfw.menu.utils;
/*    */ 
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class InventoryItemLink
/*    */ {
/*    */   private ItemStack stack;
/*    */   private int slot;
/*    */   private Runnable runnable;
/*    */   private ItemClickHandler clickHandler;
/*    */   
/*    */   public InventoryItemLink(ItemStack stack, int slot) {
/* 14 */     this.stack = stack;
/* 15 */     this.slot = slot;
/*    */   }
/*    */   
/*    */   public InventoryItemLink(ItemStack stack, int slot, Runnable runnable) {
/* 19 */     this(stack, slot);
/*    */     
/* 21 */     this.runnable = runnable;
/*    */   }
/*    */   
/*    */   public InventoryItemLink(ItemStack stack, int slot, ItemClickHandler clickHandler) {
/* 25 */     this(stack, slot);
/*    */     
/* 27 */     this.clickHandler = clickHandler;
/*    */   }
/*    */   
/*    */   public boolean isLink(ItemStack stack, int slot) {
/* 31 */     return (((this.stack.getItemMeta().getDisplayName() == null && stack.getItemMeta().getDisplayName() == null) || this.stack.getItemMeta().getDisplayName().equals(stack.getItemMeta().getDisplayName())) && stack.getDurability() == this.stack.getDurability() && this.slot == slot);
/*    */   }
/*    */   
/*    */   public void execute(InventoryClickEvent event) {
/* 35 */     if (this.runnable != null) {
/* 36 */       this.runnable.run();
/*    */     }
/* 38 */     if (this.clickHandler != null)
/* 39 */       this.clickHandler.onItemClick(event); 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\men\\utils\InventoryItemLink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */