/*     */ package de.cuuky.cfw.menu.utils;
/*     */ 
/*     */ import de.cuuky.cfw.CuukyFrameWork;
/*     */ import de.cuuky.cfw.item.ItemBuilder;
/*     */ import de.cuuky.cfw.utils.JavaUtils;
/*     */ import de.cuuky.cfw.utils.listener.InventoryClickUtil;
/*     */ import de.cuuky.cfw.version.VersionUtils;
/*     */ import de.cuuky.cfw.version.types.Materials;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class PlayerChooseInventory {
/*     */   private CuukyFrameWork instance;
/*     */   private PlayerChooseHandler chooseHandler;
/*     */   private Inventory inv;
/*     */   private PlayerInventoryHandler invHandler;
/*     */   private Listener listener;
/*     */   private int page;
/*     */   private Player player;
/*     */   private Player[] players;
/*     */   private int size;
/*     */   
/*     */   public class PlayerAddEvent {
/*     */     private String displayName;
/*     */     
/*     */     public PlayerAddEvent(Player toAdd) {
/*  34 */       this.toAdd = toAdd;
/*     */     }
/*     */     private String[] lore; private Player toAdd;
/*     */     public String getDisplayName() {
/*  38 */       return this.displayName;
/*     */     }
/*     */     
/*     */     public String[] getLore() {
/*  42 */       return this.lore;
/*     */     }
/*     */     
/*     */     public Player getToAdd() {
/*  46 */       return this.toAdd;
/*     */     }
/*     */     
/*     */     public void setDisplayName(String displayName) {
/*  50 */       this.displayName = displayName;
/*     */     }
/*     */     
/*     */     public void setLore(String[] lore) {
/*  54 */       this.lore = lore;
/*     */     }
/*     */   }
/*     */   
/*     */   public class PlayerChooseEvent
/*     */   {
/*     */     private boolean all;
/*     */     private Player choosen;
/*     */     
/*     */     public PlayerChooseEvent(Player choosen, boolean all) {
/*  64 */       this.choosen = choosen;
/*     */     }
/*     */     
/*     */     public boolean chosenAll() {
/*  68 */       return this.all;
/*     */     }
/*     */     
/*     */     public Player getChoosen() {
/*  72 */       return this.choosen;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlayerChooseInventory(Player player, Player[] players, PlayerChooseHandler handler, CuukyFrameWork instance) {
/* 105 */     this(player, players, handler, null, instance);
/*     */   }
/*     */   
/*     */   public PlayerChooseInventory(Player player, Player[] players, PlayerChooseHandler handler, PlayerInventoryHandler invHandler, CuukyFrameWork instance) {
/* 109 */     this.player = player;
/* 110 */     this.chooseHandler = handler;
/* 111 */     this.size = 54;
/* 112 */     this.page = 1;
/* 113 */     this.invHandler = invHandler;
/* 114 */     this.players = players;
/* 115 */     this.instance = instance;
/*     */     
/* 117 */     addListener(handler);
/*     */     
/* 119 */     open();
/*     */   }
/*     */   
/*     */   private void addListener(final PlayerChooseHandler handler) {
/* 123 */     this.listener = new Listener()
/*     */       {
/*     */         @EventHandler
/*     */         public void onInventoryClick(InventoryClickEvent event) {
/* 127 */           Inventory inventory = (new InventoryClickUtil(event)).getInventory();
/* 128 */           if (inventory == null || event.getCurrentItem() == null || event.getCurrentItem().getItemMeta() == null || event.getCurrentItem().getItemMeta().getDisplayName() == null) {
/*     */             return;
/*     */           }
/* 131 */           if (!PlayerChooseInventory.this.inv.equals(event.getInventory())) {
/*     */             return;
/*     */           }
/* 134 */           String displayname = event.getCurrentItem().getItemMeta().getDisplayName();
/*     */           
/* 136 */           if (displayname.contains("Backwards") || displayname.contains("Forwards")) {
/* 137 */             PlayerChooseInventory.this.page = displayname.contains("Backwards") ? (Integer.valueOf(displayname.split("| ")[1]).intValue() - 1) : (Integer.valueOf(displayname.split("§8| §7")[1]).intValue() + 1);
/* 138 */             PlayerChooseInventory.this.open();
/*     */             
/*     */             return;
/*     */           } 
/* 142 */           event.setCancelled(true);
/*     */           
/* 144 */           Player choosen = PlayerChooseInventory.this.instance.getPluginInstance().getServer().getPlayerExact(displayname.replaceFirst("§c", ""));
/* 145 */           handler.onPlayerChoose(new PlayerChooseInventory.PlayerChooseEvent(choosen, displayname.equals("§aChoose all")));
/*     */           
/* 147 */           PlayerChooseInventory.this.player.closeInventory();
/*     */         }
/*     */         
/*     */         @EventHandler
/*     */         public void onInventoryClose(InventoryCloseEvent event) {
/* 152 */           if (!PlayerChooseInventory.this.inv.equals(event.getInventory())) {
/*     */             return;
/*     */           }
/* 155 */           handler.onPlayerChoose(new PlayerChooseInventory.PlayerChooseEvent(null, false));
/*     */         }
/*     */       };
/*     */     
/* 159 */     this.instance.getPluginInstance().getServer().getPluginManager().registerEvents(this.listener, (Plugin)this.instance.getPluginInstance());
/*     */   }
/*     */   
/*     */   private void open() {
/* 163 */     this.inv = Bukkit.createInventory(null, 54, "§cChoose a player §8| §7" + this.page);
/*     */     
/* 165 */     int start = this.size * (this.page - 1);
/* 166 */     boolean notEnough = false;
/* 167 */     Player[] players = (this.players != null) ? this.players : (Player[])VersionUtils.getOnlinePlayer().toArray();
/* 168 */     for (int i = 0; i != this.size - 3; i++) {
/*     */       Player player;
/*     */       
/*     */       try {
/* 172 */         player = players[start];
/* 173 */       } catch (IndexOutOfBoundsException e) {
/*     */         break;
/*     */       } 
/*     */       
/* 177 */       ItemStack stack = (new ItemBuilder()).player(player).build();
/* 178 */       if (this.invHandler != null) {
/* 179 */         PlayerAddEvent event = new PlayerAddEvent(player);
/* 180 */         this.invHandler.onPlayerInventoryAdd(event);
/* 181 */         if (event.getDisplayName() != null) {
/* 182 */           stack.getItemMeta().setDisplayName(event.getDisplayName());
/*     */         }
/* 184 */         if (event.getLore() != null) {
/* 185 */           stack.getItemMeta().setLore(JavaUtils.collectionToArray(event.getLore()));
/*     */         }
/*     */       } 
/* 188 */       this.inv.setItem(start, stack);
/* 189 */       start++;
/*     */       
/* 191 */       if (start == this.size - 3) {
/* 192 */         notEnough = true;
/*     */       }
/*     */     } 
/* 195 */     this.inv.setItem(51, (new ItemBuilder()).displayname("§aChoose all").itemstack(new ItemStack(Materials.SKELETON_SKULL.parseMaterial())).build());
/*     */     
/* 197 */     if (notEnough) {
/* 198 */       this.inv.setItem(53, (new ItemBuilder()).displayname("§aForwards").itemstack((new ItemBuilder()).playername("MHF_ArrowRight").buildSkull()).build());
/*     */     }
/* 200 */     if (this.page != 1) {
/* 201 */       this.inv.setItem(52, (new ItemBuilder()).displayname("§cBackwards").itemstack((new ItemBuilder()).playername("MHF_ArrowLeft").buildSkull()).build());
/*     */     }
/* 203 */     this.player.openInventory(this.inv);
/*     */   }
/*     */   
/*     */   public static interface PlayerChooseHandler {
/*     */     void onPlayerChoose(PlayerChooseInventory.PlayerChooseEvent param1PlayerChooseEvent);
/*     */   }
/*     */   
/*     */   public static interface PlayerInventoryHandler {
/*     */     void onPlayerInventoryAdd(PlayerChooseInventory.PlayerAddEvent param1PlayerAddEvent);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\men\\utils\PlayerChooseInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */