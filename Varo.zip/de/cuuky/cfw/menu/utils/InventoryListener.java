/*    */ package de.cuuky.cfw.menu.utils;
/*    */ 
/*    */ import de.cuuky.cfw.menu.SuperInventory;
/*    */ import de.cuuky.cfw.menu.SuperInventoryManager;
/*    */ import de.cuuky.cfw.utils.listener.InventoryClickUtil;
/*    */ import de.cuuky.cfw.version.types.Sounds;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ 
/*    */ public class InventoryListener
/*    */   implements Listener
/*    */ {
/*    */   private SuperInventoryManager inventoryManager;
/*    */   
/*    */   public InventoryListener(SuperInventoryManager inventoryManager) {
/* 20 */     this.inventoryManager = inventoryManager;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onInvClick(InventoryClickEvent event) {
/* 25 */     Inventory inventory = (new InventoryClickUtil(event)).getInventory();
/* 26 */     if (inventory == null || event.getCurrentItem() == null || event.getCurrentItem().getItemMeta() == null || event.getCurrentItem().getItemMeta().getDisplayName() == null) {
/*    */       return;
/*    */     }
/* 29 */     Player player = (Player)event.getWhoClicked();
/* 30 */     String itemName = event.getCurrentItem().getItemMeta().getDisplayName();
/*    */     
/* 32 */     for (int i = 0; i < this.inventoryManager.getInventories().size(); ) {
/* 33 */       SuperInventory inv = this.inventoryManager.getInventories().get(i);
/* 34 */       if (!inv.getInventory().equals(inventory)) {
/*    */         i++; continue;
/*    */       } 
/* 37 */       player.playSound(player.getLocation(), Sounds.CLICK.bukkitSound(), 1.0F, 1.0F);
/* 38 */       event.setCancelled(true);
/* 39 */       if (itemName.equals("§c"))
/*    */         return; 
/*    */       String str;
/* 42 */       switch ((str = itemName).hashCode()) { case -1434450680: if (!str.equals("§aForwards"))
/*    */             break; 
/* 44 */           inv.pageForwards();
/* 45 */           inv.pageActionChanged(PageAction.PAGE_SWITCH_FORWARDS);
/*    */           return;
/*    */         
/*    */         case -556821109:
/*    */           if (!str.equals("§4Close")) {
/*    */             break;
/*    */           }
/* 52 */           inv.closeInventory(); return;
/*    */         case 536186612:
/*    */           if (!str.equals("§4Back"))
/*    */             break; 
/* 56 */           inv.back(); return;
/*    */         case 1642605492:
/*    */           if (!str.equals("§cBackwards"))
/*    */             break;  inv.pageBackwards(); inv.pageActionChanged(PageAction.PAGE_SWITCH_FORWARDS);
/*    */           return; }
/*    */       
/* 62 */       inv.executeLink(event.getCurrentItem(), event);
/* 63 */       inv.onClick(event);
/*    */       break;
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onInvClose(InventoryCloseEvent event) {
/* 70 */     if (event.getInventory() == null) {
/*    */       return;
/*    */     }
/* 73 */     SuperInventory inv1 = null;
/* 74 */     for (SuperInventory inv : this.inventoryManager.getInventories()) {
/* 75 */       if (!inv.getInventory().equals(event.getInventory())) {
/*    */         continue;
/*    */       }
/* 78 */       inv1 = inv;
/*    */       
/*    */       break;
/*    */     } 
/* 82 */     if (inv1 != null) {
/* 83 */       inv1.onClose(event);
/* 84 */       inv1.closeInventory();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\men\\utils\InventoryListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */