/*   */ package de.cuuky.cfw.menu.utils;
/*   */ 
/*   */ public enum PageAction
/*   */ {
/* 5 */   PAGE_SWITCH_BACKWARDS,
/* 6 */   PAGE_SWITCH_FORWARDS;
/*   */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\men\\utils\PageAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */