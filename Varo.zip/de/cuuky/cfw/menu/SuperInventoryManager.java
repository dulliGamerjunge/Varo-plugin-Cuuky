/*    */ package de.cuuky.cfw.menu;
/*    */ 
/*    */ import de.cuuky.cfw.manager.FrameworkManager;
/*    */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*    */ import de.cuuky.cfw.menu.utils.InventoryListener;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class SuperInventoryManager
/*    */   extends FrameworkManager {
/*    */   private List<SuperInventory> inventories;
/*    */   
/*    */   public SuperInventoryManager(JavaPlugin instance) {
/* 18 */     super(FrameworkManagerType.INVENTORY, instance);
/*    */     
/* 20 */     this.inventories = new ArrayList<>();
/* 21 */     this.ownerInstance.getServer().getPluginManager().registerEvents((Listener)new InventoryListener(this), (Plugin)this.ownerInstance);
/*    */   }
/*    */   
/*    */   public void updateInventories(Class<? extends SuperInventory> type) {
/* 25 */     for (SuperInventory inventory : this.inventories) {
/* 26 */       if (inventory.getClass().equals(type))
/* 27 */         inventory.updateInventory(); 
/*    */     } 
/*    */   }
/*    */   public SuperInventory registerInventory(SuperInventory inventory) {
/* 31 */     inventory.setManager(this);
/* 32 */     this.inventories.add(inventory);
/* 33 */     return inventory;
/*    */   }
/*    */   
/*    */   public boolean unregisterInventory(SuperInventory inventory) {
/* 37 */     return this.inventories.remove(inventory);
/*    */   }
/*    */   
/*    */   public void closeInventories() {
/* 41 */     for (int i = this.inventories.size() - 1; i > -1; i--)
/* 42 */       ((SuperInventory)this.inventories.get(i)).close(true); 
/*    */   }
/*    */   
/*    */   public List<SuperInventory> getInventories() {
/* 46 */     return this.inventories;
/*    */   }
/*    */   
/*    */   public SuperInventory getInventory(Player player) {
/* 50 */     for (SuperInventory inventory : this.inventories) {
/* 51 */       if (inventory.getOpener().equals(player))
/* 52 */         return inventory; 
/*    */     } 
/* 54 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\menu\SuperInventoryManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */