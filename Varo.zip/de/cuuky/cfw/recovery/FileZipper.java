/*     */ package de.cuuky.cfw.recovery;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ 
/*     */ public class FileZipper
/*     */ {
/*     */   private static final int BUFFER_SIZE = 4096;
/*     */   protected File zipFile;
/*     */   
/*     */   public FileZipper(File zipFile) {
/*  23 */     this.zipFile = zipFile;
/*     */   }
/*     */   
/*     */   private void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
/*  27 */     File oldFile = new File(filePath);
/*  28 */     if (oldFile.exists()) {
/*  29 */       oldFile.delete();
/*     */     }
/*  31 */     BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
/*  32 */     byte[] bytesIn = new byte[4096];
/*  33 */     int read = 0;
/*  34 */     while ((read = zipIn.read(bytesIn)) != -1) {
/*  35 */       bos.write(bytesIn, 0, read);
/*     */     }
/*  37 */     bos.close();
/*     */   }
/*     */   
/*     */   private void zipFile(File file, ZipOutputStream outputStream, Path root) {
/*  41 */     if (file.getName().endsWith(".zip")) {
/*     */       return;
/*     */     }
/*     */     try {
/*  45 */       Path orgPath = Paths.get(file.getPath(), new String[0]);
/*  46 */       Path zipFilePath = root.relativize(orgPath);
/*     */       
/*  48 */       outputStream.putNextEntry(new ZipEntry(zipFilePath.toString()));
/*  49 */       byte[] buffer = Files.readAllBytes(orgPath);
/*  50 */       outputStream.write(buffer, 0, buffer.length);
/*  51 */       outputStream.closeEntry();
/*  52 */     } catch (Exception e) {
/*  53 */       e.printStackTrace();
/*     */     }  } private void zipFolder(File file, ZipOutputStream outputStream, Path root) {
/*     */     byte b;
/*     */     int i;
/*     */     File[] arrayOfFile;
/*  58 */     for (i = (arrayOfFile = file.listFiles()).length, b = 0; b < i; ) { File toZip = arrayOfFile[b];
/*  59 */       if (toZip.isFile()) {
/*  60 */         zipFile(toZip, outputStream, root);
/*     */       } else {
/*  62 */         zipFolder(toZip, outputStream, root);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   } public void zip(ArrayList<File> files, Path rootFrom) {
/*     */     try {
/*  68 */       File file1 = new File(this.zipFile.getParent());
/*  69 */       if (!file1.isDirectory())
/*  70 */         file1.mkdirs(); 
/*  71 */       if (!this.zipFile.exists())
/*  72 */         this.zipFile.createNewFile(); 
/*  73 */     } catch (IOException e1) {
/*  74 */       e1.printStackTrace();
/*     */     } 
/*     */     
/*  77 */     String zipFileName = this.zipFile.getPath();
/*     */     try {
/*  79 */       FileOutputStream fileoutputStream = null;
/*  80 */       ZipOutputStream outputStream = new ZipOutputStream(fileoutputStream = new FileOutputStream(zipFileName));
/*     */       
/*  82 */       for (File toZip : files) {
/*  83 */         if (toZip.isFile()) {
/*  84 */           zipFile(toZip, outputStream, rootFrom); continue;
/*     */         } 
/*  86 */         zipFolder(toZip, outputStream, rootFrom);
/*     */       } 
/*  88 */       outputStream.close();
/*  89 */       fileoutputStream.close();
/*  90 */     } catch (IOException e) {
/*  91 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean unzip(String destDirectory) {
/*     */     try {
/*  97 */       File destDir = new File(destDirectory);
/*  98 */       if (!destDir.exists())
/*  99 */         destDir.mkdir(); 
/* 100 */       ZipInputStream zipIn = new ZipInputStream(new FileInputStream(this.zipFile));
/* 101 */       ZipEntry entry = zipIn.getNextEntry();
/* 102 */       while (entry != null) {
/* 103 */         String filePath = String.valueOf(destDirectory) + File.separator + entry.getName();
/* 104 */         if (!entry.isDirectory()) {
/* 105 */           extractFile(zipIn, filePath);
/*     */         } else {
/* 107 */           File dir = new File(filePath);
/* 108 */           dir.mkdir();
/*     */         } 
/* 110 */         zipIn.closeEntry();
/* 111 */         entry = zipIn.getNextEntry();
/*     */       } 
/* 113 */       zipIn.close();
/* 114 */       return true;
/* 115 */     } catch (Exception e) {
/* 116 */       e.printStackTrace();
/* 117 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public File getZipFile() {
/* 122 */     return this.zipFile;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\recovery\FileZipper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */