/*    */ package de.cuuky.cfw.recovery;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import org.json.simple.JSONObject;
/*    */ import org.json.simple.JSONValue;
/*    */ 
/*    */ 
/*    */ public class FileUploader
/*    */ {
/*    */   private static final String UPLOAD_URL = "https://api.anonfile.com/upload?token=894b0ea821338221";
/*    */   private static final String LINE_FEED = "\r\n";
/*    */   private File file;
/*    */   
/*    */   public FileUploader(File file) {
/* 24 */     this.file = file;
/*    */   }
/*    */   
/*    */   private JSONObject getJSONObject(JSONObject object, String path) {
/* 28 */     return (JSONObject)object.get(path);
/*    */   }
/*    */   
/*    */   private String uploadToServer(String link) {
/*    */     try {
/* 33 */       String boundary = "===" + System.currentTimeMillis() + "===";
/*    */       
/* 35 */       URL url = new URL("https://api.anonfile.com/upload?token=894b0ea821338221");
/* 36 */       HttpURLConnection connection = (HttpURLConnection)url.openConnection();
/* 37 */       connection.setUseCaches(false);
/* 38 */       connection.setDoOutput(true);
/* 39 */       connection.setDoInput(true);
/* 40 */       connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
/* 41 */       connection.setRequestProperty("User-Agent", "CFW - CuukyFrameWork");
/*    */       
/* 43 */       OutputStream out = connection.getOutputStream();
/* 44 */       PrintWriter writer = new PrintWriter(new OutputStreamWriter(out, "UTF-8"), true);
/*    */       
/* 46 */       writer.append("--" + boundary).append("\r\n");
/* 47 */       writer.append("Content-Disposition: form-data; name=\"file\"; filename=\"" + this.file.getName() + "\"").append("\r\n");
/* 48 */       writer.append("Content-Type: " + URLConnection.guessContentTypeFromName(this.file.getName())).append("\r\n");
/* 49 */       writer.append("Content-Transfer-Encoding: binary").append("\r\n");
/* 50 */       writer.append("\r\n");
/* 51 */       writer.flush();
/*    */       
/* 53 */       FileInputStream inputStream = new FileInputStream(this.file);
/* 54 */       byte[] buffer = new byte[4096];
/* 55 */       int bytesRead = -1;
/* 56 */       while ((bytesRead = inputStream.read(buffer)) != -1) {
/* 57 */         out.write(buffer, 0, bytesRead);
/*    */       }
/* 59 */       out.flush();
/* 60 */       inputStream.close();
/*    */       
/* 62 */       writer.append("\r\n");
/* 63 */       writer.flush();
/*    */       
/* 65 */       writer.append("\r\n").flush();
/* 66 */       writer.append("--" + boundary + "--").append("\r\n");
/* 67 */       writer.close();
/*    */       
/* 69 */       if (connection.getResponseCode() != 200) {
/* 70 */         return null;
/*    */       }
/* 72 */       return (new BufferedReader(new InputStreamReader(connection.getInputStream()))).readLine();
/* 73 */     } catch (Exception e) {
/* 74 */       e.printStackTrace();
/*    */ 
/*    */       
/* 77 */       return null;
/*    */     } 
/*    */   }
/*    */   public String uploadFile(String link) {
/*    */     try {
/* 82 */       String response = uploadToServer(link);
/*    */       
/* 84 */       if (response == null) {
/* 85 */         return null;
/*    */       }
/* 87 */       JSONObject object = (JSONObject)JSONValue.parseWithException(response);
/* 88 */       return (String)getJSONObject(getJSONObject(getJSONObject(object, "data"), "file"), "url").get("short");
/* 89 */     } catch (Exception e) {
/* 90 */       e.printStackTrace();
/*    */ 
/*    */       
/* 93 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\recovery\FileUploader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */