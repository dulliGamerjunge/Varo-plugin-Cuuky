package de.cuuky.cfw.configuration.language.languages;

import de.cuuky.cfw.player.CustomPlayer;

public interface DefaultLanguage extends LoadableMessage {
  String getValue();
  
  String getValue(CustomPlayer paramCustomPlayer);
  
  String getValue(CustomPlayer paramCustomPlayer1, CustomPlayer paramCustomPlayer2);
}


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\language\languages\DefaultLanguage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */