/*    */ package de.cuuky.cfw.configuration.language.broadcast;
/*    */ 
/*    */ import de.cuuky.cfw.configuration.placeholder.MessagePlaceholderManager;
/*    */ import de.cuuky.cfw.configuration.placeholder.placeholder.type.MessagePlaceholderType;
/*    */ import de.cuuky.cfw.configuration.placeholder.placeholder.type.PlaceholderType;
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MessageHolder
/*    */ {
/*    */   private MessagePlaceholderManager placeholderManager;
/*    */   private Map<String, String> replacements;
/*    */   
/*    */   public MessageHolder(MessagePlaceholderManager manager) {
/* 16 */     this.placeholderManager = manager;
/* 17 */     this.replacements = new HashMap<>();
/*    */   }
/*    */   
/*    */   public MessageHolder replace(String needle, String replacement) {
/* 21 */     this.replacements.put(needle, replacement);
/* 22 */     return this;
/*    */   }
/*    */   
/*    */   public String getReplaced(String message, CustomPlayer cp) {
/* 26 */     for (String repl : this.replacements.keySet()) {
/* 27 */       message = message.replace(repl, this.replacements.get(repl));
/*    */     }
/* 29 */     message = this.placeholderManager.replacePlaceholders(message, (PlaceholderType)MessagePlaceholderType.GENERAL);
/* 30 */     if (cp != null)
/* 31 */       message = this.placeholderManager.replacePlaceholders(message, cp, (PlaceholderType)MessagePlaceholderType.PLAYER); 
/* 32 */     return message;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\language\broadcast\MessageHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */