/*     */ package de.cuuky.cfw.configuration.language;
/*     */ 
/*     */ import de.cuuky.cfw.configuration.language.broadcast.MessageHolder;
/*     */ import de.cuuky.cfw.configuration.language.languages.LoadableMessage;
/*     */ import de.cuuky.cfw.configuration.placeholder.MessagePlaceholderManager;
/*     */ import de.cuuky.cfw.manager.FrameworkManager;
/*     */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*     */ import de.cuuky.cfw.player.CustomLanguagePlayer;
/*     */ import de.cuuky.cfw.player.CustomPlayer;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class LanguageManager
/*     */   extends FrameworkManager
/*     */ {
/*     */   private String languagePath;
/*     */   private String fallbackLocale;
/*     */   private Language defaultLanguage;
/*     */   private Map<String, Language> languages;
/*     */   private Map<String, String> defaultMessages;
/*     */   
/*     */   public LanguageManager(JavaPlugin instance) {
/*  27 */     this("plugins/" + instance.getName() + "/languages/", "en_us", instance);
/*     */   }
/*     */   
/*     */   public LanguageManager(String languagesPath, String fallbackLocale, JavaPlugin instance) {
/*  31 */     super(FrameworkManagerType.LANGUAGE, instance);
/*     */     
/*  33 */     this.languagePath = languagesPath;
/*  34 */     this.fallbackLocale = fallbackLocale;
/*  35 */     this.languages = new HashMap<>();
/*  36 */     this.defaultMessages = new HashMap<>();
/*     */   }
/*     */   
/*     */   public String getMessage(String messagePath, String locale) {
/*  40 */     if (locale == null) {
/*  41 */       return this.defaultLanguage.getMessage(messagePath);
/*     */     }
/*  43 */     Language language = this.languages.get(locale);
/*  44 */     String message = null;
/*     */     
/*  46 */     if (language == null) {
/*  47 */       message = (language = this.defaultLanguage).getMessage(messagePath);
/*     */     } else {
/*  49 */       message = language.getMessage(messagePath);
/*     */       
/*  51 */       if (message == null) {
/*  52 */         message = (language = this.defaultLanguage).getMessage(messagePath);
/*     */       }
/*     */     } 
/*  55 */     if (message == null) {
/*  56 */       message = ((Language)this.languages.get(this.fallbackLocale)).getMessage(messagePath);
/*     */     }
/*  58 */     return message;
/*     */   }
/*     */ 
/*     */   
/*     */   public Language registerLanguage(String name) {
/*  63 */     return registerLoadableLanguage(name, null);
/*     */   }
/*     */   
/*     */   public Language registerLoadableLanguage(String name, Class<? extends LoadableMessage> clazz) {
/*  67 */     Language language = null;
/*  68 */     this.languages.put(name, language = new Language(name, this, clazz));
/*     */     
/*  70 */     return language;
/*     */   }
/*     */   
/*     */   public void setDefaultLanguage(Language defaultLanguage) {
/*  74 */     this.defaultLanguage = defaultLanguage;
/*  75 */     this.defaultMessages = getValues(defaultLanguage.getClazz());
/*     */     
/*  77 */     this.defaultLanguage.load();
/*  78 */     for (Language lang : this.languages.values()) {
/*  79 */       if (!lang.isLoaded() && !lang.getFile().exists())
/*  80 */         lang.load(); 
/*     */     } 
/*     */   }
/*     */   public HashMap<String, String> getValues(Class<? extends LoadableMessage> clazz) {
/*  84 */     HashMap<String, String> values = new HashMap<>();
/*  85 */     LoadableMessage[] messages = null;
/*     */     
/*     */     try {
/*  88 */       messages = (LoadableMessage[])clazz.getMethod("values", new Class[0]).invoke(null, new Object[0]);
/*  89 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*  90 */       e.printStackTrace();
/*  91 */       return null;
/*     */     }  byte b; int i;
/*     */     LoadableMessage[] arrayOfLoadableMessage1;
/*  94 */     for (i = (arrayOfLoadableMessage1 = messages).length, b = 0; b < i; ) { LoadableMessage lm = arrayOfLoadableMessage1[b];
/*  95 */       values.put(lm.getPath(), lm.getDefaultMessage()); b++; }
/*     */     
/*  97 */     return values;
/*     */   }
/*     */   
/*     */   public void loadLanguages() {
/* 101 */     File file = new File(this.languagePath);
/* 102 */     if (!file.isDirectory())
/* 103 */       file.mkdir();  byte b; int i;
/*     */     File[] arrayOfFile;
/* 105 */     for (i = (arrayOfFile = file.listFiles()).length, b = 0; b < i; ) { File listFile = arrayOfFile[b];
/* 106 */       if (listFile.getName().endsWith(".yml") && !this.languages.containsKey(listFile.getName().replace(".yml", "")))
/*     */       {
/*     */         
/* 109 */         registerLanguage(listFile.getName().replace(".yml", "")); } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public MessageHolder broadcastMessage(final LoadableMessage message, final CustomPlayer replace, MessagePlaceholderManager placeholderManager, final ArrayList<CustomLanguagePlayer> players) {
/* 114 */     final MessageHolder holder = new MessageHolder(placeholderManager);
/* 115 */     this.ownerInstance.getServer().getScheduler().scheduleSyncDelayedTask((Plugin)this.ownerInstance, new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 119 */             LanguageManager.this.ownerInstance.getServer().getConsoleSender().sendMessage(holder.getReplaced(LanguageManager.this.getMessage(message.getPath(), LanguageManager.this.defaultLanguage.getName()), replace));
/* 120 */             for (CustomLanguagePlayer player : players) {
/* 121 */               if (player.getPlayer() != null)
/* 122 */                 player.getPlayer().sendMessage(holder.getReplaced(LanguageManager.this.getMessage(message.getPath(), player.getLocale()), (replace != null) ? replace : (CustomPlayer)player)); 
/*     */             }  }
/* 124 */         }1L);
/*     */     
/* 126 */     return holder;
/*     */   }
/*     */   
/*     */   public String getLanguagePath() {
/* 130 */     return this.languagePath;
/*     */   }
/*     */   
/*     */   public Language getDefaultLanguage() {
/* 134 */     return this.defaultLanguage;
/*     */   }
/*     */   
/*     */   public Map<String, String> getDefaultMessages() {
/* 138 */     return this.defaultMessages;
/*     */   }
/*     */   
/*     */   public Map<String, Language> getLanguages() {
/* 142 */     return this.languages;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\language\LanguageManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */