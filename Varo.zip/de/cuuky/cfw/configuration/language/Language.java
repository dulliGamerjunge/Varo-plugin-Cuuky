/*     */ package de.cuuky.cfw.configuration.language;
/*     */ 
/*     */ import de.cuuky.cfw.configuration.language.languages.LoadableMessage;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Language
/*     */ {
/*     */   private String name;
/*     */   private LanguageManager manager;
/*     */   private boolean loaded;
/*     */   private File file;
/*     */   private YamlConfiguration configuration;
/*     */   private Class<? extends LoadableMessage> clazz;
/*     */   private Map<String, String> messages;
/*     */   
/*     */   public Language(String name, LanguageManager manager) {
/*  24 */     this(name, manager, null);
/*     */   }
/*     */   
/*     */   public Language(String name, LanguageManager manager, Class<? extends LoadableMessage> clazz) {
/*  28 */     this.name = name;
/*  29 */     this.clazz = clazz;
/*  30 */     this.manager = manager;
/*  31 */     this.messages = new HashMap<>();
/*  32 */     this.file = new File(manager.getLanguagePath(), String.valueOf(this.name) + ".yml");
/*     */     
/*  34 */     if (manager.getDefaultLanguage() != null && !this.file.exists())
/*  35 */       load(); 
/*     */   }
/*     */   
/*     */   private void saveConfiguration() {
/*     */     try {
/*  40 */       this.configuration.save(this.file);
/*  41 */     } catch (Exception e) {
/*  42 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void load() {
/*  47 */     if (this.manager.getDefaultLanguage() == null) {
/*  48 */       throw new IllegalStateException("Cannot load language while no default language is given");
/*     */     }
/*  50 */     this.configuration = YamlConfiguration.loadConfiguration(this.file);
/*  51 */     this.configuration.options().copyDefaults(true);
/*     */     
/*  53 */     boolean save = this.file.exists();
/*  54 */     HashMap<String, String> msg = new HashMap<>();
/*  55 */     if (this.clazz != null) {
/*  56 */       msg = this.manager.getValues(this.clazz);
/*     */     }
/*  58 */     for (String defaultPath : this.manager.getDefaultMessages().keySet()) {
/*  59 */       if (this.configuration.contains(defaultPath)) {
/*     */         continue;
/*     */       }
/*  62 */       save = true;
/*  63 */       String defaultValue = this.manager.getDefaultMessages().get(defaultPath);
/*  64 */       String value = msg.containsKey(defaultPath) ? msg.get(defaultPath) : defaultValue;
/*  65 */       this.configuration.addDefault(defaultPath, value);
/*     */     } 
/*     */     
/*  68 */     for (String path : this.configuration.getKeys(true)) {
/*  69 */       if (this.configuration.isConfigurationSection(path)) {
/*     */         continue;
/*     */       }
/*  72 */       if (!this.manager.getDefaultMessages().keySet().contains(path)) {
/*  73 */         save = true;
/*  74 */         System.out.println("Removed lang path " + path);
/*  75 */         this.configuration.set(path, null);
/*     */         
/*     */         continue;
/*     */       } 
/*  79 */       this.messages.put(path, this.configuration.getString(path));
/*     */     } 
/*     */     
/*  82 */     if (save) {
/*  83 */       saveConfiguration();
/*     */     }
/*  85 */     this.loaded = true;
/*     */   }
/*     */   
/*     */   public String getMessage(String path) {
/*  89 */     if (!this.loaded) {
/*  90 */       load();
/*     */     }
/*  92 */     return this.messages.get(path);
/*     */   }
/*     */   
/*     */   public Class<? extends LoadableMessage> getClazz() {
/*  96 */     return this.clazz;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 100 */     return this.name;
/*     */   }
/*     */   
/*     */   public File getFile() {
/* 104 */     return this.file;
/*     */   }
/*     */   
/*     */   public boolean isLoaded() {
/* 108 */     return this.loaded;
/*     */   }
/*     */   
/*     */   public Map<String, String> getMessages() {
/* 112 */     return this.messages;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\language\Language.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */