/*    */ package de.cuuky.cfw.configuration.placeholder;
/*    */ 
/*    */ import de.cuuky.cfw.configuration.placeholder.placeholder.type.PlaceholderType;
/*    */ 
/*    */ public abstract class MessagePlaceholder {
/*    */   private static final int TICK_TOLERANCE = 900;
/*    */   protected PlaceholderType type;
/*    */   protected String identifier;
/*    */   protected String description;
/*    */   protected int defaultRefresh;
/*    */   protected int refreshDelay;
/*    */   protected MessagePlaceholderManager managar;
/*    */   
/*    */   public MessagePlaceholder(PlaceholderType type, String identifier, int refreshDelay, String description) {
/* 15 */     this(type, identifier, refreshDelay, false, description);
/*    */   }
/*    */   
/*    */   public MessagePlaceholder(PlaceholderType type, String identifier, int refreshDelay, boolean rawIdentifier, String description) {
/* 19 */     this.type = type;
/*    */     
/* 21 */     if (rawIdentifier) {
/* 22 */       this.identifier = identifier;
/*    */     } else {
/* 24 */       this.identifier = "%" + identifier + "%";
/*    */     } 
/* 26 */     this.description = description;
/* 27 */     this.defaultRefresh = refreshDelay;
/* 28 */     this.refreshDelay = refreshDelay * 1000;
/*    */   }
/*    */   
/*    */   protected boolean shallRefresh(long last) {
/* 32 */     if (last < 1L) {
/* 33 */       return true;
/*    */     }
/* 35 */     return (last + this.refreshDelay - 900L <= System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public boolean containsPlaceholder(String message) {
/* 39 */     return message.contains(this.identifier);
/*    */   }
/*    */   
/*    */   public PlaceholderType getType() {
/* 43 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getIdentifier() {
/* 47 */     return this.identifier;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 51 */     return this.description;
/*    */   }
/*    */   
/*    */   public int getDefaultRefresh() {
/* 55 */     return this.defaultRefresh;
/*    */   }
/*    */   
/*    */   public void setManager(MessagePlaceholderManager managaer) {
/* 59 */     this.managar = managaer;
/*    */   }
/*    */   
/*    */   public MessagePlaceholderManager getManager() {
/* 63 */     return this.managar;
/*    */   }
/*    */   
/*    */   public abstract void clearValue();
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\placeholder\MessagePlaceholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */