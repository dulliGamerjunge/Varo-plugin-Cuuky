/*     */ package de.cuuky.cfw.configuration.placeholder;
/*     */ 
/*     */ import de.cuuky.cfw.configuration.placeholder.placeholder.GeneralMessagePlaceholder;
/*     */ import de.cuuky.cfw.configuration.placeholder.placeholder.PlayerMessagePlaceholder;
/*     */ import de.cuuky.cfw.configuration.placeholder.placeholder.type.PlaceholderType;
/*     */ import de.cuuky.cfw.manager.FrameworkManager;
/*     */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*     */ import de.cuuky.cfw.player.CustomPlayer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessagePlaceholderManager
/*     */   extends FrameworkManager
/*     */ {
/*     */   private int tickTolerance;
/*     */   private Map<PlaceholderType, List<MessagePlaceholder>> placeholders;
/*     */   private Map<PlaceholderType, Map<String, List<MessagePlaceholder>>> cachedRequests;
/*     */   
/*     */   public MessagePlaceholderManager(JavaPlugin instance) {
/*  25 */     super(FrameworkManagerType.PLACEHOLDER, instance);
/*     */     
/*  27 */     this.tickTolerance = 900;
/*     */     
/*  29 */     this.placeholders = new HashMap<>();
/*  30 */     this.cachedRequests = new HashMap<>();
/*     */   }
/*     */   
/*     */   private Object[] replaceByList(String value, CustomPlayer vp, List<MessagePlaceholder> list) {
/*  34 */     if (list == null) {
/*  35 */       return new Object[] { value };
/*     */     }
/*  37 */     ArrayList<MessagePlaceholder> cached = new ArrayList<>();
/*  38 */     for (MessagePlaceholder pmp : list) {
/*  39 */       if (!pmp.containsPlaceholder(value)) {
/*     */         continue;
/*     */       }
/*  42 */       if (pmp instanceof PlayerMessagePlaceholder) {
/*  43 */         value = ((PlayerMessagePlaceholder)pmp).replacePlaceholder(value, vp);
/*     */       } else {
/*  45 */         value = ((GeneralMessagePlaceholder)pmp).replacePlaceholder(value);
/*     */       } 
/*  47 */       cached.add(pmp);
/*     */     } 
/*     */     
/*  50 */     return new Object[] { value, cached };
/*     */   }
/*     */ 
/*     */   
/*     */   public String replacePlaceholders(String value, CustomPlayer vp, PlaceholderType type) {
/*  55 */     Map<String, List<MessagePlaceholder>> reqs = this.cachedRequests.get(type);
/*  56 */     if (reqs == null) {
/*  57 */       reqs = new HashMap<>();
/*     */     }
/*  59 */     if (reqs.get(value) != null) {
/*  60 */       return (String)replaceByList(value, vp, (List)reqs.get(value))[0];
/*     */     }
/*  62 */     Object[] result = replaceByList(value, vp, getPlaceholders(type));
/*  63 */     if (result[1] != null)
/*  64 */       reqs.put(value, (List<MessagePlaceholder>)result[1]); 
/*  65 */     this.cachedRequests.put(type, reqs);
/*  66 */     return (String)result[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public String replacePlaceholders(String value, PlaceholderType type) {
/*  71 */     return replacePlaceholders(value, null, type);
/*     */   }
/*     */   
/*     */   public MessagePlaceholder registerPlaceholder(MessagePlaceholder placeholder) {
/*  75 */     if (this.placeholders.containsKey(placeholder.getType())) {
/*  76 */       ((List<MessagePlaceholder>)this.placeholders.get(placeholder.getType())).add(placeholder);
/*     */     } else {
/*  78 */       ArrayList<MessagePlaceholder> holders = new ArrayList<>();
/*  79 */       holders.add(placeholder);
/*     */       
/*  81 */       this.placeholders.put(placeholder.getType(), holders);
/*     */     } 
/*     */     
/*  84 */     return placeholder;
/*     */   }
/*     */   
/*     */   public MessagePlaceholder unregisterPlaceholder(MessagePlaceholder placeholder) {
/*  88 */     if (this.placeholders.containsKey(placeholder.getType())) {
/*  89 */       ((List)this.placeholders.get(placeholder.getType())).remove(placeholder);
/*     */     }
/*  91 */     return placeholder;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  95 */     for (PlaceholderType type : this.placeholders.keySet()) {
/*  96 */       for (MessagePlaceholder pl : this.placeholders.get(type))
/*  97 */         pl.clearValue(); 
/*     */     } 
/*  99 */     this.cachedRequests.clear();
/*     */   }
/*     */   
/*     */   public int getTickTolerance() {
/* 103 */     return this.tickTolerance;
/*     */   }
/*     */   
/*     */   public void setTickTolerance(int tickTolerance) {
/* 107 */     this.tickTolerance = tickTolerance;
/*     */   }
/*     */   
/*     */   public Map<PlaceholderType, List<MessagePlaceholder>> getPlaceholders() {
/* 111 */     return this.placeholders;
/*     */   }
/*     */   
/*     */   public List<MessagePlaceholder> getAllPlaceholders() {
/* 115 */     ArrayList<MessagePlaceholder> msg = new ArrayList<>();
/* 116 */     for (PlaceholderType type : this.placeholders.keySet()) {
/* 117 */       msg.addAll(this.placeholders.get(type));
/*     */     }
/* 119 */     return msg;
/*     */   }
/*     */   
/*     */   public List<MessagePlaceholder> getPlaceholders(PlaceholderType type) {
/* 123 */     return this.placeholders.get(type);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\placeholder\MessagePlaceholderManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */