/*    */ package de.cuuky.cfw.configuration.placeholder.placeholder;
/*    */ 
/*    */ import de.cuuky.cfw.configuration.placeholder.MessagePlaceholder;
/*    */ import de.cuuky.cfw.configuration.placeholder.placeholder.type.MessagePlaceholderType;
/*    */ import de.cuuky.cfw.configuration.placeholder.placeholder.type.PlaceholderType;
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class PlayerMessagePlaceholder
/*    */   extends MessagePlaceholder {
/*    */   private Map<CustomPlayer, String> placeholderValues;
/*    */   private Map<CustomPlayer, Long> placeholderRefreshes;
/*    */   
/*    */   public PlayerMessagePlaceholder(String identifier, int refreshDelay, String description) {
/* 16 */     super((PlaceholderType)MessagePlaceholderType.PLAYER, identifier, refreshDelay, description);
/*    */     
/* 18 */     this.placeholderValues = new HashMap<>();
/* 19 */     this.placeholderRefreshes = new HashMap<>();
/*    */   }
/*    */   
/*    */   private void checkRefresh(CustomPlayer player) {
/* 23 */     if (!shallRefresh(player)) {
/*    */       return;
/*    */     }
/* 26 */     refreshValue(player);
/*    */   }
/*    */   
/*    */   private boolean shallRefresh(CustomPlayer player) {
/* 30 */     if (!this.placeholderRefreshes.containsKey(player)) {
/* 31 */       return true;
/*    */     }
/* 33 */     return shallRefresh(((Long)this.placeholderRefreshes.get(player)).longValue());
/*    */   }
/*    */   
/*    */   private void refreshValue(CustomPlayer player) {
/* 37 */     this.placeholderValues.put(player, getValue(player));
/* 38 */     this.placeholderRefreshes.put(player, Long.valueOf(System.currentTimeMillis()));
/*    */   }
/*    */   
/*    */   protected abstract String getValue(CustomPlayer paramCustomPlayer);
/*    */   
/*    */   public String replacePlaceholder(String message, CustomPlayer player) {
/* 44 */     checkRefresh(player);
/*    */     
/* 46 */     String value = this.placeholderValues.get(player);
/* 47 */     return message.replace(this.identifier, (value != null) ? value : "");
/*    */   }
/*    */ 
/*    */   
/*    */   public void clearValue() {
/* 52 */     this.placeholderValues.clear();
/* 53 */     this.placeholderRefreshes.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\placeholder\placeholder\PlayerMessagePlaceholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */