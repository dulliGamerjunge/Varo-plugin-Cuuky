/*   */ package de.cuuky.cfw.configuration.placeholder.placeholder.type;
/*   */ 
/*   */ public enum MessagePlaceholderType
/*   */   implements PlaceholderType {
/* 5 */   GENERAL,
/* 6 */   PLAYER;
/*   */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\placeholder\placeholder\type\MessagePlaceholderType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */