package de.cuuky.cfw.configuration.placeholder.placeholder.type;

public interface PlaceholderType {}


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\placeholder\placeholder\type\PlaceholderType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */