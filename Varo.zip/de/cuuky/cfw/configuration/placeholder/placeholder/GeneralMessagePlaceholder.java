/*    */ package de.cuuky.cfw.configuration.placeholder.placeholder;
/*    */ 
/*    */ import de.cuuky.cfw.configuration.placeholder.MessagePlaceholder;
/*    */ import de.cuuky.cfw.configuration.placeholder.placeholder.type.MessagePlaceholderType;
/*    */ import de.cuuky.cfw.configuration.placeholder.placeholder.type.PlaceholderType;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ public abstract class GeneralMessagePlaceholder
/*    */   extends MessagePlaceholder
/*    */ {
/*    */   private static long lastDateRefreshTime;
/*    */   private static String[] lastDateRefresh;
/*    */   private String value;
/*    */   protected long lastRefresh;
/*    */   
/*    */   public GeneralMessagePlaceholder(String identifier, int refreshDelay, String description) {
/* 18 */     this(identifier, refreshDelay, false, description);
/*    */   }
/*    */   
/*    */   public GeneralMessagePlaceholder(String identifier, int refreshDelay, boolean rawIdentifier, String description) {
/* 22 */     super((PlaceholderType)MessagePlaceholderType.GENERAL, identifier, refreshDelay, rawIdentifier, description);
/*    */     
/* 24 */     this.lastRefresh = 0L;
/*    */   }
/*    */   
/*    */   private void checkRefresh() {
/* 28 */     if (!shallRefresh(this.lastRefresh)) {
/*    */       return;
/*    */     }
/* 31 */     refreshValue();
/*    */   }
/*    */   
/*    */   private void refreshValue() {
/* 35 */     this.value = getValue();
/* 36 */     this.lastRefresh = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   protected abstract String getValue();
/*    */   
/*    */   public String replacePlaceholder(String message) {
/* 42 */     checkRefresh();
/*    */     
/* 44 */     return message.replace(this.identifier, (this.value != null) ? this.value : "");
/*    */   }
/*    */ 
/*    */   
/*    */   public void clearValue() {
/* 49 */     this.value = null;
/* 50 */     this.lastRefresh = 0L;
/*    */   }
/*    */   
/*    */   protected static String getLastDateRefresh(int index) {
/* 54 */     if (lastDateRefresh == null || lastDateRefreshTime + 900L <= System.currentTimeMillis()) {
/* 55 */       lastDateRefreshTime = System.currentTimeMillis();
/* 56 */       lastDateRefresh = (new SimpleDateFormat("yyyy,MM,dd,HH,mm,ss")).format(new Date()).split(",");
/*    */     } 
/*    */     
/* 59 */     return lastDateRefresh[index];
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\placeholder\placeholder\GeneralMessagePlaceholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */