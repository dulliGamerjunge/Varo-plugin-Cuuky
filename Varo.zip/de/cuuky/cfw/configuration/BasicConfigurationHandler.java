/*    */ package de.cuuky.cfw.configuration;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ 
/*    */ 
/*    */ public class BasicConfigurationHandler
/*    */ {
/*    */   private File file;
/*    */   private YamlConfiguration configuration;
/*    */   
/*    */   public BasicConfigurationHandler(String path) {
/* 14 */     this.file = new File(path);
/* 15 */     this.configuration = YamlConfiguration.loadConfiguration(this.file);
/*    */     
/* 17 */     this.configuration.options().copyDefaults(true);
/*    */     
/* 19 */     if (!this.file.exists())
/* 20 */       save(); 
/*    */   }
/*    */   
/*    */   public void save() {
/*    */     try {
/* 25 */       this.configuration.save(this.file);
/* 26 */     } catch (IOException e) {
/* 27 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setValue(String path, Object object) {
/* 32 */     this.configuration.set(path, object);
/*    */   }
/*    */   
/*    */   public Object getValue(String name, Object defaultValue) {
/* 36 */     if (this.configuration.contains(name)) {
/* 37 */       return this.configuration.get(name);
/*    */     }
/* 39 */     this.configuration.addDefault(name, defaultValue);
/* 40 */     save();
/*    */     
/* 42 */     return defaultValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getBool(String name, boolean defaultValue) {
/* 47 */     return ((Boolean)getValue(name, Boolean.valueOf(defaultValue))).booleanValue();
/*    */   }
/*    */   
/*    */   public String getString(String name, String defaultValue) {
/* 51 */     return (String)getValue(name, defaultValue);
/*    */   }
/*    */   
/*    */   public int getInt(String name, int defaultValue) {
/* 55 */     return ((Integer)getValue(name, Integer.valueOf(defaultValue))).intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\configuration\BasicConfigurationHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */