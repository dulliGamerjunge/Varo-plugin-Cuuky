/*    */ package de.cuuky.cfw.player;
/*    */ 
/*    */ import de.cuuky.cfw.configuration.language.LanguageManager;
/*    */ import de.cuuky.cfw.configuration.language.broadcast.MessageHolder;
/*    */ import de.cuuky.cfw.configuration.language.languages.LoadableMessage;
/*    */ import de.cuuky.cfw.configuration.placeholder.MessagePlaceholderManager;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public abstract class CustomLanguagePlayer implements CustomPlayer {
/*    */   public MessageHolder sendTranslatedMessage(final LoadableMessage message, final CustomPlayer replace, MessagePlaceholderManager placeholder, final LanguageManager languageManager) {
/* 11 */     final MessageHolder holder = new MessageHolder(placeholder);
/* 12 */     placeholder.getOwnerInstance().getServer().getScheduler().scheduleSyncDelayedTask((Plugin)placeholder.getOwnerInstance(), new Runnable()
/*    */         {
/*    */           public void run()
/*    */           {
/* 16 */             if (CustomLanguagePlayer.this.getPlayer() == null) {
/*    */               return;
/*    */             }
/* 19 */             CustomLanguagePlayer.this.getPlayer().sendMessage(holder.getReplaced(languageManager.getMessage(message.getPath(), CustomLanguagePlayer.this.getLocale()), (replace != null) ? replace : CustomLanguagePlayer.this));
/*    */           }
/* 21 */         }1L);
/*    */     
/* 23 */     return holder;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\player\CustomLanguagePlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */