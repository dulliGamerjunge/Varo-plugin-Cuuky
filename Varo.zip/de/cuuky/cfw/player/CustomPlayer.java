package de.cuuky.cfw.player;

import de.cuuky.cfw.player.clientadapter.BoardUpdateHandler;
import de.cuuky.cfw.player.connection.NetworkManager;
import org.bukkit.entity.Player;

public interface CustomPlayer {
  String getUUID();
  
  String getName();
  
  Player getPlayer();
  
  NetworkManager getNetworkManager();
  
  String getLocale();
  
  BoardUpdateHandler<? extends CustomPlayer> getUpdateHandler();
}


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\player\CustomPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */