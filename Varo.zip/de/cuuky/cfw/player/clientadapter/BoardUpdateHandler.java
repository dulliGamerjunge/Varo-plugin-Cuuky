/*    */ package de.cuuky.cfw.player.clientadapter;
/*    */ 
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ public abstract class BoardUpdateHandler<T extends CustomPlayer>
/*    */ {
/*    */   protected T player;
/*    */   
/*    */   public BoardUpdateHandler(T player) {
/* 12 */     this.player = player;
/*    */   }
/*    */   
/*    */   public ArrayList<String> getTablistHeader() {
/* 16 */     return null;
/*    */   }
/*    */   
/*    */   public ArrayList<String> getTablistFooter() {
/* 20 */     return null;
/*    */   }
/*    */   
/*    */   public String getTablistName() {
/* 24 */     return null;
/*    */   }
/*    */   
/*    */   public String getScoreboardTitle() {
/* 28 */     return null;
/*    */   }
/*    */   
/*    */   public ArrayList<String> getScoreboardEntries() {
/* 32 */     return null;
/*    */   }
/*    */   
/*    */   public String getNametagName() {
/* 36 */     return null;
/*    */   }
/*    */   
/*    */   public String getNametagPrefix() {
/* 40 */     return null;
/*    */   }
/*    */   
/*    */   public String getNametagSuffix() {
/* 44 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isNametagVisible() {
/* 48 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\player\clientadapter\BoardUpdateHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */