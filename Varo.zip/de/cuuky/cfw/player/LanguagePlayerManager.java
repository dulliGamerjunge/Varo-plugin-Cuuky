/*    */ package de.cuuky.cfw.player;
/*    */ 
/*    */ import de.cuuky.cfw.manager.FrameworkManager;
/*    */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ public class LanguagePlayerManager
/*    */   extends FrameworkManager
/*    */ {
/*    */   private List<CustomLanguagePlayer> players;
/*    */   
/*    */   public LanguagePlayerManager(JavaPlugin instance) {
/* 16 */     super(FrameworkManagerType.PLAYER, instance);
/*    */     
/* 18 */     this.players = new ArrayList<>();
/*    */   }
/*    */   
/*    */   public CustomLanguagePlayer registerPlayer(CustomLanguagePlayer player) {
/* 22 */     this.players.add(player);
/* 23 */     return player;
/*    */   }
/*    */   
/*    */   public CustomLanguagePlayer unregisterPlayer(CustomLanguagePlayer player) {
/* 27 */     this.players.remove(player);
/* 28 */     return player;
/*    */   }
/*    */   
/*    */   public List<CustomLanguagePlayer> getPlayers() {
/* 32 */     return this.players;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\player\LanguagePlayerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */