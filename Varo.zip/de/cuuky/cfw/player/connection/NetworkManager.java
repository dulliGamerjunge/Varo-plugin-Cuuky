/*     */ package de.cuuky.cfw.player.connection;
/*     */ 
/*     */ import de.cuuky.cfw.version.BukkitVersion;
/*     */ import de.cuuky.cfw.version.VersionUtils;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ public class NetworkManager
/*     */ {
/*     */   private static Class<?> chatMessageTypeClass;
/*     */   private static Object genericSpeedType;
/*     */   private static Class<?> ioBase;
/*     */   private static Class<?> ioBaseChat;
/*     */   private static Constructor<?> titleConstructor;
/*     */   private static Class<?> packetChatClass;
/*     */   private static Class<?> tablistClass;
/*     */   private static Method ioBaseChatMethod;
/*     */   private static Object title;
/*     */   private static Object subtitle;
/*     */   private static Constructor<?> chatByteMethod;
/*     */   private static Constructor<?> chatEnumMethod;
/*     */   private static Constructor<?> chatEnumUUIDMethod;
/*     */   private Player player;
/*     */   private Object connection;
/*     */   private Object playerHandle;
/*     */   private Object tablist;
/*     */   private Object networkManager;
/*     */   private Method sendPacketMethod;
/*     */   private Field footerField;
/*     */   private Field headerField;
/*     */   private Field pingField;
/*     */   private String locale;
/*     */   
/*     */   static {
/*     */     try {
/*  43 */       ioBaseChat = VersionUtils.getChatSerializer();
/*     */       
/*  45 */       ioBase = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".IChatBaseComponent");
/*  46 */       ioBaseChatMethod = ioBaseChat.getDeclaredMethod("a", new Class[] { String.class });
/*     */       
/*  48 */       if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*  49 */         Class<?> titleClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayOutTitle");
/*     */         
/*  51 */         Class<?> enumTitleClass = null;
/*     */         try {
/*  53 */           enumTitleClass = titleClass.getDeclaredClasses()[0];
/*  54 */         } catch (Exception e) {
/*  55 */           enumTitleClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".EnumTitleAction");
/*     */         } 
/*     */         
/*  58 */         title = enumTitleClass.getDeclaredField("TITLE").get((Object)null);
/*  59 */         subtitle = enumTitleClass.getDeclaredField("SUBTITLE").get((Object)null);
/*     */         
/*  61 */         titleConstructor = titleClass.getConstructor(new Class[] { enumTitleClass, ioBase, int.class, int.class, int.class });
/*     */         
/*  63 */         packetChatClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayOutChat");
/*     */         try {
/*  65 */           chatMessageTypeClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".ChatMessageType");
/*     */           try {
/*  67 */             chatEnumMethod = packetChatClass.getConstructor(new Class[] { ioBase, chatMessageTypeClass });
/*  68 */           } catch (Exception e) {
/*  69 */             chatEnumUUIDMethod = packetChatClass.getConstructor(new Class[] { ioBase, chatMessageTypeClass, UUID.class });
/*     */           } 
/*  71 */         } catch (Exception e) {
/*  72 */           chatByteMethod = packetChatClass.getConstructor(new Class[] { ioBase, byte.class });
/*     */         } 
/*     */         
/*  75 */         tablistClass = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayOutPlayerListHeaderFooter");
/*     */       } 
/*  77 */     } catch (ClassNotFoundException|NoSuchMethodException|SecurityException|IllegalAccessException|IllegalArgumentException|NoSuchFieldException e) {
/*  78 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NetworkManager(Player player) {
/*  92 */     this.player = player;
/*     */     
/*     */     try {
/*  95 */       this.playerHandle = player.getClass().getMethod("getHandle", new Class[0]).invoke(player, new Object[0]);
/*  96 */       this.pingField = this.playerHandle.getClass().getField("ping");
/*  97 */       this.connection = this.playerHandle.getClass().getField("playerConnection").get(this.playerHandle);
/*  98 */       this.sendPacketMethod = this.connection.getClass().getMethod("sendPacket", new Class[] { Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".Packet") }); byte b; int i;
/*     */       Field[] arrayOfField;
/* 100 */       for (i = (arrayOfField = this.connection.getClass().getFields()).length, b = 0; b < i; ) { Field f = arrayOfField[b];
/* 101 */         if (f.getName().equals("networkManager"))
/* 102 */           this.networkManager = f.get(this.connection);  b++; }
/*     */       
/* 104 */       if (this.networkManager == null) {
/* 105 */         System.err.println("[CFW] Failed to initalize networkManager! Are you using a modified version of Spigot/Bukkit?");
/*     */       } else {
/* 107 */         if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_11)) {
/* 108 */           Method localeMethod = player.getClass().getDeclaredMethod("getLocale", new Class[0]);
/* 109 */           localeMethod.setAccessible(true);
/* 110 */           this.locale = (String)localeMethod.invoke(player, new Object[0]);
/*     */         } else {
/*     */           try {
/* 113 */             Field localeField = this.playerHandle.getClass().getField("locale");
/* 114 */             localeField.setAccessible(true);
/* 115 */             this.locale = (String)localeField.get(this.playerHandle);
/* 116 */           } catch (Exception e) {
/* 117 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/*     */         
/* 121 */         this.locale = this.locale.toLowerCase();
/*     */       } 
/* 123 */     } catch (Exception e) {
/* 124 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getConnection() {
/* 129 */     return this.connection;
/*     */   }
/*     */   
/*     */   public int getPing() {
/*     */     try {
/* 134 */       return this.pingField.getInt(this.playerHandle);
/* 135 */     } catch (Exception e) {
/* 136 */       e.printStackTrace();
/*     */ 
/*     */       
/* 139 */       return -1;
/*     */     } 
/*     */   }
/*     */   public Player getPlayer() {
/* 143 */     return this.player;
/*     */   }
/*     */   
/*     */   public void respawnPlayer() {
/*     */     try {
/* 148 */       Object respawnEnum = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".EnumClientCommand").getEnumConstants()[0];
/* 149 */       Constructor[] constructors = (Constructor[])Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayInClientCommand").getConstructors(); byte b; int i; Constructor[] arrayOfConstructor1;
/* 150 */       for (i = (arrayOfConstructor1 = constructors).length, b = 0; b < i; ) { Constructor<?> constructor = arrayOfConstructor1[b];
/* 151 */         Class[] args = constructor.getParameterTypes();
/* 152 */         if (args.length == 1 && args[0] == respawnEnum.getClass()) {
/* 153 */           Object packet = Class.forName(String.valueOf(VersionUtils.getNmsClass()) + ".PacketPlayInClientCommand").getConstructor(args).newInstance(new Object[] { respawnEnum });
/* 154 */           sendPacket(packet); break;
/*     */         } 
/*     */         b++; }
/*     */     
/* 158 */     } catch (Throwable e) {
/* 159 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendActionbar(final String message, final int duration, Plugin instance) {
/* 164 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/* 167 */     (new BukkitRunnable()
/*     */       {
/*     */         private int count;
/*     */ 
/*     */         
/*     */         public void run() {
/* 173 */           NetworkManager.this.sendActionbar(message);
/*     */           
/* 175 */           if (this.count >= duration) {
/* 176 */             cancel();
/*     */           }
/* 178 */           this.count++;
/*     */         }
/* 180 */       }).runTaskTimerAsynchronously(instance, 0L, 20L);
/*     */   }
/*     */   
/*     */   public void sendActionbar(String message) {
/* 184 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 188 */       Object barchat = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + message + "\"}" });
/*     */       
/* 190 */       Object packet = null;
/* 191 */       if (chatByteMethod != null) {
/* 192 */         packet = chatByteMethod.newInstance(new Object[] { barchat, Byte.valueOf((byte)2) });
/* 193 */       } else if (chatEnumMethod != null) {
/* 194 */         packet = chatEnumMethod.newInstance(new Object[] { barchat, chatMessageTypeClass.getDeclaredField("GAME_INFO").get((Object)null) });
/*     */       } else {
/* 196 */         packet = chatEnumUUIDMethod.newInstance(new Object[] { barchat, chatMessageTypeClass.getDeclaredField("GAME_INFO").get((Object)null), this.player.getUniqueId() });
/*     */       } 
/* 198 */       sendPacket(packet);
/* 199 */     } catch (Exception e) {
/* 200 */       e.printStackTrace();
/*     */     }  } public void sendLinkedMessage(String message, String link) {
/*     */     try {
/*     */       byte b;
/*     */       int i;
/*     */       Constructor[] arrayOfConstructor;
/* 206 */       for (i = (arrayOfConstructor = (Constructor[])packetChatClass.getConstructors()).length, b = 0; b < i; ) { Constructor<?> c = arrayOfConstructor[b];
/* 207 */         System.out.println(String.valueOf(c.getName()) + ":" + c.getParameterCount()); byte b1; int j; Parameter[] arrayOfParameter;
/* 208 */         for (j = (arrayOfParameter = c.getParameters()).length, b1 = 0; b1 < j; ) { Parameter p = arrayOfParameter[b1];
/* 209 */           System.out.println(String.valueOf(p.getName()) + ": " + p.getType().toString()); b1++; }
/*     */         
/*     */         b++; }
/*     */       
/* 213 */       Object text = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + message + "\", \"color\": \"white\", \"clickEvent\": {\"action\": \"open_url\" , \"value\": \"" + link + "\"}}" });
/* 214 */       Object packetFinal = null;
/*     */       try {
/* 216 */         Constructor<?> constructor = packetChatClass.getConstructor(new Class[] { ioBase });
/* 217 */         packetFinal = constructor.newInstance(new Object[] { text });
/* 218 */       } catch (Exception e) {
/* 219 */         Constructor<?> constructor = packetChatClass.getConstructor(new Class[] { ioBase, chatMessageTypeClass, UUID.class });
/* 220 */         packetFinal = constructor.newInstance(new Object[] { text, chatMessageTypeClass.getDeclaredField("CHAT").get((Object)null), this.player.getUniqueId() });
/*     */       } 
/*     */       
/* 223 */       Field field = packetFinal.getClass().getDeclaredField("a");
/* 224 */       field.setAccessible(true);
/* 225 */       field.set(packetFinal, text);
/*     */       
/* 227 */       sendPacket(packetFinal);
/* 228 */     } catch (Throwable e) {
/* 229 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendPacket(Object packet) {
/*     */     try {
/* 235 */       this.sendPacketMethod.invoke(this.connection, new Object[] { packet });
/* 236 */     } catch (Exception e) {
/* 237 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendTablist(String header, String footer) {
/* 242 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 246 */       Object tabheader = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + header + "\"}" });
/* 247 */       Object tabfooter = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + footer + "\"}" });
/*     */       
/* 249 */       if (this.tablist == null) {
/* 250 */         this.tablist = tablistClass.newInstance();
/*     */         
/* 252 */         this.headerField = getField(this.tablist.getClass(), new String[] { "a", "header" });
/* 253 */         this.headerField.setAccessible(true);
/*     */         
/* 255 */         this.footerField = getField(this.tablist.getClass(), new String[] { "b", "footer" });
/* 256 */         this.footerField.setAccessible(true);
/*     */       } 
/*     */       
/* 259 */       this.headerField.set(this.tablist, tabheader);
/* 260 */       this.footerField.set(this.tablist, tabfooter);
/*     */       
/* 262 */       sendPacket(this.tablist);
/* 263 */     } catch (Exception e) {
/* 264 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendTitle(String header, String footer) {
/* 269 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 273 */       Object titleHeader = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + header + "\"}" });
/* 274 */       Object titleFooter = ioBaseChatMethod.invoke(ioBaseChat, new Object[] { "{\"text\": \"" + footer + "\"}" });
/*     */       
/* 276 */       Object headerPacket = titleConstructor.newInstance(new Object[] { title, titleHeader, Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0) });
/* 277 */       Object footerPacket = titleConstructor.newInstance(new Object[] { subtitle, titleFooter, Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0) });
/*     */       
/* 279 */       sendPacket(headerPacket);
/* 280 */       sendPacket(footerPacket);
/* 281 */     } catch (Exception e) {
/* 282 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setAttributeSpeed(double value) {
/* 287 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_8)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 291 */       if (genericSpeedType == null) {
/* 292 */         Class<?> attribute = Class.forName("org.bukkit.attribute.Attribute");
/* 293 */         genericSpeedType = attribute.getField("GENERIC_ATTACK_SPEED").get(attribute);
/*     */       } 
/*     */       
/* 296 */       Object attributeInstance = this.player.getClass().getMethod("getAttribute", new Class[] { genericSpeedType.getClass() }).invoke(this.player, new Object[] { genericSpeedType });
/*     */       
/* 298 */       attributeInstance.getClass().getMethod("setBaseValue", new Class[] { double.class }).invoke(attributeInstance, new Object[] { Double.valueOf(value) });
/* 299 */     } catch (Exception e) {
/* 300 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getNetworkManager() {
/* 305 */     return this.networkManager;
/*     */   }
/*     */   
/*     */   public String getLocale() {
/* 309 */     return this.locale; } private static Field getField(Class<?> clazz, String... strings) {
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/* 313 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String s = arrayOfString[b];
/*     */       try {
/* 315 */         return clazz.getDeclaredField(s);
/* 316 */       } catch (NoSuchFieldException noSuchFieldException) {}
/*     */       
/*     */       b++; }
/*     */ 
/*     */     
/* 321 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\player\connection\NetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */