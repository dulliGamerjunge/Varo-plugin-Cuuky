/*    */ package de.cuuky.cfw.serialize.serializers;
/*    */ 
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*    */ import de.cuuky.cfw.serialize.loader.FieldLoader;
/*    */ import de.cuuky.cfw.serialize.serializers.type.CFWSerializeType;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CFWSerializer
/*    */ {
/*    */   private CFWSerializeManager manager;
/*    */   private ConfigurationSection section;
/*    */   private CFWSerializeable serializeable;
/*    */   
/*    */   public CFWSerializer(CFWSerializeManager manager, ConfigurationSection section, CFWSerializeable serializeable) {
/* 22 */     this.manager = manager;
/* 23 */     this.section = section;
/* 24 */     this.serializeable = serializeable;
/*    */   }
/*    */   
/*    */   public void serialize() {
/* 28 */     this.serializeable.onSerializeStart();
/* 29 */     FieldLoader loader = this.manager.loadClass(this.serializeable.getClass());
/* 30 */     List<String> keys = (List<String>)loader.getFields().keySet().stream().collect(Collectors.toList());
/* 31 */     Collections.reverse(keys);
/*    */     
/* 33 */     label21: for (String saveLocation : keys) {
/* 34 */       Field field = (Field)loader.getFields().get(saveLocation);
/* 35 */       field.setAccessible(true);
/* 36 */       Object value = null;
/*    */       try {
/* 38 */         value = field.get(this.serializeable);
/* 39 */       } catch (IllegalArgumentException|IllegalAccessException e) {
/* 40 */         e.printStackTrace();
/*    */         
/*    */         continue;
/*    */       } 
/* 44 */       if (value != null)
/* 45 */         for (CFWSerializeType type : this.manager.getSerializer()) {
/* 46 */           if (type.serialize(this.serializeable, field, value, saveLocation, this.section))
/*    */             continue label21; 
/*    */         }  
/* 49 */       this.section.set(saveLocation, value);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\serializers\CFWSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */