/*    */ package de.cuuky.cfw.serialize.serializers;
/*    */ 
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*    */ import de.cuuky.cfw.serialize.loader.FieldLoader;
/*    */ import de.cuuky.cfw.serialize.serializers.type.CFWSerializeType;
/*    */ import java.lang.reflect.Field;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CFWDeserializer
/*    */ {
/*    */   private CFWSerializeManager manager;
/*    */   private ConfigurationSection section;
/*    */   private Object parent;
/*    */   private Class<? extends CFWSerializeable> clazz;
/*    */   
/*    */   public CFWDeserializer(CFWSerializeManager manager, ConfigurationSection section, Object parent, Class<? extends CFWSerializeable> clazz) {
/* 21 */     this.manager = manager;
/* 22 */     this.section = section;
/* 23 */     this.parent = parent;
/* 24 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */   public CFWSerializeable deserialize() {
/* 28 */     CFWSerializeable instance = null;
/* 29 */     FieldLoader loader = this.manager.loadClass(this.clazz);
/*    */     
/* 31 */     if (this.parent != null) {
/*    */       try {
/* 33 */         instance = this.clazz.getConstructor(new Class[] { this.parent.getClass() }).newInstance(new Object[] { this.parent });
/* 34 */       } catch (NullPointerException|IllegalArgumentException|NoSuchMethodException|SecurityException|InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException nullPointerException) {}
/*    */     }
/*    */ 
/*    */     
/* 38 */     if (instance == null) {
/*    */       try {
/* 40 */         instance = this.clazz.newInstance();
/* 41 */       } catch (InstantiationException|IllegalAccessException e1) {
/* 42 */         e1.printStackTrace();
/* 43 */         return null;
/*    */       } 
/*    */     }
/* 46 */     for (String sections : this.section.getKeys(true)) {
/* 47 */       Field field = (Field)loader.getFields().get(sections);
/* 48 */       if (field == null) {
/*    */         continue;
/*    */       }
/* 51 */       field.setAccessible(true);
/* 52 */       Object obj = this.section.get(sections);
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 57 */       for (CFWSerializeType type : this.manager.getSerializer()) {
/* 58 */         Object get = type.deserialize(instance, sections, field, this.section);
/* 59 */         if (get == null) {
/*    */           continue;
/*    */         }
/* 62 */         obj = get;
/*    */         
/*    */         break;
/*    */       } 
/*    */       try {
/* 67 */         field.set(instance, obj);
/* 68 */       } catch (IllegalArgumentException|IllegalAccessException e) {
/* 69 */         e.printStackTrace();
/*    */       } 
/*    */     } 
/*    */     
/* 73 */     instance.onDeserializeEnd();
/* 74 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\serializers\CFWDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */