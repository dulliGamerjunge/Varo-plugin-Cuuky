/*    */ package de.cuuky.cfw.serialize.serializers.type.types;
/*    */ 
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*    */ import de.cuuky.cfw.serialize.loader.FieldLoader;
/*    */ import de.cuuky.cfw.serialize.serializers.CFWDeserializer;
/*    */ import de.cuuky.cfw.serialize.serializers.CFWSerializer;
/*    */ import de.cuuky.cfw.serialize.serializers.type.CFWSerializeType;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.lang.IllegalClassException;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ 
/*    */ 
/*    */ public class MapSerializer
/*    */   extends CFWSerializeType
/*    */ {
/*    */   public MapSerializer(CFWSerializeManager manager) {
/* 20 */     super(manager);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(CFWSerializeable instance, String key, Field field, ConfigurationSection section) {
/* 25 */     if (!Map.class.isAssignableFrom(field.getType()) || !section.isConfigurationSection(key)) {
/* 26 */       return null;
/*    */     }
/* 28 */     FieldLoader loader = this.manager.loadClass(instance.getClass());
/* 29 */     Class<? extends CFWSerializeable> keyClazz = loader.getKeyType(field), valueClazz = loader.getValueType(field);
/* 30 */     if (keyClazz == null && valueClazz == null) {
/* 31 */       return null;
/*    */     }
/* 33 */     if (keyClazz != null && 
/* 34 */       !Enum.class.isAssignableFrom(keyClazz)) {
/* 35 */       throw new IllegalClassException("Cannot deserialize CFWSerialize class other than Enums as key");
/*    */     }
/* 37 */     Map<Object, Object> content = new HashMap<>();
/* 38 */     ConfigurationSection arraySection = section.getConfigurationSection(key);
/* 39 */     for (String arrayKey : arraySection.getKeys(true)) {
/* 40 */       Object entry = arraySection.get(arrayKey);
/* 41 */       if (arrayKey.contains(".")) {
/*    */         continue;
/*    */       }
/* 44 */       Object okey = arrayKey;
/* 45 */       if (keyClazz != null && Enum.class.isAssignableFrom(keyClazz)) {
/* 46 */         okey = this.manager.deserializeEnum(this.manager.loadClass(keyClazz), arrayKey);
/*    */       }
/* 48 */       Object ovalue = entry;
/* 49 */       if (valueClazz != null)
/* 50 */         if (Enum.class.isAssignableFrom(valueClazz)) {
/* 51 */           ovalue = this.manager.deserializeEnum(this.manager.loadClass(valueClazz), entry);
/*    */         } else {
/* 53 */           ovalue = (new CFWDeserializer(this.manager, (ConfigurationSection)entry, instance, valueClazz)).deserialize();
/*    */         }  
/* 55 */       content.put(okey, ovalue);
/*    */     } 
/*    */     
/* 58 */     return content;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean serialize(CFWSerializeable instance, Field field, Object value, String saveUnder, ConfigurationSection section) {
/* 64 */     if (!(value instanceof Map)) {
/* 65 */       return false;
/*    */     }
/* 67 */     FieldLoader loader = this.manager.loadClass(instance.getClass());
/* 68 */     Class<? extends CFWSerializeable> keyClazz = loader.getKeyType(field), valueClazz = loader.getValueType(field);
/* 69 */     if (keyClazz == null && valueClazz == null) {
/* 70 */       return false;
/*    */     }
/* 72 */     if (keyClazz != null && 
/* 73 */       !Enum.class.isAssignableFrom(keyClazz)) {
/* 74 */       throw new IllegalClassException("Cannot deserialize CFWSerialize class other than Enums as key");
/*    */     }
/* 76 */     Map<Object, Object> list = (Map<Object, Object>)value;
/* 77 */     ConfigurationSection mapSection = section.createSection(saveUnder);
/* 78 */     for (Object object : list.keySet()) {
/* 79 */       String path = object.toString();
/*    */       
/* 81 */       if (keyClazz != null && Enum.class.isAssignableFrom(keyClazz)) {
/* 82 */         path = this.manager.serializeEnum(this.manager.loadClass(keyClazz), object);
/*    */       }
/* 84 */       Object listValue = list.get(object);
/* 85 */       if (valueClazz != null) {
/* 86 */         if (Enum.class.isAssignableFrom(valueClazz)) {
/* 87 */           mapSection.set(String.valueOf(path), this.manager.serializeEnum(this.manager.loadClass(valueClazz), listValue)); continue;
/*    */         } 
/* 89 */         (new CFWSerializer(this.manager, mapSection.createSection(String.valueOf(path)), (CFWSerializeable)listValue)).serialize();
/*    */       } 
/*    */     } 
/* 92 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\serializers\type\types\MapSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */