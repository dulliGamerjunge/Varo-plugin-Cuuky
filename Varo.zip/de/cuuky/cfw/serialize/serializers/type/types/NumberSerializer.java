/*    */ package de.cuuky.cfw.serialize.serializers.type.types;
/*    */ 
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*    */ import de.cuuky.cfw.serialize.serializers.type.CFWSerializeType;
/*    */ import java.lang.reflect.Field;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ 
/*    */ 
/*    */ public class NumberSerializer
/*    */   extends CFWSerializeType
/*    */ {
/*    */   public NumberSerializer(CFWSerializeManager manager) {
/* 14 */     super(manager);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(CFWSerializeable instance, String key, Field field, ConfigurationSection section) {
/* 19 */     Object object = section.get(key);
/* 20 */     if (field.getType().isAssignableFrom(long.class) || field.getType().isAssignableFrom(Long.class)) {
/* 21 */       return Long.valueOf(((Number)object).longValue());
/*    */     }
/* 23 */     if (field.getType().isAssignableFrom(short.class) || field.getType().isAssignableFrom(Short.class)) {
/* 24 */       return Short.valueOf(((Number)object).shortValue());
/*    */     }
/* 26 */     if (field.getType().isAssignableFrom(float.class) || field.getType().isAssignableFrom(Float.class)) {
/* 27 */       return Float.valueOf(((Number)object).floatValue());
/*    */     }
/* 29 */     if (field.getType().isAssignableFrom(double.class) || field.getType().isAssignableFrom(Double.class)) {
/* 30 */       return Double.valueOf(((Number)object).doubleValue());
/*    */     }
/* 32 */     if (field.getType().equals(byte.class) || field.getType().isAssignableFrom(Byte.class)) {
/* 33 */       return Byte.valueOf(((Number)object).byteValue());
/*    */     }
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean serialize(CFWSerializeable instance, Field field, Object value, String saveUnder, ConfigurationSection section) {
/* 40 */     if (!(value instanceof Long) && !(value instanceof Short) && !(value instanceof Float) && !(value instanceof Double) && !(value instanceof Byte)) {
/* 41 */       return false;
/*    */     }
/* 43 */     section.set(saveUnder, value);
/* 44 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\serializers\type\types\NumberSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */