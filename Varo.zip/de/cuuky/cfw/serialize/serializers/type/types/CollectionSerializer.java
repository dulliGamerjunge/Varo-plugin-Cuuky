/*    */ package de.cuuky.cfw.serialize.serializers.type.types;
/*    */ 
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*    */ import de.cuuky.cfw.serialize.loader.FieldLoader;
/*    */ import de.cuuky.cfw.serialize.serializers.CFWDeserializer;
/*    */ import de.cuuky.cfw.serialize.serializers.CFWSerializer;
/*    */ import de.cuuky.cfw.serialize.serializers.type.CFWSerializeType;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ 
/*    */ 
/*    */ public class CollectionSerializer
/*    */   extends CFWSerializeType
/*    */ {
/*    */   public CollectionSerializer(CFWSerializeManager manager) {
/* 19 */     super(manager);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(CFWSerializeable instance, String key, Field field, ConfigurationSection section) {
/* 24 */     if (!Collection.class.isAssignableFrom(field.getType()) || !section.isConfigurationSection(key)) {
/* 25 */       return null;
/*    */     }
/* 27 */     FieldLoader loader = this.manager.loadClass(instance.getClass());
/* 28 */     Class<? extends CFWSerializeable> keyClazz = loader.getKeyType(field);
/* 29 */     if (keyClazz == null) {
/* 30 */       return null;
/*    */     }
/* 32 */     ArrayList<CFWSerializeable> content = new ArrayList<>();
/* 33 */     ConfigurationSection arraySection = section.getConfigurationSection(key);
/* 34 */     for (String arrayKey : arraySection.getKeys(true)) {
/* 35 */       Object entry = arraySection.get(arrayKey);
/* 36 */       if (arrayKey.contains(".")) {
/*    */         continue;
/*    */       }
/* 39 */       if (Enum.class.isAssignableFrom(keyClazz)) {
/* 40 */         content.add((CFWSerializeable)this.manager.deserializeEnum(this.manager.loadClass(keyClazz), entry)); continue;
/*    */       } 
/* 42 */       content.add((new CFWDeserializer(this.manager, (ConfigurationSection)entry, instance, keyClazz)).deserialize());
/*    */     } 
/*    */     
/* 45 */     return content;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean serialize(CFWSerializeable instance, Field field, Object value, String saveUnder, ConfigurationSection section) {
/* 51 */     if (!(value instanceof Collection)) {
/* 52 */       return false;
/*    */     }
/* 54 */     FieldLoader loader = this.manager.loadClass(instance.getClass());
/* 55 */     Class<? extends CFWSerializeable> keyClazz = loader.getKeyType(field);
/* 56 */     if (loader.getKeyType(field) == null) {
/* 57 */       return false;
/*    */     }
/* 59 */     ArrayList<CFWSerializeable> list = (ArrayList<CFWSerializeable>)value;
/* 60 */     ConfigurationSection listSection = section.createSection(saveUnder);
/* 61 */     for (int i = 0; i < list.size(); i++) {
/* 62 */       if (Enum.class.isAssignableFrom(keyClazz)) {
/* 63 */         listSection.set(String.valueOf(i), this.manager.serializeEnum(this.manager.loadClass(keyClazz), list.get(i)));
/*    */       } else {
/* 65 */         (new CFWSerializer(this.manager, listSection.createSection(String.valueOf(i)), list.get(i))).serialize();
/*    */       } 
/* 67 */     }  return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\serializers\type\types\CollectionSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */