/*    */ package de.cuuky.cfw.serialize.serializers.type.types;
/*    */ 
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*    */ import de.cuuky.cfw.serialize.serializers.CFWDeserializer;
/*    */ import de.cuuky.cfw.serialize.serializers.CFWSerializer;
/*    */ import de.cuuky.cfw.serialize.serializers.type.CFWSerializeType;
/*    */ import java.lang.reflect.Field;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ 
/*    */ 
/*    */ public class CFWSerializeableSerializer
/*    */   extends CFWSerializeType
/*    */ {
/*    */   public CFWSerializeableSerializer(CFWSerializeManager manager) {
/* 16 */     super(manager);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object deserialize(CFWSerializeable instance, String key, Field field, ConfigurationSection section) {
/* 22 */     if (!CFWSerializeable.class.isAssignableFrom(field.getType()) || !section.isConfigurationSection(key) || field.getType().isEnum()) {
/* 23 */       return null;
/*    */     }
/* 25 */     return (new CFWDeserializer(this.manager, section.getConfigurationSection(key), instance, field.getType())).deserialize();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean serialize(CFWSerializeable instance, Field field, Object value, String saveLocation, ConfigurationSection section) {
/* 30 */     if (!(value instanceof CFWSerializeable) || field.getType().isEnum()) {
/* 31 */       return false;
/*    */     }
/* 33 */     (new CFWSerializer(this.manager, section.createSection(saveLocation), (CFWSerializeable)value)).serialize();
/* 34 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\serializers\type\types\CFWSerializeableSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */