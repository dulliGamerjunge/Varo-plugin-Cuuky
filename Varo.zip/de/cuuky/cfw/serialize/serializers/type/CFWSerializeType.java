/*    */ package de.cuuky.cfw.serialize.serializers.type;
/*    */ 
/*    */ import de.cuuky.cfw.serialize.CFWSerializeManager;
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*    */ import java.lang.reflect.Field;
/*    */ import org.bukkit.configuration.ConfigurationSection;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CFWSerializeType
/*    */ {
/*    */   protected CFWSerializeManager manager;
/*    */   
/*    */   public CFWSerializeType(CFWSerializeManager manager) {
/* 15 */     this.manager = manager;
/*    */   }
/*    */   
/*    */   public abstract Object deserialize(CFWSerializeable paramCFWSerializeable, String paramString, Field paramField, ConfigurationSection paramConfigurationSection);
/*    */   
/*    */   public abstract boolean serialize(CFWSerializeable paramCFWSerializeable, Field paramField, Object paramObject, String paramString, ConfigurationSection paramConfigurationSection);
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\serializers\type\CFWSerializeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */