/*     */ package de.cuuky.cfw.serialize;
/*     */ 
/*     */ import de.cuuky.cfw.manager.FrameworkManager;
/*     */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*     */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*     */ import de.cuuky.cfw.serialize.loader.FieldLoader;
/*     */ import de.cuuky.cfw.serialize.serializers.CFWDeserializer;
/*     */ import de.cuuky.cfw.serialize.serializers.CFWSerializer;
/*     */ import de.cuuky.cfw.serialize.serializers.type.CFWSerializeType;
/*     */ import de.cuuky.cfw.serialize.serializers.type.types.CFWSerializeableSerializer;
/*     */ import de.cuuky.cfw.serialize.serializers.type.types.CollectionSerializer;
/*     */ import de.cuuky.cfw.serialize.serializers.type.types.EnumSerializer;
/*     */ import de.cuuky.cfw.serialize.serializers.type.types.LocationSerializer;
/*     */ import de.cuuky.cfw.serialize.serializers.type.types.MapSerializer;
/*     */ import de.cuuky.cfw.serialize.serializers.type.types.NumberSerializer;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ public class CFWSerializeManager
/*     */   extends FrameworkManager
/*     */ {
/*     */   private Map<Class<?>, FieldLoader> loaded;
/*     */   private List<CFWSerializeType> serializer;
/*     */   
/*     */   public CFWSerializeManager(JavaPlugin instance) {
/*  34 */     super(FrameworkManagerType.SERIALIZE, instance);
/*     */     
/*  36 */     this.loaded = new LinkedHashMap<>();
/*  37 */     this.serializer = new ArrayList<>();
/*     */     
/*  39 */     this.serializer.add(new CFWSerializeableSerializer(this));
/*  40 */     this.serializer.add(new MapSerializer(this));
/*  41 */     this.serializer.add(new NumberSerializer(this));
/*  42 */     this.serializer.add(new LocationSerializer(this));
/*  43 */     this.serializer.add(new EnumSerializer(this));
/*  44 */     this.serializer.add(new CollectionSerializer(this));
/*     */   }
/*     */   
/*     */   public void saveSerializeable(String key, CFWSerializeable serializeable, YamlConfiguration configuration) {
/*  48 */     (new CFWSerializer(this, configuration.createSection(key), serializeable)).serialize();
/*     */   }
/*     */   
/*     */   public <T> List<T> loadSerializeables(Class<T> clazz, File file) {
/*  52 */     return loadSerializeables(clazz, file, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> List<T> loadSerializeables(Class<T> clazz, File file, Object invokeObject) {
/*  57 */     List<T> serializeables = new ArrayList<>();
/*  58 */     YamlConfiguration configuration = YamlConfiguration.loadConfiguration(file);
/*     */     
/*  60 */     for (String s : configuration.getKeys(true)) {
/*  61 */       if (!configuration.isConfigurationSection(s) || s.contains(".")) {
/*     */         continue;
/*     */       }
/*  64 */       serializeables.add((T)(new CFWDeserializer(this, configuration.getConfigurationSection(s), invokeObject, clazz)).deserialize());
/*     */     } 
/*     */     
/*  67 */     return serializeables;
/*     */   }
/*     */   
/*     */   public <T> void saveFiles(Class<T> clazz, List<T> list, File file, SaveVisit<T> visit) {
/*  71 */     if (file.exists()) {
/*  72 */       file.delete();
/*     */     }
/*  74 */     YamlConfiguration configuration = YamlConfiguration.loadConfiguration(file);
/*     */     
/*  76 */     for (T serializeable : list) {
/*  77 */       (new CFWSerializer(this, configuration.createSection(visit.onKeySave(serializeable)), (CFWSerializeable)serializeable)).serialize();
/*     */     }
/*     */     try {
/*  80 */       configuration.save(file);
/*  81 */     } catch (IOException e) {
/*  82 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public FieldLoader loadClass(Class<?> clazz) {
/*  87 */     if (this.loaded.containsKey(clazz)) {
/*  88 */       return this.loaded.get(clazz);
/*     */     }
/*  90 */     FieldLoader loader = new FieldLoader(clazz);
/*  91 */     this.loaded.put(clazz, loader);
/*  92 */     return loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String serializeEnum(FieldLoader loader, Object object) {
/* 100 */     for (String s : loader.getFields().keySet()) {
/* 101 */       Object enumValue = null;
/*     */       try {
/* 103 */         enumValue = ((Field)loader.getFields().get(s)).get(null);
/* 104 */       } catch (IllegalArgumentException|IllegalAccessException e) {
/* 105 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 108 */       if (enumValue.equals(object)) {
/* 109 */         return s;
/*     */       }
/*     */     } 
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   public Object deserializeEnum(FieldLoader loader, Object object) {
/*     */     try {
/* 117 */       return ((Field)loader.getFields().get(object)).get(null);
/* 118 */     } catch (IllegalArgumentException|IllegalAccessException e) {
/* 119 */       e.printStackTrace();
/*     */ 
/*     */       
/* 122 */       return null;
/*     */     } 
/*     */   }
/*     */   public List<CFWSerializeType> getSerializer() {
/* 126 */     return this.serializer;
/*     */   }
/*     */   
/*     */   public static abstract class SaveVisit<T> {
/*     */     public abstract String onKeySave(T param1T);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\CFWSerializeManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */