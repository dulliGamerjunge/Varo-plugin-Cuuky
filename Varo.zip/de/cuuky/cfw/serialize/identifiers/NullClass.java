package de.cuuky.cfw.serialize.identifiers;

public class NullClass implements CFWSerializeable {
  public void onDeserializeEnd() {}
  
  public void onSerializeStart() {}
}


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\identifiers\NullClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */