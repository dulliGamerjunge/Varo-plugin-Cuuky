/*    */ package de.cuuky.cfw.serialize.loader;
/*    */ 
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeField;
/*    */ import de.cuuky.cfw.serialize.identifiers.CFWSerializeable;
/*    */ import de.cuuky.cfw.serialize.identifiers.NullClass;
/*    */ import de.cuuky.cfw.utils.JavaUtils;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ public class FieldLoader
/*    */ {
/*    */   private Map<Field, Class<? extends CFWSerializeable>> keyTypes;
/*    */   private Map<Field, Class<? extends CFWSerializeable>> valueTypes;
/*    */   private Map<String, Field> fields;
/*    */   private Class<?> clazz;
/*    */   
/*    */   public FieldLoader(Class<?> clazz) {
/* 20 */     this.fields = new LinkedHashMap<>();
/* 21 */     this.keyTypes = new LinkedHashMap<>();
/* 22 */     this.valueTypes = new LinkedHashMap<>();
/* 23 */     this.clazz = clazz;
/*    */     
/* 25 */     loadFields();
/*    */   }
/*    */   
/*    */   private void loadFields() {
/* 29 */     Field[] declFields = this.clazz.getDeclaredFields(); byte b; int i; Field[] arrayOfField1;
/* 30 */     for (i = (arrayOfField1 = declFields).length, b = 0; b < i; ) { Field field = arrayOfField1[b];
/* 31 */       CFWSerializeField anno = field.<CFWSerializeField>getAnnotation(CFWSerializeField.class);
/* 32 */       if (anno != null) {
/*    */ 
/*    */         
/* 35 */         String path = anno.path();
/* 36 */         this.fields.put(path.equals("PATH") ? anno.enumValue() : path, field);
/* 37 */         if (anno.keyClass() != NullClass.class) {
/* 38 */           this.keyTypes.put(field, anno.keyClass());
/*    */         }
/* 40 */         if (anno.valueClass() != NullClass.class)
/* 41 */           this.valueTypes.put(field, anno.valueClass()); 
/*    */       }  b++; }
/*    */     
/* 44 */     reverseMaps();
/*    */   }
/*    */   
/*    */   private void reverseMaps() {
/* 48 */     this.fields = JavaUtils.reverseMap(this.fields);
/* 49 */     this.keyTypes = JavaUtils.reverseMap(this.keyTypes);
/* 50 */     this.valueTypes = JavaUtils.reverseMap(this.valueTypes);
/*    */   }
/*    */   
/*    */   public Class<? extends CFWSerializeable> getKeyType(Field field) {
/* 54 */     return this.keyTypes.get(field);
/*    */   }
/*    */   
/*    */   public Class<? extends CFWSerializeable> getValueType(Field field) {
/* 58 */     return this.valueTypes.get(field);
/*    */   }
/*    */   
/*    */   public Map<String, Field> getFields() {
/* 62 */     return this.fields;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\serialize\loader\FieldLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */