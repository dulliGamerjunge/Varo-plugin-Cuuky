package de.cuuky.cfw.mysql.request;

import java.sql.ResultSet;

public interface PreparedStatementQuery extends PreparedStatementHandler {
  void onResultRecieve(ResultSet paramResultSet);
}


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\mysql\request\PreparedStatementQuery.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */