/*     */ package de.cuuky.cfw.mysql.stats;
/*     */ 
/*     */ import de.cuuky.cfw.mysql.MySQLClient;
/*     */ import de.cuuky.cfw.mysql.request.PreparedStatementHandler;
/*     */ import de.cuuky.cfw.mysql.request.PreparedStatementQuery;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.reflect.Field;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLStats<T>
/*     */   extends MySQLClient
/*     */ {
/*     */   private String table;
/*     */   private Class<T> statsClazz;
/*     */   private Map<String, Field> fields;
/*     */   
/*     */   public SQLStats(String host, int port, String database, String table, String user, String password, Class<T> statsClazz) throws SQLException {
/*  32 */     super(host, port, database, user, password, new Object());
/*     */     
/*  34 */     this.table = table;
/*  35 */     this.statsClazz = statsClazz;
/*     */     
/*  37 */     loadFields();
/*  38 */     setupDatabase();
/*     */   }
/*     */   
/*     */   public SQLStats(String host, int port, String database, String table, String user, String password, Class<T> statsClazz, Object connectWait) throws SQLException {
/*  42 */     super(host, port, database, user, password, connectWait);
/*     */   }
/*     */   
/*     */   private void setupDatabase() throws SQLException {
/*  46 */     waitForConnection();
/*  47 */     createTable();
/*     */   }
/*     */   
/*     */   private void loadFields() {
/*  51 */     this.fields = new HashMap<>(); byte b; int i;
/*     */     Field[] arrayOfField;
/*  53 */     for (i = (arrayOfField = this.statsClazz.getDeclaredFields()).length, b = 0; b < i; ) { Field field = arrayOfField[b];
/*  54 */       StatsInt annotation = field.<StatsInt>getAnnotation(StatsInt.class);
/*  55 */       if (annotation != null) {
/*  56 */         String key = annotation.value();
/*     */         
/*  58 */         if (this.fields.containsKey(key)) {
/*  59 */           throw new Error("Duplicate key: " + key);
/*     */         }
/*  61 */         field.setAccessible(true);
/*  62 */         this.fields.put(key, field);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void createTable() throws SQLException {
/*  68 */     StringBuilder command = (new StringBuilder()).append("CREATE DATABASE IF NOT EXISTS `").append(this.database).append("`;").append("CREATE TABLE IF NOT EXISTS `").append(this.database).append("`.`").append(this.table).append("` (").append("`index` INT NOT NULL AUTO_INCREMENT,").append("`uuid` VARCHAR(36) NOT NULL,");
/*     */     
/*  70 */     for (String key : this.fields.keySet()) {
/*  71 */       command.append("`" + key + "` INT NULL,");
/*     */     }
/*  73 */     command.append("PRIMARY KEY (`index`), UNIQUE KEY `uuid_key` (`uuid`));");
/*     */     
/*  75 */     getQuery(command.toString());
/*     */   }
/*     */   
/*     */   private String getLoadStatsQuery(UUID uuid) {
/*  79 */     return "SELECT * from `" + this.database + "`.`" + this.table + "` WHERE `uuid` = '" + uuid.toString() + "' FOR UPDATE;";
/*     */   }
/*     */   
/*     */   private T processStats(ResultSet result) throws SQLException, InstantiationException, IllegalAccessException {
/*  83 */     T stats = this.statsClazz.newInstance();
/*     */     
/*  85 */     if (result.next())
/*  86 */       for (Map.Entry<String, Field> entry : this.fields.entrySet()) {
/*  87 */         ((Field)entry.getValue()).set(stats, Integer.valueOf(result.getInt(entry.getKey())));
/*     */       } 
/*  89 */     return stats;
/*     */   }
/*     */   
/*     */   private String getSaveQuery(UUID uuid, T stats) throws IllegalArgumentException, IllegalAccessException {
/*  93 */     Set<Map.Entry<String, Field>> entrys = this.fields.entrySet();
/*  94 */     int[] values = new int[entrys.size()];
/*     */     
/*  96 */     StringBuilder command = (new StringBuilder()).append("INSERT INTO `").append(this.database).append("`.`").append(this.table).append("` (uuid");
/*  97 */     entrys.forEach(entry -> { 
/*  98 */         }); command.append(") VALUES ('").append(uuid.toString()).append("'");
/*     */     
/* 100 */     int i = 0;
/* 101 */     for (Map.Entry<String, Field> entry : entrys) {
/* 102 */       command.append(", ").append(values[i++] = ((Integer)((Field)entry.getValue()).get(stats)).intValue());
/*     */     }
/* 104 */     command.append(") ON DUPLICATE KEY UPDATE ");
/*     */     
/* 106 */     i = 0;
/* 107 */     Iterator<Map.Entry<String, Field>> iterator = entrys.iterator();
/* 108 */     if (iterator.hasNext())
/*     */       while (true) {
/* 110 */         Map.Entry<String, Field> entry = iterator.next();
/* 111 */         command.append(entry.getKey()).append("=").append(values[i++]);
/*     */         
/* 113 */         if (iterator.hasNext()) {
/* 114 */           command.append(", ");
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/* 119 */     return String.valueOf(command.toString()) + "; COMMIT;";
/*     */   }
/*     */   
/*     */   public T loadStats(UUID uuid) throws SQLException, InstantiationException, IllegalAccessException {
/* 123 */     ResultSet result = this.connection.createStatement().executeQuery(getLoadStatsQuery(uuid));
/* 124 */     return processStats(result);
/*     */   }
/*     */   
/*     */   public boolean loadStatsAsync(UUID uuid, final Consumer<T> consumer) throws SQLException, InstantiationException, IllegalAccessException {
/* 128 */     return getAsyncPreparedQuery(getLoadStatsQuery(uuid), (PreparedStatementHandler)new PreparedStatementQuery()
/*     */         {
/*     */           public void onStatementPrepared(PreparedStatement statement) {}
/*     */ 
/*     */ 
/*     */           
/*     */           public void onResultRecieve(ResultSet result) {
/*     */             try {
/* 136 */               consumer.accept(SQLStats.this.processStats(result));
/* 137 */             } catch (InstantiationException|IllegalAccessException|SQLException e) {
/* 138 */               e.printStackTrace();
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public boolean saveStats(UUID uuid, T stats) throws SQLException, IllegalArgumentException, IllegalAccessException {
/* 145 */     return getQuery(getSaveQuery(uuid, stats));
/*     */   }
/*     */   
/*     */   public boolean saveStatsAsync(UUID uuid, T stats) throws SQLException, IllegalArgumentException, IllegalAccessException {
/* 149 */     return getAsyncPreparedQuery(getSaveQuery(uuid, stats));
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   public static @interface StatsInt {
/*     */     String value();
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\mysql\stats\SQLStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */