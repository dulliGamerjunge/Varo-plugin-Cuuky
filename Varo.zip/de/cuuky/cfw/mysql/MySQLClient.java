/*     */ package de.cuuky.cfw.mysql;
/*     */ 
/*     */ import de.cuuky.cfw.mysql.request.PreparedStatementHandler;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MySQLClient
/*     */ {
/*  19 */   private static final ExecutorService THREAD_POOL = Executors.newCachedThreadPool();
/*     */   
/*     */   private static final long HEARTBEAT_DELAY = 3600000L;
/*     */   
/*     */   protected Connection connection;
/*     */   
/*     */   protected String host;
/*     */   
/*     */   protected String database;
/*     */   protected String user;
/*     */   
/*     */   public MySQLClient(String host, int port, String database, String user, String password) {
/*  31 */     this(host, port, database, user, password, new Object());
/*     */   }
/*     */   protected String password; protected int port; protected Object connectWait; protected boolean autoReconnect; protected boolean keepAlive; private volatile CopyOnWriteArrayList<MySQLRequest> queries;
/*     */   public MySQLClient(String host, int port, String database, String user, String password, Object connectWait) {
/*  35 */     this.host = host;
/*  36 */     this.port = port;
/*  37 */     this.database = database;
/*  38 */     this.user = user;
/*  39 */     this.password = password;
/*  40 */     this.autoReconnect = true;
/*  41 */     this.keepAlive = true;
/*  42 */     this.queries = new CopyOnWriteArrayList<>();
/*  43 */     this.connectWait = connectWait;
/*     */     
/*  45 */     startConnecting();
/*  46 */     startKeepingAlive();
/*  47 */     THREAD_POOL.execute(this::prepareAsyncHandler);
/*     */   }
/*     */   
/*     */   private void startKeepingAlive() {
/*  51 */     THREAD_POOL.execute(() -> {
/*     */           try {
/*     */             Thread.sleep(3600000L);
/*  54 */           } catch (InterruptedException e) {
/*     */             e.printStackTrace();
/*     */           } 
/*     */           if (!this.keepAlive) {
/*     */             return;
/*     */           }
/*     */           waitForConnection();
/*     */           getQuery(new MySQLRequest("SHOW TABLES;", null));
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void startConnecting() {
/*  67 */     THREAD_POOL.execute(() -> {
/*     */           try {
/*     */             this.connection = DriverManager.getConnection("jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database + "?allowMultiQueries=true&autoReconnect=true&testWhileIdle=true&testOnBorrow=true", this.user, this.password);
/*     */             
/*     */             if (this.connectWait != null) {
/*     */               synchronized (this.connectWait) {
/*     */                 this.connectWait.notifyAll();
/*     */               } 
/*     */             }
/*  76 */           } catch (SQLException e) {
/*     */             e.printStackTrace();
/*     */             System.err.println("[MySQL] Couldn't connect to MySQL-Database!");
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   private boolean getQuery(MySQLRequest mqr) {
/*  84 */     waitForConnection();
/*     */     
/*     */     try {
/*  87 */       PreparedStatement statement = this.connection.prepareStatement(mqr.getSql());
/*  88 */       if (mqr.getHandler() != null)
/*  89 */         mqr.getHandler().onStatementPrepared(statement); 
/*  90 */       mqr.doRequest(statement);
/*  91 */     } catch (Exception e) {
/*  92 */       e.printStackTrace();
/*  93 */       System.err.println("[MySQL] An error occured on executing a query!");
/*  94 */       System.err.println("[MySQL] Query: " + mqr.getSql());
/*  95 */       return false;
/*     */     } 
/*     */     
/*  98 */     return true;
/*     */   }
/*     */   
/*     */   private Runnable prepareAsyncHandler() {
/*     */     while (true) {
/*     */       try {
/* 104 */         Thread.sleep(10L);
/* 105 */       } catch (InterruptedException e) {
/* 106 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 109 */       waitForConnection();
/*     */       
/* 111 */       MySQLRequest[] loop = this.queries.<MySQLRequest>toArray(new MySQLRequest[0]);
/* 112 */       for (int i = loop.length - 1; i >= 0; i--) {
/* 113 */         MySQLRequest mqr = loop[i];
/* 114 */         this.queries.remove(mqr);
/* 115 */         THREAD_POOL.execute(() -> {
/*     */               if (!getQuery(paramMySQLRequest))
/*     */                 this.queries.add(paramMySQLRequest); 
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void waitForConnection() {
/* 124 */     if (isConnected()) {
/*     */       return;
/*     */     }
/* 127 */     synchronized (this.connectWait) {
/*     */       try {
/* 129 */         this.connectWait.wait();
/* 130 */       } catch (InterruptedException e) {
/* 131 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void disconnect() {
/* 137 */     if (!isConnected()) {
/*     */       return;
/*     */     }
/*     */     try {
/* 141 */       this.connection.close();
/* 142 */     } catch (SQLException e) {
/* 143 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 146 */     this.connection = null;
/*     */   }
/*     */   
/*     */   public boolean getQuery(String query) {
/* 150 */     return getQuery(new MySQLRequest(query, null));
/*     */   }
/*     */   
/*     */   public boolean getQuery(String query, PreparedStatementHandler handler) {
/* 154 */     return getQuery(new MySQLRequest(query, handler));
/*     */   }
/*     */   
/*     */   public boolean getAsyncPreparedQuery(String query) {
/* 158 */     return this.queries.add(new MySQLRequest(query, null));
/*     */   }
/*     */   
/*     */   public boolean getAsyncPreparedQuery(String query, PreparedStatementHandler dr) {
/* 162 */     return this.queries.add(new MySQLRequest(query, dr));
/*     */   }
/*     */   
/*     */   public void setKeepAlive(boolean keepAlive) {
/* 166 */     this.keepAlive = keepAlive;
/*     */   }
/*     */   
/*     */   public boolean isConnected() {
/* 170 */     return (this.connection != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\mysql\MySQLClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */