/*    */ package de.cuuky.cfw.mysql;
/*    */ 
/*    */ import de.cuuky.cfw.mysql.request.PreparedStatementExec;
/*    */ import de.cuuky.cfw.mysql.request.PreparedStatementHandler;
/*    */ import de.cuuky.cfw.mysql.request.PreparedStatementQuery;
/*    */ import java.sql.PreparedStatement;
/*    */ 
/*    */ 
/*    */ public class MySQLRequest
/*    */ {
/*    */   private String sql;
/*    */   private PreparedStatementHandler handler;
/*    */   
/*    */   public MySQLRequest(String sql, PreparedStatementHandler handler) {
/* 15 */     this.sql = sql;
/* 16 */     this.handler = handler;
/*    */   }
/*    */   
/*    */   public void doRequest(PreparedStatement statement) {
/*    */     try {
/* 21 */       if (this.handler == null) {
/* 22 */         statement.execute();
/*    */         
/*    */         return;
/*    */       } 
/* 26 */       if (this.handler instanceof PreparedStatementExec) {
/* 27 */         ((PreparedStatementExec)this.handler).onStatementExec(statement.execute());
/* 28 */       } else if (this.handler instanceof PreparedStatementQuery) {
/* 29 */         ((PreparedStatementQuery)this.handler).onResultRecieve(statement.executeQuery());
/*    */       } else {
/* 31 */         statement.execute();
/*    */       } 
/* 33 */     } catch (Exception e) {
/* 34 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getSql() {
/* 39 */     return this.sql;
/*    */   }
/*    */   
/*    */   public PreparedStatementHandler getHandler() {
/* 43 */     return this.handler;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\mysql\MySQLRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */