/*     */ package de.cuuky.cfw.clientadapter.board.nametag;
/*     */ 
/*     */ import de.cuuky.cfw.clientadapter.board.CustomBoard;
/*     */ import de.cuuky.cfw.clientadapter.board.CustomBoardType;
/*     */ import de.cuuky.cfw.player.CustomPlayer;
/*     */ import de.cuuky.cfw.version.BukkitVersion;
/*     */ import de.cuuky.cfw.version.VersionUtils;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ public class CustomNametag<T extends CustomPlayer> extends CustomBoard<T> {
/*     */   private static Class<?> visibilityClass;
/*     */   private static Method setVisibilityMethod;
/*     */   private static Object visibilityNever;
/*     */   private static Object visibilityAlways;
/*     */   
/*     */   static {
/*  23 */     if (VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       try {
/*  25 */         visibilityClass = Class.forName("org.bukkit.scoreboard.NameTagVisibility");
/*  26 */         visibilityNever = visibilityClass.getDeclaredField("NEVER").get(null);
/*  27 */         visibilityAlways = visibilityClass.getDeclaredField("ALWAYS").get(null);
/*  28 */         setVisibilityMethod = Team.class.getDeclaredMethod("setNameTagVisibility", new Class[] { visibilityClass });
/*  29 */       } catch (Exception e) {
/*  30 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private String[] nametagContent;
/*     */   private String oldName;
/*     */   private boolean initalized;
/*     */   private boolean nametagShown;
/*     */   
/*     */   public CustomNametag(T player) {
/*  41 */     super(CustomBoardType.NAMETAG, (CustomPlayer)player);
/*     */     
/*  43 */     this.nametagContent = new String[3];
/*  44 */     this.nametagShown = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  49 */     Scoreboard sb = this.player.getPlayer().getScoreboard();
/*  50 */     if (sb.getTeams().size() > 0) {
/*  51 */       for (int i = sb.getTeams().size() - 1; i != 0; i--) {
/*  52 */         Team team = (Team)sb.getTeams().toArray()[i];
/*     */         try {
/*  54 */           if (!team.getName().startsWith("team-"))
/*  55 */             team.unregister(); 
/*  56 */         } catch (IllegalStateException illegalStateException) {}
/*     */       } 
/*     */     }
/*  59 */     giveAll();
/*  60 */     this.initalized = true;
/*     */   }
/*     */   
/*     */   public void startDelayedRefresh() {
/*  64 */     this.manager.getOwnerInstance().getServer().getScheduler().scheduleSyncDelayedTask((Plugin)this.manager.getOwnerInstance(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  68 */             CustomNametag.this.update();
/*     */           }
/*  70 */         },  1L);
/*     */   }
/*     */   
/*     */   private boolean refreshPrefix() {
/*  74 */     String newName = this.player.getUpdateHandler().getNametagName();
/*  75 */     if (newName != null && newName.startsWith("team-")) {
/*  76 */       throw new IllegalArgumentException("Player nametag name cannot start with 'team-'");
/*     */     }
/*  78 */     String[] check = { newName, this.player.getUpdateHandler().getNametagPrefix(), this.player.getUpdateHandler().getNametagSuffix() };
/*  79 */     for (int i = 0; i < check.length; i++) {
/*  80 */       String newContent = check[i];
/*  81 */       if (newContent != null)
/*     */       {
/*     */         
/*  84 */         if (newContent.length() > 16)
/*  85 */           check[i] = newContent.substring(0, 16); 
/*     */       }
/*     */     } 
/*  88 */     boolean showNametag = this.player.getUpdateHandler().isNametagVisible();
/*  89 */     boolean changed = !(Arrays.equals((Object[])this.nametagContent, (Object[])check) && showNametag == this.nametagShown);
/*  90 */     if (!changed) {
/*  91 */       return false;
/*     */     }
/*  93 */     this.oldName = this.nametagContent[0];
/*  94 */     this.nametagContent = check;
/*  95 */     this.nametagShown = showNametag;
/*  96 */     return true;
/*     */   }
/*     */   
/*     */   private void updateFor(Scoreboard board, CustomNametag<T> nametag) {
/* 100 */     Team oldTeam = board.getTeam((nametag.getOldName() != null) ? nametag.getOldName() : this.player.getPlayer().getName());
/* 101 */     if (oldTeam != null) {
/* 102 */       oldTeam.unregister();
/*     */     }
/* 104 */     String teamName = (nametag.getName() == null) ? this.player.getPlayer().getName() : nametag.getName();
/* 105 */     Team team = board.getTeam(teamName);
/* 106 */     if (team == null) {
/* 107 */       team = board.registerNewTeam(teamName);
/* 108 */       team.addPlayer((OfflinePlayer)nametag.getPlayer().getPlayer());
/*     */     } 
/*     */     
/* 111 */     setVisibility(team, nametag.isNametagShown());
/* 112 */     if (nametag.getPrefix() != null)
/* 113 */     { if (team.getPrefix() == null) {
/* 114 */         team.setPrefix(nametag.getPrefix());
/* 115 */       } else if (!team.getPrefix().equals(nametag.getPrefix())) {
/* 116 */         team.setPrefix(nametag.getPrefix());
/*     */       }  }
/* 118 */     else { team.setPrefix(null); }
/*     */     
/* 120 */     if (nametag.getSuffix() != null)
/* 121 */     { if (team.getSuffix() == null) {
/* 122 */         team.setSuffix(nametag.getSuffix());
/* 123 */       } else if (!team.getSuffix().equals(nametag.getSuffix())) {
/* 124 */         team.setSuffix(nametag.getSuffix());
/*     */       }  }
/* 126 */     else { team.setSuffix(null); }
/*     */   
/*     */   }
/*     */   
/*     */   protected void onUpdate() {
/* 131 */     if (!refreshPrefix()) {
/*     */       return;
/*     */     }
/* 134 */     setToAll();
/*     */   }
/*     */   
/*     */   public void giveAll() {
/* 138 */     Scoreboard board = this.player.getPlayer().getScoreboard();
/* 139 */     for (CustomBoard<T> nametag : (Iterable<CustomBoard<T>>)this.manager.getBoards(CustomBoardType.NAMETAG)) {
/* 140 */       if (((CustomNametag)nametag).isInitalized())
/* 141 */         updateFor(board, (CustomNametag<T>)nametag); 
/*     */     } 
/*     */   }
/*     */   public void setToAll() {
/* 145 */     for (Player toSet : VersionUtils.getOnlinePlayer())
/* 146 */       updateFor(toSet.getScoreboard(), this); 
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 150 */     return this.nametagContent[1];
/*     */   }
/*     */   
/*     */   public String getName() {
/* 154 */     return this.nametagContent[0];
/*     */   }
/*     */   
/*     */   public String getSuffix() {
/* 158 */     return this.nametagContent[2];
/*     */   }
/*     */   
/*     */   public String getOldName() {
/* 162 */     return this.oldName;
/*     */   }
/*     */   
/*     */   public boolean isNametagShown() {
/* 166 */     return this.nametagShown;
/*     */   }
/*     */   
/*     */   public boolean isInitalized() {
/* 170 */     return this.initalized;
/*     */   }
/*     */   
/*     */   private static void setVisibility(Team team, boolean shown) {
/* 174 */     if (!VersionUtils.getVersion().isHigherThan(BukkitVersion.ONE_7)) {
/*     */       return;
/*     */     }
/*     */     try {
/* 178 */       setVisibilityMethod.invoke(team, new Object[] { shown ? visibilityAlways : visibilityNever });
/* 179 */     } catch (Exception e) {
/* 180 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\clientadapter\board\nametag\CustomNametag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */