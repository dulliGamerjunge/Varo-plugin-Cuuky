/*    */ package de.cuuky.cfw.clientadapter.board.tablist;
/*    */ 
/*    */ import de.cuuky.cfw.clientadapter.board.CustomBoard;
/*    */ import de.cuuky.cfw.clientadapter.board.CustomBoardType;
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ import de.cuuky.cfw.utils.JavaUtils;
/*    */ import de.cuuky.cfw.version.BukkitVersion;
/*    */ import de.cuuky.cfw.version.VersionUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomTablist<T extends CustomPlayer>
/*    */   extends CustomBoard<T>
/*    */ {
/*    */   private Map<Player, List<String>> headerReplaces;
/*    */   private Map<Player, List<String>> footerReplaces;
/*    */   private String tabname;
/*    */   
/*    */   public CustomTablist(T player) {
/* 25 */     super(CustomBoardType.TABLIST, (CustomPlayer)player);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void onEnable() {
/* 30 */     this.headerReplaces = new HashMap<>();
/* 31 */     this.footerReplaces = new HashMap<>();
/*    */   }
/*    */   
/*    */   private Object[] updateList(T player, boolean header) {
/* 35 */     List<String> tablistLines = header ? player.getUpdateHandler().getTablistHeader() : player.getUpdateHandler().getTablistFooter(), oldList = null;
/*    */     
/* 37 */     if (tablistLines == null) {
/* 38 */       return new Object[] { Boolean.valueOf(false) };
/*    */     }
/* 40 */     if (header) {
/* 41 */       oldList = this.headerReplaces.get(player.getPlayer());
/* 42 */       if (oldList == null)
/* 43 */         this.headerReplaces.put(player.getPlayer(), oldList = new ArrayList<>()); 
/*    */     } else {
/* 45 */       oldList = this.footerReplaces.get(player.getPlayer());
/* 46 */       if (oldList == null) {
/* 47 */         this.footerReplaces.put(player.getPlayer(), oldList = new ArrayList<>());
/*    */       }
/*    */     } 
/* 50 */     boolean changed = false;
/* 51 */     for (int index = 0; index < tablistLines.size(); index++) {
/* 52 */       String line = tablistLines.get(index);
/*    */       
/* 54 */       if (oldList.size() < tablistLines.size()) {
/* 55 */         oldList.add(line);
/* 56 */         changed = true;
/* 57 */       } else if (!((String)oldList.get(index)).equals(line)) {
/* 58 */         oldList.set(index, line);
/* 59 */         changed = true;
/*    */       } 
/*    */     } 
/*    */     
/* 63 */     return new Object[] { Boolean.valueOf(changed), oldList };
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void onUpdate() {
/* 69 */     String tablistname = this.player.getUpdateHandler().getTablistName();
/*    */     
/* 71 */     if (tablistname != null) {
/* 72 */       int maxlength = BukkitVersion.ONE_8.isHigherThan(VersionUtils.getVersion()) ? 16 : -1;
/* 73 */       if (maxlength > 0 && 
/* 74 */         tablistname.length() > maxlength) {
/* 75 */         tablistname = this.player.getName();
/*    */       }
/* 77 */       if (this.tabname == null || !this.tabname.equals(tablistname)) {
/* 78 */         this.player.getPlayer().setPlayerListName(this.tabname = tablistname);
/*    */       }
/*    */     } 
/* 81 */     Object[] headerUpdate = updateList((T)this.player, true);
/* 82 */     Object[] footerUpdate = updateList((T)this.player, false);
/*    */     
/* 84 */     if (((Boolean)headerUpdate[0]).booleanValue() || ((Boolean)footerUpdate[0]).booleanValue())
/* 85 */       this.player.getNetworkManager().sendTablist(JavaUtils.getArgsToString((ArrayList)headerUpdate[1], "\n"), JavaUtils.getArgsToString((ArrayList)footerUpdate[1], "\n")); 
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\clientadapter\board\tablist\CustomTablist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */