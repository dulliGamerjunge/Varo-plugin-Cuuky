/*    */ package de.cuuky.cfw.clientadapter.board;
/*    */ 
/*    */ import de.cuuky.cfw.clientadapter.board.nametag.CustomNametag;
/*    */ import de.cuuky.cfw.clientadapter.board.scoreboard.CustomScoreboard;
/*    */ import de.cuuky.cfw.clientadapter.board.tablist.CustomTablist;
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ 
/*    */ public enum CustomBoardType
/*    */ {
/* 10 */   NAMETAG((Class)CustomNametag.class),
/* 11 */   SCOREBOARD((Class)CustomScoreboard.class),
/* 12 */   TABLIST((Class)CustomTablist.class);
/*    */   
/*    */   private Class<? extends CustomBoard<? extends CustomPlayer>> clazz;
/*    */   
/*    */   <B extends CustomBoard<? extends CustomPlayer>> CustomBoardType(Class<B> clazz) {
/* 17 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */   public Class<? extends CustomBoard<? extends CustomPlayer>> getTypeClass() {
/* 21 */     return this.clazz;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\clientadapter\board\CustomBoardType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */