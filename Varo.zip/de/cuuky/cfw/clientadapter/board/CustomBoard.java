/*    */ package de.cuuky.cfw.clientadapter.board;
/*    */ 
/*    */ import de.cuuky.cfw.clientadapter.ClientAdapterManager;
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ 
/*    */ public abstract class CustomBoard<T extends CustomPlayer>
/*    */ {
/*    */   protected ClientAdapterManager<T> manager;
/*    */   protected T player;
/*    */   private CustomBoardType boardType;
/*    */   private boolean initalized;
/*    */   private boolean enabled;
/*    */   
/*    */   public CustomBoard(CustomBoardType boardType, T player) {
/* 15 */     this.player = player;
/* 16 */     this.boardType = boardType;
/* 17 */     this.enabled = true;
/*    */   }
/*    */   
/*    */   protected abstract void onEnable();
/*    */   
/*    */   protected abstract void onUpdate();
/*    */   
/*    */   public void remove() {
/* 25 */     this.manager.unregisterBoard(this);
/*    */   }
/*    */   
/*    */   public void setManager(ClientAdapterManager<T> manager) {
/* 29 */     this.manager = manager;
/*    */     
/* 31 */     if (this.manager.isBoardTypeEnabled(this.boardType) && this.enabled) {
/* 32 */       onEnable();
/* 33 */       this.initalized = true;
/*    */       
/* 35 */       update();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void update() {
/* 40 */     if (this.player.getPlayer() == null || !this.enabled) {
/*    */       return;
/*    */     }
/* 43 */     if (!this.manager.isBoardTypeEnabled(this.boardType))
/*    */       return; 
/* 45 */     if (!this.initalized) {
/* 46 */       onEnable();
/* 47 */       this.initalized = true;
/*    */     } 
/*    */     
/* 50 */     onUpdate();
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 54 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 58 */     this.enabled = enabled;
/*    */   }
/*    */   
/*    */   public CustomPlayer getPlayer() {
/* 62 */     return (CustomPlayer)this.player;
/*    */   }
/*    */   
/*    */   public CustomBoardType getBoardType() {
/* 66 */     return this.boardType;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\clientadapter\board\CustomBoard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */