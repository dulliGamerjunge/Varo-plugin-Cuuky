/*     */ package de.cuuky.cfw.clientadapter.board.scoreboard;
/*     */ 
/*     */ import de.cuuky.cfw.clientadapter.board.CustomBoard;
/*     */ import de.cuuky.cfw.clientadapter.board.CustomBoardType;
/*     */ import de.cuuky.cfw.player.CustomPlayer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.scoreboard.DisplaySlot;
/*     */ import org.bukkit.scoreboard.Objective;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ 
/*     */ public final class CustomScoreboard<T extends CustomPlayer>
/*     */   extends CustomBoard<T>
/*     */ {
/*     */   private List<String> replaces;
/*     */   private String title;
/*     */   
/*     */   public CustomScoreboard(T player) {
/*  23 */     super(CustomBoardType.SCOREBOARD, (CustomPlayer)player);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onEnable() {
/*  28 */     this.replaces = new ArrayList<>();
/*     */   }
/*     */   
/*     */   private String prepareScoreboardStatement(int index, String line) {
/*  32 */     Scoreboard board = this.player.getPlayer().getScoreboard();
/*  33 */     String name = getAsTeam(index);
/*     */     
/*  35 */     int firstEndIndex = 16;
/*  36 */     String line16Char = line.substring(0, (line.length() > firstEndIndex) ? firstEndIndex : line.length());
/*  37 */     if (line.length() > firstEndIndex) {
/*  38 */       String lastColor = "";
/*     */       
/*  40 */       if (line16Char.endsWith("§")) {
/*  41 */         lastColor = ChatColor.getLastColors("§" + line.charAt(firstEndIndex));
/*     */         
/*  43 */         if (!lastColor.isEmpty()) {
/*  44 */           line = String.valueOf(line.substring(0, firstEndIndex - 1)) + line.substring(firstEndIndex + 1);
/*  45 */           firstEndIndex = 15;
/*     */         } 
/*     */       } 
/*     */       
/*  49 */       if (lastColor.isEmpty()) {
/*  50 */         lastColor = ChatColor.getLastColors(line16Char);
/*     */       }
/*  52 */       name = String.valueOf(name) + (!lastColor.isEmpty() ? lastColor : "§f");
/*     */     } 
/*     */     
/*  55 */     Team team = board.getTeam("team-" + name);
/*  56 */     if (team == null) {
/*  57 */       team = board.registerNewTeam("team-" + name);
/*     */     }
/*  59 */     team.setPrefix(line.substring(0, (line.length() < firstEndIndex) ? line.length() : firstEndIndex));
/*     */     
/*  61 */     int suffixLength = (line.length() > firstEndIndex + 16) ? (firstEndIndex + 16) : line.length();
/*  62 */     team.setSuffix((line.length() > firstEndIndex) ? line.substring(firstEndIndex, suffixLength) : "");
/*  63 */     team.addPlayer(new FakeOfflinePlayer(name));
/*     */     
/*  65 */     return name;
/*     */   }
/*     */   
/*     */   private String getAsTeam(int index) {
/*  69 */     return ChatColor.values()[index].toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void onUpdate() {
/*  74 */     ArrayList<String> scoreboardLines = this.player.getUpdateHandler().getScoreboardEntries();
/*  75 */     if (scoreboardLines == null) {
/*  76 */       scoreboardLines = new ArrayList<>();
/*     */     }
/*  78 */     Collections.reverse(scoreboardLines);
/*     */     
/*  80 */     Scoreboard board = this.player.getPlayer().getScoreboard();
/*  81 */     Objective objective = board.getObjective(DisplaySlot.SIDEBAR);
/*     */     
/*  83 */     if (objective == null || this.title == null || !this.title.equals(objective.getDisplayName())) {
/*  84 */       sendScoreBoard();
/*     */       
/*     */       return;
/*     */     } 
/*  88 */     if (board.getEntries().size() > scoreboardLines.size()) {
/*  89 */       for (Team team : board.getTeams()) {
/*  90 */         if (team.getName().startsWith("team-"))
/*  91 */           team.unregister(); 
/*     */       } 
/*  93 */       for (String s : board.getEntries()) {
/*  94 */         board.resetScores(s);
/*     */       }
/*  96 */       this.replaces = new ArrayList<>();
/*     */     } 
/*     */     
/*  99 */     for (int index = 0; index < scoreboardLines.size(); index++) {
/* 100 */       String line = scoreboardLines.get(index);
/*     */       
/* 102 */       if (this.replaces.size() < scoreboardLines.size()) {
/* 103 */         objective.getScore(prepareScoreboardStatement(index, line)).setScore(index + 1);
/* 104 */         this.replaces.add(line);
/* 105 */       } else if (!((String)this.replaces.get(index)).equals(line)) {
/* 106 */         String sbs = prepareScoreboardStatement(index, line);
/* 107 */         board.resetScores(sbs);
/* 108 */         objective.getScore(sbs).setScore(index + 1);
/* 109 */         this.replaces.set(index, line);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sendScoreBoard() {
/* 115 */     Scoreboard sb = this.manager.getOwnerInstance().getServer().getScoreboardManager().getNewScoreboard();
/* 116 */     Objective obj = sb.registerNewObjective("CFW", "dummy");
/* 117 */     this.title = this.player.getUpdateHandler().getScoreboardTitle();
/* 118 */     if (this.title == null) {
/* 119 */       this.title = "";
/*     */     }
/* 121 */     if (this.title.length() >= 32) {
/* 122 */       this.title = this.title.substring(0, 32);
/*     */     }
/* 124 */     obj.setDisplayName(this.title);
/* 125 */     obj.setDisplaySlot(DisplaySlot.SIDEBAR);
/* 126 */     this.player.getPlayer().setScoreboard(sb);
/*     */     
/* 128 */     this.replaces = new ArrayList<>();
/* 129 */     update();
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\clientadapter\board\scoreboard\CustomScoreboard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */