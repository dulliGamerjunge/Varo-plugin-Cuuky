/*    */ package de.cuuky.cfw.clientadapter;
/*    */ 
/*    */ import de.cuuky.cfw.clientadapter.board.CustomBoard;
/*    */ import de.cuuky.cfw.clientadapter.board.CustomBoardType;
/*    */ import de.cuuky.cfw.manager.FrameworkManager;
/*    */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.scheduler.BukkitRunnable;
/*    */ import org.bukkit.scheduler.BukkitTask;
/*    */ 
/*    */ public class ClientAdapterManager<T extends CustomPlayer>
/*    */   extends FrameworkManager
/*    */ {
/*    */   private List<CustomBoard<T>> boards;
/*    */   private Map<CustomBoardType, Boolean> boardTypesEnabled;
/*    */   
/*    */   public ClientAdapterManager(JavaPlugin instance) {
/* 24 */     super(FrameworkManagerType.CLIENT_ADAPTER, instance);
/*    */     
/* 26 */     this.boards = new ArrayList<>();
/* 27 */     this.boardTypesEnabled = new HashMap<>(); byte b; int i;
/*    */     CustomBoardType[] arrayOfCustomBoardType;
/* 29 */     for (i = (arrayOfCustomBoardType = CustomBoardType.values()).length, b = 0; b < i; ) { CustomBoardType type = arrayOfCustomBoardType[b];
/* 30 */       this.boardTypesEnabled.put(type, Boolean.valueOf(false));
/*    */       b++; }
/*    */   
/*    */   }
/* 34 */   public BukkitTask addUpdateTask(long delay, long period, CustomBoardType... board) { return (new BukkitRunnable()
/*    */       {
/*    */         public void run()
/*    */         {
/* 38 */           ClientAdapterManager.this.updateBoards(board);
/*    */         }
/* 40 */       }).runTaskTimerAsynchronously((Plugin)this.ownerInstance, delay, period); } public void updateBoards(CustomBoardType... bType) {
/*    */     byte b;
/*    */     int i;
/*    */     CustomBoardType[] arrayOfCustomBoardType;
/* 44 */     for (i = (arrayOfCustomBoardType = bType).length, b = 0; b < i; ) { CustomBoardType type = arrayOfCustomBoardType[b];
/* 45 */       this.boards.stream().filter(board -> (board.getBoardType() == paramCustomBoardType)).forEach(board -> board.update());
/*    */       b++; }
/*    */   
/*    */   }
/* 49 */   public void updateBoards() { this.boardTypesEnabled.keySet().forEach(type -> updateBoards(new CustomBoardType[] { type })); } public void setBoardTypeEnabled(boolean enabled, CustomBoardType... board) {
/*    */     byte b;
/*    */     int i;
/*    */     CustomBoardType[] arrayOfCustomBoardType;
/* 53 */     for (i = (arrayOfCustomBoardType = board).length, b = 0; b < i; ) { CustomBoardType type = arrayOfCustomBoardType[b];
/* 54 */       this.boardTypesEnabled.put(type, Boolean.valueOf(enabled));
/*    */       b++; }
/*    */   
/*    */   } @Deprecated
/*    */   public void setBoardTypeEnabled(CustomBoardType type, boolean enabled) {
/* 59 */     this.boardTypesEnabled.put(type, Boolean.valueOf(enabled));
/*    */   }
/*    */   
/*    */   public boolean isBoardTypeEnabled(CustomBoardType type) {
/* 63 */     return ((Boolean)this.boardTypesEnabled.get(type)).booleanValue();
/*    */   }
/*    */   
/*    */   public <B extends CustomBoard<T>> B registerBoard(B board) {
/* 67 */     board.setManager(this);
/* 68 */     this.boards.add((CustomBoard<T>)board);
/* 69 */     return board;
/*    */   }
/*    */   
/*    */   public <B extends CustomBoard<T>> boolean unregisterBoard(B board) {
/* 73 */     return this.boards.remove(board);
/*    */   }
/*    */   
/*    */   public ArrayList<CustomBoard<T>> getBoards(CustomBoardType type) {
/* 77 */     ArrayList<CustomBoard<T>> rBoards = new ArrayList<>();
/* 78 */     for (CustomBoard<T> board : this.boards) {
/* 79 */       if (board.getBoardType() == type)
/* 80 */         rBoards.add(board); 
/*    */     } 
/* 82 */     return rBoards;
/*    */   }
/*    */   
/*    */   public <B extends CustomBoard<T>> ArrayList<B> getBoards(Class<B> boardClass) {
/* 86 */     ArrayList<B> rBoards = new ArrayList<>();
/* 87 */     for (CustomBoard<T> board : this.boards) {
/* 88 */       if (boardClass.isAssignableFrom(board.getClass()))
/* 89 */         rBoards.add((B)board); 
/*    */     } 
/* 91 */     return rBoards;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\clientadapter\ClientAdapterManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */