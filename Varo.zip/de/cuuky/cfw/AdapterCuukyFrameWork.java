/*    */ package de.cuuky.cfw;
/*    */ 
/*    */ import de.cuuky.cfw.clientadapter.ClientAdapterManager;
/*    */ import de.cuuky.cfw.manager.FrameworkManager;
/*    */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*    */ import de.cuuky.cfw.player.CustomPlayer;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class AdapterCuukyFrameWork<T extends CustomPlayer>
/*    */   extends CuukyFrameWork
/*    */ {
/*    */   public AdapterCuukyFrameWork(JavaPlugin pluginInstance) {
/* 13 */     super(pluginInstance);
/*    */   }
/*    */   
/*    */   public AdapterCuukyFrameWork(JavaPlugin pluginInstance, FrameworkManager... manager) {
/* 17 */     super(pluginInstance, manager);
/*    */   }
/*    */ 
/*    */   
/*    */   public ClientAdapterManager<T> getClientAdapterManager() {
/* 22 */     return (ClientAdapterManager<T>)loadManager(FrameworkManagerType.CLIENT_ADAPTER);
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\AdapterCuukyFrameWork.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */