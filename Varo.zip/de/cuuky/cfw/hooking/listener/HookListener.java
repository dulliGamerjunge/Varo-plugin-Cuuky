/*     */ package de.cuuky.cfw.hooking.listener;
/*     */ 
/*     */ import de.cuuky.cfw.hooking.HookManager;
/*     */ import de.cuuky.cfw.hooking.hooks.HookEntityType;
/*     */ import de.cuuky.cfw.hooking.hooks.chat.ChatHook;
/*     */ import de.cuuky.cfw.hooking.hooks.item.ItemHook;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ import org.bukkit.event.player.PlayerChatEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ 
/*     */ public class HookListener
/*     */   implements Listener
/*     */ {
/*     */   private HookManager manager;
/*     */   
/*     */   public HookListener(HookManager manager) {
/*  26 */     this.manager = manager;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/*  31 */     if (event.getItem() == null) {
/*     */       return;
/*     */     }
/*  34 */     ItemHook hook = this.manager.getItemHook(event.getItem(), event.getPlayer());
/*  35 */     if (hook == null) {
/*     */       return;
/*     */     }
/*  38 */     hook.getHookListener().onInteract(event);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
/*  43 */     if (event.getPlayer().getItemInHand() == null || event.getRightClicked() == null) {
/*     */       return;
/*     */     }
/*  46 */     ItemHook hook = this.manager.getItemHook(event.getPlayer().getItemInHand(), event.getPlayer());
/*  47 */     if (hook == null) {
/*     */       return;
/*     */     }
/*  50 */     hook.getHookListener().onInteractEntity(event);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDamageEntity(EntityDamageByEntityEvent event) {
/*  55 */     if (!(event.getEntity() instanceof Player) || !(event.getDamager() instanceof Player) || ((Player)event.getDamager()).getItemInHand() == null) {
/*     */       return;
/*     */     }
/*  58 */     Player damager = (Player)event.getDamager();
/*  59 */     ItemHook hook = this.manager.getItemHook(damager.getItemInHand(), damager);
/*  60 */     if (hook == null) {
/*     */       return;
/*     */     }
/*  63 */     hook.getHookListener().onEntityHit(event);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onItemMove(InventoryClickEvent event) {
/*  68 */     ItemHook hook = this.manager.getItemHook(event.getCurrentItem(), (Player)event.getWhoClicked());
/*  69 */     if (hook != null && !hook.isDragable())
/*  70 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onItemDrop(PlayerDropItemEvent event) {
/*  75 */     ItemHook hook = this.manager.getItemHook(event.getItemDrop().getItemStack(), event.getPlayer());
/*  76 */     if (hook != null && !hook.isDropable())
/*  77 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onItemPick(PlayerPickupItemEvent event) {
/*  82 */     ItemHook hook = this.manager.getItemHook(event.getItem().getItemStack(), event.getPlayer());
/*  83 */     if (hook != null && !hook.isDropable())
/*  84 */       event.setCancelled(true); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onASyncChat(AsyncPlayerChatEvent event) {
/*  89 */     ChatHook hook = (ChatHook)this.manager.getHook(HookEntityType.CHAT, event.getPlayer());
/*  90 */     if (hook == null) {
/*     */       return;
/*     */     }
/*  93 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onASyncChatLow(AsyncPlayerChatEvent event) {
/*  98 */     ChatHook hook = (ChatHook)this.manager.getHook(HookEntityType.CHAT, event.getPlayer());
/*  99 */     if (hook == null) {
/*     */       return;
/*     */     }
/* 102 */     hook.run(event);
/* 103 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGHEST)
/*     */   public void onSyncChat(PlayerChatEvent event) {
/* 108 */     ChatHook hook = (ChatHook)this.manager.getHook(HookEntityType.CHAT, event.getPlayer());
/* 109 */     if (hook == null) {
/*     */       return;
/*     */     }
/* 112 */     event.setCancelled(true);
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onSyncChatLow(PlayerChatEvent event) {
/* 117 */     ChatHook hook = (ChatHook)this.manager.getHook(HookEntityType.CHAT, event.getPlayer());
/* 118 */     if (hook == null) {
/*     */       return;
/*     */     }
/* 121 */     hook.run(event);
/* 122 */     event.setCancelled(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\hooking\listener\HookListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */