/*    */ package de.cuuky.cfw.hooking;
/*    */ 
/*    */ import de.cuuky.cfw.hooking.hooks.HookEntity;
/*    */ import de.cuuky.cfw.hooking.hooks.HookEntityType;
/*    */ import de.cuuky.cfw.hooking.hooks.item.ItemHook;
/*    */ import de.cuuky.cfw.hooking.listener.HookListener;
/*    */ import de.cuuky.cfw.manager.FrameworkManager;
/*    */ import de.cuuky.cfw.manager.FrameworkManagerType;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class HookManager
/*    */   extends FrameworkManager {
/*    */   private List<HookEntity> hooks;
/*    */   
/*    */   public HookManager(JavaPlugin instance) {
/* 22 */     super(FrameworkManagerType.HOOKING, instance);
/*    */     
/* 24 */     this.hooks = new ArrayList<>();
/* 25 */     this.ownerInstance.getServer().getPluginManager().registerEvents((Listener)new HookListener(this), (Plugin)this.ownerInstance);
/*    */   }
/*    */   
/*    */   public <B extends HookEntity> B registerHook(B hook) {
/* 29 */     hook.setManager(this);
/* 30 */     this.hooks.add((HookEntity)hook);
/* 31 */     return hook;
/*    */   }
/*    */   
/*    */   public boolean unregisterHook(HookEntity hook) {
/* 35 */     return this.hooks.remove(hook);
/*    */   }
/*    */   
/*    */   public void clearHooks() {
/* 39 */     for (int i = this.hooks.size() - 1; i > -1; i--)
/* 40 */       ((HookEntity)this.hooks.get(i)).unregister(); 
/*    */   }
/*    */   
/*    */   public void clearHooks(HookEntityType type) {
/* 44 */     for (int i = this.hooks.size() - 1; i > -1; i--) {
/* 45 */       HookEntity ent = this.hooks.get(i);
/* 46 */       if (ent.getType() == type)
/*    */       {
/*    */         
/* 49 */         ((HookEntity)this.hooks.get(i)).unregister(); } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public List<HookEntity> getHooks(HookEntityType type) {
/* 54 */     return getHooks(type.getTypeClass());
/*    */   }
/*    */   
/*    */   public <B extends HookEntity> List<B> getHooks(Class<B> clazz) {
/* 58 */     ArrayList<B> rHooks = new ArrayList<>();
/* 59 */     for (HookEntity ent : this.hooks) {
/* 60 */       if (ent.getType().getTypeClass().equals(clazz))
/* 61 */         rHooks.add((B)ent); 
/*    */     } 
/* 63 */     return rHooks;
/*    */   }
/*    */   
/*    */   public HookEntity getHook(HookEntityType type, Player player) {
/* 67 */     return getHook(type.getTypeClass(), player);
/*    */   }
/*    */   
/*    */   public <B extends HookEntity> B getHook(Class<B> clazz, Player player) {
/* 71 */     for (HookEntity hookEntity : getHooks(clazz)) {
/* 72 */       if (hookEntity.getPlayer().equals(player))
/* 73 */         return (B)hookEntity; 
/*    */     } 
/* 75 */     return null;
/*    */   }
/*    */   
/*    */   public ItemHook getItemHook(ItemStack stack, Player player) {
/* 79 */     for (HookEntity ent : this.hooks) {
/* 80 */       if (ent.getType() == HookEntityType.ITEM && ent.getPlayer().equals(player) && ((ItemHook)ent).getItemStack().equals(stack))
/* 81 */         return (ItemHook)ent; 
/*    */     } 
/* 83 */     return null;
/*    */   }
/*    */   
/*    */   public List<HookEntity> getHooks() {
/* 87 */     return this.hooks;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\hooking\HookManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */