/*    */ package de.cuuky.cfw.hooking.hooks.item;
/*    */ 
/*    */ import de.cuuky.cfw.hooking.HookManager;
/*    */ import de.cuuky.cfw.hooking.hooks.HookEntity;
/*    */ import de.cuuky.cfw.hooking.hooks.HookEntityType;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ItemHook
/*    */   extends HookEntity {
/*    */   private ItemHookHandler hookListener;
/*    */   private boolean dropable;
/*    */   private boolean dragable;
/*    */   private ItemStack stack;
/*    */   
/*    */   public ItemHook(Player player, ItemStack stack, int slot, ItemHookHandler listener) {
/* 17 */     super(HookEntityType.ITEM, player);
/*    */     
/* 19 */     this.hookListener = listener;
/* 20 */     this.stack = stack;
/* 21 */     this.dropable = false;
/* 22 */     this.dragable = false;
/*    */     
/* 24 */     player.getInventory().setItem(slot, stack);
/*    */     
/* 26 */     player.updateInventory();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setManager(HookManager manager) {
/* 31 */     if (manager.getItemHook(this.stack, this.player) != null) {
/* 32 */       manager.getItemHook(this.stack, this.player).unregister();
/*    */     }
/* 34 */     super.setManager(manager);
/*    */   }
/*    */   
/*    */   public void setDropable(boolean dropable) {
/* 38 */     this.dropable = dropable;
/*    */   }
/*    */   
/*    */   public boolean isDropable() {
/* 42 */     return this.dropable;
/*    */   }
/*    */   
/*    */   public void setDragable(boolean dragable) {
/* 46 */     this.dragable = dragable;
/*    */   }
/*    */   
/*    */   public boolean isDragable() {
/* 50 */     return this.dragable;
/*    */   }
/*    */   
/*    */   public ItemStack getItemStack() {
/* 54 */     return this.stack;
/*    */   }
/*    */   
/*    */   public ItemHookHandler getHookListener() {
/* 58 */     return this.hookListener;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\hooking\hooks\item\ItemHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */