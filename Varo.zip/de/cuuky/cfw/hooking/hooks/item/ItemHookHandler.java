package de.cuuky.cfw.hooking.hooks.item;

import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public interface ItemHookHandler {
  void onEntityHit(EntityDamageByEntityEvent paramEntityDamageByEntityEvent);
  
  void onInteract(PlayerInteractEvent paramPlayerInteractEvent);
  
  void onInteractEntity(PlayerInteractEntityEvent paramPlayerInteractEntityEvent);
}


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\hooking\hooks\item\ItemHookHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */