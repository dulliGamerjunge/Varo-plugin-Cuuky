/*    */ package de.cuuky.cfw.hooking.hooks;
/*    */ 
/*    */ import de.cuuky.cfw.hooking.hooks.chat.ChatHook;
/*    */ import de.cuuky.cfw.hooking.hooks.item.ItemHook;
/*    */ 
/*    */ public enum HookEntityType
/*    */ {
/*  8 */   CHAT((Class)ChatHook.class),
/*  9 */   ITEM((Class)ItemHook.class);
/*    */   
/*    */   private Class<? extends HookEntity> clazz;
/*    */   
/*    */   <B extends HookEntity> HookEntityType(Class<B> clazz) {
/* 14 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */   public Class<? extends HookEntity> getTypeClass() {
/* 18 */     return this.clazz;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\hooking\hooks\HookEntityType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */