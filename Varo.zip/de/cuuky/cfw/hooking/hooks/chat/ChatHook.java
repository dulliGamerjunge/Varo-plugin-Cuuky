/*    */ package de.cuuky.cfw.hooking.hooks.chat;
/*    */ 
/*    */ import de.cuuky.cfw.hooking.HookManager;
/*    */ import de.cuuky.cfw.hooking.hooks.HookEntity;
/*    */ import de.cuuky.cfw.hooking.hooks.HookEntityType;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*    */ import org.bukkit.event.player.PlayerChatEvent;
/*    */ 
/*    */ public class ChatHook
/*    */   extends HookEntity
/*    */ {
/*    */   private ChatHookHandler listener;
/*    */   
/*    */   public ChatHook(Player player, String message, ChatHookHandler chatHookListener) {
/* 16 */     super(HookEntityType.CHAT, player);
/*    */     
/* 18 */     this.listener = chatHookListener;
/*    */     
/* 20 */     player.sendMessage(message);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setManager(HookManager manager) {
/* 25 */     if (manager.getHook(HookEntityType.CHAT, this.player) != null) {
/* 26 */       manager.getHook(HookEntityType.CHAT, this.player).unregister();
/*    */     }
/* 28 */     super.setManager(manager);
/*    */   }
/*    */   
/*    */   public boolean run(AsyncPlayerChatEvent event) {
/* 32 */     boolean unregister = this.listener.onChat(event);
/*    */     
/* 34 */     if (unregister) {
/* 35 */       unregister();
/*    */     }
/* 37 */     return unregister;
/*    */   }
/*    */   
/*    */   public boolean run(PlayerChatEvent event) {
/* 41 */     boolean unregister = this.listener.onChat(event);
/*    */     
/* 43 */     if (unregister) {
/* 44 */       unregister();
/*    */     }
/* 46 */     return unregister;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\hooking\hooks\chat\ChatHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */