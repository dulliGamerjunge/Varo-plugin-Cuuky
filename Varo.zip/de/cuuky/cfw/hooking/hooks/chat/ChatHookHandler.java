/*    */ package de.cuuky.cfw.hooking.hooks.chat;
/*    */ 
/*    */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*    */ import org.bukkit.event.player.PlayerChatEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ChatHookHandler
/*    */ {
/*    */   default boolean onChat(AsyncPlayerChatEvent event) {
/* 12 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean onChat(PlayerChatEvent event) {
/* 19 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\hooking\hooks\chat\ChatHookHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */