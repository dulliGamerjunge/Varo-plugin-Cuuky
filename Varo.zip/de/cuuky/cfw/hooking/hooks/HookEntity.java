/*    */ package de.cuuky.cfw.hooking.hooks;
/*    */ 
/*    */ import de.cuuky.cfw.hooking.HookManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public abstract class HookEntity
/*    */ {
/*    */   protected HookManager manager;
/*    */   protected HookEntityType type;
/*    */   protected Player player;
/*    */   
/*    */   public HookEntity(HookEntityType type, Player player) {
/* 14 */     this.type = type;
/* 15 */     this.player = player;
/*    */   }
/*    */   
/*    */   public void setManager(HookManager manager) {
/* 19 */     this.manager = manager;
/*    */   }
/*    */   
/*    */   public void unregister() {
/* 23 */     this.manager.unregisterHook(this);
/*    */   }
/*    */   
/*    */   public HookEntityType getType() {
/* 27 */     return this.type;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 31 */     return this.player;
/*    */   }
/*    */ }


/* Location:              C:\Users\dulli\Downloads\Varo v4.5.3.jar!\de\cuuky\cfw\hooking\hooks\HookEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */